-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 26, 2022 at 06:01 AM
-- Server version: 5.7.36-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digitalinovation_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admindetail`
--

CREATE TABLE `admindetail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twitter_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insta_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admindetail`
--

INSERT INTO `admindetail` (`id`, `name`, `email`, `mobileno`, `address`, `twitter_id`, `insta_id`, `google_id`, `fb_id`, `created_at`, `updated_at`) VALUES
(1, 'Digital Innovation', 'info@digitalinovation.com', '+91-9558561212\r\n+91-8000257798', 'Shop No. 19, Shree Vinayak Homes Apartment,\r\nOpp. I.T.I Bilimora\r\n396325', NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `token`, `created_at`, `updated_at`) VALUES
(1, 'DigitalInnovation', 'info@digitalinovation.com', '$2y$10$oFmrgVIQ4nf86u1nz4Ww8...Mo2pqwUNNLl6ZVvOKbisEUNnM/Pyy', '5553', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `mobileno`, `subject`, `description`, `created_at`, `updated_at`) VALUES
(3, 'jinalpatel', 'jp@gmail.com', '1234567890', 'test contact', 'test message', NULL, NULL),
(5, 'fenipatel', 'fenipatel6988@gmail.com', '769887904', 'test', 'test', NULL, NULL),
(6, 'bhogi tandel', 'bhogi11188@gmail.com', '8849039110', 'Testing job vaccancy', 'Job', NULL, NULL),
(7, 'Maddison Fikes', 'hregina.mugue@fwhyhs.com', '062 689 21 40', 'maddison.fikes98@googlemail.com', 'Give your new site a boost, submit your site now to our free directory and start getting more clients https://1mdr.short.gy/submityoursite', NULL, NULL),
(8, 'sonu jaiswal', 'sonujaiswal347@gmail.com', '7984191631', 'Job vacancy', 'Hello there, i am working as a freelancar, i want full time job in php \r\nIf vacancy available please inform me. \r\nThank you...', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `emp_type`
--

CREATE TABLE `emp_type` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_type`
--

INSERT INTO `emp_type` (`id`, `type`) VALUES
(1, 'Owner'),
(2, 'Employee');

-- --------------------------------------------------------

--
-- Table structure for table `event_image`
--

CREATE TABLE `event_image` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `event_type` int(11) DEFAULT NULL,
  `event_subtype` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `event_type`
--

CREATE TABLE `event_type` (
  `id` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `sub_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_type`
--

INSERT INTO `event_type` (`id`, `type`, `sub_type`) VALUES
(1, 'All', 'image'),
(2, 'Anniversary celebration', 'anniversary'),
(3, 'Diwali celebration', 'diwali'),
(4, 'Birthday celebration', 'birthday');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_07_02_094919_create_admindetail_table', 1),
(5, '2021_07_02_110921_create_contact_us_table', 2),
(6, '2021_07_05_062525_create_team_table', 3),
(7, '2021_07_05_123445_create_portfolio_table', 4),
(8, '2021_07_05_124013_create_portfolio_image_table', 5),
(9, '2021_07_06_075321_create_portfolio_type_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `portfoliotype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `image`, `portfoliotype`, `name`, `url`, `description`, `type`, `created_at`, `updated_at`) VALUES
(16, '1646912810_homepage.png', 'Web Development', 'Soby Tour & Travels', 'https://sobytourandtravels.com/', NULL, 'web', NULL, NULL),
(17, '1646828431_homepage.png', 'Web Development', 'NM Balaji Interior Designs', 'http://nmbalajiinteriordesign.in', NULL, 'web', NULL, NULL),
(18, '1646716430_seasontoursandtravels- home.png', 'Web Development', 'Season Tours & Travels', 'http://www.seasontoursandtravels.com/', NULL, 'web', NULL, NULL),
(19, '1646827761_homepage.png', 'Web Development', 'R&R Transportation Inc.', 'https://rrtransportationinc.com/', NULL, 'web', NULL, NULL),
(20, '1646913274_Homepage.png', 'Web Development', 'Sevn3.ai', 'https://sevn3.ai/', NULL, 'web', NULL, NULL),
(22, '1646982606_homepage.png', 'Web Development', 'Photography', 'http://139.59.20.185/', NULL, 'web', NULL, NULL),
(23, '1646982879_homepage.png', 'Web Development', 'ARQX', 'http://arqx-capital.com/', NULL, 'web', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_image`
--

CREATE TABLE `portfolio_image` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `portfolio_image`
--

INSERT INTO `portfolio_image` (`id`, `name`, `p_id`, `created_at`, `updated_at`) VALUES
(14, '1626499595_04.jpg', '12', NULL, NULL),
(15, '1626499595_05.jpg', '12', NULL, NULL),
(16, '1626499595_22-1.jpg', '12', NULL, NULL),
(17, '1626499595_about-11.jpg', '12', NULL, NULL),
(58, '1640582871_season-12.png', '18', NULL, NULL),
(59, '1640582871_season-11.png', '18', NULL, NULL),
(60, '1640582871_season-10.png', '18', NULL, NULL),
(61, '1640582871_season-9.png', '18', NULL, NULL),
(62, '1640582871_season-8.png', '18', NULL, NULL),
(63, '1640582871_season-7.png', '18', NULL, NULL),
(64, '1640582871_season-5.png', '18', NULL, NULL),
(65, '1640582871_season-4.png', '18', NULL, NULL),
(66, '1640582871_season-3.png', '18', NULL, NULL),
(67, '1640582871_season-2.png', '18', NULL, NULL),
(68, '1640582871_season1.png', '18', NULL, NULL),
(69, '1640583986_nmbalaji-10.png', '17', NULL, NULL),
(70, '1640583986_nmbalaji-9.png', '17', NULL, NULL),
(71, '1640583986_nmbalaji-8.png', '17', NULL, NULL),
(72, '1640583986_nmbalaji-7.png', '17', NULL, NULL),
(73, '1640583986_nmbalaji-6.png', '17', NULL, NULL),
(74, '1640583986_nmbalaji-5.png', '17', NULL, NULL),
(75, '1640583986_nmbalaji-4.png', '17', NULL, NULL),
(76, '1640583986_nmbalaji-3.png', '17', NULL, NULL),
(77, '1640583986_nmbalaji-2.png', '17', NULL, NULL),
(78, '1640583986_nmbalaji-1.png', '17', NULL, NULL),
(79, '1640584383_soby-6.png', '16', NULL, NULL),
(80, '1640584383_soby-5.png', '16', NULL, NULL),
(81, '1640584383_soby-4.png', '16', NULL, NULL),
(82, '1640584383_soby-3.png', '16', NULL, NULL),
(83, '1640584383_soby-2.png', '16', NULL, NULL),
(84, '1640584383_soby_1.png', '16', NULL, NULL),
(85, '1640585301_rr-12.png', '19', NULL, NULL),
(86, '1640585301_rr-11.png', '19', NULL, NULL),
(87, '1640585301_rr-10.png', '19', NULL, NULL),
(88, '1640585301_rr-9.png', '19', NULL, NULL),
(89, '1640585301_rr-8.png', '19', NULL, NULL),
(90, '1640585301_rr-7.png', '19', NULL, NULL),
(91, '1640585301_rr-6.png', '19', NULL, NULL),
(92, '1640585301_rr-5.png', '19', NULL, NULL),
(93, '1640585301_rr-4.png', '19', NULL, NULL),
(94, '1640585301_rr-3.png', '19', NULL, NULL),
(95, '1640585301_rr-2.png', '19', NULL, NULL),
(96, '1640585301_rr-1.png', '19', NULL, NULL),
(97, '1640585543_sevn-16.png', '20', NULL, NULL),
(98, '1640585543_sevn-15.png', '20', NULL, NULL),
(99, '1640585543_sevn-14.png', '20', NULL, NULL),
(100, '1640585543_sevn-13.png', '20', NULL, NULL),
(101, '1640585543_sevn-12.png', '20', NULL, NULL),
(102, '1640585543_sevn-11.png', '20', NULL, NULL),
(103, '1640585543_sevn-10.png', '20', NULL, NULL),
(104, '1640585543_sevn-9.png', '20', NULL, NULL),
(106, '1640585543_sevn-7.png', '20', NULL, NULL),
(107, '1640585543_sevn-6.png', '20', NULL, NULL),
(108, '1640585543_sevn-5.png', '20', NULL, NULL),
(109, '1640585543_sevn-4.png', '20', NULL, NULL),
(110, '1640585543_sevn-3.png', '20', NULL, NULL),
(111, '1640585543_sevn-2.png', '20', NULL, NULL),
(113, '1646715564_seasontoursandtravels- home.png', '18', NULL, NULL),
(114, '1646827814_homepage.png', '19', NULL, NULL),
(117, '1646982606_homepage.png', '22', NULL, NULL),
(118, '1646982879_homepage.png', '23', NULL, NULL),
(119, '1647346151_7.png', '23', NULL, NULL),
(120, '1647346170_6.png', '23', NULL, NULL),
(121, '1647346226_5.png', '23', NULL, NULL),
(122, '1647346257_2.png', '23', NULL, NULL),
(123, '1647346257_3.png', '23', NULL, NULL),
(124, '1647346257_4.png', '23', NULL, NULL),
(125, '1647346335_Homepage.png', '23', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_type`
--

CREATE TABLE `portfolio_type` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `portfolio_type`
--

INSERT INTO `portfolio_type` (`id`, `name`, `sub_type`, `created_at`, `updated_at`) VALUES
(1, 'App Customization', 'app', NULL, NULL),
(2, 'IT Solutions', 'IT', NULL, NULL),
(3, 'Web Development', 'web', NULL, NULL),
(4, 'Photography', 'photo', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fblink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `name`, `image`, `type`, `occupation`, `fblink`, `instalink`, `created_at`, `updated_at`) VALUES
(14, 'Jinal Patel', '1647343055_img-1.png', 'Owner', 'CEO', NULL, NULL, NULL, NULL),
(15, 'Archan Patel', '1647343125_img-9.png', 'Owner', 'COO', NULL, NULL, NULL, NULL),
(16, 'Apexa Patel', '1647343157_img-8.png', 'Owner', 'CTO', NULL, NULL, NULL, NULL),
(17, 'Sandhya Patel', '1647344842_img-10.png', 'Employee', 'Sr. Web Designer', NULL, NULL, NULL, NULL),
(18, 'Dinkal Patel', '1647343482_img-7.png', 'Employee', 'Jr. Web Designer', NULL, NULL, NULL, NULL),
(19, 'Jinal Patel', '1647343648_img-6.png', 'Employee', 'Sr. PHP Developer', NULL, NULL, NULL, NULL),
(20, 'Dixa Patel', '1647343774_img-2.png', 'Employee', 'iOS Developer', NULL, NULL, NULL, NULL),
(21, 'Feni Patel', '1647343839_img-5.png', 'Employee', 'BDE', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`id`, `image`, `name`, `occupation`, `description`) VALUES
(2, '1626678428_22-1.jpg', 'Kristiana1', 'Web Designer1', 'rfrgtrgtrrfgtgttrtfwqedwdewfwe');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admindetail`
--
ALTER TABLE `admindetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_type`
--
ALTER TABLE `emp_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_image`
--
ALTER TABLE `event_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_type`
--
ALTER TABLE `event_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio_image`
--
ALTER TABLE `portfolio_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio_type`
--
ALTER TABLE `portfolio_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admindetail`
--
ALTER TABLE `admindetail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `emp_type`
--
ALTER TABLE `emp_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `portfolio_image`
--
ALTER TABLE `portfolio_image`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `portfolio_type`
--
ALTER TABLE `portfolio_type`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
