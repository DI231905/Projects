<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class userController extends Controller
{
     public function index(){


     

        $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
        $data['insta_id']=$admindetail[0]->insta_id;
        $data['fb_id']=$admindetail[0]->fb_id;
        $data['twitter_id']=$admindetail[0]->twitter_id; 
        $data['google_id']=$admindetail[0]->google_id;

         $portfolio=DB::table('portfolio')->orderBy('id', 'desc')->take(3)->get();
         $data['portfolio']=$portfolio;

           $main_array = array();

        foreach($portfolio as $key => $p){

            $id=$p->id;
          $portfolio_image=DB::table('portfolio_image')->where('p_id',$id)->orderBy('id', 'desc')->get();
           $main_array[$key]['id'] = $id;
           $main_array[$key]['images_details'] = $portfolio_image;


         }

         $data['portfolio_image']=$main_array;
 
 
     
      
        return view('welcome',$data);
    }



     public function About(){

        $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
         $data['insta_id']=$admindetail[0]->insta_id;
        $data['fb_id']=$admindetail[0]->fb_id;
        $data['twitter_id']=$admindetail[0]->twitter_id; 
        $data['google_id']=$admindetail[0]->google_id;


        return view('Aboutview',$data);
    }

    public function Service(){

        $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
        $data['insta_id']=$admindetail[0]->insta_id;
        $data['fb_id']=$admindetail[0]->fb_id;
        $data['twitter_id']=$admindetail[0]->twitter_id; 
        $data['google_id']=$admindetail[0]->google_id;

        return view('service',$data);
    }
    
     public function Training(){

        $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
         $data['insta_id']=$admindetail[0]->insta_id;
        $data['fb_id']=$admindetail[0]->fb_id;
        $data['twitter_id']=$admindetail[0]->twitter_id; 
        $data['google_id']=$admindetail[0]->google_id;

        return view('training',$data);
    }

      public function Team(){

       $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
         $data['insta_id']=$admindetail[0]->insta_id;
        $data['fb_id']=$admindetail[0]->fb_id;
        $data['twitter_id']=$admindetail[0]->twitter_id; 
        $data['google_id']=$admindetail[0]->google_id;

         $owner_team=DB::table('team')->where('type','Owner')->get();
         $data['owner_team']=$owner_team;


          $emp_team=DB::table('team')->where('type','Employee')->get();
         $data['emp_team']=$emp_team;


        return view('team',$data);
    }
     public function Contact(){

         $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
         $data['insta_id']=$admindetail[0]->insta_id;
        $data['fb_id']=$admindetail[0]->fb_id;
        $data['twitter_id']=$admindetail[0]->twitter_id; 
        $data['google_id']=$admindetail[0]->google_id;

        return view('contact',$data);
    }

     public function Portfolio(){

        $admindetail=DB::table('admindetail')->where('id',1)->get();
        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
         $data['insta_id']=$admindetail[0]->insta_id;
        $data['fb_id']=$admindetail[0]->fb_id;
        $data['twitter_id']=$admindetail[0]->twitter_id; 
        $data['google_id']=$admindetail[0]->google_id;

         $portfolio=DB::table('portfolio')->orderBy('id', 'desc')->get();
         $data['portfolio']=$portfolio;

         $main_array = array();

        foreach($portfolio as $key => $p){

            $id=$p->id;
          $portfolio_image=DB::table('portfolio_image')->where('p_id',$id)->orderBy('id', 'desc')->get();
           $main_array[$key]['id'] = $id;
           $main_array[$key]['images_details'] = $portfolio_image;


         }

         $data['portfolio_image']=$main_array;
 
 
     

        return view('portfolio',$data);
    }

     public function getgallery($id){

      return json_encode(DB::table('portfolio_image')->where('p_id',$id)->get()->toArray());
     }
 
     public function contactusfrom(Request $request){

        $request->validate([

            'name' => 'required',
            'email' => 'required|email', 
            'mobileno'=>'required',
            'subject' => 'required',  
            'description' => 'required',  


        ]);

            $name=$request->input('name'); 
            $email=$request->input('email');
            $mobileno=$request->input('mobileno');
            $subject=$request->input('subject');
            $description=$request->input('description');

            echo $name;
            echo $email;
            echo $mobileno;
            echo $subject;
            echo $description;

         DB::table('contact_us')->insert(['name'=>$name,'email'=>$email,'mobileno'=>$mobileno,'subject'=>$subject,'description'=>$description]);
          

       return redirect()->back()->with('error','your massage was submitted sucessfully !!!!' );


    }

    public function event(){


     $admindetail=DB::table('admindetail')->where('id',1)->get();
        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
        $data['insta_id']=$admindetail[0]->insta_id;
        $data['fb_id']=$admindetail[0]->fb_id;
        $data['twitter_id']=$admindetail[0]->twitter_id; 
        $data['google_id']=$admindetail[0]->google_id;

          $event_image=DB::table('event_image')->get();
          $data['event_image']=$event_image;

          $event_type=DB::table('event_type')->get();
          $data['event_type']=$event_type;


        return view('event',$data);
    }


}
