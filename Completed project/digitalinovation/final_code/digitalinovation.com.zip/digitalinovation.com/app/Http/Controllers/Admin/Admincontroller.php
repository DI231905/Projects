<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
//use App\Models\User;
use Carbon\carbon;
use DB;
use Hash;
use Auth;
use \Crypt;

use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class Admincontroller extends Controller{


   public function __construct(){

                $this->middleware('auth:admin');
        }

   public function home(){
 
     
         $admin=Auth::guard('admin')->user();
         $data['admin']=$admin;
         $data['site_url']= env('APP_URl');
         $data['metatitle']='home page';


         $admindetail=DB::table('admindetail')->get();
         $data['admindetail']=$admindetail;

         $contact_us=DB::table('contact_us')->get();
         $data['contact_us']=$contact_us;

         $team=DB::table('team')->get();
         $data['team']=$team;

         $portfolio=DB::table('portfolio')->get();
         $data['portfolio']=$portfolio;

         $portfolio_image=DB::table('portfolio_image')->get();
         $data['portfolio_image']=$portfolio_image;

         $testimonial=DB::table('testimonial')->get();
         $data['testimonial']=$testimonial;

         $event_image=DB::table('event_image')->get();
         $data['event_image']=$event_image;
    
         return view('admin.home',$data);
      
    } 

   public function changepassword(){
       
         return view('admin.changepassword');
    }

   public function updatepassword(Request $request,$id){

         $request->validate([
              'oldpassword' => 'required|string',
              'newpassword' => 'required|string|min:8',
           
           ]);

             $oldpassword=$request->input('oldpassword');
             $newpassword=$request->input('newpassword');

             $password=DB::table('admins')->where('id', $id)->get();

             $password1=$password[0]->password;

           if(Hash::check($oldpassword,$password1)){

               DB::table('admins')->where('id', $id)->update(['password'=>Hash::make($newpassword)]);

              return redirect('admin/home')->with('error','your password has been update sucessfully' );

             }else{

                return Redirect::back()->with('error','Your Old password is not correct!!!!');

            }
         }

         public function addprotfolio(){

        $portfolio_type=DB::table('portfolio_type')->get();
         $data['portfolio_type']=$portfolio_type;    

       return view('admin.addprotfolio',$data);

     }

    public function storeprotfolio(Request $request){

           $request->validate([

            
            'image' => 'required',
            'portfoliotype' =>'required',
            'name' => 'required|string',
         
            

        ]);

            $image=$request->file('image');
            $portfoliotype=$request->input('portfoliotype');
            $name=$request->input('name');
             $url=$request->input('url');
            $description=$request->input('description');

             $portfolio=DB::table('portfolio_type')->where('id',$portfoliotype)->get();

             $portfoliotype1=$portfolio[0]->name;
             $sub_type1=$portfolio[0]->sub_type;


             $imagename=' ';

            if ($image){
          
                $destinationPath='uploads';
                $imagename=time().'_'.$image->getClientOriginalName();

               $image->move($destinationPath,$imagename);
      
            }

         DB::table('portfolio')->insert(['name'=>$name, 'url'=>$url,'image'=>$imagename,'portfoliotype'=>$portfoliotype1,'type'=>$sub_type1,'description'=> $description]);

         $last_id = DB::table('portfolio')->max('id'); 

       

            $file=$request->file('file');
        $imagename=' ';
       
         foreach($file as $key =>$f) {

             $destinationPath='uploads';
            $imagename=time().'_'.$f->getClientOriginalName();
    
           $f->move($destinationPath,$imagename);

             DB::table('portfolio_image')->insert(['p_id'=>$last_id,'name'=>$imagename]);
             
         }

        
         return redirect('admin/home')->with('error',' insert Portfolio succcesfully!!!!'); 

        }

        public function deleteprotfolio($id){


            $portfolio= DB::table('portfolio')->where('id', $id)->get();

          if ($portfolio[0]->image!='') {

          
             unlink(public_path("/uploads/".$portfolio[0]->image));

            }

           DB::table('portfolio')->where('id', $id)->delete();



           $image= DB::table('portfolio_image')->where('p_id', $id)->get();
             
           foreach($image as $key =>$f){

             unlink(public_path("/uploads/".$f->name));
           
           }

            DB::table('portfolio_image')->where('p_id', $id)->delete();

           return redirect('admin/home')->with('error',' delete Portfolio  data succcesfully!!!!');

        }
        public function updateprotfolio($id){

        $portfolio_type=DB::table('portfolio_type')->get();
        $data['portfolio_type']=$portfolio_type;   

        $portfolio= DB::table('portfolio')->where('id', $id)->get();
      
        $data['id']=$portfolio[0]->id;
        $data['name']=$portfolio[0]->name;
        $data['image']=$portfolio[0]->image;
        $data['url']=$portfolio[0]->url;
        $data['portfoliotype']=$portfolio[0]->portfoliotype;
        $data['description']=$portfolio[0]->description;

        $portfolioname=$portfolio[0]->portfoliotype;
       
         $ptype=DB::table('portfolio_type')->where('name', $portfolioname)->get();
         $data['ptype_id']=$ptype[0]->id;

         $portfolio_image=DB::table('portfolio_image')->where('p_id', $id)->get();
         $data['portfolio_image']=$portfolio_image;

         return view('admin.updateportflio',$data);
        }


         public function imageDelete($id){

         $pimages=DB::table('portfolio_image')->where('id', $id)->get();

         $p_id= $pimages[0]->p_id;
       

        if ( $pimages[0]->name!='') {

        echo $pimages[0]->name;
       

            unlink(public_path("/uploads/".$pimages[0]->name));   

          }

         DB::table('portfolio_image')->where('id',$id)->delete();
      
           return redirect('admin/updateprotfolio/'.$p_id);

      }

      public function storeupdateprotfolio(Request $request, $id){

          $request->validate([

            'name' => 'required',
            'portfoliotype' => 'required',
            
        ]);
       

        $name=$request->input('name');
        $url=$request->input('url');
        $file = $request->file('image');
        $portfoliotype=$request->input('portfoliotype');
        $description=$request->input('description');

        $portfolio=DB::table('portfolio_type')->where('id',$portfoliotype)->get();

        $portfoliotype1=$portfolio[0]->name;
        $sub_type1=$portfolio[0]->sub_type;

       
                $imagename=' ';

        if($file){
         
            $destinationPath='uploads';
            $imagename=time().'_'.$file->getClientOriginalName();
    
            $file->move($destinationPath,$imagename);

            DB::table('portfolio')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink(public_path("/uploads/".$request->input('oldimage')));

          }

        }

       DB::table('portfolio')->where('id', $id)->update(['name'=>$name,'url'=>$url,'type'=>$sub_type1,'portfoliotype'=>$portfoliotype1,'description'=> $description]);

         $filename=$request->file('file');
        $imagename=' ';

         if($filename){

            foreach($filename as $key =>$f) {
    
                    $destinationPath='uploads';
                    $imagename=time().'_'.$f->getClientOriginalName();
             
                    $f->move($destinationPath,$imagename);
    
                DB::table('portfolio_image')->insert(['p_id'=>$id,'name'=>$imagename]);
         }
     }

  
       return redirect('admin/home')->with('error',' update portfolio detail sucessfully!!!!');
         
    
      }
  


     public function updateadmindetail($id){


       $admindetail=DB::table('admindetail')->where('id', $id)->get();

        $data['id']=$admindetail[0]->id;
         $data['email']=$admindetail[0]->email;
        $data['name']=$admindetail[0]->name;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      

         return view('admin.updateadmindetailview',$data);


       }

       public function storeadmindetail(Request $request,$id){


         $request->validate([

            'name' => 'required|string',
            'email' => 'required|email',
            'mobileno' => 'required',
            'address' => 'required',  

        ]);
       

        $name=$request->input('name');
        $email = $request->input('email');
        $mobileNo=$request->input('mobileno');
        $address=$request->input('address');

       DB::table('admindetail')->where('id',$id)->update(['name'=>$name ,'email'=>$email,'mobileno'=>$mobileNo,'address'=>$address]);

        return redirect('admin/home')->with('error',' update admin detail sucessfully!!!!');
         
    
          }


     public function deletecontactus($id){
  
       DB::table('contact_us')->where('id', $id)->delete();

       return redirect('admin/home');

    }
      public function teamview(){

         $emp_type=DB::table('emp_type')->get();
         $data['emp_type']=$emp_type;
  
      
       return view('admin.teamview',$data);

    }

    public function addteam(Request $request){


         $request->validate([

            'name' => 'required|string',
            'image' => 'required',
            'type' => 'required',
            'occupation' => 'required', 

        ]);
       

        $name=$request->input('name');
        $occupation=$request->input('occupation');
        $file=$request->file('image');
        $type1=$request->input('type');
        $fblink=$request->input('fblink');
        $instalink=$request->input('instalink');
        $imagename=' ';

         $type= DB::table('emp_type')->where('id', $type1)->get();
          $emp_type=$type[0]->type;

        if ($file) {
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();

         $file->move($destinationPath,$imagename);
      
        }
  

         DB::table('team')->insert(['name'=>$name,'image'=>$imagename,'type'=>$emp_type,'occupation'=>$occupation,'fblink'=>$fblink,'instalink'=>$instalink]);
       
          return redirect('admin/home')->with('error',' insert Team member data succcesfully!!!!');

          }

       public function teamdelete($id){


        $team= DB::table('team')->where('id', $id)->get();

         if ($team[0]->image!='') {

            unlink(public_path("/uploads/".$team[0]->image));

          }

        DB::table('team')->where('id', $id)->delete();

        return redirect('admin/home')->with('error',' delete Team member data succcesfully!!!!');

     
    } 

    public function teamupdateview($id){

         $emp_type=DB::table('emp_type')->get();
         $data['emp_type']=$emp_type;

       $team= DB::table('team')->where('id', $id)->get();
      
        $data['id']=$team[0]->id;
        $data['name']=$team[0]->name;
        $data['image']=$team[0]->image;
        $data['type']=$team[0]->type;
        $data['occupation']=$team[0]->occupation;
        $data['fblink']=$team[0]->fblink;
        $data['instalink']=$team[0]->instalink;

         

          $type1=$team[0]->type;

          $type= DB::table('emp_type')->where('type', $type1)->get();
          $data['type_id'] =$type[0]->id;
       
        return view('admin.updateteamview',$data);   

    }

       public function storeupdateteam(Request $request,$id){


   $request->validate([

            'name' => 'required',
            'occupation' => 'required', 
            'type' => 'required', 
           
        ]);
       
        $name=$request->input('name');
        $occupation=$request->input('occupation');
       $type1=$request->input('type');
        $fblink=$request->input('fblink');

        $instalink=$request->input('instalink');


         $type=DB::table('emp_type')->where('id', $type1)->get();
          $emp_type=$type[0]->type;


        $file=$request->file('image');
        $imagename=' ';

        if($file){
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('team')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink(public_path("/uploads/".$request->input('oldimage')));

             }

           }

          DB::table('team')->where('id', $id)->update(['name'=>$name ,'type'=>$emp_type,'occupation'=>$occupation,'fblink'=>$fblink,'instalink'=>$instalink]);

           return redirect('admin/home')->with('error',' update Team member data succcesfully!!!!');

     }
       public function addtestimonial(){
  
         return view(' admin.testimonial');

   }


    public function updatetestimonial($id){

       $testimonial = DB::table('testimonial')->where('id',$id)->get();  
        $data['id']= $testimonial[0]->id;
        $data['name']=$testimonial[0]->name;
        $data['occupation']=$testimonial[0]->occupation;
        $data['image']=$testimonial[0]->image;
        $data['description']=$testimonial[0]->description;
             
        return view('admin.updatetestimonial',$data);

       
       }

    public function storetestimonial(Request $request){


          $request->validate([

            'name' => 'required|string',
            'occupation' => 'required',
            'description' => 'required',
          

        ]);
       
  
        $name=$request->input('name');
        $occupation = $request->input('occupation');
        $description=$request->input('description');
        
 
         $file=$request->file('image');
        $imagename=' ';

    echo $name;
    echo $occupation;
    echo $description;

        if ($file) {
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
          echo $imagename;
          $file->move($destinationPath,$imagename);
      
        }
    
    DB::table('testimonial')->insert(['name'=>$name ,'occupation'=>$occupation,'image'=>$imagename,'description'=>$description]);
    
       return redirect('admin/home');
   }

    public function deletetestimonial($id){
  
       DB::table('testimonial')->where('id', $id)->delete();

       return redirect('admin/home');

   }
     public function storeupdatetestimonial(Request $request,$id){


         $request->validate([

            'name' => 'required|string',
            'occupation' => 'required',
            'description' => 'required',

        ]);
       

        $name=$request->input('name');
        $occupation = $request->input('occupation');
        $description=$request->input('description');

        $file=$request->file('image');
         $imagename=' ';

        if ($file) {
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('testimonial')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

            unlink(public_path("/uploads/".$request->input('oldimage')));

             }

           }
     
     
          DB::table('testimonial')->where('id',$id)->update(['name'=>$name ,'occupation'=>$occupation,'description'=>$description]);
    
         
         return redirect('admin/home');

       }

         public function addevent(){


            $event_type=DB::table('event_type')->get();

            $data['event_type']=$event_type;    

             return view('admin.addnewevent',$data);

          }

          public function storeevent(Request $request){

          $event_type=$request->input('event_type');

          $portfolio=DB::table('event_type')->where('id',$event_type)->get();

          $sub_type1=$portfolio[0]->sub_type;

        
          $file=$request->file('image');

          $imagename=' ';
       
          foreach($file as $key =>$f) {

            $destinationPath='uploads';
            $imagename=time().'_'.$f->getClientOriginalName();
    
             $f->move($destinationPath,$imagename);

             DB::table('event_image')->insert(['image'=>$imagename,'event_type'=>$event_type,'event_subtype'=>$sub_type1]);
             
         }
                
           return redirect('admin/home')->with('error',' store event data succcesfully!!!!');

           }

           public function delete_image($id){

             $event_image=DB::table('event_image')->where('id', $id)->get();

       
            if ($event_image[0]->image!=''){

               unlink(public_path("/uploads/".$event_image[0]->image));

               }

            DB::table('event_image')->where('id', $id)->delete();

            return response()->json([
            'success' => 'Record has been deleted successfully!'
            ]);


           }

       



    }



     
 


   

  




