

<?php $__env->startSection('content'); ?>
    <div class="fixed">
        <div class="co-bg">
            <div class="bg-img">
                <div class="heading" data-aos="fade-right" data-aos-duration="1000">
                    <h1>ABOUT US</h1>
                </div>
            </div>
            <div class="set-bg">
                <ul type="none">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li>|</li>
                    <li>About</li>
                </ul>
            </div>
        </div>
        <div class="co_about2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="about2 middle-11" data-aos="fade-right">
                            <div class="circle-4">
                                <img src="image/circle1.png">
                            </div>
                            <div class="circle-5">
                                <img src="image/image-2.jpg">
                            </div>
                            <div class="circle-6">
                                <img src="image/image-1.jpg">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="about2" data-aos="fade-left">
                            <div class="set-about2">
                                <h3 class="we">About Us</h3>
                                <h1>Our Values & Vision</h1>
                                <p>Digital Inovation Software Solution Pvt. Ltd. is a leading mobile app and web development company that strives to meet client’s needs and objectives with customized digital marketing solutions. We believe in solving real-world problems to deliver tangible and measurable results to our clients. Customer satisfaction, teamwork, and innovation are our core values, and we are passionate about connecting businesses with the end-users.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="co_service2">
            <div class="container">
                <div class="set-service2 row">
                    <div class="col-lg-8 service2" data-aos="fade-down-right">
                        <h3>OUR SERVICES</h3>
                        <h1>SEE WHAT WE DO BEST</h1>
                    </div>  
                    <div class="col-lg-4 link-3" data-aos="zoom-in-up">
                        <a href="#">learn more</a>
                    </div>
                </div>
                <div class="row co_box">
                    <div class="col-lg-3 col-md-6 col-12 fix-box" data-aos="flip-right" data-aos-easing="ease-out-cubic" data-aos-duration="1000" data-aos-delay="2000">
                        <div class="box">
                            <h5>&#x2192</h5>
                            <h3>ADVISORY SERVICES</h3>
                            <p>We work with clients to develop a robust strategy that fully supports their business goals.</p>
                            <i class="fa1 far fa-eye"></i>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12 fix-box" data-aos="flip-right" data-aos-easing="ease-out-cubic" data-aos-duration="1000" data-aos-delay="1500">
                        <div class="box">
                            <h5>&#x2192</h5>
                            <h3>DATA ANALYSIS</h3>
                            <p>We identify growth opportunities to translate better performance and higher ROI.s</p>
                            <i class="fa1 fas fa-lightbulb"></i>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12 fix-box" data-aos="flip-right" data-aos-easing="ease-out-cubic" data-aos-duration="1000" data-aos-delay="1000">
                        <div class="box">
                            <h5>&#x2192</h5>
                            <h3>DIGITAL SERVICES</h3>
                            <p>We craft solutions with next-gen delivery models such as DevOps, automation, and agile practices.</p>
                            <i class="fa1 far fa-sync-alt"></i>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12 fix-box" data-aos="flip-right" data-aos-easing="ease-out-cubic" data-aos-duration="1000" data-aos-delay="500">
                        <div class="box">
                            <h5>&#x2192</h5>
                            <h3>CONSULTING</h3>
                            <p>We discuss initiatives and focus on competitive advantages to build even a greater customer experience.</p>
                            <i class="fa1 fas fa-globe"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="co_middle-4">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-12 middle-4" data-aos="fade-down">
                        <img src="image/22-1.jpg">
                    </div>
                    <div class="col-lg-6 col-md-12 col-12 middle-4" data-aos="fade-up">
                        <div class="set-middle set-middle-4">
                            <h3 class="we">End-To-End Services</h3>
                            <h1>We Successfully Align Business Needs And Customer Demands.</h1>
                            <p>At Digital Inovation Software Solution Pvt. Ltd., we use the latest tools and technology to deliver revenue-generating solutions. With the delivery of valuable service offerings, we measure KPIs for successful business growth.</p>
                            <div class="main-test row">
                                <div class="col-lg-3 col-md-3 col-6">
                                    <div class="test-1">
                                        <i class="fab fa-wordpress"></i>
                                        <div><a href="#">Wordpress</a></div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-6">
                                    <div class="test-2">
                                        <i class="co fab fa-html5"></i>
                                        <div><a href="#">HTML5</a></div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-6">
                                    <div class="test-2">
                                        <i class="co fab fa-css3"></i>
                                        <div><a href="#">CSS</a></div>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-6">
                                    <div class="test-2">
                                        <i class="co fas fa-chart-line"></i>
                                        <div><a href="#">DATA</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="cover_last">
            <div class="container" data-aos="fade-right" data-aos-duration="500">
                <div class="last">
                    <h2>Testimonials</h2>
                    <div class="row">
                    <div class="testi">
                        <img src="image/quote.png">
                    </div>
                    <div class="testi-1">
                        <p>Working with Digital Inovation Software Solution Pvt. Ltd.  On our website has been a real treat. They took a mediocre website and transformed it completely that exceeded our expectations making it responsive, intuitive, and user-friendly. They fully care about your project from the start and help you every step of the way to bring your vision come true. It was a pleasure working with them. No doubt this has been the best experience for me, and we got along very well. I will continue to develop my products from Digital Inovation Software Solution Pvt. Ltd. also takes care of marketing strategy.</p>
                        <a href="#">Linda Green</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }
        
      var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });
    </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/digitalinovation.com/resources/views/Aboutview.blade.php ENDPATH**/ ?>