<!DOCTYPE html>
<html>
<head>
    <title>DIGITAL Innovation</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;1,100;1,200;1,300;1,400;1,500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/jquery.slick/1.5.9/slick.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
    <div class="main-head">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="logo">
                         <h1><a href="<?php echo e(url('/')); ?>"><img src="image/logo1.png"></a></h1>
                    </div>
                </div>
                <div class="col-lg-9 col-md-6 col-6">
                    <div class="menu">
                         <a href="<?php echo e(url('/')); ?>">Home</a>
                         <a href="<?php echo e(url('/About')); ?>">About</a>
                         <a href="<?php echo e(url('/Service')); ?>">Service</a>
                         <a href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>
                         <a href="<?php echo e(url('/Training')); ?>">Training</a>
                         <a href="<?php echo e(url('/Team')); ?>">Team</a>
                         <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
                    </div>
                    <div class="mobile-menu">
                        <div id="mySidepanel" class="sidepanel">
                            <div class="m_menu">
                                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times"></i></a>    
                               <a class="link" href="<?php echo e(url('/')); ?>">Home</a>  
                               <a class="link" href="<?php echo e(url('/About')); ?>">About</a> 
                               <a class="link" href="<?php echo e(url('/Service')); ?>">Service</a>   
                               <a class="link" href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>    
                               <a class="link" href="<?php echo e(url('/Training')); ?>">Training</a>
                               <a class="link" href="<?php echo e(url('/Team')); ?>">Team</a>
                               <a class="link" href="<?php echo e(url('/Contact')); ?>">Contact</a>
                            </div>
                        </div>
                        <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="fixed">
        <div class="cover_img">
            <div id="demo" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                    <li data-target="#demo" data-slide-to="1"></li>
                </ul>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="banner-img">
                            <img src="image/banner.jpg" alt="showcase-1">
                        </div>
                        <div class="fix_update">
                            <div class="update">
                                <h2>We Help Your Business Grow With Improved Digital Experience</h2>
                            </div>   
                            <div class="btn_">
                                 <a href="<?php echo e(url('/Training')); ?>" class="btn1">Training</a>
                                <a href="<?php echo e(url('/Contact')); ?>" class="btn2">Call for inquiry</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="banner-img">
                            <img src="image/banner-1.jpg" alt="onepress2_hero">
                        </div>
                        <div class="fix_update">
                            <div class="update">
                                <h2>Inspiring Possibilities With Digital Innovations</h2>
                            </div>   
                            <div class="btn_">
                                 <a href="<?php echo e(url('/Training')); ?>" class="btn1">Training</a>
                                <a href="<?php echo e(url('/Contact')); ?>" class="btn2">Call for inquiry</a>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#demo" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>
        <div class="first">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="set-post">
                            <h5 class="we">WHO WE ARE</h5>
                            <h1>We Are Leaders In Mobile App, Website, and Digital Marketing Solutions</h1>
                            <p>At Digital Innovation, we make high-functionality mobile and web apps that support the full capabilities of the latest platforms and systems. Our qualified digital marketing team also develops a strategy to drive qualified visitors to your business and conquer them into leads and sales. Boost conversion rates by utilizing the full potential of mobile and web platforms only with Digital Innovation.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="about-bg">
                            <img src="image/about-11.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="back-img-1">
                <img src="image/what-we-are-shape-1.png">
            </div>
        </div>
        <!-- <div class="cover_info" data-aos="fade-up" data-aos-anchor-placement="top-center">
            <div class="info">
                <h2>How Can We Help You?</h2>
                <p>You are just one step away from booking a free consultation.</p>
                <button class="my-btn btn-1"><a href="tel:9558017423"> Get Free Consultation Now</a></button>
            </div>
        </div> -->
        <div class="co_service">
            <div class="container">
                <h1 class="title-1">Our Service</h1>
                <div class="row row1">
                    <div class="col-lg-4 col-md-6 service1">
                        <div class="service">
                            <div class="service-info">
                                <div class="service-icon">
                                    <i class="fas fa-desktop"></i>
                                </div>
                                <h3>Web Development</h3>
                                <p>We design and develop websites on all major open-source fronts, create web services to provide online tools and back-end for mobile applications.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 service1">
                        <div class="service">
                            <div class="service-info">
                                <div class="service-icon">
                                    <i class="fas fa-phone-volume"></i>
                                </div>
                                <h3>Mobile App Development</h3>
                                <p>From concept to release, we craft high-functionality feature-rich mobile apps for iOS and Android.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 service1">
                        <div class="service">
                            <div class="service-info">
                                <div class="service-icon">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                                <h3>Digital Marketing</h3>
                                <p>Customized online marketing strategy to employ result-driven tactics like PPC, SEO, Email Marketing, Social Media Marketing, and much more.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wrapper">
                    <a href="<?php echo e(url('/Service')); ?>">See All Services</a>
                </div>
            </div>
        </div>
        <div class="co_project">
            <div class="container">
                <h1 class="title-1">Portfolio</h1>
                <div class="gallery-wrapper middle-1">
                    <div class="row row1">
                         <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="image-wrapper set-middle-1" data-aos="fade-up" data-aos-anchor-placement=" top-bottom" data-aos-delay="500">
                                <div class="middle-2">
                                    <img src="/uploads/<?php echo e($p->image); ?>" alt="">
                                    <div class="upload">
                                        <div class="content">
                                            <p><?php echo e($p->portfoliotype); ?></p>
                                        <h6><?php echo e($p->name); ?></h6>
                                        </div>
                                        <div class="icon-1">
                                            <a class="galleryopener" href="#gallerydetail<?php echo e($key); ?>"><i class="far fa-file-image"></i></a>
                                        </div>
                                    </div>       
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </div>
                </div>
                <?php $__currentLoopData = $portfolio_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys => $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <section class="gallerydetail mfp-hide" id="gallerydetail<?php echo e($keys); ?>">
                        <div class="gallerydetail__main gallerymain">
                             <?php $__currentLoopData = $ps['images_details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyss => $pss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="gallerymain__slide">
                                <img src="/uploads/<?php echo e($pss->name); ?>" alt="" class="gallerymain__img">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                        <div class="gallerydetail__lower">
                            <div class="gallerydetail__thumb gallerythumb">

                                <?php $__currentLoopData = $ps['images_details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyss => $pss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="gallerythumb__slide">
                                <img src="/uploads/<?php echo e($pss->name); ?>" alt=""class="gallerythumb__img">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                              
                            </div>
                        </div>
                   </section>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="wrapper">
                    <a href="#">View All Portfolio</a>
                </div>
            </div>
        </div>
        <div class="second">
            <div class="container">
                <div class="_head" data-aos="fade-left" data-aos-duration="1000">
                    <h5>WHY CHOOSE US</h5>
                    <h1>We Are Very Different Form Others IT Solutions</h1>
                </div>
                <div class="row row1">
                    <div class="col-lg-4 col-md-6 why1" data-aos="zoom-in" data-aos-delay="500">
                        <div class="set-icon-3">
                            <div class="icon-3">
                                <i class="fa fa-laptop"></i>
                            </div>
                            <div class="set-main-circle">
                                <div class="main-circle">
                                    <span class="circle">
                                        <i class="fa fa-circle"></i>
                                    </span>
                                    <span class="circle-1">
                                        <i class="fa fa-circle"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="set-top-1">
                            <h2>Modify Whole System</h2>
                            <p>Irrespective of the device or platform, our team of developers and designers can optimize and streamline all your operations across business verticals.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 why1" data-aos="zoom-in" data-aos-delay="1000">
                        <div class="set-icon-3">
                            <div class="icon-3">
                                <i class="fa fa-server"></i>
                            </div>
                            <div class="set-main-circle">
                                <div class="main-circle">
                                    <span class="circle">
                                        <i class="fa fa-circle"></i>
                                    </span>
                                    <span class="circle-1">
                                        <i class="fa fa-circle"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="set-top-1">
                            <h2>Beneficial Strategies</h2>
                            <p>From ideation to release and support, we focus on data-driven strategies for digital experiences that match your business objectives.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 why1" data-aos="zoom-in" data-aos-delay="1500">
                        <div class="set-icon-3">
                            <div class="icon-3">
                                <i class="fa fa-tools"></i>
                            </div>
                            <div class="set-main-circle">
                                <div class="main-circle">
                                    <span class="circle">
                                        <i class="fa fa-circle"></i>
                                    </span>
                                    <span class="circle-1">
                                        <i class="fa fa-circle"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="set-top-1">
                            <h2>Automated Software</h2>
                            <p>Get access to greater business agility as we connect all your work in one place by integrating project management, HR functions, and much more.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="back-img-3">
                <img src="image/choose-dot.png">
            </div>
            <div class="back-img-4">
                <img src="image/choose-shape.png">
            </div>
        </div>
        <div class="co_mission">
            <div class="container">
                <div class="mission">
                    <h2>Our Mission</h2>
                    <p class="prg-1">Our main objective is to provide valuable digital services to our clients that help them maintain long-lasting relationships with their end-users. We strive to craft mobile and web solutions with a digital sales strategy that is client-focused, trustworthy, reliable, knowledgeable, and successful.</p>
                </div>
                <div class="row row1">
                    <div class="col-lg-3 col-md-6 main-mission1">
                        <div class="mission1">
                            <img src="image/page-1_img-4.png">
                            <h3>Certified Developers</h3>
                            <p>Our in-house team of certified developers and designers are knowledgeable in a wide range of fields and are always contributing to new ideas.</p>
                            <div class="tm-stepnum">01</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 main-mission1">
                        <div class="mission1">
                            <img src="image/page-1_img-6.png">
                            <h3>Custom Strategy</h3>
                            <p>Our client-centric data-driven strategies focus on improving online visibility that gives you a competitive edge with increased value in return.</p>
                            <div class="tm-stepnum">02</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 main-mission1">
                        <div class="mission1">
                            <img src="image/page-1_img-5.png">
                            <h3>Timely Deliverables</h3>
                            <p>We plan, execute, evaluate, develop and map our client’s goals and objectives with realistic timelines.</p>
                            <div class="tm-stepnum">03</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 main-mission1">
                        <div class="mission1">
                            <img src="image/page-1_img-7.png">
                            <h3>Maintenance & Support</h3>
                            <p>Our advanced maintenance and support services for website and mobile apps ensures that the relevant business needs are met effortlessly.</p>
                            <div class="tm-stepnum">04</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-12 col-md-12 col-12">
                    <div class="about about1">
                        <a href="<?php echo e(url('/')); ?>"><img src="image/logo1.png"></a>
                        <p class="p1">We will help you find the right development strategy and digital marketing solutions. Give us a call at <a href="tel:<?php echo e($mobileno); ?>"></a>  <?php echo e($mobileno); ?> or drop us a mail at <?php echo e($email); ?>.</p>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="about">
                                <h2>Quick Link</h2>
                                <a href="#">Web Development</a>
                                <a href="#">Mobile App Development</a>
                                <a href="#">Digital Marketing</a>
                                <a href="#">E-commerce Solution</a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="about">
                                <h2>Help Link</h2>
                                 <a href="<?php echo e(url('/About')); ?>">About Us</a>
                                 <a href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>
                                 <a href="<?php echo e(url('/Contact')); ?>">Contact Us</a>
                                 <a href="<?php echo e(url('/Service')); ?>">Services</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                    <div class="about about_">
                        <h2>Contact Us</h2>
                        <ul type="none">
                             <li>
                        <i class="fa fa-map-marker"></i><p><?php echo e($address); ?></p>
                    </li>
                    <li>
                        <i class="fa fa-phone"></i><a href="tel:<?php echo nl2br(e($mobileno)); ?>"><?php echo nl2br(e($mobileno)); ?></a>
                    </li>
                    <li>
                        <i class="fa fa-envelope"></i><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                    </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7 col-12">
                    <div class="port-1">
                        <h2>Sign Up for Exclusive Newsletter</h2>
                        <p>Sign up here to receive the latest news, updates, breakthroughs, and information in the Information Technology sector.</p>
                        <form class="form">
                            <div class="email">
                                <input type="text" placeholder="Enter Your Email" name="email" value="">
                            </div>
                            <div class="sub">
                                <input type="submit" value="Suscribe Now" name="">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-12">
                    <div class="port-1">
                        <div class="footer-social">
                            <h2>Keep Updated</h2>
                            <ul type="none">
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                            </ul>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copy">
        <a class="up-btn" href="#">
            <span class="fa fa-angle-double-up"></span>
        </a>
    </div>
            


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery.slick/1.5.9/slick.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }
        
        // AOS.init({
        //     duration: 1000,
        //     offset: 300
        // });

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });
    
        var _galleryOpenFunct = function(galleryid, openClose){
            openClose = openClose || true;

            var gallery__main  = galleryid+ ' .gallerydetail__main';
            var gallery__thumb = galleryid+ ' .gallerydetail__thumb';
  
            var $mainSlider  = $(galleryid).find('.gallerydetail__main');
            var $thumbSlider = $(galleryid).find('.gallerydetail__thumb');
  
            if( openClose === 'close' ){
              $mainSlider.slick('unslick');   
              $thumbSlider.slick('unslick');   
              return;
            }

            var $slider = $mainSlider
                .on('init', function(slick) {
                    $(gallery__main).fadeIn(1000);
                })
                .slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: true,
                    prevArrow: '<div class="gallerydetail__mainPrev gallerydetail__button"> <i class="fa fa-chevron-left" aria-hidden="true"></i> </div>',
                    nextArrow: '<div class="gallerydetail__mainNext gallerydetail__button"> <i class="fa fa-chevron-right" aria-hidden="true"></i> </div>',
                    autoplay: false,
                    lazyLoad: 'ondemand',
                    autoplaySpeed: 30000,
                    speed: 600,
                    asNavFor: gallery__thumb
                });

                var $slider2 = $thumbSlider
                    .on('init', function(slick) {
                        $(gallery__thumb).fadeIn(1000);
                    })
                    .slick({
                        slidesToShow: 5,
                        variableWidth: true,
                        slidesToScroll: 1,
                        arrows: false,
                        slidesToScroll: 1,
                        lazyLoad: 'ondemand',
                        asNavFor: gallery__main,
                        dots: false,
                        centerMode: false,
                        focusOnSelect: true,
                        infinite: false,
                    });

                    //remove active class from all thumbnail slides
                    $(gallery__thumb+' .slick-slide').removeClass('slick-active');

                    //set active class to first thumbnail slides
                    $(gallery__thumb + ' .slick-slide[data-slick-index="0"]').addClass('slick-active-2');

                    // On after slide change mark proper transitions on main slider
                    $('.gallerydetail__main').on('afterChange', function (event, slick, currentSlide, nextSlide) {
                        var currentSlideIndex =  $('.gallerydetail__main .slick-active').data('slick-index');
                        $(gallery__main + ' .slick-slide[data-slick-index="'+(currentSlideIndex+1)+'"] img').addClass('nextImg')
                        $(gallery__main + ' .slick-slide[data-slick-index="'+(currentSlideIndex-1)+'"] img').addClass('prevImg')
                    });
     
                    // On before slide change match active thumbnail to current slide
                    $(gallery__main).on('beforeChange', function (event, slick, currentSlide, nextSlide) {
                        var mySlideNumber = nextSlide;
                        $(gallery__main + ' .slick-slide img').removeClass('nextImg');
                        $(gallery__main + ' .slick-slide img').removeClass('prevImg');
                        $(gallery__thumb + ' .slick-slide').removeClass('slick-active-2');
                        $(gallery__thumb + ' .slick-slide[data-slick-index="'+(mySlideNumber)+'"]').addClass('slick-active-2');
                    });
                }

                $('.galleryopener').magnificPopup({
                    type:'inline',
                    midClick: true,
                    mainClass: 'gallerydialog',
                    callbacks: {
                        open: function() {
                          // slicks the correct slider when magnific is opened
                          _galleryOpenFunct( $(this)[0].currItem.src );
                        },
                        close: function() {
                          // destroys theslick instance when closed
                          _galleryOpenFunct( $(this)[0].currItem.src, 'close' );
                        }
                    }
                });
    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\digitalinovation\resources\views/welcome.blade.php ENDPATH**/ ?>