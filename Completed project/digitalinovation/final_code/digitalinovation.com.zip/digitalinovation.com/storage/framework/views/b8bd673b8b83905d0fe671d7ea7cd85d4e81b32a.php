<!DOCTYPE html>
<html>
<head>
  <title>IT COMPANY</title>
  <link rel="stylesheet" type="text/css" href="css/IT_header-footer.css">
  <link rel="stylesheet" type="text/css" href="css/IT_about.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;1,100;1,200;1,300;1,400;1,500&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
  <div class="main-head">
        <div class="fix-head">
            <div class="head">
              <h1><a href="IT.html"><img src="image/logo1.png"></a></h1>
            </div>
            <div class="menu">
              <a href="IT.html">Home</a>
              <a href="IT_about.html">About</a>
              <a href="IT_service.html">Service</a>
              <a href="IT_portfolio.html">Portfolio</a>
              <a href="IT_training.html">Training</a>
              <a href="IT_team.html">Team</a>
              <a href="IT_contact.html">Contact</a>
            </div>
            <div class="mobile-menu">
                <div id="mySidepanel" class="sidepanel">
                  <div class="m_menu">
                      <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>    
                        <a class="link" href="IT.html">Home</a>    
                      <a class="link" href="IT_about.html">About</a>    
                      <a class="link" href="IT_service.html">Service    </a>    
                      <a class="link" href="IT_portfolio.html">Portfolio</a>    
                      <a class="link" href="IT_training.html">Training</a>
                      <a class="link" href="IT_team.html">Team</a>
                      <a class="link" href="IT_contact.html">Contact</a>
                  </div>
                </div>
                <button class="openbtn" onclick="openNav()">☰</button> 
            </div>
        </div>
    </div>
    <div class="fixed">
         <?php echo $__env->yieldContent('content'); ?>
    </div>

      <div class="footer">
      <div class="fix-footer">
        <div class="about">
          <h2><a href="IT.html"><img src="image/logo1.png"></a></h2>
          <p class="p1">We will help you find the right development strategy and digital marketing solutions. Give us a call at +91-9558561212 or drop us a mail at info@digitalinovation.com.</p>
        </div>
        <div class="_about">
          <div class="about1">
            <h2>Quick Link</h2>
              <a href="#">Web Development</a>
              <a href="#">Mobile App Development</a>
              <a href="#">Digital Marketing</a>
              <a href="#">E-commerce Solution</a>
          </div>
          <div class="about1">
            <h2>Help Link</h2>
            <a href="IT_about.html">About Us</a>
            <a href="IT_portfolio.html">Portfolio</a>
            <a href="IT_contact.html">Contact Us</a>
            <a href="IT_service.html">Services</a>
          </div>
        </div>
        <div class="about about_">
          <h2>Contact Us</h2>
          <ul type="none">
            <li>
              <i class="fa fa-map-marker"></i><p>Shop No. 19, Shree Vinayak Homes Apartment,<br>Opp. I.T.I Bilimora<br>396325</p>
            </li>
            <li>
              <i class="fa fa-phone"></i><a href="tel:9558017423">+91-9558561212</a>
            </li>
            <li>
              <i class="fa fa-envelope"></i><a href="mailto:info@digitalinovation.com">info@digitalinovation.com</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="bottom-footer">
      <div class="fix-bm-footer">
        <div class="set-bottom">
          <div class="port-1">
              <h2>Sign Up for Exclusive Newsletter</h2>
              <p>Sign up here to receive the latest news, updates, breakthroughs, and information in the Information Technology sector.</p>
              <form class="form">
                <div class="email">
                    <input type="text" placeholder="Enter Your Email" name="email" value="">
                  </div>
                <div class="sub">
                    <input type="submit" value="Suscribe Now" name="">
                  </div>
              </form>
            </div>
            <div class="port-1">
              <div class="footer-social">
                        <h2>Keep Updated</h2>
                        <ul type="none">
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>  
                </div>
              </div>
            </div>
        </div>
    </div>
    <div class="copy">
        <a class="up-btn" href="#"><i class="fas fa-angle-double-up"></i></a>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script type="text/javascript">
      function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }


        AOS.init({
            duration: 1000,
            offset: 300
        });

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });
    </script>

</body>
</html><?php /**PATH D:\xampp\htdocs\digitalinovation\resources\views/layouts/app.blade.php ENDPATH**/ ?>