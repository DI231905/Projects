

<?php $__env->startSection('content'); ?>
    <div class="fixed">
        <div class="co-bg">
            <div class="bg-img">
                <div class="heading" data-aos="fade-right" >
                    <h1>CONTACT</h1>
                </div>
            </div>
            <div class="set-bg">
                <ul type="none">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li>|</li>
                    <li>Contact</li>
                </ul>
            </div>
        </div>
        <div class="co_contact">
            <div class="container">
                <div class="test test1" data-aos="fade-left">
                    <h4>LET’S GET TO WORK</h4>
                    <h1>Contact Us</h1>
                </div>
                 <div class="row row1">
                    <div class="col-lg-6 col-md-12 col-12" data-aos="fade-up">
                        <div class="contact">
                            <img src="image/contact.jpg">
                            <p>Let us know about your queries and requirements. Get a free quotation by simply filling out the form. You can also dial the number<strong><?php echo e($mobileno); ?></strong> or <strong><?php echo e($email); ?></strong>, Rest assured, our support team will get back to you within 24 hours. </p>
                            <p>We look forward to hearing from you!</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12" data-aos="fade-down" >
 
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 

                    <?php if(session()->has('error')): ?>
                           <div id="hideDiv" class="alert alert-success">
                           <?php echo e(session()->get('error')); ?>

                         </div>
                    <?php endif; ?>
                      

                        <div class="contact">
                         <form method="POST" action="<?php echo e(url('/Contactusfrom')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="test">
                                   <input type="text" placeholder="Your Name" name="name" value="" required>    
                                    <input type="text" placeholder="Your Email" name="email" value=""required>    
                                    <input type="number" placeholder="Your Phone" name="mobileno" value=""required>    
                                    <input type="text" placeholder="Your Subject" name="subject" value=""required>    
                                    <textarea placeholder="Your Message" name="description" value=""required></textarea>      
                                </div>    
                                <div class="sub-1">    
                                    <input type="submit" name="Send Message" value="submit"></input>
                                </div>    
                            </form>    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
     <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }
           AOS.init({
             duration: 1000,
             offset: 300
        });
        
        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });</script>
  <?php $__env->stopSection(); ?>    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digitalinovation\resources\views/contact.blade.php ENDPATH**/ ?>