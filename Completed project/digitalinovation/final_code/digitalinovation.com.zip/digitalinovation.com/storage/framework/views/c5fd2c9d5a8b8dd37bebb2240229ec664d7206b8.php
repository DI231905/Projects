<!DOCTYPE html>
<html>
<head>
    <title>Digital Innovation</title>
    <link rel="stylesheet" type="text/css" href="/css/main-dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div class="mobile-view">
        <div class="row">
            <div class="col-md-6 col-6 logo1">
                <img src="/image/f_logo.png">
            </div>
            <div class="col-md-6 col-6">
                <div class="mobile-menu">
                    <div id="mySidepanel" class="sidepanel">
                        <div class="m_menu">
                            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>  
                            <div class="top-nav-wrapper">
                                <div class="top-nav">                       
                                    <div class="co_profile">
    
                                        <div class="user-details">
                                            <span id="more-details">Digital Innovation<i class="fa fa-caret-down"></i></span>
                                        </div>
                                    </div>
                                    <div class="main-menu-content">
                                        <ul>
                                            

                                            <li class="more-details">
                                                <i class="" aria-hidden="true"></i><a href="<?php echo e(url('admin/changepassword')); ?>">change password</a>
                                            </li>

                                           

                                             <li class="more-details">
                                          <i class="fa fa-lock" aria-hidden="true"></i><a href="<?php echo e(route('adminlogout')); ?>">Logout</a>
                                      </li>


                                        </ul>

                                    </div>
                                    <div class="nav-slider"></div>
                                    <div class="hosting dash">
                                        <div class="hosting-btn nav-btn">Portfolio list</div>
                                    </div>
                                     <div class="marketplace dash">
                                     <div class="marketplace-btn nav-btn"> Admin Detail List</div>
                                    </div>
                                    <div class="domains dash">
                                        <div class="domain-btn nav-btn">Contact List</div>
                                    </div>
                                    <div class="message dash">
                                         <div class="message-btn nav-btn">Teamlist</div>
                                    </div>
                                   <div class="category dash">
                                     <div class="category-btn nav-btn">Testimonial </div>
                                   </div>
                                   <div class="dashboard dash">
                                     <div class="dashboard-btn nav-btn">Event Images</div>
                                   </div> 
    
   
                                    <div class="nav-slider"></div>
                                </div>
                            </div> 
                        </div>
                    </div>
                    <button class="openbtn" onclick="openNav()">☰</button> 
                </div>
            </div>
        </div> 
    </div>
    <div class="row">
        <div class="col-xl-2 col-lg-3 col-md-6">
            <div class="two">
                <div class="top-nav-wrapper">
                    <div class="top-nav">
                        <div class="logo">
                            <img src="/image/f_logo.png">
                        </div>
                        <div class="co_profile">
                            <div class="profile-img">
                                
                            </div>
                            <div class="user-details">
                                <span id="more-details">Digital Innovation<i class="fa fa-caret-down"></i></span>
                            </div>
                        </div>
                        <div class="main-menu-content">
                                  <ul>

                                            <li class="more-details">
                                                <i class= ""aria-hidden="true"></i><a href="<?php echo e(url('admin/changepassword')); ?>">change password</a>
                                            </li>

                                             <!--  <li class="more-details">
                                                <i class=aria-hidden="true"></i><a href="<?php echo e(url('admin/admincontactdetail')); ?>">Add Admin detail</a>
                                            </li><br> -->

                                             <li class="more-details">
                                          <i class="fa fa-lock" aria-hidden="true"></i><a href="<?php echo e(route('adminlogout')); ?>">Logout</a>
                                      </li>
                                  </ul>
                              </div>
                        <div class="nav-slider"></div>
                        <!-- <div class="dashboard dash">
                            <button class="active dashboard-btn nav-btn">Details List</button>
                        </div> -->
                        <div class="hosting dash">
                            <div class="hosting-btn nav-btn">Portfolio List</div>
                        </div>
                        <div class="domains dash">
                            <div class="domain-btn nav-btn">Contact List</div>
                        </div>
                        <div class="marketplace dash">
                            <div class="marketplace-btn nav-btn"> Admin Detail List</div>
                        </div>
                        <div class="message dash">
                            <div class="message-btn nav-btn"> Team List</div>
                        </div>
                         <div class="category dash">
                            <div class="category-btn nav-btn">Testimonial </div>
                        </div> 
                        <div class="dashboard dash">
                            <div class="dashboard-btn nav-btn">Event Images</div>
                        </div> 
 
                        <div class="nav-slider"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-10 col-lg-9 col-md-12">

              <?php if($message = Session::get('error')): ?>
           <div  id="hideDiv" class="alert alert-success alert-block" >
<!--     <input type="text" class="close" data-dismiss="alert"></input> -->
           <strong style=" padding-top : 5px !important; display: inline-block;"><?php echo e($message); ?></strong>
           </div>
           <?php endif; ?>
            <div class="page mt-4 hosting-page title1">
                <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4"> Protfolio List</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addprotfolio')); ?>" style="color:white">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Portfolio Type</th>
                                    <th> Name</th>
                                     <th> Url</th>
                                    <th>Description</th>
                                    <th>Screenshorts</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                               <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                               
                                <tr>
                                    <td>
                                      <img src="/uploads/<?php echo e($pf->image); ?>" width="60" height="60"><br>
                                       <?php echo e($pf->image); ?>

                                    </td>
                                

                                    <td>
                                          <?php echo e($pf->portfoliotype); ?>

                                    </td>
                                    <td>
                                         <?php echo e($pf->name); ?>

                                    </td>
                                     <td>
                                         <?php echo e($pf->url); ?>

                                    </td>
                                    <td>
                                         <?php echo e($pf->description); ?>

                                   </td>
                                    <td>
                                        <?php $__currentLoopData = $portfolio_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      
                                           
                                          <?php if($pi->p_id == $pf->id): ?>

                                         <img src="/uploads/<?php echo e($pi->name); ?>" width="60" height="60"><?php echo e($pi->name); ?> <br><br>  

                                                 <?php endif; ?> 

                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </td>
                                   
                                  
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateprotfolio')); ?>/<?php echo e($pf->id); ?>">Update</a></button></td>
                            <td><button class="btn3 btn0"><a href="<?php echo e(url('admin/deleteprotfolio')); ?>/<?php echo e($pf->id); ?>">Delete</a></button></td>
                                </tr>
                              
                            </tbody>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div> 


             <div class="page mt-4 dashboard-page title1">
                  <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">EVENT List</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addevent')); ?>" >ADD</a></button>
                    </div>
                

                          <div class="detail" style="display:flex; flex-wrap:wrap;"  > 
                        <?php $__currentLoopData = $event_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                         <div class="image_<?php echo e($g->id); ?>">
 
                    
                         <div class="gallery" style="margin-left: 30px ; margin-top: 30px">
                          <a target="_blank" href="/uploads/<?php echo e($g->image); ?>">
                          <img src="/uploads/<?php echo e($g->image); ?>" alt="Cinque Terre" width="350" height="300">
                           </a>


                           <?php

                              $event_type=DB::table('event_type')->where('id',$g->event_type)->get();

                              $evnet_name=$event_type[0]->type;
                          
                           ?>

                            <div class="desc"><b><?php echo e($evnet_name); ?></b></div>


                           <div class="desc"><a class="btnsubmit" onclick="deleteimage(<?php echo e($g->id); ?>)"><b>Delete</b></a>
                        
                               </div>
                             </div>      
                          </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    </div>                    
                  </div>
              </div>
    
  
            <div class="page mt-4 marketplace-page title1">
                <div class="mt-5">
                    <h4 class="mb-4"> Admin Details List</h4>
                     <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile no</th>
                                    <th>Address</th>
                                    <th>instalink</th>
                                    <th>fblink</th>
                                    <th>twitterlink</th>
                                    <th>Googlelink</th>
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                                 <?php $__currentLoopData = $admindetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($ac->name); ?>

                                    </td>
                                
                    
                                    <td>
                                          <?php echo e($ac->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($ac->mobileno); ?>

                                    </td>
                                    <td>
                                        <?php echo e($ac->address); ?>

                                   </td>
                                    <td>
                                        <?php echo e($ac->insta_id); ?>

                                   </td>
                                    <td>
                                        <?php echo e($ac->fb_id); ?>

                                   </td>
                                    <td>
                                        <?php echo e($ac->twitter_id); ?>

                                   </td>
                                    <td>
                                        <?php echo e($ac->google_id); ?>

                                   </td>
                                  
                             <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateadmindetail')); ?>/<?php echo e($ac->id); ?>">Update</a></button></td>
                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
  
            <div class="page mt-4 domain-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Contact List</h4>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>MobileNo</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <tbody>
                                 <?php $__currentLoopData = $contact_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($cu->name); ?>

                                    </td>
                                

                                    <td>
                                          <?php echo e($cu->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($cu->mobileno); ?>

                                    </td>
                                    <td>
                                        <?php echo e($cu->subject); ?>

                                   </td>
                                   
                                    <td>
                                        <?php echo e($cu->description); ?>

                                   </td>
                                  
                             <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/deletecontactus')); ?>/<?php echo e($cu->id); ?>" style="color:white">Delete</a></button></td>
                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 

            <div class="page mt-4 message-page title1">
                <div class="mt-5">
                     <div class="list1">
                        <h4 class="mb-4">Team List</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/teamview')); ?>" style="color:white">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>name</th>
                                    <th>image</th>
                                    <th>Type</th>
                                    <th>occupation</th>
                                    <th>facbook</th>
                                    <th>instagram</th>
                                    <th>update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                              <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>

                                <tr>
                                    <td>
                                       <?php echo e($t->name); ?>

                                    </td>
                                       

                                    <td>
                                         <img src="/uploads/<?php echo e($t->image); ?>" width="60" height="60"><br>
                                         <?php echo e($t->image); ?>

                                    </td>

                                    <td>
                                       <?php echo e($t->type); ?>

                                    </td>
                                    <td>
                                       <?php echo e($t->occupation); ?>

                                    </td>
                                    <td>
                                      <?php echo e($t->fblink); ?>

                                   </td>
                                    <td>
                                      <?php echo e($t->instalink); ?>

                                   </td>

                                     <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/teamupdate')); ?>/<?php echo e($t->id); ?>" style="color:white">Update</a></button></td>

                         
                                    <td><button class="btn3 btn0"><a href="<?php echo e(url('admin/teamdelete')); ?>/<?php echo e($t->id); ?>">Delete</a></button></td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            </tbody>
                        </table>
                    </div>
            
                </div>
            </div> 

             <div class="page mt-4 category-page title1">
                  <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Testimonial List</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addtestimonial')); ?>" >ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>image</th>
                                    <th>Name</th>
                                    <th>Occupation</th>
                                    <th>Description</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                               <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr>
                                    <td> 
                                        <img src="/uploads/<?php echo e($t->image); ?>" width="60" height="60"><br>
                                         <?php echo e($t->image); ?>

                                    </td>

                                    <td>
                                      <?php echo e($t->name); ?>

                                    </td>
                                    <td>
                                      <?php echo e($t->occupation); ?>

                                    </td>
                                    <td>
                                      <?php echo e($t->description); ?>

                                    </td>

                                     <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updatetestimonial')); ?>/<?php echo e($t->id); ?>">update</a></button></td>
                                    <td><button class="btn3 btn0"><a href="<?php echo e(url('admin/deletetestimonial')); ?>/<?php echo e($t->id); ?>">Delete</a></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </div>              
                  </div>
              </div>

          
    </div> 



    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

        $(function() {
setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

});

    $(document).ready(function(){
       
        $(".user-details").click(function(){
            $(".main-menu-content").slideToggle("slow");
        })
    });


        function deleteimage($id){

    if(confirm("do you want delete this record ?")){
             $.ajax({

                url:'delete_image/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                          
          var v='image_'+$id;
 
            $('.image_'+$id).hide();  
    
          
                        },

      error: function(response) {
 
        
              alert('something went wrong. try again!!')
                 
                  },        
          
                });


          
          }
      }
        



      
    var tl = new TimelineMax();

//Logos
TweenMax.set('.wp-logo', { scale: 1 })
TweenMax.set('.weebly-logo', { scale: 1 })  

// Pages 
TweenMax.set('.dashboard-page', { display: 'none' })
TweenMax.set('.hosting-page', { display: 'block' })
TweenMax.set('.marketplace-page', { display: 'none' })
TweenMax.set('.domain-page', { display: 'none' })
TweenMax.set('.message-page', { display: 'none' })
TweenMax.set('.manage-account-page', { display: 'none' })
TweenMax.set('.dryfruit-page', { display: 'none' })
TweenMax.set('.category-page', { display: 'none' })
TweenMax.set('.event-page', { display: 'none' })


TweenMax.to('.mobile-nav', 0, { x: -300 })

/* Message Btn Starts */
$('.message-btn').on('click', function(){  
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.manage-account-page').css({ display: 'none' })
   $('.message-page').css({ display: 'block' })
    $('.manage-account-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
      $('.event-page').css({ display: 'none' })



  
});
/* Message Btn Ends */

// Manage Account Btn STARTS
$('.message-btn').on('click', function(){  
    $(this).addClass('active').removeClass('nav-btn');
    $('.marketplace-btn').removeClass('active').addClass('nav-btn');
    $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.hosting-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.dashboard-btn').removeClass('active').addClass('nav-btn');
    $('.manage-account-btn').removeClass('active').addClass('nav-btn');
    $('.event-btn').removeClass('active').addClass('nav-btn');


   
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.manage-account-page').css({ display: 'none' })
   $('.message-page').css({ display: 'block' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
       $('.event-page').css({ display: 'none' })
  
});
$('.manage-account-btn').on('click', function(){
    $(this).addClass('active').removeClass('nav-btn');
    $('.marketplace-btn').removeClass('active').addClass('nav-btn');
    $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.hosting-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.dashboard-btn').removeClass('active').addClass('nav-btn');
    $('.message-btn').removeClass('active').addClass('nav-btn');
      $('.event-btn').removeClass('active').addClass('nav-btn');

   
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.message-page').css({ display: 'none' })
  $('.manage-account-page').css({ display: 'block' })
  $('.account-info-drop-down').css({ display: 'none' })
  $('.dryfruit-page').css({ display: 'none' })
  $('.category-page').css({ display: 'none' })
    $('.event-page').css({ display: 'none' })
});

    $('.hosting-btn').on('click', function() {
        $(this).addClass('active').removeClass('nav-btn');
        $('.dashboard-btn').removeClass('active').addClass('nav-btn');
        $('.marketplace-btn').removeClass('active').addClass('nav-btn');
        $('.domain-btn').removeClass('active').addClass('nav-btn');
        $('.dryfruit-btn').removeClass('active').addClass('nav-btn');   
        $('.message-btn').removeClass('active').addClass('nav-btn'); 
        $('.manage-account-btn').removeClass('active').addClass('nav-btn');  
        $('.event-btn').removeClass('active').addClass('nav-btn');

        $('.dashboard-page').css({ display: 'none' })
        $('.hosting-page').css({ display: 'block' })
        $('.marketplace-page').css({ display: 'none' })
        $('.domain-page').css({ display: 'none' })
        $('.message-page').css({ display: 'none' })
         $('.manage-account-page').css({ display: 'none' })
         $('.dryfruit-page').css({ display: 'none' })
          $('.category-page').css({ display: 'none' })
            $('.event-page').css({ display: 'none' })
  
    });

$('.marketplace-btn').on('click', function(){
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
     $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.category-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
     $('.event-btn').removeClass('active').addClass('nav-btn');

  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'block' })
     $('.domain-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
     $('.manage-account-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
     $('.event-page').css({ display: 'none' })

});

$('.domain-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.category-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
     $('.event-btn').removeClass('active').addClass('nav-btn');
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.domain-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
     $('.manage-account-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
     $('.event-page').css({ display: 'none' })

});

$('.dryfruit-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
     $('.event-btn').removeClass('active').addClass('nav-btn');

    $(".page1").hide();
    $(".page2").hide();
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
     $('.manage-account-page').css({ display: 'none' })
     $('.domain-page').css({ display: 'none' })
     $('.event-page').css({ display: 'none' })

});

$('.category-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
     $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
     $('.event-btn').removeClass('active').addClass('nav-btn');
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.manage-account-page').css({ display: 'none' })
     $('.domain-page').css({ display: 'none' })
     $('.event-page').css({ display: 'none' })

});

$('.dashboard-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
     $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
     $('.category-btn').removeClass('active').addClass('nav-btn');
  
 
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.manage-account-page').css({ display: 'none' })
     $('.domain-page').css({ display: 'none' })
     $('.dashboard-page').css({ display: 'block' })

});
</script>
</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/digitalinovation.com/resources/views/admin/home.blade.php ENDPATH**/ ?>