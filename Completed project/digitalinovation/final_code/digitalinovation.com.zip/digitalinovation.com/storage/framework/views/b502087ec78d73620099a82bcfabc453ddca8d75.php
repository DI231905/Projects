<!DOCTYPE html>
<html>
<head>
    <title>DIGITAL Innovation</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;1,100;1,200;1,300;1,400;1,500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
    <div class="main-head">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="logo">
                         <h1><a href="<?php echo e(url('/')); ?>"><img src="image/logo1.png"></a></h1>
                    </div>
                </div>
                <div class="col-lg-9 col-md-6 col-6">
                    <div class="menu">
                       <a href="<?php echo e(url('/')); ?>">Home</a>
                       <a href="<?php echo e(url('/About')); ?>">About</a>
                       <a href="<?php echo e(url('/Service')); ?>">Service</a>
                       <a href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>
                       <a href="<?php echo e(url('/Training')); ?>">Training</a>
                       <a href="<?php echo e(url('/Team')); ?>">Team</a>
                       <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
                    </div>
                    <div class="mobile-menu">
                        <div id="mySidepanel" class="sidepanel">
                            <div class="m_menu">
                                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times"></i></a>    
                                 <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>    
                                  <a class="link" href="<?php echo e(url('/')); ?>">Home</a>  
                                  <a class="link" href="<?php echo e(url('/About')); ?>">About</a> 
                                  <a class="link" href="<?php echo e(url('/Service')); ?>">Service</a>   
                                  <a class="link" href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>    
                                  <a class="link" href="<?php echo e(url('/Training')); ?>">Training</a>
                                  <a class="link" href="<?php echo e(url('/Team')); ?>">Team</a>
                                  <a class="link" href="<?php echo e(url('/Contact')); ?>">Contact</a>
                            </div>
                        </div>
                        <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="fixed">
        <div class="co-bg">
            <div class="bg-img">
                <div class="heading" data-aos="fade-right" data-aos-duration="1000">
                    <h1>CONTACT</h1>
                </div>
            </div>
            <div class="set-bg">
                <ul type="none">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li>|</li>
                    <li>Contact</li>
                </ul>
            </div>
        </div>
        <div class="co_contact">
            <div class="container">
                <div class="test test1" data-aos="fade-left">
                    <h4>LET’S GET TO WORK</h4>
                    <h1>Contact Us</h1>
                </div>
                 <div class="row row1">
                    <div class="col-lg-6 col-md-12 col-12" data-aos="fade-up" data-aos-delay="500">
                        <div class="contact">
                            <img src="image/contact.jpg">
                            <p>Let us know about your queries and requirements. Get a free quotation by simply filling out the form. You can also dial the number<strong><?php echo e($mobileno); ?></strong> or <strong><?php echo e($email); ?></strong>, Rest assured, our support team will get back to you within 24 hours. </p>
                            <p>We look forward to hearing from you!</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12" data-aos="fade-down" data-aos-delay="500">
 
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 

                    <?php if(session()->has('error')): ?>
                           <div id="hideDiv" class="alert alert-success">
                           <?php echo e(session()->get('error')); ?>

                         </div>
                    <?php endif; ?>
                      

                        <div class="contact">
                         <form method="POST" action="<?php echo e(url('/Contactusfrom')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="test">
                                   <input type="text" placeholder="Your Name" name="name" value="" required>    
                                    <input type="text" placeholder="Your Email" name="email" value=""required>    
                                    <input type="number" placeholder="Your Phone" name="mobileno" value=""required>    
                                    <input type="text" placeholder="Your Subject" name="subject" value=""required>    
                                    <textarea placeholder="Your Message" name="description" value=""required></textarea>      
                                </div>    
                                <div class="sub-1">    
                                    <input type="submit" name="Send Message" value="submit"></input>
                                </div>    
                            </form>    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-12 col-md-12 col-12">
                    <div class="about about1">
                        <a href="<?php echo e(url('/')); ?>"><img src="image/logo1.png"></a>
                        <p class="p1">We will help you find the right development strategy and digital marketing solutions. Give us a call at +91-9558561212 or drop us a mail at info@digitalinovation.com.</p>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="about">
                                <h2>Quick Link</h2>
                                <a href="#">Web Development</a>
                                <a href="#">Mobile App Development</a>
                                <a href="#">Digital Marketing</a>
                                <a href="#">E-commerce Solution</a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="about">
                                <h2>Help Link</h2>
                                <a href="<?php echo e(url('/About')); ?>">About Us</a>
                                <a href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>
                                <a href="<?php echo e(url('/Contact')); ?>">Contact Us</a>
                                <a href="<?php echo e(url('/Service')); ?>">Services</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                    <div class="about about_">
                        <h2>Contact Us</h2>
                        <ul type="none">
                           <li>
                               <i class="fa fa-map-marker"></i><p><?php echo e($address); ?></p>
                           </li>
                           <li>
                               <i class="fa fa-phone"></i><a href="tel:<?php echo nl2br(e($mobileno)); ?>"><?php echo nl2br(e($mobileno)); ?></a>
                           </li>
                           <li>
                               <i class="fa fa-envelope"></i><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                           </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7 col-12">
                    <div class="port-1">
                        <h2>Sign Up for Exclusive Newsletter</h2>
                        <p>Sign up here to receive the latest news, updates, breakthroughs, and information in the Information Technology sector.</p>
                        <form class="form">
                            <div class="email">
                                <input type="text" placeholder="Enter Your Email" name="email" value="">
                            </div>
                            <div class="sub">
                                <input type="submit" value="Suscribe Now" name="">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-12">
                    <div class="port-1">
                        <div class="footer-social">
                            <h2>Keep Updated</h2>
                            <ul type="none">
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                            </ul>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copy">
        <a class="up-btn" href="#">
            <span class="fa fa-angle-double-up"></span>
        </a>
    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }
        
        // AOS.init({
        //     duration: 1000,
        //     offset: 300
        // });

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });

    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\digitalinovation\resources\views/contact.blade.php ENDPATH**/ ?>