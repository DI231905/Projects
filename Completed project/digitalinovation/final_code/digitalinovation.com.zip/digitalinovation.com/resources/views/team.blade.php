@extends('layouts.app')

@section('content')
    <div class="fixed">
        <div class="co-bg">
            <div class="bg-img">
                <div class="heading" data-aos="fade-right" data-aos-duration="1000">
                    <h1>OUR TEAM</h1>
                </div>
            </div>
            <div class="set-bg">
                <ul type="none">
                    <li><a href="{{url('/')}}">Home</a></li>
                    <li>|</li>
                    <li>Team</li>
                </ul>
            </div>
        </div>
        <div class="co_team">
            <div class="container">
                <div class="test" data-aos="fade-left">
                    <h4>OUR LEADERSHIP</h4>
                    <h1>Team Members</h1>
                </div>
                <div class="row row1">
                     @foreach($owner_team as $ot)
                    <div class="col-lg-4 col-md-4 team" data-aos="flip-left" >
                         
                        <div class="box13">
                            <img src="/uploads/{{$ot->image}}">
                            <div class="box-content">
                                <h3 class="title">{{$ot->name}}</h3>
                                <span class="post">{{$ot->occupation}}</span>
                                <ul class="social">
                                    <li><a href="{{$ot->fblink}}"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="{{$ot->instalink}}"><i class="fab fa-linkedin-in"></i></a></li>
                                </ul>
                            </div>
                        </div>
                          
                    </div>
                     @endforeach

                     @foreach($emp_team as $et)
                    <div class="col-md-6 team-1"  data-aos="flip-left" data-aos-delay="500" >
                         
                        <div class="box13">
                            <img src="/uploads/{{$et->image}}">
                            <div class="box-content">
                                <h3 class="title">{{$et->name}}</h3>
                                <span class="post">{{$et->occupation}}</span>
                                <ul class="social">
                                    <li><a href="{{$et->fblink}}"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="{{$et->instalink}}"><i class="fab fa-linkedin-in"></i></a></li>
                                </ul>
                            </div>
                        </div>
                         
                    </div>
                   @endforeach
                </div>
            </div>
        </div>
    </div>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
     <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }
        
         AOS.init({
            duration: 1000,
             offset: 300
        });


        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        }); </script>
 @endsection
   
