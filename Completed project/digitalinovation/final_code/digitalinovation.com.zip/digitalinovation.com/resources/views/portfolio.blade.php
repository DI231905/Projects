<!DOCTYPE html>
<html>
<head>
    <title>DIGITAL Innovation</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;1,100;1,200;1,300;1,400;1,500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/jquery.slick/1.5.9/slick.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>
<body class="body">
    <div class="main-head">
        <div class="container">
            <div class="row row2">
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="logo">
                        <h1><a href="{{url('/')}}"><img src="image/logo1.png"></a></h1>
                    </div>
                </div>
                <div class="col-lg-9 col-md-6 col-6">
                    <div class="menu">
                        <a href="{{url('/')}}">Home</a>
                        <a href="{{url('/About')}}">About</a>
                        <a href="{{url('/Service')}}">Service</a>
                        <a href="{{url('/Portfolio')}}">Portfolio</a>
                        <a href="{{url('/Training')}}">Training</a>
                        <a href="{{url('/Team')}}">Team</a>
                        <a href="{{url('/Contact')}}">Contact</a>
                        <a href="{{url('/event')}}">Event</a>
                    </div>
                    <div class="mobile-menu">
                        <div id="mySidepanel" class="sidepanel">
                            <div class="m_menu">
                                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times"></i></a>    
                               <a class="link" href="{{url('/')}}">Home</a>  
                               <a class="link" href="{{url('/About')}}">About</a> 
                               <a class="link" href="{{url('/Service')}}">Service</a>   
                               <a class="link" href="{{url('/Portfolio')}}">Portfolio</a>    
                               <a class="link" href="{{url('/Training')}}">Training</a>
                               <a class="link" href="{{url('/Team')}}">Team</a>
                               <a class="link" href="{{url('/Contact')}}">Contact</a>
                                <a class="link" href="{{url('/event')}}">Event</a>
                            </div>
                        </div>
                        <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="fixed">
        <div class="co-bg">
            <div class="bg-img">
                <div class="heading" data-aos="fade-right" data-aos-duration="1000">
                    <h1>PORTFOLIO</h1>
                </div>
            </div>
            <div class="set-bg">
                <ul type="none">
                    <li><a href="{{url('/')}}">Home</a></li>
                    <li>|</li>
                    <li>Portfolio</li>
                </ul>
            </div>
        </div>
        <div class="co_project">
            <div class="container">
                <div class="test" data-aos="fade-left">
                    <h4>CASE STUDIES</h4>
                    <h1>Latest Portfolio</h1>
                </div>
                <div class="gallery"data-aos="fade-up">
                    <ul class="controls">
                        <li class="buttons active" data-filter="all">All</li>
                        <li class="buttons" data-filter="app">App Customization</li>
                        <li class="buttons" data-filter="IT">IT Solutions</li>
                        <li class="buttons" data-filter="web">Web Development</li>
                        <li class="buttons" data-filter="photo">Photography</li>
                    </ul>
                    <div class="image-container row">

                    @foreach($portfolio as $key => $p)
                        <span class="col-lg-4 col-md-6 col-12 product-list image {{$p->type}}">
                            <div class="middle-2">
                                <img src="/uploads/{{$p->image}}"alt="">
                                <div class="upload">
                                    <div class="content">
                                        <p>{{$p->portfoliotype}}</p>
                                        <h6><a style="color: black ; font-weight: 600; " href="{{$p->url}}" target="_blank">{{$p->name}}</a></h6>
                                    </div>
                                    <div class="icon-1">
                                        <a class="galleryopener" href="#gallerydetail{{$key}}" ><i class="far fa-file-image"></i></a>
                                    </div>
                                </div>       
                            </div>
                        </span>
                        @endforeach 
                    </div>
                   @foreach($portfolio_image as $keys => $ps)
                   <section class="gallerydetail mfp-hide" id="gallerydetail{{$keys}}">
                        <div class="gallerydetail__main gallerymain">
                             @foreach($ps['images_details'] as $keyss => $pss)
                            <div class="gallerymain__slide">
                                <img src="/uploads/{{$pss->name}}" alt="" class="gallerymain__img">
                            </div>
                            @endforeach
                            
                        </div>
                        <div class="gallerydetail__lower">
                            <div class="gallerydetail__thumb gallerythumb">

                                @foreach($ps['images_details'] as $keyss => $pss)
                           <div class="gallerythumb__slide">
                                <img src="/uploads/{{$pss->name}}" alt=""class="gallerythumb__img">
                            </div>
                            @endforeach

                                                              
                            </div>
                        </div>
                   </section>
                     @endforeach
                </div>
             
                <div class="cover_info" data-aos="fade-up" data-aos-anchor-placement="top-center" data-aos-delay="500">
                    <div class="info">
                        <h2>Got A Project in Mind?</h2>
                        <p>Schedule a free call with our experts on +91-9558561212 or drop us a mail -info@digitalinovation.com.</p>
                        <button class="my-btn btn-1"><a href="{{url('/Contact')}}">Contact Us Now</a></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-12 col-md-12 col-12">
                    <div class="about about1">
                        <a href="{{url('/')}}"><img src="image/f_logo.png"></a>
                        <p class="p1">We will help you find the right development strategy and digital marketing solutions. Give us a call at {{$mobileno}} or drop us a mail at {{$email}}.</p>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="about">
                                <h2>Quick Link</h2>
                                <a href="#">Web Development</a>
                                <a href="#">Mobile App Development</a>
                                <a href="#">Digital Marketing</a>
                                <a href="#">E-commerce Solution</a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="about">
                                <h2>Help Link</h2>
                                 <a href="{{url('/About')}}">About Us</a>
                                 <a href="{{url('/Portfolio')}}">Portfolio</a>
                                 <a href="{{url('/Contact')}}">Contact Us</a>
                                 <a href="{{url('/Service')}}">Services</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                    <div class="about about_">
                        <h2>Contact Us</h2>
                        <ul type="none">
                            <li>
                                <i class="fa fa-map-marker"></i><p>{{$address}}</p>
                            </li>
                            <li>
                                <i class="fa fa-phone"></i><a href="tel:{!!nl2br(e($mobileno))!!}">{!!nl2br(e($mobileno))!!}</a>
                            </li>
                            <li>
                                <i class="fa fa-envelope"></i><a href="mailto:{{$email}}">{{$email}}</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7 col-12">
                    <div class="port-1">
                        <h2>Sign Up for Exclusive Newsletter</h2>
                        <p>Sign up here to receive the latest news, updates, breakthroughs, and information in the Information Technology sector.</p>
                        <form class="form">
                            <div class="email">
                                <input type="text" placeholder="Enter Your Email" name="email" value="">
                            </div>
                            <div class="sub">
                                <input type="submit" value="Suscribe Now" name="">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-12">
                    <div class="port-1">
                        <div class="footer-social">
                            <h2>Keep Updated</h2>
                            <ul type="none">
                                  <li><a href="{{$twitter_id}}"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="{{$fb_id}}"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="{{$google_id}}"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="{{$insta_id}}"><i class="fab fa-instagram"></i></a></li>
                            </ul>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copy">
        <a class="up-btn" href="#">
            <span class="fa fa-angle-double-up"></span>
        </a>
    </div>
                

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery.slick/1.5.9/slick.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }
        
        AOS.init({
            duration: 1000,
            offset: 300
        });


          function myFunction() {

             $('.galleryopener1').click(function() {

            var pr_id= $(this).attr('id');
                 console.log(pr_id);
      
               if(pr_id){
                   $.ajax({

                     url:'getgallery/'+pr_id,
                     type:'GET',
                     dataType:'json',       
                     success:function(data){
                     console.log(data);

                     
               $.each(data,function(key,value){

                        console.log(value.name);


                       $('.gallerydetail__main').html('<div class="gallerymain__slide"><img src=/uploads/'+value.name+' class="gallerymain__img" ></div>');
                        
                       
                     });



                   $.each(data,function(key,value){

                     console.log(value.name);


                      $('.gallerydetail__thumb').html('<div class="gallerythumb__slide"><img src=/uploads/'+value.name+' class="gallerythumb__img" ></div>');

                   });
                  }
  
                  }); 
               }


           });

            
         }
        

    $(document).ready(function(){
        $('.buttons').click(function(){
            $(this).addClass('active').siblings().removeClass('active');
            var filter = $(this).attr('data-filter')
            if(filter == 'all'){
                $('.image').show(400);
            }else{
                $('.image').not('.'+filter).hide(200);
                $('.image').filter('.'+filter).show(400);
            }
        });
    });

    var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });

        var _galleryOpenFunct = function(galleryid, openClose){
  
  openClose = openClose || true;

  var gallery__main  = galleryid+ ' .gallerydetail__main';
  var gallery__thumb = galleryid+ ' .gallerydetail__thumb';
  
  var $mainSlider  = $(galleryid).find('.gallerydetail__main');
  var $thumbSlider = $(galleryid).find('.gallerydetail__thumb');
  
  if( openClose === 'close' ){
    $mainSlider.slick('unslick');   
    $thumbSlider.slick('unslick');   
    return;
  }

  
  var $slider = $mainSlider
    .on('init', function(slick) {
        $(gallery__main).fadeIn(1000);
    })
    .slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: true,
      prevArrow: '<div class="gallerydetail__mainPrev gallerydetail__button"> <i class="fa fa-chevron-left" aria-hidden="true"></i> </div>',
      nextArrow: '<div class="gallerydetail__mainNext gallerydetail__button"> <i class="fa fa-chevron-right" aria-hidden="true"></i> </div>',
      autoplay: false,
      lazyLoad: 'ondemand',
      autoplaySpeed: 30000,
      speed: 600,
      asNavFor: gallery__thumb,
      adaptiveHeight: true
    });

  var $slider2 = $thumbSlider
    .on('init', function(slick) {
        $(gallery__thumb).fadeIn(1000);
    })
    .slick({
      slidesToShow: 5,
      variableWidth: true,
      slidesToScroll: 1,
      arrows: false,
      slidesToScroll: 1,
      lazyLoad: 'ondemand',
      asNavFor: gallery__main,
      dots: false,
      centerMode: false,
      focusOnSelect: true,
      infinite: true,
      adaptiveHeight: true
    });

  //remove active class from all thumbnail slides
  $(gallery__thumb+' .slick-slide').removeClass('slick-active');

  //set active class to first thumbnail slides
  $(gallery__thumb + ' .slick-slide[data-slick-index="0"]').addClass('slick-active-2');

  // On after slide change mark proper transitions on main slider
  $('.gallerydetail__main').on('afterChange', function (event, slick, currentSlide, nextSlide) {
    var currentSlideIndex =  $('.gallerydetail__main .slick-active').data('slick-index');
    $(gallery__main + ' .slick-slide[data-slick-index="'+(currentSlideIndex+1)+'"] img').addClass('nextImg')
    $(gallery__main + ' .slick-slide[data-slick-index="'+(currentSlideIndex-1)+'"] img').addClass('prevImg')
  });
     
  // On before slide change match active thumbnail to current slide
  $(gallery__main).on('beforeChange', function (event, slick, currentSlide, nextSlide) {
      var mySlideNumber = nextSlide;
    $(gallery__main + ' .slick-slide img').removeClass('nextImg');
    $(gallery__main + ' .slick-slide img').removeClass('prevImg');
   
      $(gallery__thumb + ' .slick-slide').removeClass('slick-active-2');

    $(gallery__thumb + ' .slick-slide[data-slick-index="'+(mySlideNumber)+'"]').addClass('slick-active-2');
    
      // $(gallery__thumb + ' .slick-slide').eq(mySlideNumber).addClass('slick-active');
  });
     
}


 function myFunction() {
             $('.galleryopener').click(function() {

            var pr_id= $(this).attr('id');
                  console.log(pr_id);
            if(pr_id){
                $.ajax({
                     url:'getgallery/'+pr_id,
                     type:'GET',
                     dataType:'json',       
                     success:function(data){
                     console.log(data);

                     $('#main_img').empty(); 
                        $('#scr_img').empty(); 
                     
                $.each(data,function(key,value){

                    

                  $('.gallerydetail__main').html('<div class="gallerymain__slide"><img src=/uploads/'+value.name+' class="gallerymain__img" id="main_img" ></div>')
                    });

                  $.each(data,function(key,value){
                      $('.gallerydetail__thumb').html('<div class="gallerythumb__slide"><img src=/uploads/'+value.name+' class="gallerythumb__img" id="scr_img"  ></div>');

                        });
                     }

                   }); 
                }
           });
         }



$('.galleryopener').magnificPopup({
  type:'inline',
  midClick: true,
  mainClass: 'gallerydialog',
  callbacks: {
    open: function() {
      // slicks the correct slider when magnific is opened
      _galleryOpenFunct( $(this)[0].currItem.src );
    },
    close: function() {
      // destroys theslick instance when closed
      _galleryOpenFunct( $(this)[0].currItem.src, 'close' );
    }
  }
});
    </script>
    
</body>
</html>