@extends('layouts.app')

@section('content')
    <div class="fixed">
        <div class="co-bg">
            <div class="bg-img">
                <div class="heading" data-aos="fade-right">
                    <h1>TRAINING</h1>
                </div>
            </div>
            <div class="set-bg">
                <ul type="none">
                    <li><a href="{{url('/')}}">Home</a></li>
                    <li>|</li>
                    <li>Training</li>
                </ul>
            </div>
        </div>
        <div class="co_training">
            <div class="container">
                <div class="test" data-aos="fade-left">
                    <h4>WHY CHOOSE US</h4>
                    <h1>One-Stop-Solution</h1>
                    <p>Experience the excellence of our dedicated developers, designers, and marketers who have a thorough knowledge of software applications. We can effectively address complex issues with dynamic training courses.</p>
                </div>
                <div class="row row1">
                    <div class="col-lg-6 col-md-6 col-12 type1" data-aos="fade-down">
                        <div class="type">
                            <div class="box1">
                                <h4>Web Design/Front-end Developer</h4>
                            </div>
                            <div class="course-content"data-aos="fade-up">
                                <ul>
                                    <li>HTML</li>
                                    <li>CSS</li>
                                    <li>Bootstrap</li>
                                    <li>Photoshop</li>
                                    <li>Jquery</li>
                                    <li>Interview Preparation</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12 type1" data-aos="fade-up">
                        <div class="type">
                            <div class="box1">
                                <h4>BDE- Business Development Services</h4>
                            </div>
                            <div class="course-content">
                                <ul>
                                    <li>Online Bidding</li>
                                    <li>Email Marketing</li>
                                    <li>Social Media Marketing</li>
                                    <li>Lead Generation</li>
                                    <li>Cold Calling</li>
                                    <li>Client Management Relationships</li>
                                    <li>Interview Preparation</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="co_type">
            <div class="container">
                <div class="row">
                    <div class="main">
                        <div class="slider slider-nav">
                            <div>
                                <div class="main-type">
                                    <div class="set-part-1">
                                        <div class="_icon">
                                            <i class="fas fa-layer-group"></i>
                                        </div>
                                        <div class="prg1">
                                            <h3>Web Designing</h3>
                                            <p>Learn web designing from scratch and build beautiful websites. </p>
                                        </div>
                                    </div>
                                    <div class="right-arrow">
                                        <div class="round">
                                            <span class="arrow primera next fa fa-long-arrow-right"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="main-type">
                                    <div class="set-part-1">
                                        <div class="_icon">
                                            <i class="fas fa-chart-area"></i>
                                        </div>
                                        <div class="prg1">
                                            <h3>BDE- Business Development Executive</h3>
                                            <p>Determine solutions to business problems with the BDE training course.</p>
                                        </div>
                                    </div>
                                    <div class="right-arrow">
                                        <div class="round">
                                            <span class="arrow primera next fa fa-long-arrow-right"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="main-type">
                                    <div class="set-part-1">
                                        <div class="_icon">
                                            <i class="fab fa-wordpress"></i>
                                        </div>
                                        <div class="prg1">
                                            <h3>Wordpress</h3>
                                            <p>The complete WordPress course from web development to content management.</p>
                                        </div>
                                    </div>
                                    <div class="right-arrow">
                                        <div class="round">
                                            <span class="arrow primera next fa fa-long-arrow-right"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="main-type">
                                    <div class="set-part-1">
                                        <div class="_icon">
                                            <i class="fab fa-php"></i>
                                        </div>
                                        <div class="prg1">
                                            <h3>PHP- Laravel, Codeigneter, CorePHP</h3>
                                            <p>A complete web development course for powerful web applications.</p>
                                        </div>
                                    </div>
                                    <div class="right-arrow">
                                        <div class="round">
                                            <span class="arrow primera next fa fa-long-arrow-right"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="main-type">
                                    <div class="set-part-1">
                                        <div class="_icon">
                                            <i class="fab fa-android"></i>
                                        </div>
                                        <div class="prg1">
                                            <h3>Android</h3>
                                            <p>Design and develop your app as a full-stack developer.</p>
                                        </div>
                                    </div>
                                    <div class="right-arrow">
                                        <div class="round">
                                            <span class="arrow primera next fa fa-long-arrow-right"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="main-type">
                                    <div class="set-part-1">
                                        <div class="_icon">
                                            <i class="fab fa-apple"></i>
                                        </div>
                                        <div class="prg1">
                                            <h3>iOS</h3>
                                            <p>Become an iOS developer by learning the basics of iOS app development.</p>
                                        </div>
                                    </div>
                                    <div class="right-arrow">
                                        <div class="round">
                                            <span class="arrow primera next fa fa-long-arrow-right"></span> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="co_invest">
            <div class="container">
                <h1 class="title-1" data-aos="fade-left">WHY DIGITAL INNOVATION?</h1>
                <div class="invest-tab">
                    <div class="row">
                        <div class="col-md-4" data-aos="fade-left">
                            <!-- Tabs nav -->
                            <div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
                                    <i class="fab1 fab fa-wikipedia-w"></i>
                                    <span>Online - Offline Courses</span>
                                </a>

                                <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">
                                    <i class="fab1 fab fa-gg"></i>
                                    <span>One-on-One Interaction</span>
                                </a>

                                <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                                    <i class="fab1 fas fa-balance-scale"></i>
                                    <span>Limited Batch</span>
                                </a>

                                <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">
                                    <i class="fab1 far fa-object-group"></i>
                                    <span>Guaranteed Job</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-8" data-aos="fade-right">
                            <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane active invest-bg" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-7 col-12">
                                            <div class="tab-color">
                                                <h2>Online - Offline Courses</h2>
                                                <p>For flexibility and convenience, we offer online and offline courses. Whatever you choose, interactive learning and collaborative sessions will follow you every step of the way.</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-5 col-12"></div>
                                    </div>
                                </div>
                    
                                <div class="tab-pane invest-bg" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-7 col-12">
                                            <div class="tab-color">
                                                <h2>One-on-One Interaction</h2>
                                                <p>We believe in having one-on-interaction with beginners, so they can fully master the materials on hand and rely on lesson others moving forward.</p> 
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-5 col-12"></div>
                                    </div>
                                </div>
                    
                                <div class="tab-pane invest-bg" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-7 col-12">
                                            <div class="tab-color">
                                                <h2>Limited Batch</h2>
                                                <p>We focus on a limited batch, not taking more than ten individuals per course. This way we get more opportunities to spend time with you with less disturbance and distractions.</p>  
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-5 col-12"></div>
                                    </div>
                                </div>
                    
                                <div class="tab-pane invest-bg" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-7 col-12">
                                            <div class="tab-color">
                                                <h2>Guaranteed Job</h2>
                                                <p> Whether you are from an IT background or non-IT background, our personalized courses and training methods have proven to employ our candidates in the IT industry and continue to do so. From personality development classes to group session discussions, we leave no stone unturned to make your dreams come true.</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-5 col-12"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

          AOS.init({
            duration: 1000,
            offset: 300
        });
        
        $('.slider-nav').slick({
            autoplay: false,
            autoplaySpeed:1500,
            slidesToShow: 3,
            slidesToScroll: 1,
            dots: true,
            focusOnSelect: true,
            responsive: [
            {
            breakpoint: 1200,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
           },
          {
            breakpoint: 1008,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
          },
           {
            breakpoint: 800,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
           },
          {
            breakpoint: 800,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
          },
          {
            breakpoint: 767,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
          }

          ]
          });

       
      var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
           });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
           });

    </script>
  
@endsection       
