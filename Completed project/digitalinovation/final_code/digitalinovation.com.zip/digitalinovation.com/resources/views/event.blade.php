
@extends('layouts.app')

@section('content')
    <div class="fixed">
        <div class="co-bg">
            <div class="bg-img">
                <div class="heading">
                    <h1>EVENT</h1>
                </div>
            </div>
            <div class="set-bg">
                <ul type="none">
                    <li><a href="http://www.digitalinovation.com">Home</a></li>
                    <li>|</li>
                    <li>Event</li>
                </ul>
            </div>
        </div>
        <div class="co_project">
            <div class="container">
                <div class="test">
                    <h4>CASE STUDIES</h4>
                    <h1>Latest Event</h1>
                </div>
                <div class="co_portfolio">
                    <div class="gallery">
                        <ul class="controls">

                            @foreach($event_type as $et)
                            <li class="buttons" data-filter="{{$et->sub_type}}">{{$et->type}}</li>
                         <!--    <li class="buttons" data-filter="spa">Anniversary celebration</li>
                            <li class="buttons" data-filter="Furniture">Diwali celebration</li>
                            <li class="buttons" data-filter="Decor">Birthday celebration</li>
 -->
                            @endforeach
                        </ul>
                        <div class="image-container">
                            @foreach($event_image as $e)
                            <a href="uploads/{{$e->image}}" class="image {{$e->event_subtype}}">
                                <div class="product-list set-product">
                                    <img src="uploads/{{$e->image}}" alt="">
                                    <div class="product-name">
                                        <i class="search far fa-search-plus"></i>
                                    </div>
                                </div>
                            </a>
                            @endforeach
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
                

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery.slick/1.5.9/slick.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
         <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

        $(document).ready(function(){
            $('.buttons').click(function(){
                $(this).addClass('active').siblings().removeClass('active');
                var filter = $(this).attr('data-filter')
                if(filter == 'all'){
                    $('.image').show(400);
                }else{
                    $('.image').not('.'+filter).hide(200);
                    $('.image').filter('.'+filter).show(400);
                }
            });
            $('.gallery').magnificPopup({
                delegate:'a',
                type:'image',
                gallery:{
                    enabled:true
                }
            });
        });

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });


           $('.nav li a').click(function(){
  
     $('.tab-pane').hide();
     $('.nav li a.active').removeClass('active');
     $(this).addClass('active');
     
     var panel = $(this).attr('href');
     $(panel).fadeIn(1000);
     
     return false;  // prevents link action
    
  });  // end click 

   $('.nav li:first a').click();


    </script>
    
@endsection