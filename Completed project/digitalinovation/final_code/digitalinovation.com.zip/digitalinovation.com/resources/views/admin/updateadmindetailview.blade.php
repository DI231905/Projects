<!DOCTYPE html>
<html>
<head>
    <title>Digital Innovation</title>
    <link rel="stylesheet" type="text/css" href="/css/admin.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
      <link rel="icon" type="image/png" href="/image/logo1.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
            @foreach ($errors->all() as $error)
                <li  style="color:red;">{{ $error }}</li>
            @endforeach
            </ul>
        </div>
    @endif 
    <div class="main-form">
        <div class="form">
            <h2>  UPDATE ADMIN CONTACT DETAIL</h2>
            @if(session()->has('error'))
                <div class="alert alert-danger">
                    {{ session()->get('error') }}
                </div>
            @endif

            <form method="POST" action="{{url('admin/storeadmindetail')}}/{{$id}}" class="form1">
              @csrf

                <div class="email">
                    <div class="icon">
                       <i class="fa fa-user" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Name" name="name" value="{{$name}}" required>
                    </div>  
                </div>
                <div class="email">
                    <div class="icon">
                       <i class="fa fa-envelope-o" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Email" name="email" value="{{$email}}" required>
                    </div>  
                </div>
                <div class="email">
                    <div class="icon">
                       <i class="fa fa-phone" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Enter your mobile no" name="mobileno" value="{{$mobileno}}" required>
                    </div> 
                </div>
                <div class="email">
                    <div class="icon">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <textarea placeholder="Enter here... " name="address" value="{{$address}}"required>{{$address}}</textarea>
                    </div> 
                </div>
                 <div class="email">
                    <div class="icon">
                       <i class="fab fa-twitter" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Enter your twitter url" name="twitter_id" value="{{$twitter_id}}">
                    </div> 
                </div>
                 <div class="email">
                    <div class="icon">
                       <i class="fab fa-instagram" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Enter your instagram url" name="insta_id" value="{{$insta_id}}" >
                    </div> 
                </div>
                 <div class="email">
                    <div class="icon">
                       <i class="fab fa-google-plus-g" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Enter your google url" name="google_id" value="{{$google_id}}" >
                    </div> 
                </div>
                 <div class="email">
                    <div class="icon">
                       <i class="fab fa-facebook-f" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Enter your Facebook url" name="fb_id" value="{{$fb_id}}" >
                    </div> 
                </div>
                <div class="forgot">
                    <a href="{{url('admin/home')}}">Back to Home ?</a>
                </div>
                    <button class="btn" name="submit">submit</button>
            </form>
        </div>
    </div>
</body>
</html>