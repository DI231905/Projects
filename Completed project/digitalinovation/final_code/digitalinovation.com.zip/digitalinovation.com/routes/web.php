<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\userController;
use App\Http\Controllers\Auth\Adminlogincontroller;
use App\Http\Controllers\Admin\Admincontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[userController::class, 'index']);
Route::get('/About',[userController::class, 'About']);
Route::get('/Service',[userController::class, 'Service']);
Route::get('/Portfolio',[userController::class, 'Portfolio']);
Route::get('/Training',[userController::class, 'Training']);
Route::get('/Team',[userController::class, 'Team']);
Route::get('/Contact',[userController::class, 'Contact']);
Route::post('/Contactusfrom',[userController::class, 'contactusfrom']);
Route::get('/getgallery/{id}',[userController::class, 'getgallery']);
Route::get('/event',[userController::class, 'event']);



           ///////////   Admin view /////////////////////
Route::prefix('admin')->group(function(){

        
Route::get('/login',[Adminlogincontroller::class, 'login']);
Route::post('/login',[Adminlogincontroller::class, 'authenticate'])->name('login');
Route::get('/logout',[Adminlogincontroller::class, 'logout'])->name('adminlogout');
Route::get('/home',[Admincontroller::class, 'home']);
Route::get('/forgetpasswordview',[Adminlogincontroller::class, 'forgetpasswordview'])->name('forgetpasswordview');
Route::post('/resetpasswordlink',[Adminlogincontroller::class, 'resetpasswordlink'])->name('resetpasswordlink');

Route::get('/resetpasswordview/{id}',[Adminlogincontroller::class, 'resetpasswordview'])->name('resetpasswordview');
Route::post('/resetpassword',[Adminlogincontroller::class, 'resetpassword'])->name('resetpassword');
Route::get('/changepassword',[Admincontroller::class, 'changepassword']);
Route::post('/updatepassword/{id}',[Admincontroller::class, 'updatepassword']);
Route::get('/updateadmindetail/{id}',[Admincontroller::class, 'updateadmindetail']);
Route::post('/storeadmindetail/{id}',[Admincontroller::class, 'storeadmindetail']);
Route::get('/deletecontactus/{id}',[Admincontroller::class, 'deletecontactus']);
Route::get('/teamview',[Admincontroller::class, 'teamview']);
Route::post('/addteam',[Admincontroller::class, 'addteam']);
Route::get('/teamdelete/{id}',[Admincontroller::class, 'teamdelete']);
Route::get('/teamupdate/{id}',[Admincontroller::class, 'teamupdateview']);
Route::post('/storeupdateteam/{id}',[Admincontroller::class, 'storeupdateteam']);
Route::get('/addprotfolio',[Admincontroller::class, 'addprotfolio']);
Route::post('/storeprotfolio',[Admincontroller::class, 'storeprotfolio']);
Route::get('/deleteprotfolio/{id}',[Admincontroller::class, 'deleteprotfolio']);
Route::get('/updateprotfolio/{id}',[Admincontroller::class, 'updateprotfolio']);
Route::get('/deleteimage/{id}',[Admincontroller::class, 'imageDelete']);
Route::post('/storeupdateprotfolio/{id}',[Admincontroller::class, 'storeupdateprotfolio']);
Route::get('/addtestimonial',[Admincontroller::class, 'addtestimonial']);
Route::post('/storetestimonial',[Admincontroller::class, 'storetestimonial']);
Route::get('/deletetestimonial/{id}',[Admincontroller::class, 'deletetestimonial']);
Route::get('/updatetestimonial/{id}',[Admincontroller::class, 'updatetestimonial']);
Route::post('/storeupdatetestimonial/{id}',[Admincontroller::class, 'storeupdatetestimonial']);
Route::get('/addevent',[Admincontroller::class, 'addevent']);
Route::post('/storeevent',[Admincontroller::class, 'storeevent']);
Route::get('/delete_image/{id}',[Admincontroller::class, 'delete_image']);











 }); 



 
 