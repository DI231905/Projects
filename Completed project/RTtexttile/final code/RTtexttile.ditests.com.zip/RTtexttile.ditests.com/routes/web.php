<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\Admincontroller;
use App\Http\Controllers\Auth\Adminlogincontroller;
use App\Http\Controllers\Admin\HomeController;
use App\Http\Controllers\Admin\AboutUsController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\MediaController;
use App\Http\Controllers\Admin\BlogsController;
use App\Http\Controllers\Admin\ContactUsController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Auth\AuthController;





/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[UserController::class, 'index']);
Route::get('/about_us',[UserController::class, 'about_us']);
Route::get('/who_we_are',[UserController::class, 'who_we_are']);
Route::get('/rt_story',[UserController::class, 'rt_story']);
Route::get('/mission_vision',[UserController::class, 'mission_vision']);
Route::get('/media',[UserController::class, 'media']);
Route::get('/certification',[UserController::class, 'certification']);
Route::get('/csr',[UserController::class, 'csr']);
Route::get('/product',[UserController::class, 'product']);
Route::get('/product_detail/{id}',[UserController::class, 'product_detail']);
Route::get('/contact_us',[UserController::class, 'contact_us']);
Route::post('/store_contact_us',[UserController::class, 'store_contact_us']);
Route::get('/search',[UserController::class, 'search']);





Route::prefix('admin')->group(function(){

Route::get('/login',[Adminlogincontroller::class, 'login']);
Route::post('/login',[Adminlogincontroller::class, 'authenticate'])->name('login');
Route::get('/logout',[Adminlogincontroller::class, 'logout'])->name('adminlogout');


Route::get('/forgetpasswordview',[Adminlogincontroller::class, 'forgetpasswordview'])->name('forgetpasswordview');
Route::post('/resetpasswordlink',[Adminlogincontroller::class, 'resetpasswordlink'])->name('resetpasswordlink');

Route::get('/resetpasswordview/{id}',[Adminlogincontroller::class, 'resetpasswordview'])->name('resetpasswordview');
Route::post('/resetpassword/{id}',[Adminlogincontroller::class, 'resetpassword'])->name('resetpassword');

Route::get('/changepassword',[Admincontroller::class, 'changepassword']);
Route::post('/updatepassword/{id}',[Admincontroller::class, 'updatepassword']);

Route::get('/home',[Admincontroller::class, 'home']);

Route::get('/viewBannerlist',[HomeController::class, 'viewBannerlist']);
Route::get('/addhomebanner',[HomeController::class, 'addhomebanner']);
Route::post('/storehomebanner',[HomeController::class,'storehomebanner']);
Route::get('/updatebanner/{id}',[HomeController::class, 'updatebanner']);
Route::post('/storeupdatebanner/{id}',[HomeController::class, 'storeupdatebanner']);
Route::get('/deletemaintitle/{id}',[HomeController::class,'deletemaintitle']);
Route::get('/deletehomebannerdata/{id}',[HomeController::class, 'deletehomebanner']);

Route::get('/home_about_us',[HomeController::class, 'home_about_us']);
Route::get('/update_home_about_us/{id}',[HomeController::class, 'update_home_about_us']);
Route::post('/store_home_aboutus/{id}',[HomeController::class, 'store_home_aboutus']);

Route::get('/addfeatures',[HomeController::class, 'addfeatures']);
Route::post('/storefeatures',[HomeController::class, 'storefeatures']);
Route::get('/deletefeatures/{id}',[HomeController::class, 'deletefeatures']);
Route::get('/updatefeatures/{id}',[HomeController::class, 'updatefeatures']);
Route::post('/storeupdatefeatures/{id}',[HomeController::class, 'storeupdatefeatures']);


Route::get('/achieve_target',[HomeController::class, 'achieve_target']); 
Route::get('/add_achieve_target',[HomeController::class, 'add_achieve_target']); 
Route::post('/store_achieve_target',[HomeController::class, 'store_achieve_target']); 
Route::get('/delete_achieve_target/{id}',[HomeController::class, 'delete_achieve_target']);  
Route::get('/update_achieve_target/{id}',[HomeController::class, 'update_achieve_target']);  
Route::post('/store_update_achieve_target/{id}',[HomeController::class, 'store_update_achieve_target']); 

Route::get('/update_achieve_desc/{id}',[HomeController::class, 'update_achieve_desc']);
Route::post('/store_update_achieve_desc/{id}',[HomeController::class, 'store_update_achieve_desc']);


Route::get('/product_desc',[HomeController::class, 'product_desc']); 
Route::get('/update_product_desc/{id}',[HomeController::class, 'update_product_desc']);
Route::post('/store_update_product_desc/{id}',[HomeController::class, 'store_update_product_desc']);

Route::get('/admincontactview',[Admincontroller::class, 'admincontactview']);
Route::get('/updateadmincontact/{id}',[Admincontroller::class,'updateadmincontact']);
Route::post('/storeadmincontact/{id}',[Admincontroller::class, 'storeadmincontact']);
Route::get('/updateadmincontact/delete_mobileno/{id}',[Admincontroller::class,'delete_mobileno']);
Route::get('/updateadmincontact/delete_address/{id}',[Admincontroller::class,'delete_address']);
Route::get('/update_address/{id}',[Admincontroller::class,'update_address']);
Route::post('/store_address/{id}',[Admincontroller::class,'store_address']);

Route::get('/about_section',[AboutUsController::class, 'about_section']); 
Route::get('/add_about_section',[AboutUsController::class, 'add_about_section']); 
Route::post('/store_about_section',[AboutUsController::class, 'store_about_section']); 
Route::get('/delete_about_section/{id}',[AboutUsController::class, 'delete_about_section']);  
Route::get('/update_about_section/{id}',[AboutUsController::class, 'update_about_section']);  
Route::post('/store_update_abou_section/{id}',[AboutUsController::class, 'store_update_about_section']); 


Route::get('/aboutusBannerlist',[AboutUsController::class, 'aboutusBannerlist']);
Route::get('/updatebannerimg/{id}',[AboutUsController::class,'updatebannerimg']);
Route::post('/storeupdatebannerimg/{id}',[AboutUsController::class,'storeupdatebannerimg']);

Route::get('/who_we_are',[AboutUsController::class, 'who_we_are']);
Route::get('/update_who_we_are/{id}',[AboutUsController::class,'update_who_we_are']);
Route::post('/store_who_we_are/{id}',[AboutUsController::class,'store_who_we_are']);

Route::get('/rt_history',[AboutUsController::class, 'rt_history']);
Route::get('/update_rt_history_desc/{id}',[AboutUsController::class,'update_rt_history_desc']);
Route::post('/store_rt_history_desc/{id}',[AboutUsController::class,'store_rt_history_desc']);


Route::get('/add_history',[AboutUsController::class, 'add_history']);
Route::post('/store_history',[AboutUsController::class, 'store_history']);
Route::get('/delete_history/{id}',[AboutUsController::class, 'delete_history']);
Route::get('/update_history/{id}',[AboutUsController::class, 'update_history']);
Route::post('/store_update_history/{id}',[AboutUsController::class, 'store_update_history']);

Route::get('/mission_vission',[AboutUsController::class, 'mission_vission']);
Route::get('/add_mission_vission',[AboutUsController::class, 'add_mission_vission']);
Route::post('/store_mission_vission',[AboutUsController::class, 'store_mission_vission']);
Route::get('/delete_mission_vission/{id}',[AboutUsController::class, 'delete_mission_vission']);
Route::get('/update_mission_vission/{id}',[AboutUsController::class, 'update_mission_vission']);
Route::post('/store_update_mission_vission/{id}',[AboutUsController::class, 'store_update_mission_vission']);

Route::get('/media_banner',[MediaController::class, 'media_banner']);
Route::get('/media_section',[MediaController::class, 'media_section']); 
Route::get('/add_media_section',[MediaController::class, 'add_media_section']); 
Route::post('/store_media_section',[MediaController::class, 'store_media_section']); 
Route::get('/delete_media_section/{id}',[MediaController::class, 'delete_media_section']);  
Route::get('/update_media_section/{id}',[MediaController::class, 'update_media_section']);  
Route::post('/store_update_media_section/{id}',[MediaController::class, 'store_update_media_section']); 

Route::get('/certificate',[MediaController::class, 'certificate']);
Route::get('/add_certificate',[MediaController::class, 'add_certificate']); 
Route::post('/store_certificate',[MediaController::class, 'store_certificate']); 
Route::get('/delete_certificate/{id}',[MediaController::class, 'delete_certificate']);  

Route::get('/csr_banner',[MediaController::class, 'csr_banner']);
Route::get('/csr_description',[MediaController::class, 'csr_description']); 
Route::get('/update_csr_description/{id}',[MediaController::class, 'update_csr_description']);  
Route::post('/store_update_csr_description/{id}',[MediaController::class, 'store_update_csr_description']); 

Route::get('/csr_initiative',[MediaController::class, 'csr_initiative']);
Route::get('/add_csr_initiative',[MediaController::class, 'add_csr_initiative']);
Route::post('/store_csr_initiative',[MediaController::class, 'store_csr_initiative']);
Route::get('/delete_csr_initiative/{id}',[MediaController::class, 'delete_csr_initiative']);
Route::get('/update_csr_initiative/{id}',[MediaController::class, 'update_csr_initiative']);
Route::post('/store_update_csr_initiative/{id}',[MediaController::class, 'store_update_csr_initiative']);

Route::get('/update_csr_initiative_image/{id}',[MediaController::class, 'update_csr_initiative_image']);
Route::post('/store_csr_initiative_image/{id}',[MediaController::class, 'store_csr_initiative_image']);

Route::get('/product',[ProductController::class, 'product']);
Route::get('/add_product',[ProductController::class, 'add_product']);
Route::post('/store_product',[ProductController::class, 'store_product']);
Route::get('/update_product/{id}',[ProductController::class,'update_product']);
Route::post('/store_update_product/{id}',[ProductController::class, 'store_update_product']);
Route::get('/delete_product/{id}',[ProductController::class, 'delete_product']);
Route::get('/view_product/{id}',[ProductController::class, 'view_product']);













Route::get('/viewFeaturelist',[HomeController::class, 'viewFeaturelist']);                                                  
Route::get('/key_features',[HomeController::class, 'key_features']);
Route::get('/update_key_features/{id}',[HomeController::class, 'update_key_features']);
Route::post('/store_key_features/{id}',[HomeController::class, 'store_key_features']);
Route::get('/delete_description/{id}',[HomeController::class, 'delete_description']);





Route::get('/investment_process',[HomeController::class, 'investment_process']); 
Route::get('/update_investment_process/{id}',[HomeController::class, 'update_investment_process']);
Route::post('/store_investment_process/{id}',[HomeController::class, 'store_investment_process']); 


Route::get('/add_investment_process',[HomeController::class, 'add_investment_process']); 
Route::post('/store_investment_process_step',[HomeController::class, 'store_investment_process_step']); 
Route::get('/delete_process_step/{id}',[HomeController::class, 'delete_process_step']); 
Route::get('/update_process_step/{id}',[HomeController::class, 'update_process_step']);  
Route::post('/store_update_process_step/{id}',[HomeController::class, 'store_update_process_step']);  





Route::get('/view_skillset',[HomeController::class, 'view_skillset']);
Route::get('/add_new_skillset',[HomeController::class, 'add_new_skillset']);
Route::post('/store_skillset',[HomeController::class, 'store_skillset']);
Route::get('/update_skillset/{id}',[HomeController::class,'update_skillset']);
Route::post('/store_update_skillset/{id}',[HomeController::class, 'store_update_skillset']);
Route::get('/delete_skillset/{id}',[HomeController::class, 'delete_skillset']);


Route::get('/view_benefits',[AboutUsController::class, 'view_benefits']);
Route::get('/add_benefits',[AboutUsController::class, 'add_benefits']);
Route::post('/store_benefits',[AboutUsController::class, 'store_benefits']);
Route::get('/update_benefits/{id}',[AboutUsController::class,'update_benefits']);
Route::post('/store_update_benefits/{id}',[AboutUsController::class, 'store_update_benefits']);
Route::get('/delete_benefits/{id}',[AboutUsController::class, 'delete_benefits']);

Route::get('/view_whychooseus',[AboutUsController::class, 'view_whychooseus']);
Route::get('/add_whychooseus',[AboutUsController::class, 'add_whychooseus']);
Route::post('/store_whychooseus',[AboutUsController::class, 'store_whychooseus']);
Route::get('/update_whychooseus/{id}',[AboutUsController::class,'update_whychooseus']);
Route::post('/store_update_whychooseus/{id}',[AboutUsController::class, 'store_update_whychooseus']);
Route::get('/delete_whychooseus/{id}',[AboutUsController::class, 'delete_whychooseus']);

Route::get('/view_performance',[AboutUsController::class, 'view_performance']);
Route::get('/update_performance/{id}',[AboutUsController::class,'update_performance']);
Route::post('/store_update_performance/{id}',[AboutUsController::class, 'store_update_performance']);


Route::get('/servicesBannerlist',[ServiceController::class, 'servicesBannerlist']);



Route::get('/view_service',[ServiceController::class, 'view_service']);
Route::get('/add_service',[ServiceController::class, 'add_service']);
Route::post('/store_service',[ServiceController::class, 'store_service']);
Route::get('/update_service/{id}',[ServiceController::class,'update_service']);
Route::post('/store_update_service/{id}',[ServiceController::class, 'store_update_service']);
Route::get('/delete_service/{id}',[ServiceController::class, 'delete_service']);


Route::get('/service_about_us',[ServiceController::class, 'service_about_us']);
Route::get('/update_service_about_us/{id}',[ServiceController::class, 'update_service_about_us']);
Route::get('/update_service_about_image/{id}',[ServiceController::class, 'update_service_about_us_image']);
Route::post('/store_service_about_image/{id}',[ServiceController::class, 'store_service_about_image']);
Route::post('/store_service_aboutus/{id}',[ServiceController::class, 'store_service_aboutus']);

Route::get('/blogsBannerlist',[BlogsController::class, 'blogsBannerlist']);
Route::get('/ContactUsBannerlist',[ContactUsController::class, 'ContactUsBannerlist']);


Route::get('/footer_data_list',[Admincontroller::class,'footer_data_list']);
Route::get('/update_footer_data/{id}',[Admincontroller::class,'update_footer_data']);
Route::post('/store_update_footer_data/{id}',[Admincontroller::class,'store_update_footer_data']);




Route::get('/viewblog',[BlogsController::class, 'viewblog']);
Route::get('/addblog',[BlogsController::class, 'addblog']);
Route::post('/storeblog',[BlogsController::class, 'storeblog']);
Route::get('/updateblog/{id}',[BlogsController::class,'updateblog']);
Route::post('/storeupdateblog/{id}',[BlogsController::class, 'storeupdateblog']);
Route::get('/deleteblog/{id}',[BlogsController::class, 'deleteblog']);

Route::get('/view_get_in_touch',[AboutUsController::class, 'view_get_in_touch']);
Route::get('/delete_get_in_touch/{id}',[AboutUsController::class, 'delete_get_in_touch']);

Route::get('/view_contact_us_msg',[ContactUsController::class, 'view_contact_us_msg']);
Route::get('/delete_contact_us/{id}',[ContactUsController::class, 'delete_contact_us']);















 }); 

