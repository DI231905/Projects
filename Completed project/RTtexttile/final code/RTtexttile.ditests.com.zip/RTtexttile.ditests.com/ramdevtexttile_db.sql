-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 26, 2022 at 06:08 AM
-- Server version: 5.7.36-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ramdevtexttile_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_section`
--

CREATE TABLE `about_section` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `about_section`
--

INSERT INTO `about_section` (`id`, `image`, `title`) VALUES
(4, '1648012741_air-covered-yarn.jpg', 'WHO WE ARE'),
(5, '1648012756_product1.jpg', 'THE RT STORY'),
(6, '1648012769_product3.jpg', 'VISION & MISSION');

-- --------------------------------------------------------

--
-- Table structure for table `achieve_target_desc`
--

CREATE TABLE `achieve_target_desc` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `main_title` varchar(255) DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `achieve_target_desc`
--

INSERT INTO `achieve_target_desc` (`id`, `title`, `main_title`, `description`) VALUES
(1, 'WELCOME TO', 'Ramdev Traders', '<span style=\"color: rgb(33, 37, 41); font-family: \"Source Sans Pro\", sans-serif; font-size: 16px; letter-spacing: 0.5px; text-align: center; background-color: rgb(245, 248, 251);\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</span>');

-- --------------------------------------------------------

--
-- Table structure for table `achive_target`
--

CREATE TABLE `achive_target` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `achive_target`
--

INSERT INTO `achive_target` (`id`, `title`, `value`, `created_at`, `updated_at`) VALUES
(3, 'CUSTOMERS', '500', NULL, NULL),
(4, 'PRODUCTS', '75', NULL, NULL),
(5, 'EXPERIENCE', '15', NULL, NULL),
(6, 'WORKFORCE', '150', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `address`, `admin_id`) VALUES
(13, 'Laxmi Enklev 2, 5th floor, Office No-516\r\nNear Gajera School, Katargam Surat, 395004', 1),
(14, '44-45, Samir industrialestate, section- 3\r\n Navapara, kim, 394111', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_day` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_certification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`id`, `name`, `email`, `opening_day`, `opening_time`, `company_type`, `company_certification`, `created_at`, `updated_at`) VALUES
(1, 'Ramdev Traders', 'Ramdev87@gmail.com', 'MONDAY TO SATURDAY', '10:00 to 19:00', 'Manufacturer & Exporters of Polyester Yarns', 'An ISO 9001-2015 Certified Company', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `token`, `created_at`, `updated_at`) VALUES
(1, 'apptest', 'apptest2303@gmail.com', '$2y$10$lv9YKyRLCAbtc0k4DtSmrOsqzG12oJrPH1bMrj5lQe/ueR43ucm7.', '9593', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `image`, `title`, `created_at`, `updated_at`) VALUES
(2, '1648114229_banner-2.jpg', 'home', NULL, NULL),
(3, '1647951237_banner-3.jpg', 'home', NULL, NULL),
(4, '1647951243_banner-1.jpg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `banner_image`
--

CREATE TABLE `banner_image` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `page_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner_image`
--

INSERT INTO `banner_image` (`id`, `name`, `image`, `page_name`) VALUES
(2, 'Who We Are', '1647320466_banner-1 (1).jpg', 'Who We Are'),
(3, 'The RT Story', '1647328539_banner-1 (1).jpg', 'The RT Story'),
(4, 'About Us', '1647278244_banner-1.jpg', 'About Us'),
(5, 'Contact Us', '1647946778_banner-1 (1).jpg', 'Contact Us'),
(6, 'Media', '1647348651_banner-1 (1).jpg', 'Media'),
(8, 'Vision & Mission', '1647347621_banner-1 (1).jpg', 'Vision & Mission'),
(9, 'Certifications', '1647414771_banner-1 (1).jpg', 'Certifications'),
(10, 'CSR', '1647416098_banner-1 (1).jpg', 'CSR');

-- --------------------------------------------------------

--
-- Table structure for table `certificate`
--

CREATE TABLE `certificate` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `certificate`
--

INSERT INTO `certificate` (`id`, `image`) VALUES
(4, '1647414315_certi-1.jpg'),
(5, '1647414315_certi-2.jpg'),
(6, '1647414315_certi-3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `subject` text,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `csr_description`
--

CREATE TABLE `csr_description` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `csr_description`
--

INSERT INTO `csr_description` (`id`, `title`, `description`) VALUES
(1, 'CSR', '<p style=\"font-size: 16px; line-height: 26px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 20px; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p><p style=\"font-size: 16px; line-height: 26px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 20px; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `csr_initiative`
--

CREATE TABLE `csr_initiative` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `main_title` text,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `csr_initiative`
--

INSERT INTO `csr_initiative` (`id`, `title`, `main_title`, `description`) VALUES
(4, 'EDUCATION', 'We believe that education is everyone’s right. VPPL focus on children, youth, and adult of rural and tribal society so that they have a positive impact on their life.', '<ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">We are closely coordinating with EKAL VIDYALAYA in their program “Van Bandhu Parishad”. The main aim of the program is to educate the children and adults of the tribal society so as to achieve a better future for them.</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Made a considerable donation to AGARWAL EDUCATION FOUNDATION an educational institute to provide the best educational services to the youth of the Community and Society.</li></ul>'),
(5, 'HEALTHCARE FACILITIES', 'HEALTHCARE FACILITIES', '<ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">Vineet Polyfab believes in “Life is the birth right of every individual”. To enhance healthcare facilities in the locality, VPPL has provided Financial Support to Shri Prannath Multispecialty Hospital, Ved Road, Surat for advance machines and equipments. Our financial support extends even further to the needy patients who cannot afford to pay their medical bills for treatments.</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">During the second wave of covid-19 in India and looking at the situation of the country and need of the hour Vineet Polyfab Stepped up Voluntarily by donating oxygen cylinders, oxygen concentrators and a ventilator to various healthcare organisation in the city of Surat.</li></ul>');

-- --------------------------------------------------------

--
-- Table structure for table `csr_initiative_image`
--

CREATE TABLE `csr_initiative_image` (
  `id` int(11) NOT NULL,
  `csr_initiative_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `csr_initiative_image`
--

INSERT INTO `csr_initiative_image` (`id`, `csr_initiative_id`, `image`) VALUES
(4, 5, '1647932369_csr1.jpeg'),
(5, 5, '1647932369_csr2.jpeg'),
(6, 5, '1647932369_csr3.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`id`, `icon`, `title`, `description`, `created_at`, `updated_at`) VALUES
(9, 'far fa-check-square', 'Product Research', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', NULL, NULL),
(10, 'fas fa-headphones-alt', 'Product Support', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', NULL, NULL),
(11, 'far fa-check-square', 'Quality Products', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', NULL, NULL),
(12, 'fas fa-network-wired', 'Strong Network', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `footer_data`
--

CREATE TABLE `footer_data` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `footer_data`
--

INSERT INTO `footer_data` (`id`, `title`, `image`, `description`) VALUES
(1, 'About Us', '1647254802_logo.png', '<p><span style=\"color: rgb(248, 249, 250); font-family: &quot;Source Sans Pro&quot;, sans-serif; font-size: 16px; letter-spacing: 0.5px;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley</span><br></p>');

-- --------------------------------------------------------

--
-- Table structure for table `history_data`
--

CREATE TABLE `history_data` (
  `id` int(11) NOT NULL,
  `year` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history_data`
--

INSERT INTO `history_data` (`id`, `year`, `title`, `description`) VALUES
(2, '2010', 'Lorem Ipsum Is Simply', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'),
(3, '2011', 'Lorem Ipsum Is Simply', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'),
(4, '2012', 'Lorem Ipsum Is Simply', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'),
(5, '2013', 'Lorem Ipsum Is Simply', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.'),
(6, '2014', 'Lorem Ipsum is simply', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.');

-- --------------------------------------------------------

--
-- Table structure for table `history_desciption`
--

CREATE TABLE `history_desciption` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history_desciption`
--

INSERT INTO `history_desciption` (`id`, `title`, `description`) VALUES
(1, 'RT History', '<span style=\"color: rgb(33, 37, 41); font-family: &quot;Source Sans Pro&quot;, sans-serif; letter-spacing: 0.5px;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>');

-- --------------------------------------------------------

--
-- Table structure for table `home_aboutus`
--

CREATE TABLE `home_aboutus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `home_aboutus`
--

INSERT INTO `home_aboutus` (`id`, `image`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, '1647173881_about-1.jpg', 'One Of The Best Yarn Manufacturing Company In India', '<span style=\"color: rgb(33, 37, 41); font-family: &quot;Source Sans Pro&quot;, sans-serif; font-size: 16px; letter-spacing: 0.5px;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type</span>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `media_section`
--

CREATE TABLE `media_section` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `media_section`
--

INSERT INTO `media_section` (`id`, `image`, `title`) VALUES
(2, '1648017003_certi-1.jpg', 'Certfications');

-- --------------------------------------------------------

--
-- Table structure for table `mission_vision`
--

CREATE TABLE `mission_vision` (
  `id` int(11) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mission_vision`
--

INSERT INTO `mission_vision` (`id`, `icon`, `title`, `description`) VALUES
(1, 'fa fa-eye', 'OUR VISION', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,'),
(2, 'fa fa-bullseye', 'OUR MISSION', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,');

-- --------------------------------------------------------

--
-- Table structure for table `more_maintitle`
--

CREATE TABLE `more_maintitle` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `more_maintitle` text COLLATE utf8mb4_unicode_ci,
  `banner_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phone_no`
--

CREATE TABLE `phone_no` (
  `id` int(11) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phone_no`
--

INSERT INTO `phone_no` (`id`, `phone`, `admin_id`) VALUES
(7, '+91 97127 87287', 1),
(8, '+91 7096287287', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `specification` text,
  `features` text,
  `application` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `banner_image`, `product_image`, `name`, `description`, `specification`, `features`, `application`) VALUES
(3, '1647946279_banner-1.jpg', '1647946279_product3.jpg', 'GRS Certified Yarns', '<p><span style=\"color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; letter-spacing: 0.5px; text-align: center;\">We manufacture and supply Global Recycle Standard eco-friendly yarn. VPPL has adopted the latest equipment and technology to ensure the sustainable production of eco-friendly yarns. The aim of our team is to produce low-cost high-quality polyester yarn using different deniers and at the same time fulfill our social responsibility. We make sure that no hazardous material is used or produced during the manufacturing of regenerated yarn!</span><br></p>', '<p style=\"display: block; position: relative; padding-bottom: 10px;\"></p><p style=\"font-size: 18px; line-height: 1; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(29, 117, 202); font-weight: 600; width: 756px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">DTY is used widely in various industries like</p><p style=\"font-size: 18px; line-height: 1; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(29, 117, 202); font-weight: 600; width: 756px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"><span style=\"font-size: 16px; font-weight: 400;\">Denier range: 75 to 600<br></span></p><p style=\"font-size: 18px; line-height: 29px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(29, 117, 202); font-weight: 600; width: 756px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"><span style=\"color: rgb(29, 117, 202);\">These yarns can be provided in Raw White, Package Dyed &amp; Space dyed can be made in NIM, SIM, or HIM.</span></p><p style=\"display: block; position: relative; padding-bottom: 10px;\">Filaments range: 36 to 288<br></p><ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-bottom: 1rem; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"></ul><p style=\"display: block; position: relative; padding-bottom: 10px;\">Plies: from 1 to 2 plies</p><p style=\"display: block; position: relative; padding-bottom: 10px;\">Luster: Semi-Dull</p><p style=\"display: block; position: relative; padding-bottom: 10px;\">Variations: S or Z twist, low oil, oil-less</p><p style=\"display: block; position: relative; padding-bottom: 10px;\">NIM (Non-Intermingled Yarns )</p><p style=\"display: block; position: relative; padding-bottom: 10px;\">SIM ( Slight Intermingled Yarns )</p><p style=\"display: block; position: relative; padding-bottom: 10px;\">HIM ( Highly Intermingled Yarns )</p>', '<ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">Eco-friendly.</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Reduce greenhouse gas emissions.</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Processed from 100% recycled PET bottles.</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Smooth and tight shape using a great rewinding machine.</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">No harm to skin and no fading.</li></ul>', '<p style=\"font-size: 18px; line-height: 29px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(29, 117, 202); font-weight: 600; width: 756px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">GRS is used widely in various industries like</p><ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">Eco-clothing</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Footwear and leather goods</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Automotive</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Workwear</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Home textile</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Accessories and trimming</li></ul>'),
(4, '1647946455_banner-1 (1).jpg', '1647946455_product1.jpg', 'Draw Texturized Yarn', '<p style=\"text-align: center; \"><font color=\"#212529\" face=\"Source Sans Pro, sans-serif\"><span style=\"font-size: 16px; letter-spacing: 0.5px;\">DTY (Draw Texturized Yarn) is the basic and most used yarn made by drawing and twisting the POY (Partially Oriented Yarn). The varieties of textile yarns can be generated by adjusting the levels of drawing and twisting of the yarn as per the end use.</span></font><br></p>', '<ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">Denier range: 30 to 1800</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Filaments range: 14 to 576</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Plies: from 2 to 6 plies</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Luster: Semi-Dull, Full Dull, Trilobal Bright, Cationic, Bright Cationic, etc</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Variations: S or Z twist, low oil, oil-less, High Stretch, High Shrinkage, Twisted (TPM), Plastic Perforated tube, etc</li></ul><p style=\"font-size: 18px; line-height: 29px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(29, 117, 202); font-weight: 600; width: 756px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">These yarns can be provided in Raw White, Dope Dyed, Package Dyed &amp; Space dyed Can be made in NIM, SIM (LIM), or HIM</p><ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">NIM (Non-Intermingled Yarns)</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">SIM (Slight Intermingled Yarns)</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">HIM (Highly Intermingled Yarns)</li></ul>', NULL, '<p style=\"font-size: 18px; line-height: 29px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(29, 117, 202); font-weight: 600; width: 756px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">DTY is used widely in various industries like</p><p style=\"font-size: 18px; line-height: 29px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(29, 117, 202); font-weight: 600; width: 756px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"><span style=\"font-size: 16px; font-weight: 400;\">Garments</span></p><ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">Home Textiles</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Knitted Fabrics</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Upholstery</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Socks</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Carpets</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Labels</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Furnishing</li></ul>'),
(5, '1647946597_banner-1 (1).jpg', '1647946597_product2.jpg', 'Dyed Yarns (DTY)', '<p><span style=\"color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; letter-spacing: 0.5px; text-align: center;\">We specialize in dyed yarns to fulfilling the huge demands of the textile industry. We use premium quality dye subtracts which are totally free from harmful and banned chemicals. We manufacture a wide assortment of colors and shades so that our clients get all the range they require. We do manufacture specific shades as well in case of any special requisites. We assure that our dyed yarns show amazing performance regarding the fastness of dyes and quality which are well efficient to be used in any kind of process. These yarns can withstand the pressure and high speed in the knitting and weaving machines immensely well. We make an extensive range of batch sizes from small and big.</span><br></p>', '<p style=\"font-size: 18px; line-height: 29px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(29, 117, 202); font-weight: 600; width: 756px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">DTY is used widely in various industries like</p><ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">Denier range: 30 to 1800</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Filaments range: 14 to 576</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Plies: from 2 to 6 ply</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Batch Size: from 10 kg to 2000 kg</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Luster: Semi-Dull, Full Dull, Trilobal Bright, Cationic, Bright Cationic, etc</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Variations: S or Z twist, low oil, oil-less, High Stretch, High Shrinkage, Twisted (TPM), Plastic Perforated tube, etc</li></ul><p style=\"font-size: 18px; line-height: 29px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(29, 117, 202); font-weight: 600; width: 756px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\">These&nbsp;<a href=\"file:///C:/Users/DIGI2/Downloads/RAMDEVREADERS/RAMDEVREADERS/product.html\" style=\"color: rgb(0, 123, 255); text-decoration: none;\">yarns</a>&nbsp;can be provided in Dope Dyed, Package Dyed &amp; Space-Dyed. Can be made in NIM, SIM (LIM), or HIM.</p>', '<ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">DTY (Draw Texturized Yarn)</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">ATY (Air Textured Yarn)</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">FDY (Fully Drawn Yarn)</li></ul>', '<ul style=\"padding: 0px 0px 0px 30px; margin-right: 0px; margin-left: 0px; list-style: none; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px;\"><li style=\"display: block; position: relative; padding-bottom: 10px;\">Knitting</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Weaving</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Embroidery</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Multi-colored Garments</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Sewing Threads</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Elastics</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Socks</li><li style=\"display: block; position: relative; padding-bottom: 10px;\">Automotive Industries</li></ul>');

-- --------------------------------------------------------

--
-- Table structure for table `product_desc`
--

CREATE TABLE `product_desc` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `main_title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_desc`
--

INSERT INTO `product_desc` (`id`, `title`, `main_title`, `description`) VALUES
(1, 'QUICK GLANCE AT OUR', 'Textile Yarns', '<p><span style=\"color: rgb(33, 37, 41); font-family: &quot;Source Sans Pro&quot;, sans-serif; font-size: 16px; letter-spacing: 0.5px;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span><br></p>');

-- --------------------------------------------------------

--
-- Table structure for table `who_we_are_desc`
--

CREATE TABLE `who_we_are_desc` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `who_we_are_desc`
--

INSERT INTO `who_we_are_desc` (`id`, `title`, `description`) VALUES
(1, 'WHO WE ARE', '<p style=\"line-height: 30px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(33, 37, 41); font-family: &quot;Source Sans Pro&quot;, sans-serif;\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p><p style=\"line-height: 30px; letter-spacing: 0.5px; margin-bottom: 1rem; padding-bottom: 30px; color: rgb(33, 37, 41); font-family: &quot;Source Sans Pro&quot;, sans-serif;\">It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_section`
--
ALTER TABLE `about_section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `achieve_target_desc`
--
ALTER TABLE `achieve_target_desc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `achive_target`
--
ALTER TABLE `achive_target`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner_image`
--
ALTER TABLE `banner_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificate`
--
ALTER TABLE `certificate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `csr_description`
--
ALTER TABLE `csr_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `csr_initiative`
--
ALTER TABLE `csr_initiative`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `csr_initiative_image`
--
ALTER TABLE `csr_initiative_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer_data`
--
ALTER TABLE `footer_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history_data`
--
ALTER TABLE `history_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history_desciption`
--
ALTER TABLE `history_desciption`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_aboutus`
--
ALTER TABLE `home_aboutus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media_section`
--
ALTER TABLE `media_section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mission_vision`
--
ALTER TABLE `mission_vision`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `more_maintitle`
--
ALTER TABLE `more_maintitle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `phone_no`
--
ALTER TABLE `phone_no`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_desc`
--
ALTER TABLE `product_desc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `who_we_are_desc`
--
ALTER TABLE `who_we_are_desc`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_section`
--
ALTER TABLE `about_section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `achieve_target_desc`
--
ALTER TABLE `achieve_target_desc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `achive_target`
--
ALTER TABLE `achive_target`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `admininfo`
--
ALTER TABLE `admininfo`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `banner_image`
--
ALTER TABLE `banner_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `certificate`
--
ALTER TABLE `certificate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `csr_description`
--
ALTER TABLE `csr_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `csr_initiative`
--
ALTER TABLE `csr_initiative`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `csr_initiative_image`
--
ALTER TABLE `csr_initiative_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `footer_data`
--
ALTER TABLE `footer_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `history_data`
--
ALTER TABLE `history_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `history_desciption`
--
ALTER TABLE `history_desciption`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `home_aboutus`
--
ALTER TABLE `home_aboutus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `media_section`
--
ALTER TABLE `media_section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mission_vision`
--
ALTER TABLE `mission_vision`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `more_maintitle`
--
ALTER TABLE `more_maintitle`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `phone_no`
--
ALTER TABLE `phone_no`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product_desc`
--
ALTER TABLE `product_desc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `who_we_are_desc`
--
ALTER TABLE `who_we_are_desc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
