

<?php $__env->startSection('content'); ?>

   <div class="page mt-4 hosting-page title1">
                <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4"> Product List</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/add_product')); ?>">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Banner Image</th>
                                    <th>Product Image</th>
                                    <th>Name</th>
                                    <th>View</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <tbody>
                            
                                 <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="product_<?php echo e($p->id); ?>">
                                    <td>

                                      <img src="/uploads/<?php echo e($p->banner_image); ?>" width="120" height="120">
                                        <?php echo e($p->banner_image); ?>

                                    </td>

                                     <td>

                                      <img src="/uploads/<?php echo e($p->product_image); ?>" width="120" height="120">
                                        <?php echo e($p->product_image); ?>

                                    </td>
                                

                                       <td>
                                         <?php echo e($p->name); ?>

                                      </td>
                                    <td>

                                        <button class="btn3 btn0"><a href="<?php echo e(url('admin/view_product')); ?>/<?php echo e($p->id); ?>" ><i class="fa fa-eye" aria-hidden="true"></i></a></button>
                                       
                                    </td>
                                    
                          
                                 <td>

                                     <button class="btn0 btn2"><a href="<?php echo e(url('admin/update_product')); ?>/<?php echo e($p->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              
                              </td>
                              <td>
                                <button class="btn3 btn0" onclick="delete_product(<?php echo e($p->id); ?>)"><i class="fal fa-trash-alt"></i></button>
                              </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 


   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(3000); }, 3000)

             });


         function delete_product($id){

     if(confirm("do you want delete this product ?")){
             $.ajax({

                url:'delete_product/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.product_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
        




     
        
        
        
      
      </script>

  <style type="text/css">
  	.data{

  		margin-left: 25px;
  	}

  </style>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/RTtexttile.ditests.com/resources/views/admin/home.blade.php ENDPATH**/ ?>