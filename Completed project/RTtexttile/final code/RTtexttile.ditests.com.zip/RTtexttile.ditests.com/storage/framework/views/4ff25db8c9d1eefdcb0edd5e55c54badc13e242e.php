

<?php $__env->startSection('content'); ?>

 <div class="page mt-4 hosting-page title1" style="display: block;">

         <div class="mt-5">

             <div class="list1">
                  <h4 class="mb-4">Special CSR Initiative</h4>
                  <button class="btn1"><a href="<?php echo e(url('admin/add_csr_initiative')); ?>">ADD</a></button>
              </div>
          
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th> 
                                    <th>Title</th> 
                                    <th>Main Title</th>  
                                    <th>Description</th>  
                                    <th>Update</th>
                                    <th>delete</th>
                                   
                                </tr>
                            </thead>
                         
                             <tbody>

                                <?php $__currentLoopData = $csr_initiative; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                               <tr class="csr_<?php echo e($ha->id); ?>">
                                    <td class="">

                                         <?php $__currentLoopData = $csr_initiative_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                         <?php if($ha->id == $hi->csr_initiative_id): ?>
                                        
                                   
                                           <img src="/uploads/<?php echo e($hi->image); ?>" width="130" height="130">

                                          
                                      
                                       
                                         <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     
                                                                           
                                    </td>

                                    <td>
                                     
                                      <?php echo e($ha->title); ?>

                                    </td>
                                    <td>
                                        <?php echo e($ha->main_title); ?>


                                    </td>
                                    <td>
                                      
                                          <?php echo $ha->description; ?>


                                    </td>

    
                                 <td>

                                     <button class="btn0 btn2"><a href="<?php echo e(url('admin/update_csr_initiative')); ?>/<?php echo e($ha->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              
                              </td>
                              <td>
                                <button class="btn3 btn0" onclick="delete_csr_initiative(<?php echo e($ha->id); ?>)"><i class="fal fa-trash-alt"></i></button>
                              </td>
                            </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                          
                         
                           
                        </table>
                    </div>
                 </div>
               </div>



  






 

   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(3000); }, 3000)

             });


         function delete_csr_initiative($id){

     if(confirm("do you want delete this  ?")){
             $.ajax({

                url:'delete_csr_initiative/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.csr_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
        




     
        
        
        
      
      </script>

  <style type="text/css">
  	.data{

  		margin-left: 25px;
  	}

  </style>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texttile_app\resources\views/admin/csr_initiative.blade.php ENDPATH**/ ?>