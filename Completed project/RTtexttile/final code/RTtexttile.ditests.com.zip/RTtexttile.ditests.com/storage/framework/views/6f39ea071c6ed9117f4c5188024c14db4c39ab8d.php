   


<?php $__env->startSection('content'); ?>

    <div class="page mt-4 hosting-page title1" style="display: block;"><div class="mt-5">
                   
                   <h4 class="mb-4">About Us page Banner</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th> 
                                    <th>Page Name</th>   
                                    <th>Image</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                           <?php if($a->name=="About Us"): ?>
                             <tbody>
                             
                               <tr>
                                    <td>
                                      <?php echo e($a->name); ?>

                                    </td>

                                      <td>
                                      <?php echo e($a->page_name); ?>

                                    </td>
                                   
                                    <td>

                                       <img src="/uploads/<?php echo e($a->image); ?>" width="400" height="200"><br>
                                       <?php echo e($a->image); ?>  
                                         
                                    </td>

                                     
                             <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updatebannerimg')); ?>/<?php echo e($a->id); ?>">Update</a></button></td>
                                   
                                </tr>
                                
                            </tbody>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>
               </div>
              <?php $__env->stopSection(); ?>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
       <script type="text/javascript">
                   
       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    
       
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texttile_app\resources\views/admin/aboutusbannerlist.blade.php ENDPATH**/ ?>