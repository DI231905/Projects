<?php $__env->startSection('content'); ?>

<div class="co_banner">
        <div class="slideshow">
            <div class="slider">
             <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <img src="uploads/<?php echo e($b->image); ?>">
                </div>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
              
            </div>
        </div>
    </div>
    <div class="co_service">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="service-img">
                        <img src="uploads/<?php echo e($home_image); ?>">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="service-info">
                        <h2><?php echo e($home_title); ?></h2>
                        <p><?php echo $home_description; ?></p>
                        <div class="set-service-list">
                            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="service-list">
                                <div class="service-icon">
                                    <i class="<?php echo e($f->icon); ?>"></i>
                                </div>
                                <div class="service-name">
                                    <h2><?php echo e($f->title); ?></h2>
                                    <p><?php echo e($f->description); ?></p>
                                </div>
                            </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </div>
                    </div>
                </div>              
            </div>
            
        </div>
    </div>
    <div class="co_about">
        <div class="container">
            <div class="about">
                <h6><?php echo e($achieve_title); ?></h6>
                <h2><?php echo e($achieve_main_title); ?></h2>
                <p><?php echo $achieve_description; ?></p>
                <div class="co_counter">
                    <div class="row">

                        <?php $__currentLoopData = $achive_target; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-lg-3 col-md-3 count_1">
                            <div class="count-up">
                                <p class="counter-count"><?php echo e($at->value); ?></p>
                                <h3><?php echo e($at->title); ?></h3>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_product">
        <div class="container">
            <div class="inner-product about">
                <h6><?php echo e($product_title); ?></h6>
                <h2><?php echo e($product_main_title); ?></h2>
                <p><?php echo $product_description; ?></p>
            </div>
        </div>
        <div class="all-product">
            <div class="product-slider">

                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div class="product">
                        <div class="product-img">
                            <img src="uploads/<?php echo e($p->product_image); ?>">
                        </div>
                        <div class="product-name">
                            <h2><?php echo e($p->name); ?></h2>
                            <?php echo $p->description; ?>

                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
        </div>
    </div>
    



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texttile_app\resources\views/welcome.blade.php ENDPATH**/ ?>