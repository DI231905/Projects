   


<?php $__env->startSection('content'); ?>

    <div class="page mt-4 hosting-page title1" style="display: block;">
      <div class="mt-5">
                   
                   <h4 class="mb-4">Vision & Mission page Banner</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th> 
                                    <th>Page Name</th>   
                                    <th>Image</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                           <?php if($a->name=="Vision & Mission"): ?>
                             <tbody>
                             
                               <tr>
                                    <td>
                                      <?php echo e($a->name); ?>

                                    </td>

                                      <td>
                                      <?php echo e($a->page_name); ?>

                                    </td>
                                   
                                    <td>

                                       <img src="/uploads/<?php echo e($a->image); ?>" width="400" height="200"><br>
                                       <?php echo e($a->image); ?>  
                                         
                                    </td>

                                     
                             <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updatebannerimg')); ?>/<?php echo e($a->id); ?>">Update</a></button></td>
                                   
                                </tr>
                                
                            </tbody>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>


                        <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Vision & Mission</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/add_mission_vission')); ?>">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>

                                    <th>Icon</th> 
                                    <th>Title</th>    
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $mission_vision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="mission_<?php echo e($hd->id); ?>">

                                      <td>

                                        <i class="<?php echo e($hd->icon); ?>"></i>
                                     
                                       <?php echo e($hd->icon); ?>

                                    </td>
                                    

                                     <td>
                                      <?php echo e($hd->title); ?>

                                    </td>


                                   
                                   
                                    <td>
                                    <?php echo e($hd->description); ?>

                                    </td>


                                   <td>

                                    <button class="btn0 btn2"><a href="<?php echo e(url('admin/update_mission_vission')); ?>/<?php echo e($hd->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              
                                   </td>
                                    <td>
                                 <button class="btn3 btn0" onclick="deletemission_vision(<?php echo e($hd->id); ?>)"><i class="fal fa-trash-alt"></i></button>
                                 </td>
                                          
                                  
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>
               </div>
              <?php $__env->stopSection(); ?>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
       <script type="text/javascript">
                   
       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });



  function deletemission_vision($id){
    // alert('i am here');

     if(confirm("do you want delete this  ?")){
             $.ajax({

                url:'delete_mission_vission/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.mission_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 


      </script>
    
       
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texttile_app\resources\views/admin/mission_vision.blade.php ENDPATH**/ ?>