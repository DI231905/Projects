

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 marketplace-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Product Details View</h4>
                     <div class="detail">
                        <div class="detail__1">
                             <table class="table table-bordered table-striped">
                                  <tbody>
                                  <tr class="detail"><h3>Name</h3></tr>
                                  <tr class="detail"><?php echo e($name); ?></tr>
                                  <tr class="detail"><h3>Banner Image</h3></tr>
                                  <tr class="detail"><img src="/uploads/<?php echo e($banner_image); ?>" height="200" width="250"></tr>
                                  <tr class="detail"><h3>Product Image</h3></tr>
                                  <tr class="detail"><img src="/uploads/<?php echo e($product_image); ?>" height="200" width="250"></tr>
                                  <tr class="detail"><h3>Description</h3></tr>
                                  <tr class="detail"><?php echo $description; ?></tr>
                                  <tr class="detail"><h3>Specification</h3></tr>
                                  <tr class="detail"><?php echo $specification; ?></tr>
                                  <tr class="detail"><h3>Features</h3></tr>
                                  <tr class="detail"><?php echo $features; ?></tr>
                                  <tr class="detail"><h3>Application</h3></tr>
                                  <tr class="detail"><?php echo $application; ?></tr>
            
                                   </tbody>                   
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <style type="text/css">
              .detail {
                    padding-left: 25px!important;
                    padding-top: 20px;
                }
                .detail__1 h3 {
                        font-size: 21px;
                        margin: 0;
                        font-weight: 700;
                        padding-top: 20px;
                }
                    
                .detail__1 h2 {
                    padding-left: 0;
                    width: 80%;
                }
               .detail__1  p {
                    width: 79%;
                }
            </style>




  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/RTtexttile.ditests.com/resources/views/admin/product_detail.blade.php ENDPATH**/ ?>