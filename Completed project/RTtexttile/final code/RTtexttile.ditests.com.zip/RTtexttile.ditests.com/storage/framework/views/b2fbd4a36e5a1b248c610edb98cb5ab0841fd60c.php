

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">

         <div class="mt-5">
                   
                   <h4 class="mb-4">Product Section Description</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Title</th> 
                                    <th>Main Title</th> 
                                    <th>Description</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                         
                             <tbody>

                                <?php $__currentLoopData = $product_desc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                               <tr>
                                    <td>
                                       <?php echo e($pd->title); ?>                                     
                                    </td>

                                    <td>
                                       <?php echo e($pd->main_title); ?>

                                    </td>

                                    <td>
                                     <?php echo $pd->description; ?> 
                                    </td>

    
                                 <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/update_product_desc')); ?>/<?php echo e($pd->id); ?>">Update</a></button></td>
                                   
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                          
                         
                           
                        </table>
                    </div>
                 </div>

             </div>
           

       <?php $__env->stopSection(); ?>

         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">


       

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texttile_app\resources\views/admin/product_desc.blade.php ENDPATH**/ ?>