

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Home Page Banner List</h4>
                  <button class="btn1"><a href="<?php echo e(url('admin/addhomebanner')); ?>" style="color:black;">ADD</a></button>
              </div>
               <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>   
                                    <th>Title</th>
                                    <!-- <th>Main Heading</th> --> 
                                    <th>Update</th>
                                     <th>Delete</th>
                                   
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="banner_<?php echo e($b->id); ?>">
                                    <td>

                                       <img src="/uploads/<?php echo e($b->image); ?>" width="400" height="200"><br>
                                       <?php echo e($b->image); ?>  
                                         
                                    </td>

                                     <td>
                                      <?php echo $b->title; ?>

                                    </td>

                                  
                                   <td>

                                     <button class="btn0 btn2"><a href="<?php echo e(url('admin/updatebanner')); ?>/<?php echo e($b->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              
                              </td>
                              <td>
                                <button class="btn3 btn0" onclick="deletehomebanner(<?php echo e($b->id); ?>)"><i class="fal fa-trash-alt"></i></button>
                              </td>
                                                  
                            
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
          </div>
      </div>
       <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">
        
         function deletehomebanner($id){

     if(confirm("do you want delete this banner ?")){
             $.ajax({

                url:'deletehomebannerdata/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.banner_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  


       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/RTtexttile.ditests.com/resources/views/admin/homebannerlistView.blade.php ENDPATH**/ ?>