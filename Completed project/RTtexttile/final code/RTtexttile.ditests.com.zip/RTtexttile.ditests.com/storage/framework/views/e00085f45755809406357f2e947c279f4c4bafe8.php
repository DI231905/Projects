
<?php $__env->startSection('content'); ?>

<div class="co-banner1">
		<img src="image/banner-1.jpg">
        <div class="container_11">
            <h1>Textile Yarns</h1>
            <ul class="breadcrumb1">
                <li><a href="index.html">Home</a></li>
                <li>/</li>
                <li>Textile Yarns</li>
            </ul>
        </div>
    </div>
	<div class="product_details">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-6">
					<div class="all-service">
						<div class="service-text">
							<h3>Our Textile Yarns</h3>
							<ul>
								  <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="fas fa-chevron-right"></i><a href="<?php echo e(url('/product_detail')); ?>/<?php echo e($p->id); ?>"><?php echo e($p->name); ?></a></li>
                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-8 col-md-6 pro_image">
					<div class="pro_main">
						<div class="pro_text">
							<p>Textile yarns are used in a variety of products which we use in day to day life. As the range of textiles is rapidly increasing, an understanding of the range and types of Textile Yarns available is important, to cater the requirements of the intended end-use.</p>
						</div>
						<div class="pro_image">
							<div class="row">

								  <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<div class="col-lg-6">
									<div class="image_detail">
										<div class="t-img">
							    	        <a href="<?php echo e(url('/product_detail')); ?>/<?php echo e($p->id); ?>" tabindex="0"><img src="uploads/<?php echo e($p->product_image); ?>"></a>
							    	    </div>
							    	    <div class="t-details">
							    	    	<h2><?php echo e($p->name); ?></h2>
							    	    </div>
									</div>
								</div>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>























<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/RTtexttile.ditests.com/resources/views/product.blade.php ENDPATH**/ ?>