


<?php $__env->startSection('content'); ?>



    <div class="page mt-4 hosting-page title1" style="display: block;"><div class="mt-5">
                   
                   <h4 class="mb-4">Certifications page Banner</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th> 
                                    <th>Page Name</th>   
                                    <th>Image</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                           <?php if($a->name=="Certifications"): ?>
                             <tbody>
                             
                               <tr>
                                    <td>
                                      <?php echo e($a->name); ?>

                                    </td>

                                      <td>
                                      <?php echo e($a->page_name); ?>

                                    </td>
                                   
                                    <td>

                                       <img src="/uploads/<?php echo e($a->image); ?>" width="400" height="200"><br>
                                       <?php echo e($a->image); ?>  
                                         
                                    </td>

                                     
                             <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updatebannerimg')); ?>/<?php echo e($a->id); ?>">Update</a></button></td>
                                   
                                </tr>
                                
                            </tbody>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>
               </div>
           

         <div class="page mt-4 manage-account-page title1">
                <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4">Certfications</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/add_certificate')); ?>" >ADD</a></button>
                     </div>
                    
                     <div class="detail" style="display:flex; flex-wrap:wrap ;" > 
                        <?php $__currentLoopData = $certificate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                         <div class="image_<?php echo e($g->id); ?>">
 
                         <div class="gallery">
                          <a target="_blank" href="/uploads/<?php echo e($g->image); ?>">
                          <img  class="gallery_image" src="/uploads/<?php echo e($g->image); ?>" alt="Cinque Terre" width="200" height="300">
                           </a>
                           <div class=""><button class="btn21" onclick="deleteimage(<?php echo e($g->id); ?>)">Delete Image</button>
                         </div>
                       </div>             
                      </div>  
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    </div>   
                </div>
            </div> 

        <?php $__env->stopSection(); ?>
        <style type="text/css">
          .gallery {

           margin-top: 21px;
           margin-right: 20px;

           }

            .gallery_image{

                width: 300px;
                height: 300px;

           }
           .btn21{

             margin-top: 11px;


           }
          

        </style>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>

        <script type="text/javascript">

             $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
        	
        	 function deleteimage($id){

    
             $.ajax({

                url:'delete_certificate/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){

           var v='image_'+$id;
       

            $('.image_'+$id).hide();  
        
                    
          
                        },

      error: function(response) {
 
        
         
    /* var x = document.getElementById('image_'+$id);
         
              x.style.display = "none";*/
                 
                  },        
          
                });


          
          }
        
        </script>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texttile_app\resources\views/admin/certificate.blade.php ENDPATH**/ ?>