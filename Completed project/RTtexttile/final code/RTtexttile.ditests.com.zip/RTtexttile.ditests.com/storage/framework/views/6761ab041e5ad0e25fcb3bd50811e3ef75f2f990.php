

<?php $__env->startSection('content'); ?>

<div class="co_contact">
        <div class="container">
            <div class="row fix-contact">

                <div class="col-lg-7 col-md-6 col-12 set-contact"> 
                     <?php if($message = Session::get('error')): ?>
           <div id="hideDiv"class="alert alert-success alert-block" >
<!--     <input type="text" class="close" data-dismiss="alert"></input> -->
           <strong style=" padding-top : 5px !important; display: inline-block;"><?php echo e($message); ?></strong>
           </div>
                      <?php endif; ?>


                    <h2>Get in touch</h2>
                    <form method="post" action="<?php echo e(url('/store_contact_us')); ?>"  class="form1 row" id="contact_us">
                   
                                 <?php echo e(csrf_field()); ?>

                            <div class="col-lg-6">
                            <div class="part-1">
                                <input type="text" placeholder="Name" name="name" id="name" value="">
                                <?php if($errors->has('name')): ?> <p class="error_mes"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="part-1">
                                <input type="email" placeholder="Email" name="email" id="email" value="">
                                <?php if($errors->has('email')): ?> <p class="error_mes"><?php echo e($errors->first('email')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="part-1">
                                <input type="text" placeholder="Subject" name="subject" id="subject" value="" >
                                <?php if($errors->has('subject')): ?> <p class="error_mes"><?php echo e($errors->first('subject')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="part-1">
                                <textarea placeholder="Your Message" name="description" id="description" rows="7" cols="30" value=""></textarea>
                                <?php if($errors->has('description')): ?> <p class="error_mes"><?php echo e($errors->first('description')); ?></p> <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="sub1">
                                <input type="submit" id="submit" value="Send Message">
                            </div>
                        </div>
                        
                    </form>
                </div>
                <div class="col-lg-5 col-md-6 col-12 set-contact1">
                    <h2>Contact us</h2>
                    <div class="co_info row">
                        <div class="info-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="info-text">
                            <p>
                                <strong>Address:</strong>

                             <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($a->admin_id == 1 ): ?>
                               <p>Office <?php echo e($key+1); ?>: <?php echo $a->address; ?></p>
                                           
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                            </p>
                        </div>
                    </div>
                    <div class="co_info row row1">
                        <div class="info-icon">
                           <i class="fas fa-phone-alt"></i>
                        </div>
                        <div class="info-text">
                            <p class="c_email">
                                <strong>Contact Number:</strong> 

                                 <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <?php if($p->admin_id==1): ?>
                                 <div class="f-text-c">
          
                                  <a href="tel:<?php echo e($p->phone); ?>"><?php echo e($p->phone); ?></a>
                                 </div>

                              <?php endif; ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </p>
                            
                        </div>
                    </div>
                    <div class="co_info row row1">
                        <div class="info-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="info-text info-text1">
                            <p class="c_email">
                                <strong>Email Us:</strong>
                                <p><?php echo e($email); ?></p>
                            </p>  
                        </div>
                    </div>
                    <div class="one_img">
                        <img src="image/contact-1.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
     <div class="map1">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14881.146483658336!2d72.820203!3d21.18077!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xde729d13987fd21!2sVineet+Polyfab+Pvt.+Ltd.!5e0!3m2!1sen!2sin!4v1556620390578!5m2!1sen!2sin"  frameborder="0" style="border:0" allowfullscreen="" loading="lazy"></iframe>
    </div>
  <style type="text/css">

    p.error_mes {
    color: red;
}
    

  </style>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://kenwheeler.github.io/slick/slick/slick.js"></script>
    <script type="text/javascript">
        
        $(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

         $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texttile_app\resources\views/contact_us.blade.php ENDPATH**/ ?>