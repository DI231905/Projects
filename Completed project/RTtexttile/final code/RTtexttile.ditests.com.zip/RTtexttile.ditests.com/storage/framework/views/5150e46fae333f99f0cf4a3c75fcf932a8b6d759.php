<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ramdev Traders</title>
  <link rel="stylesheet" type="text/css" href="/css/home2.css">
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css">
  <link rel="icon" href="/uploads/<?php echo e($footer_image); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
  <div class="subheader">
    <div class="container">
      <div class="row row1 justify-content-end">
        <div class="col-lg-4 col-md-4 main-name">
          <div class="name">
            <h6><?php echo e($company_type); ?></h6>
          </div>
        </div>
        <!--<div class="col-lg-4 col-md-4 main-name">-->
        <!--  <div class="name">-->
        <!--    <h6><?php echo e($company_certification); ?></h6>-->
        <!--  </div>-->
        <!--</div>-->
        <div class="col-lg-4 col-md-4 main-name">
          <div class="name">
            <h6><i class="far fa-envelope"></i><?php echo e($email); ?></h6>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="co_logo-header">
    <div class="container">
      <div class="row row1">
        <div class="col-lg-3 col-md-3">
          <div class="logo">
            <a href="<?php echo e(url('/')); ?>"><img src="/uploads/<?php echo e($footer_image); ?>"></a>
          </div>
        </div>
        <div class="col-lg-9 col-md-9">
          <div class="row">

             <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                         <?php if($p->admin_id==1): ?>
        

            <div class="col-lg-4 col-md-4">
              
               <div class="inner-info">

                              <a href="tel:<?php echo e($p->phone); ?>">
                                    <div class="info-icon">
                                     <i class="fas fa-phone-alt"></i>
                                   </div>
                          <div class="info-name">
                           <h5>CALL US ON</h5>
                            <h6><?php echo e($p->phone); ?></h6>
                            </div>
                             </a>
                        </div>
            </div>

                      <?php break; ?>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-4">
              <div class="inner-info">
                  <a>
                    <div class="info-icon">
                      <i class="fas fa-clock"></i>
                    </div>
                    <div class="info-name">
                       <h5><?php echo e($opening_day); ?></h5>
                       <h6><?php echo e($opening_time); ?></h6>
                    </div>
                  </a>
              </div>
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="inner-info">
                  <a href="tel:+91 261 2473 121 / 22">
                    <div class="info-icon">
                      <i class="fas fa-map-marker-alt"></i>
                    </div>
                     <div class="info-name">
                      <h5>FIND US ON MAP</h5>
                      <h6>Ring Road,surat</h6>
                    </div>
                  </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="mobile_manu">
    <div class="row">
      <div class="col-md-6 col-6">
        <div class="logo">
          <a href="<?php echo e(url('/')); ?>"><img src="/uploads/<?php echo e($footer_image); ?>"></a>
        </div>
      </div>
      <div class="col-md-6 col-6">
        <div class="item">
          <i class="icon1 fas fa-search"></i>
            <div class="mobile-menu">
                        <div id="mySidepanel" class="sidepanel" style="width: 0px;">
                            <div class="m_menu">
                              <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times"></i></a>
                                <a class="link1" href="<?php echo e(url('/')); ?>">Home</a>
                          <nav class='animated bounceInDown'>
                  <ul>
                    <li class='sub-menu link1'><a  href='<?php echo e(url('/about_us')); ?>'>about</a><div class='fa fa-caret-down right'></div>
                      <ul>
                        <li><a href="<?php echo e(url('/who_we_are')); ?>">Who we are</a></li>
                        <li><a href="<?php echo e(url('/rt_story')); ?>">The RT Story</a></li>
                        <li><a href="<?php echo e(url('/mission_vision')); ?>">Vision & Mission</a></li>
                      </ul>
                    </li>
                    <li class='sub-menu link1'><a  href='<?php echo e(url('/product')); ?>'>Textile Yarns</a> <div class='fa fa-caret-down right'></div>
                      <ul>
                          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
                        <li><a href="<?php echo e(url('product_detail')); ?>/<?php echo e($p->id); ?>"><?php echo e($p->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      </ul>
                    </li>
                    <li class='sub-menu link1'><a  href='<?php echo e(url('/media')); ?>'>Media</a> <div class='fa fa-caret-down right'></div>
                      <ul>
                        <li><a href="<?php echo e(url('/certification')); ?>">Certfications</a></li>
                      </ul>
                    </li>
                  </ul>
                </nav>
                          <a class="link1" href="<?php echo e(url('/csr')); ?>">CSR</a>
                          <a class="link1" href="<?php echo e(url('/contact_us')); ?>">contact us</a>
                          </div>
                        </div>
                        <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                    </div>
        </div>
      </div>
    </div>
 <!--   <div class="search-box1">
    
      
      <div class="dropdown">
						  <div onclick="myFunction()" class="dropbtn search" >
							<input type="text" placeholder="search" name="search" autocomplete="oFF">
							<i class="fas fa-search"></i>
						 </div>
						  <div id="myDropdown" class="dropdown-content">
						   
						  </div>
					</div>
    </div>-->
  </div>
  <div class="co_menu" id="dynamic">
    <div class="container">
      <div class="row">
        <div class="col-lg-9 col-md-9">
          <ul class="menu">
            <li><a href="<?php echo e(url('/')); ?>">home</a></li>
            <li>
              <a href="<?php echo e(url('/about_us')); ?>">about <i class="fas fa-angle-down"></i></a>
              <div class="submenu">
                <a href="<?php echo e(url('/who_we_are')); ?>">Who we are</a>
                <a href="<?php echo e(url('/rt_story')); ?>">The RT Story</a>
                <a href="<?php echo e(url('/mission_vision')); ?>">Vision & Mission</a>
              </div>
            </li>
            <li>
              <a href="<?php echo e(url('/product')); ?>">Textile Yarns <i class="fas fa-angle-down"></i></a>
              <div class="submenu">
             <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <a href="<?php echo e(url('product_detail')); ?>/<?php echo e($p->id); ?>"><?php echo e($p->name); ?></a>
               
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </li>
            <li>
              <a href="<?php echo e(url('/media')); ?>">Media <i class="fas fa-angle-down"></i></a>
              <div class="submenu">
                <a href="<?php echo e(url('/certification')); ?>">Certfications</a>
              </div>
            </li>
            <li><a href="<?php echo e(url('/csr')); ?>">CSR</a></li>
            <li><a href="<?php echo e(url('/contact_us')); ?>">contact us</a></li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3">
           <div class="dropdown">
						  <div onclick="myFunction()" class="dropbtn search" >
						    <input type="text" placeholder="search here.." name="search" id="txtSearch">
							<i class="fas fa-search"></i>
						 </div>
						  <div id="myDropdown" class="dropdown-content">
						  
						  </div>
					</div>
        </div>
      </div>
    </div>
  </div>
    <div>
  <?php echo $__env->yieldContent('content'); ?>
</div>

    <div class="call-now">
    <div class="container">
      <div class="call-main">
        <div class="now">
          <h3>For more details about Ramdev Traders & our products</h3>
          <p>feel free to call us anytime</p>
        </div>
        <div class="call-btn">
          <button>
              <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <?php if($p->admin_id==1): ?>
                            
          
                                  <a href="tel:<?php echo e($p->phone); ?>"><?php echo e($p->phone); ?></a>
                            

                           
                              <?php endif; ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
          </button>
        </div>
      </div>
    </div>
  </div>
    <div class="main-footer">
        <div class="container">
            <div class="footer-block">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-12">
                        <div class="f-logo">
                            <div class="logo_img">
                                <a href="<?php echo e(url('/')); ?>"><img src="/uploads/<?php echo e($footer_image); ?>"></a>
                            </div>
                            <?php echo $footer_description; ?>

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-6">
                       <div class="f-service">
                            <h2>Help-Link</h2>
                          <ul>
                             <li><i class="fas fa-chevron-right"></i><a href="<?php echo e(url('/')); ?>">Home</a></li>
                             <li><i class="fas fa-chevron-right"></i><a href="<?php echo e(url('/about_us')); ?>">About</a></li>
                             <li><i class="fas fa-chevron-right"></i><a href="<?php echo e(url('/media')); ?>">Media</a></li>
                             <li><i class="fas fa-chevron-right"></i><a href="<?php echo e(url('/csr')); ?>">CSR</a></li>
                             <li><i class="fas fa-chevron-right"></i><a href="<?php echo e(url('/contact_us')); ?>">Contact Us</a></li>
                          </ul>
                        </div>
                    </div> 
                    <div class="col-lg-4 col-md-4 col-12">
                      <div class="f-service">
                          <h2>Contacts</h2>
                          <div class="c-block">
                            <i class="fa fa-map-marker"></i>
                              <div class="f-text-c">
                             <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($a->admin_id == 1 ): ?>
                              <p class="f-text-c"><?php echo $a->address; ?></p>
                               <?php break; ?>
                              <?php endif; ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                          </div>
                        <div class="c-block">
                          <i class="fas fa-phone-alt"></i>
                            
                                <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <?php if($p->admin_id==1): ?>
                              <div class="f-text-c">
          
                                  <a href="tel:<?php echo e($p->phone); ?>"><?php echo e($p->phone); ?></a>
                             </div>

                              <?php break; ?>

                              <?php endif; ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </div>
                        <div class="c-block">
                          <i class="fa fa-envelope"></i>
                            <div class="f-text-c">
                              <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                            </div>
                        </div>
                      </div>
                    </div> 
               </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
              <div class="col-md-7 col-12 bm-1">
                    <p>©opyrights 2022 Ramdev Traders All rights reserved</p>
              </div>
              <div class="col-md-5 col-12 bm-1">
                <div class="last">
                  <span>Website designed by :</span>
                  <a title="Website designer in Gujarat" href="http://www.trivia.co.in" target="_blank">Digital Inovation</a>
                </div>
              </div>
            </div>
        </div>
    </div>
    

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
  <script type="text/javascript">
  
            $(document).ready(function(){

    $('#txtSearch').on('keyup', function(){

        var text = $('#txtSearch').val();


        $.ajax({

            type:"GET",
            url: '/search',
            data: {text: $('#txtSearch').val()},
            success: function(response) {
             
              $('#myDropdown').html("");
              $('#myDropdown').html(response);

                 console.log(response);
             }



        });


    });

});
  
  
  
  
  
  
  
  
    $('.sub-menu ul').hide();
    $(".sub-menu .fa.fa-caret-down").click(function () {
      $(this).parent(".sub-menu").children("ul").slideToggle("100");
      $(this).find(".right").toggleClass("fa-caret-up fa-caret-down");
    });

    $(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

         $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

         $('.slider').slick({
          autoplay: true,
            autoplaySpeed: 1200,
        draggable: true,
        arrows: false,
        dots: false,
        fade: true,
        speed: 1000,
        infinite: true,
        cssEase: 'cubic-bezier(0.7, 0, 0.3, 1)',
        touchThreshold: 100,
        prevArrow: '<div class="slide-arrow prev-arrow"><i class="far fa-chevron-left"></i></div>',
            nextArrow: '<div class="slide-arrow next-arrow"><i class="far fa-chevron-right"></i></div>'
        })

        $('.counter-count').each(function () {
            $(this).prop('Counter',0).animate({
                Counter: $(this).text()
                }, {          
                //chnage count up speed here
                duration: 4000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });

        $('.product-slider').slick({
           slidesToShow: 3,
           slidesToScroll: 1,
           dots: false,
           focusOnSelect: true,
           prevArrow: '<div class="slide-arrow prev-arrow product-arrow"><i class="far fa-chevron-left"></i></div>',
            nextArrow: '<div class="slide-arrow next-arrow product-arrow"><i class="far fa-chevron-right"></i></div>',
            responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            adaptiveHeight: true,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    });
    
    $(document).ready(function(){
			  $(".search").click(function(){
			    $(".dropdown-content").toggleClass('new__1');
			  });
			});

        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

      $(document).ready(function(){
            $(".font").click(function(){
                 $(".search-box").slideDown("slow");
             });

            $(".search-close").click(function(){
                $(".search-box").slideUp("slow");
            });
        });

        $(document).ready(function(){
            $(".icon1").click(function(){
                $(".search-box1").slideDown("slow");
            });
            $(".search-box1 a").click(function(){
                $(".search-box1").slideUp("slow");
            });
        });

        $('.search-toggle').addClass('closed');
        $('.search-toggle .search-icon').click(function(e) {
            if ($('.search-toggle').hasClass('closed')) {
                $('.search-toggle').removeClass('closed').addClass('opened');
                $('.search-toggle, .search-container').addClass('opened');
                $('#search-terms').focus();
            } else {
                $('.search-toggle').removeClass('opened').addClass('closed');
                $('.search-toggle, .search-container').removeClass('opened');
            }
        });



      $('.slider-nav').slick({
            autoplay: false,
            autoplaySpeed: 1500,
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: true,
            arrows: false,
            focusOnSelect: true,
            // adaptiveHeight:true,
            responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            // adaptiveHeight: true,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],

        });

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });


  </script>
  <style>
  
  .dropbtn {
  color: white;
  font-size: 16px;
  border: none;
  cursor: pointer;
}
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 1px 16px;
    text-decoration: none;
    display: block;
    border-bottom: 1px solid #dee2e6;
}

.dropdown a:hover {background-color: #ddd;}

.new__1 {
	display: block;
	z-index: 99;
	position: relative;
}
      
      
  </style>

</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/RTtexttile.ditests.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>