
<!DOCTYPE html>
<html>
<head>
    <title>ARQX</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" href="image/logo.jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1">


<style type="text/css">

/*---------------- LOGIN-PAGE -----------------*/
.body1{
    background-color: #8080802b;
}
.user-form-part {
    padding-top: 65px;
    width: 30%;
    margin: auto;
}
.user-form-logo {
    text-align: center;
    margin-bottom: 25px;
}
.user-form-logo img {
    width: 200px;
    margin: auto;
}
.user-form-card {
    padding: 30px;
    border-radius: 8px;
    margin-bottom: 20px;
    background: white;
    border: 1px solid #e8e8e8;
}
.user-form-title {
    text-align: center;
    margin-bottom: 25px;
}
.user-form-title h2 {
    font-size: 25px;
    line-height: 45px;
    margin-bottom: 5px;
    color: #676767;
    font-weight: 600;
    text-transform: capitalize;
}
.user-form-title p {
    text-transform: capitalize;
    font-size: 16px;
    font-weight: 500;
}
.user-form {
    width: 100%;
}
.user-form .form-group {
    margin-bottom: 20px;
    text-align: center;
}
.form-group input:focus{
  outline: none;
  box-shadow: unset;
}
.user-form .form-control {
    height: 45px!important;
    border-radius: 6px!important;
    padding: 0px 20px 2px!important;
    color: black!important;
    background: #f5f5f5!important;
    border: 1px solid #e8e8e8!important;
}
.form-button button {
    width: 50%;
    height: 41px;
    font-size: 14px;
    font-weight: 500;
    line-height: 41px;
    border-radius: 8px;
    letter-spacing: 0.3px;
    text-align: center;
    color: white!important;
    background: #140958!important;
    border: none;
    display: block;
    margin: 0 auto;
}
.form-button button:focus{
    outline: none;
}
.form-button p {
    font-size: 16px;
    margin-top: 22px;
    text-transform: capitalize;
    text-align: center;
    font-weight: 500;
}
.form-button p a {
    font-weight: 500;
    margin-left: 5px;
    color: #0263F6;
    text-decoration: underline;
}
.user-form-remind {
    padding: 20px;
    border-radius: 8px;
    text-align: center;
    background: white;
    border: 1px solid #e8e8e8;
}
.user-form-remind p {
    font-size: 16px;
    text-transform: capitalize;
    margin: 0;
    font-weight: 500;
}
.user-form-remind p a {
    font-weight: 500;
    margin-left: 5px;
    color: #0263F6;
    text-decoration: underline;
}
.user-form-footer {
    text-align: center;
    margin-top: 25px;
    margin-bottom: 40px;
}
.user-form-footer p {
    font-size: 14px;
    color: black;
    font-weight: 500;
}
.user-form-footer p a {
    color: #0263F6;
    transition: all linear .3s;
    text-decoration: underline;
}

@media  only screen and (min-width: 1024px) and (max-width: 1260px){
    .user-form-part {
   
    width: 60%!important;

   }
}

   @media  only screen and (min-width: 768px) and (max-width: 1023px){
    .user-form-part {
   
    width: 75%!important;

   }
}

@media  only screen and (max-width: 767px){
    .user-form-part {
   
    width: 100%!important;


   }

   .form-button button {
    width: 60%;
}

   
 }

 @media  only screen and (max-width: 767px){
    .user-form-part {
   
    width: 100%!important;


   }

   .form-button button {
    width: 60%;
}

 @media  only screen and (max-width: 320px){
    .user-form-part {
   
    width: 100% !important;


   }

   .form-button button {
    width: 80% !important;
}


   
 }
</style>
</head>
<body style="background-color: #8080802b;">
    <table class="user-form-part" style="padding-top: 65px;width: 30%;margin: auto;">
        <tr style="text-align: center;margin-bottom: 25px;">
            <td><a href="index.html"><img src="image/logo.jpg"></a></td>
        </tr>
        <tr >
            <td style="padding: 30px;border-radius: 8px;margin-bottom: 20px;background: white;border: 1px solid #e8e8e8;">
                <table>
                    <tr style="text-align: center;margin-bottom: 25px;">
                        <td><h2 style="font-size: 25px;
    line-height: 45px;
    margin-bottom: 5px;
    color: #676767;
    font-weight: 600;
    text-transform: capitalize;">PASSWORD RESET</h2></td>
                    </tr>

                    <tr style="width: 100%;">
                        <td>
                            <table>
                                <tr style="margin-bottom: 20px;text-align: center;">
                                    <td><p style="font-size: 17px;margin-top: 0;
    margin-bottom: 1rem;">You're receiving this e-mail because you requested a password reset for your <b style="color:#140958; font-size: 19px "> ARQX Capital SA </b>account.</p></td>
                                </tr>
                                <tr style="margin-bottom: 20px;text-align: center;">
                                    <td><p  style="margin-top: 0;
    margin-bottom: 1rem;">OTP for RESET PASSWORD is: <b p="" style="font-size:17px; color:#000; "> <?php echo e($token); ?> </b></p></td>
                                </tr>
                                <tr>
                                    <td><button style="width: 50%;height: 41px;font-size: 14px;font-weight: 500;line-height: 41px;border-radius: 8px;letter-spacing: 0.3px;text-align: center;color: white!important;background: #140958!important;border: none;display: block;margin: 0 auto;"><b style="color: white"><a href="<?php echo e(url('admin/resetpasswordview')); ?>/<?php echo e($id); ?>">Reset My Password</a>  </b></button>
                                        <p style="font-size: 16px; margin-top: 22px;text-transform: capitalize;text-align: center;font-weight: 500;margin-bottom: 1rem;">If you did not forgot your password you can safely ignore this email.</p></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        
    </table>

</body>
</html>

<?php /**PATH C:\xampp\htdocs\texttile_app\resources\views/email/adminotp.blade.php ENDPATH**/ ?>