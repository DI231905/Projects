
<?php $__env->startSection('content'); ?>

<div class="co-banner1">

           <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'CSR'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
        <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

        <div class="product_details">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="all-service">
                        <div class="service-text">
                            <h3>Our Textile Yarns</h3>
                            <ul>
                                  <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="fas fa-chevron-right"></i><a href="product-details.html"><?php echo e($p->name); ?></a></li>
                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="csr">
                        <h3>CSR</h3>
                        <?php echo $csr_description; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_tab1">
        <div class="container">
            <p class="size">Special CSR Initiative at Ramdev Traders:-</p>
            <div class="tile" id="tile-1">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs nav-justified" role="tablist">
                    <div class="slider"></div>

                    <?php $__currentLoopData = $csr_initiative; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">

                        <a class="nav-link active " id="<?php echo e($c->id); ?>-tab" data-toggle="tab" href="#<?php echo e($c->id); ?>" role="tab" aria-controls="<?php echo e($c->id); ?>" aria-selected="true"><p><?php echo e($c->title); ?>:</p></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                  <?php $__currentLoopData = $csr_initiative; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="tab-pane fade  show" id="<?php echo e($c->id); ?>" role="tabpanel" aria-labelledby="<?php echo e($c->id); ?>-tab">
                        <div class="in_details">
                            <p><?php echo e($c->main_title); ?></p>
                            <ul>
                                <?php echo $c->description; ?>

                               
                            </ul>
                        </div>

                    
                           <div class="co_certi co_new">
                                <div class="row row1">
                                    <?php $__currentLoopData = $csr_initiative_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($im->csr_initiative_id == $c->id): ?>

                                     <?php if($im->image !=''): ?>
                                    <span href="image/certi-1.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-lg-4 col-md-4 col-12">
                                        <div class="certi co_new">
                                            <img src="uploads/<?php echo e($im->image); ?>" class="img-fluid">
                                            <div class="certi-icon">
                                                <i class="search far fa-search-plus"></i>
                                            </div>
                                        </div>
                                    </span>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                          </div>
                      </div> 


                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
  

 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://kenwheeler.github.io/slick/slick/slick.js"></script>
    <script type="text/javascript">
        
        $("#tile-1 .nav-tabs a").click(function() {
            var position = $(this).parent().position();
            var width = $(this).parent().width();
            $("#tile-1 .slider").css({"left":+ position.left,"width":width});
        });
        var actWidth = $("#tile-1 .nav-tabs").find(".active").parent("li").width();
        var actPosition = $("#tile-1 .nav-tabs .active").position();
        $("#tile-1 .slider").css({"left":+ actPosition.left,"width": actWidth});

        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });

        $('.nav li a').click(function(){
  
     $('.tab-pane').hide();
     $('.nav li a.active').removeClass('active');
     $(this).addClass('active');
     
     var panel = $(this).attr('href');
     $(panel).fadeIn(1000);
     
     return false;  // prevents link action
    
  });  // end click 

     $('.nav li:first a').click();
    </script>


	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\texttile_app\resources\views/csr.blade.php ENDPATH**/ ?>