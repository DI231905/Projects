


<?php $__env->startSection('content'); ?>

<div class="co-banner1">
       <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'The RT Story'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
        <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


  <div class="product_details">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 ">
                    <div class="all-service">
                        <div class="service-text">
                            <h3>Our Textile Yarns</h3>
                            <ul>
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="fas fa-chevron-right"></i><a href="<?php echo e(url('product_detail')); ?>/<?php echo e($p->id); ?>"><?php echo e($p->name); ?></a></li>
                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 ">
                    <div class="who-info info1">
                        <p>
                              <?php echo $history_desciption; ?>

                        </p>
                     
                        <div class="story-history">
                            <h2> <?php echo $history_title; ?></h2>
                            <div class="row history">
                          <div class="col-md-12">
                             <ul class="timeline">

                                <?php $__currentLoopData = $history_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php if( $key %2 ==0): ?>
                                <li class="timeline-inverted">
                                    <div class="posted-date">
                                        <span class="month"><?php echo e($h->year); ?></span>
                                    </div>
                                    <div class="timeline-panel">
                                        <div class="timeline-content">
                                            <div class="timeline-heading">
                                                <h3><a><?php echo e($h->title); ?></a></h3>
                                            </div>
                                            <div class="timeline-body">
                                                <p><?php echo e($h->description); ?></p>
                                            </div>
                                        </div> 
                                    </div>
                                </li><?php else: ?>
                                
                                 <li>
                                    <div class="posted-date">
                                        <span class="month"><?php echo e($h->year); ?></span>
                                    </div>
                                    <div class="timeline-panel">
                                        <div class="timeline-content">
                                            <div class="timeline-heading">
                                                <h3><a><?php echo e($h->title); ?></a></h3>
                                            </div>
                                            <div class="timeline-body">
                                                <p><?php echo e($h->description); ?></p>
                                            </div>
                                        </div> 
                                    </div>
                                </li>
                                
                                <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                             </ul>
                          </div>
                       </div>
                        </div>
                    </div>
               </div>
           </div>
        </div>
    </div>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

         $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/RTtexttile.ditests.com/resources/views/rt_story.blade.php ENDPATH**/ ?>