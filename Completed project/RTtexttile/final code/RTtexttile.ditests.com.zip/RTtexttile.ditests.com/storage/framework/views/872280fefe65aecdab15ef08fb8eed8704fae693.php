 


<?php $__env->startSection('content'); ?>
	<div class="co-banner1">
		<img src="/uploads/<?php echo e($banner_image); ?>">
        <div class="container_11">
            <h1><?php echo e($p_name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li>/</li>
                <li><?php echo e($p_name); ?></li>
            </ul>
        </div>
    </div>
	<div class="product_details">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-6">
					<div class="all-service">
						<div class="service-text">
							<h3>Our Textile Yarns</h3>
							<ul>
								  <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="fas fa-chevron-right"></i><a href="<?php echo e(url('product_detail')); ?>/<?php echo e($p->id); ?>"><?php echo e($p->name); ?></a></li>
                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-8 col-md-6 pro_image">
					<div class="p-image">
							<div class="t-img p-img">
				    	        <a href="<?php echo e(url('product_detail')); ?>/<?php echo e($p->id); ?>" tabindex="0"><img src="/uploads/<?php echo e($product_image); ?>"></a>
				    	    </div>
				    	    <div class="p-details">
				    	    	<p><?php echo $description; ?></p>
				    	    </div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="co_tab1">
        <div class="container">
            <div class="tile" id="tile-1">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs nav-justified" role="tablist">
                    <div class="slider"></div>
                    <li class="nav-item">
                        <a class="nav-link active" id="management-tab" data-toggle="tab" href="#management" role="tab" aria-controls="management" aria-selected="true"><p>Specifications</p></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="resource-tab" data-toggle="tab" href="#resource" role="tab" aria-controls="resource" aria-selected="false"><p>Features</p></a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" id="approach-tab" data-toggle="tab" href="#approach" role="tab" aria-controls="approach" aria-selected="false"><p>Applications</p></a>
                    </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="management" role="tabpanel" aria-labelledby="management-tab">
                    	<div class="in_details">
                    		<?php echo $specification; ?>

                    	</div>
                    </div>
                    <div class="tab-pane fade" id="resource" role="tabpanel" aria-labelledby="resource-tab">
                    	<div class="in_details">
                    		<?php echo $features; ?>

                    	</div>
                    </div>
                     <div class="tab-pane fade" id="approach" role="tabpanel" aria-labelledby="approach-tab">
                     	<div class="in_details">
                    		  <?php echo $application; ?>

                    	</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://kenwheeler.github.io/slick/slick/slick.js"></script>
    <script type="text/javascript">
    	
        $("#tile-1 .nav-tabs a").click(function() {
            var position = $(this).parent().position();
            var width = $(this).parent().width();
            $("#tile-1 .slider").css({"left":+ position.left,"width":width});
        });
        var actWidth = $("#tile-1 .nav-tabs").find(".active").parent("li").width();
        var actPosition = $("#tile-1 .nav-tabs .active").position();
        $("#tile-1 .slider").css({"left":+ actPosition.left,"width": actWidth});


        $(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

        $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });
    </script>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/RTtexttile.ditests.com/resources/views/product_detail.blade.php ENDPATH**/ ?>