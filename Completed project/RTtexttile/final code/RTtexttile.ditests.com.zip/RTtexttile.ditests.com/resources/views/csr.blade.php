@extends('layouts.app')
@section('content')

<div class="co-banner1">

           @foreach($allbanner as $a)
            @if($a->name == 'CSR')
        <img src="uploads/{{$a->image}}">
        <div class="container_11">
            <h1>{{$a->name}}</h1>
            <ul class="breadcrumb1">
                <li><a href="{{url('/')}}"> Home</a></li>
                <li>/</li>
                <li>{{$a->name}}</li>
            </ul>
        </div>
        @endif
       @endforeach
    </div>

        <div class="product_details">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="all-service">
                        <div class="service-text">
                            <h3>Our Textile Yarns</h3>
                            <ul>
                                  @foreach($product as $p)
                                <li><i class="fas fa-chevron-right"></i><a href="{{url('product_detail')}}/{{$p->id}}">{{$p->name}}</a></li>
                             
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="csr">
                        <h3>CSR</h3>
                        {!!$csr_description!!}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_tab1">
        <div class="container">
            <p class="size">Special CSR Initiative at Ramdev Traders:-</p>
            <div class="tile" id="tile-1">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs nav-justified" role="tablist">
                    <div class="slider"></div>

                    @foreach($csr_initiative as $c)
                    <li class="nav-item">

                        <a class="nav-link active " id="{{$c->id}}-tab" data-toggle="tab" href="#{{$c->id}}" role="tab" aria-controls="{{$c->id}}" aria-selected="true"><p>{{$c->title}}:</p></a>
                    </li>
                    @endforeach
                  
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                  @foreach($csr_initiative as $c)

                    <div class="tab-pane fade  show" id="{{$c->id}}" role="tabpanel" aria-labelledby="{{$c->id}}-tab">
                        <div class="in_details">
                            <p>{{$c->main_title}}</p>
                            <ul>
                                {!! $c->description !!}
                               
                            </ul>
                        </div>
               
                         <div class="co_certi co_new">
                                <div class="row row1">
                                    @foreach($csr_initiative_image as $im)
                                    @if($im->csr_initiative_id == $c->id)

                                     @if($im->image !='')
                                    <span href="image/certi-1.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-lg-4 col-md-4 col-12">
                                        <div class="certi co_new">
                                            <img src="uploads/{{$im->image}}" class="img-fluid">
                                            <div class="certi-icon">
                                                <i class="search far fa-search-plus"></i>
                                            </div>
                                        </div>
                                    </span>
                                    @endif
                                    @endif
                                    @endforeach
                              </div>
                          </div>
                      </div> 
                      @endforeach
                   </div>
  

 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://kenwheeler.github.io/slick/slick/slick.js"></script>
    <script type="text/javascript">
        
        $("#tile-1 .nav-tabs a").click(function() {
            var position = $(this).parent().position();
            var width = $(this).parent().width();
            $("#tile-1 .slider").css({"left":+ position.left,"width":width});
        });
        var actWidth = $("#tile-1 .nav-tabs").find(".active").parent("li").width();
        var actPosition = $("#tile-1 .nav-tabs .active").position();
        $("#tile-1 .slider").css({"left":+ actPosition.left,"width": actWidth});

        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });

        $('.nav li a').click(function(){
  
     $('.tab-pane').hide();
     $('.nav li a.active').removeClass('active');
     $(this).addClass('active');
     
     var panel = $(this).attr('href');
     $(panel).fadeIn(1000);
     
     return false;  // prevents link action
    
  });  // end click 

     $('.nav li:first a').click();
    </script>


	@endsection