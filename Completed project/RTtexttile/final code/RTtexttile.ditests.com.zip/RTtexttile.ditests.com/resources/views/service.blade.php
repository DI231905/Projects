
@extends('layouts.app')

@section('content')


<div class="co-banner1">
       @foreach($allbanner as $a)
            @if($a->name == 'Services')
        <img src="uploads/{{$a->image}}">
        <div class="container_11">
            <h1>{{$a->name}}</h1>
            <ul class="breadcrumb1">
                <li><a href="{{url('/')}}"><img src="image/house.png"> Home</a></li>
                <li>/</li>
                <li>{{$a->name}}</li>
            </ul>
        </div>
        @endif
       @endforeach
    </div>
    <div class="co_service">
		<div class="container">
			<div class="col-xl-12">
				<div class="row service_detail align-items-center mb-5">
					<div class="col-xl-6 col-md-6 col-12">
						<h2>{{$name}}</h2>
					</div>
					<div class="col-xl-6 col-md-6 col-12 text-right">
						<button class="download">Download our Investment Brochure</button>
					</div>
				</div>
			</div>
			<div class="col-xl-12">
				<div class="row row1 content_1">
					<div class="col-lg-6 col-md-12 col-12 order_05">
						<div class="about-content">
							<h2>{{$title}}</h2>
							<p>{!! $description !!}</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-12 col-12 order_06">
						<div class="row inner_service1">
							<div class="col-lg-4 col-md-4 col-4 pr-2">
								<img src="uploads/{{$image1}}" class="mb-3 s1">
								<img src="uploads/{{$image2}}" class="s2">
							</div>
							<div class="col-lg-4 col-md-4 col-4 pl-2">
								<img src="uploads/{{$image3}}" class="s3" >
								
							</div>
							<div class="col-lg-4 col-md-4 col-4 pl-0">
								<img src="uploads/{{$image4}}" class="mb-3 s2">
								<img src="uploads/{{$image5}}" class="s1">
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>
    <div class="co_inner-about">
    	<div class="container">
    		<div class="about-service">
    			<div class="row">
    				@foreach($servicedata as $s)
    				<div class="col-lg-4 col-md-6 col-12 mb-4">
    					<div class="inner-about-service">
    						<img src="uploads/{{$s->image}}">
    						<div class="about-service-content service-content1">
    							<h2>{{$s->title}}</h2>
    							<p>{!!$s->description!!}</p>
    						</div>
    					</div>
    				</div>

    				@endforeach
    				
    			</div>
    		</div>
    	</div>
    </div>

    @endsection