@extends('layouts.app')

@section('content')
<div class="co-banner1">

           @foreach($allbanner as $a)
            @if($a->name == 'Contact Us')
        <img src="uploads/{{$a->image}}">
        <div class="container_11">
            <h1>{{$a->name}}</h1>
            <ul class="breadcrumb1">
                <li><a href="{{url('/')}}"> Home</a></li>
                <li>/</li>
                <li>{{$a->name}}</li>
            </ul>
        </div>
        @endif
       @endforeach
    </div>


<div class="co_contact">
        <div class="container">
            <div class="row fix-contact">

                <div class="col-lg-7 col-md-6 col-12 set-contact"> 
                     @if ($message = Session::get('error'))
           <div id="hideDiv"class="alert alert-success alert-block" >
<!--     <input type="text" class="close" data-dismiss="alert"></input> -->
           <strong style=" padding-top : 5px !important; display: inline-block;">{{ $message }}</strong>
           </div>
                      @endif


                    <h2>Get in touch</h2>
                    <form method="post" action="{{url('/store_contact_us')}}"  class="form1 row" id="contact_us">
                   
                                 {{ csrf_field() }}
                            <div class="col-lg-6">
                            <div class="part-1">
                                <input type="text" placeholder="Name" name="name" id="name" value="">
                                @if($errors->has('name')) <p class="error_mes">{{ $errors->first('name') }}</p> @endif
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="part-1">
                                <input type="email" placeholder="Email" name="email" id="email" value="">
                                @if($errors->has('email')) <p class="error_mes">{{ $errors->first('email') }}</p> @endif
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="part-1">
                                <input type="text" placeholder="Subject" name="subject" id="subject" value="" >
                                @if($errors->has('subject')) <p class="error_mes">{{ $errors->first('subject') }}</p> @endif
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="part-1">
                                <textarea placeholder="Your Message" name="description" id="description" rows="7" cols="30" value=""></textarea>
                                @if($errors->has('description')) <p class="error_mes">{{ $errors->first('description') }}</p> @endif
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="sub1">
                                <input type="submit" id="submit" value="Send Message">
                            </div>
                        </div>
                        
                    </form>
                </div>
                <div class="col-lg-5 col-md-6 col-12 set-contact1">
                    <h2>Contact us</h2>
                    <div class="co_info row">
                        <div class="info-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="info-text">
                            <p>
                                <strong>Address:</strong>

                             @foreach($address as $key=>$a)
                               @if($a->admin_id == 1 )
                               <p>Office {{$key+1}}: {!!$a->address !!}</p>
                                           
                              @endif
                              @endforeach   
                            </p>
                        </div>
                    </div>
                    <div class="co_info row row1">
                        <div class="info-icon">
                           <i class="fas fa-phone-alt"></i>
                        </div>
                        <div class="info-text">
                            <p class="c_email">
                                <strong>Contact Number:</strong> 

                                 @foreach($phone_no as $p)

                               @if($p->admin_id==1)
                                 <div class="f-text-c">
          
                                  <a href="tel:{{$p->phone}}">{{$p->phone}}</a>
                                 </div>

                              @endif

                              @endforeach
                                
                            </p>
                            
                        </div>
                    </div>
                    <div class="co_info row row1">
                        <div class="info-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="info-text info-text1">
                            <p class="c_email">
                                <strong>Email Us:</strong>
                                <p>{{$email}}</p>
                            </p>  
                        </div>
                    </div>
                    <div class="one_img">
                        <img src="image/contact-1.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
     <div class="map1">
         <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d929.7538404909131!2d72.82927862193782!3d21.231239417645405!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04fffd4724a7f%3A0x19cb166c8e641d83!2sShree%20Radharani2%20Boutique.!5e0!3m2!1sen!2sin!4v1648187436821!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    
    </div>
  <style type="text/css">

    p.error_mes {
    color: red;
}
    

  </style>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://kenwheeler.github.io/slick/slick/slick.js"></script>
    <script type="text/javascript">
        
        $(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

         $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });
    </script>
    @endsection