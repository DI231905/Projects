@extends('layouts.app')

@section('content')

<div class="co_banner">
        <div class="slideshow">
            <div class="slider">
             @foreach($banner as $b)
                <div class="item">
                    <img src="uploads/{{$b->image}}">
                </div>

               @endforeach 
              
            </div>
        </div>
    </div>
    <div class="co_service">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="service-img">
                        <img src="uploads/{{$home_image}}">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="service-info">
                        <h2>{{$home_title}}</h2>
                        <p>{!! $home_description !!}</p>
                        <div class="set-service-list">
                            @foreach($features as $f)
                            <div class="service-list">
                                <div class="service-icon">
                                    <i class="{{$f->icon}}"></i>
                                </div>
                                <div class="service-name">
                                    <h2>{{$f->title}}</h2>
                                    <p>{{$f->description}}</p>
                                </div>
                            </div>
                         @endforeach
                          
                        </div>
                    </div>
                </div>              
            </div>
            
        </div>
    </div>
    <div class="co_about">
        <div class="container">
            <div class="about">
                <h6>{{$achieve_title}}</h6>
                <h2>{{$achieve_main_title}}</h2>
                <p>{!! $achieve_description !!}</p>
                <div class="co_counter">
                    <div class="row">

                        @foreach($achive_target as $at )
                        <div class="col-6 col-lg-3 col-md-3 count_1">
                            <div class="count-up">
                                <p class="counter-count">{{$at->value}}</p>
                                <h3>{{$at->title}}</h3>
                            </div>
                        </div>
                        @endforeach
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_product">
        <div class="container">
            <div class="inner-product about">
                <h6>{{$product_title}}</h6>
                <h2>{{$product_main_title}}</h2>
                <p>{!!$product_description !!}</p>
            </div>
        </div>
        <div class="all-product">
            <div class="product-slider">

                @foreach($product as $p)
                <div>
                    <div class="product">
                        <div class="product-img">
                            <img src="uploads/{{$p->product_image}}">
                        </div>
                        <div class="product-name">
                            <h2>{{$p->name}}</h2>
                            {!!$p->description!!}
                        </div>
                    </div>
                </div>

                @endforeach
              
            </div>
        </div>
    </div>
    



@endsection