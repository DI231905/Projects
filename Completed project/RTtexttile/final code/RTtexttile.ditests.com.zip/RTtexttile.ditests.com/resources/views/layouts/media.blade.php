
    
@extends('layouts.app')
@section('content')


<div class="co-banner1">

           @foreach($allbanner as $a)
            @if($a->name == 'Media')
        <img src="uploads/{{$a->image}}">
        <div class="container_11">
            <h1>{{$a->name}}</h1>
            <ul class="breadcrumb1">
                <li><a href="{{url('/')}}"> Home</a></li>
                <li>/</li>
                <li>{{$a->name}}</li>
            </ul>
        </div>
        @endif
       @endforeach
    </div>
    <div class="product_details">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="all-service">
                        <div class="service-text">
                            <h3>Our Textile Yarns</h3>
                            <ul>
                                 @foreach($product as $p)
                                <li><i class="fas fa-chevron-right"></i><a href="product-details.html">{{$p->name}}</a></li>
                             
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 pro_image">
                    <div class="row">
                        @foreach($media_section as $as)
                        <div class="col-lg-6">
                            <div class="image_detail">
                                <div class="t-img">

                              <a href="{{url('/certification')}}"><img src="uploads/{{$as->image}}"></a>

                              
                                </div>
                                <div class="t-details">
                                    <h2>{{$as->title}}</h2>
                                </div>
                            </div>
                        </div>

                      @endforeach
                       
                   </div>
               </div>
           </div>
        </div>
    </div>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

        $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

    </script>



	@endsection