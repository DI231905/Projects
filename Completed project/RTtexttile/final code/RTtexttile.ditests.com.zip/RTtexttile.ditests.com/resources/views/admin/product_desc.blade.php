@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">

         <div class="mt-5">
                   
                   <h4 class="mb-4">Product Section Description</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Title</th> 
                                    <th>Main Title</th> 
                                    <th>Description</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                         
                             <tbody>

                                @foreach($product_desc as $pd)
                             
                               <tr>
                                    <td>
                                       {{$pd->title}}                                     
                                    </td>

                                    <td>
                                       {{$pd->main_title}}
                                    </td>

                                    <td>
                                     {!!$pd->description!!} 
                                    </td>

    
                                 <td><button class="btn0 btn2"><a href="{{url('admin/update_product_desc')}}/{{$pd->id}}">Update</a></button></td>
                                   
                                </tr>

                                @endforeach
                                
                            </tbody>
                          
                         
                           
                        </table>
                    </div>
                 </div>

             </div>
           

       @endsection

         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">


       

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    