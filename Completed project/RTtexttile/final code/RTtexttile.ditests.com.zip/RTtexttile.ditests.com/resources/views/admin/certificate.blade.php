
@extends('admin.layouts.app')

@section('content')



    <div class="page mt-4 hosting-page title1" style="display: block;"><div class="mt-5">
                   
                   <h4 class="mb-4">Certifications page Banner</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th> 
                                    <th>Page Name</th>   
                                    <th>Image</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                           @foreach($allbanner as $a)
                           
                           @if($a->name=="Certifications")
                             <tbody>
                             
                               <tr>
                                    <td>
                                      {{$a->name}}
                                    </td>

                                      <td>
                                      {{$a->page_name}}
                                    </td>
                                   
                                    <td>

                                       <img src="/uploads/{{$a->image}}" width="400" height="200"><br>
                                       {{$a->image}}  
                                         
                                    </td>

                                     
                             <td><button class="btn0 btn2"><a href="{{url('admin/updatebannerimg')}}/{{$a->id}}">Update</a></button></td>
                                   
                                </tr>
                                
                            </tbody>
                            @endif
                            @endforeach
                           
                        </table>
                    </div>
                 </div>
               </div>
           

         <div class="page mt-4 manage-account-page title1">
                <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4">Certfications</h4>
                        <button class="btn1"><a href="{{url('admin/add_certificate')}}" >ADD</a></button>
                     </div>
                    
                     <div class="detail" style="display:flex; flex-wrap:wrap ;" > 
                        @foreach($certificate as $g)
                         
                         <div class="image_{{$g->id}}">
 
                         <div class="gallery">
                          <a target="_blank" href="/uploads/{{$g->image}}">
                          <img  class="gallery_image" src="/uploads/{{$g->image}}" alt="Cinque Terre" width="200" height="300">
                           </a>
                           <div class=""><button class="btn21" onclick="deleteimage({{$g->id}})">Delete Image</button>
                         </div>
                       </div>             
                      </div>  
                       @endforeach   
                    </div>   
                </div>
            </div> 

        @endsection
        <style type="text/css">
          .gallery {

           margin-top: 21px;
           margin-right: 20px;

           }

            .gallery_image{

                width: 300px;
                height: 300px;

           }
           .btn21{

             margin-top: 11px;


           }
          

        </style>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>

        <script type="text/javascript">

             $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
        	
        	 function deleteimage($id){

    
             $.ajax({

                url:'delete_certificate/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){

           var v='image_'+$id;
       

            $('.image_'+$id).hide();  
        
                    
          
                        },

      error: function(response) {
 
        
         
    /* var x = document.getElementById('image_'+$id);
         
              x.style.display = "none";*/
                 
                  },        
          
                });


          
          }
        
        </script>