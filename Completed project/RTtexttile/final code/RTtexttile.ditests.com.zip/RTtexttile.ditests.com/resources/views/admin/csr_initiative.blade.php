@extends('admin.layouts.app')

@section('content')

 <div class="page mt-4 hosting-page title1" style="display: block;">

         <div class="mt-5">

             <div class="list1">
                  <h4 class="mb-4">Special CSR Initiative</h4>
                  <button class="btn1"><a href="{{url('admin/add_csr_initiative')}}">ADD</a></button>
              </div>
          
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th> 
                                    <th>Title</th> 
                                    <th>Main Title</th>  
                                    <th>Description</th>  
                                    <th>Update</th>
                                    <th>delete</th>
                                   
                                </tr>
                            </thead>
                         
                             <tbody>

                                @foreach($csr_initiative as $ha)
                             
                               <tr class="csr_{{$ha->id}}">
                                    <td class="">

                                         @foreach($csr_initiative_image as $hi)

                                         @if($ha->id == $hi->csr_initiative_id)
                                        
                                   
                                           <img src="/uploads/{{$hi->image}}" width="130" height="130">

                                          
                                      
                                       
                                         @endif
                                      @endforeach
                                     
                                                                           
                                    </td>

                                    <td>
                                     
                                      {{$ha->title}}
                                    </td>
                                    <td>
                                        {{$ha->main_title}}

                                    </td>
                                    <td>
                                      
                                          {!!$ha->description!!}

                                    </td>

    
                                 <td>

                                     <button class="btn0 btn2"><a href="{{url('admin/update_csr_initiative')}}/{{$ha->id}}"><i class="fal fa-pencil"></i></a></button>
                              
                              </td>
                              <td>
                                <button class="btn3 btn0" onclick="delete_csr_initiative({{$ha->id}})"><i class="fal fa-trash-alt"></i></button>
                              </td>
                            </tr>

                                @endforeach
                                
                            </tbody>
                          
                         
                           
                        </table>
                    </div>
                 </div>
               </div>



  






 

   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(3000); }, 3000)

             });


         function delete_csr_initiative($id){

     if(confirm("do you want delete this  ?")){
             $.ajax({

                url:'delete_csr_initiative/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.csr_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
        




     
        
        
        
      
      </script>

  <style type="text/css">
  	.data{

  		margin-left: 25px;
  	}

  </style>
  @endsection