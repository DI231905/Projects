@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">

         <div class="mt-5">
                   
                   <h4 class="mb-4">Achieve Target Description</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Title</th> 
                                    <th>Main Title</th> 
                                    <th>Description</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                         
                             <tbody>

                                @foreach($achieve_target_desc as $at)
                             
                               <tr>
                                    <td>
                                       {{$at->title}}                                     
                                    </td>

                                    <td>
                                       {{$at->main_title}}
                                    </td>

                                    <td>
                                     {!!$at->description!!} 
                                    </td>

    
                                 <td><button class="btn0 btn2"><a href="{{url('admin/update_achieve_desc')}}/{{$at->id}}">Update</a></button></td>
                                   
                                </tr>

                                @endforeach
                                
                            </tbody>
                          
                         
                           
                        </table>
                    </div>
                 </div>



          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Achieve Target List</h4>
                  <button class="btn1"><a href="{{url('admin/add_achieve_target')}}" style="color:black;">ADD</a></button>
              </div>
               <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th> 
                                    
                                   
                                </tr>
                            </thead>
                           @foreach($achive_target as $at)
                             <tbody>
                             
                               <tr class="target_{{$at->id}}">
                                    

                                     <td>
                                      {{$at->title}}
                                    
                                    </td>

                                     <td>

                                         {{$at->value}}
                                   
                                    </td>

                                   <td>

                                     <button class="btn0 btn2"><a href="{{url('admin/update_achieve_target')}}/{{$at->id}}"><i class="fal fa-pencil"></i></a></button>
                              
                                 </td>
                                 <td>
                                   
                                   <button class="btn3 btn0" onclick="delete_target({{$at->id}})"><i class="fal fa-trash-alt"></i></button>
                                 </td>
                              
                            
                                </tr>
                                
                            </tbody>
                            @endforeach
                           
                        </table>
                    </div>
          </div>
      </div>
           

       @endsection

         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">


         function delete_target($id){

     if(confirm("do you want delete this Achieve Target ?")){
             $.ajax({

                url:'delete_achieve_target/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.target_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
        
        

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    