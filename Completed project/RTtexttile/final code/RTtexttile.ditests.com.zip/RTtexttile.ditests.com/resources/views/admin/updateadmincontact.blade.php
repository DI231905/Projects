<!DOCTYPE html>
<html>
<head>
       <title>Ramdev Traders</title>
      <link rel="stylesheet" type="text/css" href="/css/main-dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   <link rel="icon" type="image/png" href="/image/logo.jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body"> 
    <div class="page my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">Admin Contact Info</h4>
                <div class="form">

                 <form  action="{{url('admin/storeadmincontact')}}/{{$id}}" enctype="multipart/form-data" method="POST" >
                         @csrf
                        <!-- <div class="part">
                            <div class="col-md-12 label">
                                <label>Image</label>
                            </div>
                            <div class="col-md-12">
                                  <input type="file" value="" name="image" accept="image/*"  onchange="readURL(this);" />
                                  <img id="blah" src="#" alt="" />

                               
                             </div>   
                        </div>    -->                        

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Name</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Admin Name"  name="name" value="{{$name}}" >

                                 @if($errors->has('name')) <p class="error_mes">{{ $errors->first('name') }}</p> @endif
                            </div>   
                          </div>
                          
                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Email</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Email" name="email" value="{{$email}}" >

                                @if($errors->has('email')) <p class="error_mes">{{ $errors->first('email') }}</p> @endif
                            </div>   
                          </div>


                             <div class="part">
                            <div class="col-md-12 label">
                                <label>Already inserted mobile no</label>
                            </div>
                            <div class="col-md-12 data">


                            @foreach($phone_no as $m)

                               <label class="badge bg-info  tag_{{$m->id}}">{{ $m->phone }}<a> <i class="fa fa-times" aria-hidden="true" onclick="delete_mobile({{$m->id}})"></i></a> </label>
                                    
                            @endforeach

                                
                            </div>   
                          </div>

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Phone</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Phone number" name="phone"data-role="tagsinput" >
                            </div>   
                          </div>

                            <div class="part">
                            <div class="col-md-12 label">
                                <label>Opening Days</label>
                            </div>
                            <div class="col-md-12 data">
                        <input type="text" placeholder="Enter Opening days" name="opening_day" value="{{$opening_day}}" >

                               
                            </div>   
                          </div>


    
                           <div class="part">
                            <div class="col-md-12 label">
                                <label>Opening Time</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Opening Time" name="opening_time" value="{{$opening_time}}" >

                               
                            </div>   
                          </div>

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Company Type</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Company Type" name="company_type" value="{{$company_type}}" >

                               
                            </div>   
                          </div>

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Company cerfication</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Company cerfication" name="company_certification" value="{{$company_certification}}" >

                               
                            </div>   
                          </div>

                            <div class="part">
                            <div class="col-md-12 label">
                                <label> Already inserted Address</label>
                            </div>
                           
                           @foreach($address as $m)
                       <div class="col-md-12 data data1" id="address_{{$m->id}}">
                          <div class="days data1">
                              <textarea class="address" type="text"   value="{{$m->address}}" rows="1">{{$m->address}}</textarea> 
                                <button id="" type="button" class="btn-remove"><a style="color:white" href="{{url('admin/update_address')}}/{{$m->id}}">Update</a></button>
                                <button id="" type="button" class="btn-remove" onclick="delete_address({{$m->id}})">Delete</button>
                          </div>
                       </div>
                      @endforeach
                          </div>

                 <div class="part part1">
                  <div class="col-md-12 label">
                     <label>Add New Address</label>
                  </div>
                  <div class="col-md-12 data data1">
                     <div class="days data1">
                       <textarea type="text"  placeholder="Enter here" name="address" value="" rows="1"></textarea>   
                        <button id="removeRow" type="button" class="btn-remove">Remove</button>
                     </div>
                     <div id="newRow"></div>
                     <button id="addRow1" type="button" class="btn-remove btn-add1">Add more</button>
                  </div>
               </div>      

                     <div class="upload">
                        <button class="submit">Update</button> 
                        <a href="{{url('admin/admincontactview')}}">Back to Home?</a>       
                      </div>  
                        </div>

                    </form>     

                </div>
            </div>
        </div>
    </div>
  
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css" rel="stylesheet" />
   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.js"></script>

    
 <script type="text/javascript">
         function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result)
                        .width(130)
                        .height(130);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }


        $(document).on('click', '#addRow1', function () {
           var html = '';
             
            html += '<div class="days">';
           html += ' <textarea type="text" placeholder="Enter here" name="addresses[]" value="" row="1"> </textarea>';
            html += '<button id="removeRow" type="button" class="btn-remove">Remove</button>';
            html += '</div>';
           

            $('#newRow').append(html);
        });


        // remove row
        $(document).on('click', '#removeRow', function () {
            $(this).closest('.days').remove();
        });

           function delete_mobile($id){

     if(confirm("do you want delete this mobile number ?")){
             $.ajax({

                url:'delete_mobileno/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.tag_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  

        function delete_address($id){

     if(confirm("do you want delete this Address ?")){
             $.ajax({

                url:'delete_address/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('#address_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  



         
</script>

 <style type="text/css">

    .address{

        height: 10px;


}

      
      .bootstrap-tagsinput .tag {
    margin-right: 2px;
    color: black !important;
    background: #17a2b8!important;
}

.bootstrap-tagsinput {
   width: 75%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #858a8e;
    position: relative;
    /* margin-left: 16px;
*/
     border-radius: 0px;
}

.bg-info {
    background-color: #17a2b8!important;
    height: 30px !important;
    line-height: 24px!important;
   
}
    </style>
</body>
</html>

