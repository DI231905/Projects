@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">

         <div class="mt-5">


             <div class="list1">
                  <h4 class="mb-4">Media Page Section</h4>
                  <button class="btn1"><a href="{{url('admin/add_media_section')}}" style="color:black;">ADD</a></button>
              </div>
          
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th> 
                                    <th>Title</th>   
                                    <th>Update</th>
                                    <th>delete</th>
                                   
                                </tr>
                            </thead>
                         
                             <tbody>

                                @foreach($media_section as $at)
                             
                               <tr class="media_{{$at->id}}">
                                    <td>
                                       <img src="/uploads/{{$at->image}}" height="120" width="120">
                                                                           
                                    </td>

                                    <td>
                                       {{$at->title}}
                                    </td>

    
                                 <td>

                                     <button class="btn0 btn2"><a href="{{url('admin/update_media_section')}}/{{$at->id}}"><i class="fal fa-pencil"></i></a></button>
                              
                              </td>
                              <td>
                                <button class="btn3 btn0" onclick="deletemediasection({{$at->id}})"><i class="fal fa-trash-alt"></i></button>
                              </td>

                                @endforeach
                                
                            </tbody>
                          
                         
                           
                        </table>
                    </div>
                 </div>



        
      </div>
           

       @endsection

         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">


         function deletemediasection($id){

     if(confirm("do you want delete this section ?")){
             $.ajax({

                url:'delete_media_section/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.media_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
        
        

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    