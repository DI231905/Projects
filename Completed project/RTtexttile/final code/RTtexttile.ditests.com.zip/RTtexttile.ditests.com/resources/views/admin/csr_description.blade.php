@extends('admin.layouts.app')

@section('content')

    <div class="page mt-4 hosting-page title1" style="display: block;">
    
          <div class="mt-5">
                   
                <h4 class="mb-4">CSR Page Description</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Title</th> 
                                    <th>Description</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                         
                             <tbody>

                                @foreach($csr_description as $hd)
                             
                               <tr>
                                    <td>
                                       {{$hd->title}}                                     
                                    </td>

                                    <td>
                                     {!!$hd->description!!} 
                                    </td>

    
                                 <td><button class="btn0 btn2"><a href="{{url('admin/update_csr_description')}}/{{$hd->id}}">Update</a></button></td>
                                   
                                </tr>

                                @endforeach
                                
                            </tbody>
                          
                         
                           
                        </table>
                    </div>
                 </div>


               </div>
              @endsection

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
       <script type="text/javascript">
                   
       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });





      </script>
    
       