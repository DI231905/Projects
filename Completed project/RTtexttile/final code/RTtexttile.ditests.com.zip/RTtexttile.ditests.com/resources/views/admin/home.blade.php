@extends('admin.layouts.app')

@section('content')

   <div class="page mt-4 hosting-page title1">
                <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4"> Product List</h4>
                        <button class="btn1"><a href="{{url('admin/add_product')}}">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Banner Image</th>
                                    <th>Product Image</th>
                                    <th>Name</th>
                                    <th>View</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <tbody>
                            
                                 @foreach($product as $p)
                                <tr class="product_{{$p->id}}">
                                    <td>

                                      <img src="/uploads/{{$p->banner_image}}" width="120" height="120">
                                        {{$p->banner_image}}
                                    </td>

                                     <td>

                                      <img src="/uploads/{{$p->product_image}}" width="120" height="120">
                                        {{$p->product_image}}
                                    </td>
                                

                                       <td>
                                         {{$p->name}}
                                      </td>
                                    <td>

                                        <button class="btn3 btn0"><a href="{{url('admin/view_product')}}/{{$p->id}}" ><i class="fa fa-eye" aria-hidden="true"></i></a></button>
                                       
                                    </td>
                                    
                          
                                 <td>

                                     <button class="btn0 btn2"><a href="{{url('admin/update_product')}}/{{$p->id}}"><i class="fal fa-pencil"></i></a></button>
                              
                              </td>
                              <td>
                                <button class="btn3 btn0" onclick="delete_product({{$p->id}})"><i class="fal fa-trash-alt"></i></button>
                              </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 


   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(3000); }, 3000)

             });


         function delete_product($id){

     if(confirm("do you want delete this product ?")){
             $.ajax({

                url:'delete_product/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.product_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
        




     
        
        
        
      
      </script>

  <style type="text/css">
  	.data{

  		margin-left: 25px;
  	}

  </style>
  @endsection