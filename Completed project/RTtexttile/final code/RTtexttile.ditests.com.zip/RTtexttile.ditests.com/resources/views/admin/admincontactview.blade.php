@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Admin Contact Info</h4>
                  
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>   
                                    <th>Email</th>
                                    <th>Phone</th> 
                                    <th>Address</th>
                                    <th>Opening Day</th>   
                                    <th>Opening Time</th>
                                    <th>Company Type</th> 
                                    <th>Company Certification</th>
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                        
                             <tbody>
                               
                               <tr class="">
                                  @foreach($admindata as $a)
                                    <td>{{$a->name}}</td>

                                    <td>{{$a->email}}</td>

                                    <td>

                                        
                                        @foreach($phone_no as $p)

                                          @if($a->id== $p->admin_id)

                                           <li>{{$p->phone}}</li>
                                        

                                          @endif


                                        @endforeach          

                                    </td>

                                    <td>
                                         @foreach($address as $ad)

                                          @if($a->id== $ad->admin_id)

                                           <li>{{$ad->address}}</li>
                                        

                                          @endif


                                        @endforeach

                                    </td>

                                    <td>{{$a->opening_day}}</td>
                                    <td>{{$a->opening_time}}</td>
                                    <td>{{$a->company_type}}</td>
                                    <td>{{$a->company_certification}}</td>

                                
                                  @endforeach  
                             <td>
                                <button class="btn0 btn2"><a href="{{url('/admin/updateadmincontact')}}/{{$a->id}}"><i class="fal fa-pencil"></i></a></button>
                              </td>
                              
                            
                                </tr>
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

             $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

              }); 
        
         function deletehomebanner($id){

     if(confirm("do you want delete this banner ?")){
             $.ajax({

                url:'deletehomebannerdata/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.banner_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
      </script>

       @endsection