   
@extends('admin.layouts.app')

@section('content')

    <div class="page mt-4 hosting-page title1" style="display: block;">
      <div class="mt-5">
                   
                   <h4 class="mb-4">Vision & Mission page Banner</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th> 
                                    <th>Page Name</th>   
                                    <th>Image</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                           @foreach($allbanner as $a)
                           
                           @if($a->name=="Vision & Mission")
                             <tbody>
                             
                               <tr>
                                    <td>
                                      {{$a->name}}
                                    </td>

                                      <td>
                                      {{$a->page_name}}
                                    </td>
                                   
                                    <td>

                                       <img src="/uploads/{{$a->image}}" width="400" height="200"><br>
                                       {{$a->image}}  
                                         
                                    </td>

                                     
                             <td><button class="btn0 btn2"><a href="{{url('admin/updatebannerimg')}}/{{$a->id}}">Update</a></button></td>
                                   
                                </tr>
                                
                            </tbody>
                            @endif
                            @endforeach
                           
                        </table>
                    </div>
                 </div>


                        <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Vision & Mission</h4>
                        <button class="btn1"><a href="{{url('admin/add_mission_vission')}}">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>

                                    <th>Icon</th> 
                                    <th>Title</th>    
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           @foreach($mission_vision as $hd)
                             <tbody>
                             
                               <tr class="mission_{{$hd->id}}">

                                      <td>

                                        <i class="{{$hd->icon}}"></i>
                                     
                                       {{$hd->icon}}
                                    </td>
                                    

                                     <td>
                                      {{$hd->title}}
                                    </td>


                                   
                                   
                                    <td>
                                    {{ $hd->description }}
                                    </td>


                                   <td>

                                    <button class="btn0 btn2"><a href="{{url('admin/update_mission_vission')}}/{{$hd->id}}"><i class="fal fa-pencil"></i></a></button>
                              
                                   </td>
                                    <td>
                                 <button class="btn3 btn0" onclick="deletemission_vision({{$hd->id}})"><i class="fal fa-trash-alt"></i></button>
                                 </td>
                                          
                                  
                                </tr>
                                
                            </tbody>
                            @endforeach
                           
                        </table>
                    </div>
                 </div>
               </div>
              @endsection

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
       <script type="text/javascript">
                   
       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });



  function deletemission_vision($id){
    // alert('i am here');

     if(confirm("do you want delete this  ?")){
             $.ajax({

                url:'delete_mission_vission/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.mission_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 


      </script>
    
       