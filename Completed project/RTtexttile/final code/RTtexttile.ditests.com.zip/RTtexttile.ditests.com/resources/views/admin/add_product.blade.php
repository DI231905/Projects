<!DOCTYPE html>
<html>
<head>
       <title>Ramdev Traders</title>
    <link rel="stylesheet" type="text/css" href="/css/upload.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css">
      <link rel="icon" type="image/png" href="/image/logo.jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body"> 
                             

    <div class="page my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">ADD NEW PRODUCT</h4>
            <div class="detail">
                <div class="form">

                 <form  action="{{url('admin/store_product')}}" enctype="multipart/form-data" method="POST" >
                         @csrf

                           <div class="part">
                            <div class="col-md-12 label">
                                <label>Banner Image</label>
                            </div>
                            <div class="col-md-12">
                                 <input type="file" name="banner_image" value="" onchange="readURL(this);">
                                    @if($errors->has('banner_image')) <p class="error_mes">{{ $errors->first('banner_image') }}</p> @endif
                                 <img id="blah" src="#" alt="" />

                               
                             </div>   
                        </div>


                         <div class="part">
                            <div class="col-md-12 label">
                                <label>Product Image</label>
                            </div>
                            <div class="col-md-12">
                                 <input type="file" name="product_image"  onchange="readURL1(this);">
                                  @if($errors->has('product_image')) <p class="error_mes">{{ $errors->first('product_image') }}</p> @endif
                                 <img id="blah1" src="#" alt="" />

                               
                             </div>   
                        </div>

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Name</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Name" name="name" value="">
                                  @if($errors->has('name')) <p class="error_mes">{{ $errors->first('name') }}</p> @endif
                            </div>   
                        </div> 

                
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Description</label>
                            </div>
                             <div class="col-md-12 data">
                                   <textarea placeholder="Enter text.."  name="description" value="" id="summernote"></textarea><br>
                                     @if($errors->has('description')) <p class="error_mes">{{ $errors->first('description') }}</p> @endif
                            </div>   
                        </div> 

                           <div class="part">
                            <div class="col-md-12 label">
                                <label>Product Specifications</label>
                            </div>
                             <div class="col-md-12 data">
                                   <textarea placeholder="Enter text.."  name="specification" value="" id="summernote"></textarea><br>
                                     @if($errors->has('specification')) <p class="error_mes">{{ $errors->first('specification') }}</p> @endif
                            </div>   
                        </div>

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Product Features</label>
                            </div>
                             <div class="col-md-12 data">
                                   <textarea placeholder="Enter text.."  name="features" value="" id="summernote"></textarea><br>
                                     @if($errors->has('features')) <p class="error_mes">{{ $errors->first('features') }}</p> @endif
                            </div>   
                        </div>

                         <div class="part">
                            <div class="col-md-12 label">
                                <label>Product Application</label>
                            </div>
                             <div class="col-md-12 data">
                                   <textarea placeholder="Enter text.."  name="application" value="" id="summernote"></textarea><br>
                                     @if($errors->has('application')) <p class="error_mes">{{ $errors->first('application') }}</p> @endif
                            </div>   
                        </div>  
                        
                        <div class="main-button">
                          <button class="btn1">Add</button> 
                       
                      <a href="{{url('admin/product')}}"> Back to Home?</a>
                            
                        </div>
          
                    </form>             
                </div>  
            </div>
         </div>
      </div>
   </body>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>

    <script type="text/javascript">

         $('textarea#summernote').summernote({
        placeholder: 'Hello bootstrap 4',
        tabsize: 2,
        height: 100,
  toolbar: [
        ['style', ['style']],
        ['font', ['bold', 'italic', 'underline', 'clear']],
        // ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
        //['fontname', ['fontname']],
       // ['fontsize', ['fontsize']],
        ['color', ['color']],
        ['para', ['ul', 'ol', 'paragraph']],
        ['height', ['height']],
        ['table', ['table']],
        ['insert', ['link', 'picture', 'hr']],
        //['view', ['fullscreen', 'codeview']],
        ['help', ['help']]
      ],
      });


             function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result)
                        .width(130)
                        .height(130);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

          function readURL1(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah1')
                        .attr('src', e.target.result)
                        .width(130)
                        .height(130);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }




    

    </script>

    <style type="text/css">
        /*.col-md-12 {
   
        display: flex;
     }
*/
    .gallery{

          margin-bottom: 23px;
          margin-right: 15px;
    }



    </style>
</html>
