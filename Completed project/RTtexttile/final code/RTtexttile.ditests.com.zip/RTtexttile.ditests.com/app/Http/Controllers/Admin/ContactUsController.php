<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;

class ContactUsController extends Controller
{


       public function __construct(){

                $this->middleware('auth:admin');
        }

    public function ContactusBannerlist(){

           $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $allbanner=DB::table('banner_image')->get();
           $data['allbanner']=$allbanner;
         

             return view('admin.ContactusBannerlist',$data);
 
         }

           public function view_contact_us_msg(){

           $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $get_in_touch=DB::table('contact_us')->get();
           $data['get_in_touch']=$get_in_touch;
         

             return view('admin.get_in_touch',$data);
 
         }

             public function delete_contact_us($id){

           DB::table('contact_us')->where('id',$id)->delete();
         
          
          return response()->json(['success'=>'data deleted successfully!!!']);

         }

         
}
