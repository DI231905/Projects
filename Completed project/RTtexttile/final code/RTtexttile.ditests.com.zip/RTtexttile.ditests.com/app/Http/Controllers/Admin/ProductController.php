<?php


namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;



class ProductController extends Controller
{

	   public function __construct(){

                $this->middleware('auth:admin');
        }



         public function product()
         {
          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

          $product=DB::table('product')->get();
          $data['product']=$product;

          return view('admin.product',$data);
         }

         public function add_product()
         {
           return view('admin.add_product');
         }

         public function store_product(Request $request)
         {
           $error=$request->validate([

               'banner_image'=>'required',
               'product_image'=>'required',
               'name'=>'required',
               'description'=>'required'

           ]);

      
             $name=$request->input('name');
             $file = $request->file('banner_image');
             $file1 = $request->file('product_image');
             $description=$request->input('description');
             $specification=$request->input('specification');
             $features=$request->input('features');
             $application=$request->input('application');

    
    
             $imagename=' ';

             if ($file){
               
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
     
                   $file->move($destinationPath,$imagename); 
     
              }

          $imagename1=' ';

            if($file1){
              
              $destinationPath='uploads';
              $imagename1=time().'_'.$file1->getClientOriginalName();

             $file1->move($destinationPath,$imagename1); 

                }



            DB::table('product')->insert(['name'=>$name,'banner_image'=>$imagename, 'product_image'=>$imagename1,'description'=> $description,'specification'=> $specification ,'features'=> $features ,'application'=> $application]);
       
     
           return redirect('admin/product')->with('error','Product data inserted successfully!!!');

         }

         public function delete_product($id)
         {
          $product=DB::table('product')->where('id',$id)->get();
        

           if ($product[0]->banner_image!='') {

            unlink(public_path("/uploads/".$product[0]->banner_image));

            }

            if ($product[0]->product_image!='') {

            unlink(public_path("/uploads/".$product[0]->product_image));


            }

            DB::table('product')->where('id', $id)->delete();



          return response()->json(['success'=>'Service data deleted successfully!!!']);
         }

         public function update_product($id)
         {
           $product=DB::table('product')->where('id',$id)->get();
             $data['id']=$product[0]->id;
             $data['name']=$product[0]->name;
             $data['banner_image']=$product[0]->banner_image;
             $data['product_image']=$product[0]->product_image;
             $data['description']=$product[0]->description;
             $data['specification']=$product[0]->specification;
             $data['features']=$product[0]->features;
             $data['application']=$product[0]->application;

            return view('admin.update_product',$data);
         }

         public function store_update_product(Request $request,$id)
         {
           $error=$request->validate([

               'name'=>'required',
               'description'=>'required'

           ]);

             $name=$request->input('name');
             $file = $request->file('banner_image');
             $file1 = $request->file('product_image');
             $description=$request->input('description');
             $specification=$request->input('specification');
             $features=$request->input('features');
             $application=$request->input('application');


                        $imagename='';
                        $imagename1='';
                    

                        if($file){
                         
                          $destinationPath='uploads';
                          $imagename=time().'_'.$file->getClientOriginalName();
                    
                           $file->move($destinationPath,$imagename);

                           DB::table('product')->where('id', $id)->update(['banner_image'=>$imagename]);

                            if ($request->input('oldimage')!='') {

                             unlink(public_path("/uploads/".$request->input('oldimage')));

                             }

                           }

                          if($file1){
                         
                          $destinationPath='uploads';
                          $imagename1=time().'_'.$file1->getClientOriginalName();
                    
                           $file->move($destinationPath,$imagename1);

                           DB::table('product')->where('id', $id)->update(['product_image'=>$product_image]);

                            if ($request->input('oldimage1')!='') {

                             unlink(public_path("/uploads/".$request->input('oldimage1')));

                             }

                           }

                          DB::table('product')->where('id', $id)->update(['name'=>$name,'description'=> $description,'specification'=> $specification ,'features'=> $features ,'application'=> $application]);

                  return redirect('admin/product')->with('error','Product data updated successfully!!!');

         }

         public function view_product($id){

            $product=DB::table('product')->where('id',$id)->get();
             $data['id']=$product[0]->id;
             $data['name']=$product[0]->name;
             $data['banner_image']=$product[0]->banner_image;
             $data['product_image']=$product[0]->product_image;
             $data['description']=$product[0]->description;
             $data['specification']=$product[0]->specification;
             $data['features']=$product[0]->features;
             $data['application']=$product[0]->application;

            return view('admin.product_detail',$data);


         }



         
}
