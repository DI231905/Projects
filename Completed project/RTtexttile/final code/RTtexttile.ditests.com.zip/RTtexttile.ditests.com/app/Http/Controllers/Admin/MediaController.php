<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;

class MediaController extends Controller
{
     public function __construct(){

                $this->middleware('auth:admin');
        }



         public function media_banner(){



            $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $allbanner=DB::table('banner_image')->get();
           $data['allbanner']=$allbanner;
         

             return view('admin.media_banner',$data);
 
         }

           public function media_section(){

           $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $media_section=DB::table('media_section')->get();
           $data['media_section']=$media_section;


            return view('admin.media_section',$data);
          }


          public function add_media_section(){


            return view('admin.add_media_section');

          }





          public function store_media_section(Request $request){


             $error=$request->validate([

               'image'=>'required',
               'title'=>'required',
              
           ]);

           $title=$request->input('title');
           $image=$request->file('image');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);
       
           }
           DB::table('media_section')->insert(['title'=>$title,'image'=>$imagename]);

           return redirect('admin/media_section')->with('error','Media Section inserted successfully!!!');


          }

          public function update_media_section($id){

             $media_section=DB::table('media_section')->get();
             $data['id']=$media_section[0]->id;
             $data['title']=$media_section[0]->title;
             $data['image']=$media_section[0]->image;
      
           return view('admin.update_media_section',$data);


          }

          public function store_update_media_section(Request $request, $id){

             $error=$request->validate([

              'title' => 'required',
            
               
            ]);

           $title=$request->input('title');

           $file=$request->file('image');

           $imagename='';

            if($file){
         
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
               $file->move($destinationPath,$imagename);

               DB::table('media_section')->where('id', $id)->update(['image'=>$imagename]);

              if($request->input('oldimage')!='') {

                    unlink(public_path("/uploads/".$request->input('oldimage')));  
                 }
              }
        

         DB::table('media_section')->where('id',$id)->update(['title'=>$title]);
       
          return redirect('admin/media_section')->with('error','media_section updated sucessfully !!' );
        

        }

        public function delete_media_section($id)
         {
          $list=DB::table('media_section')->where('id',$id)->get();
          $image=$list[0]->image;

          if($image!='')
          {
               unlink(public_path('/uploads/'.$image));
          }

          DB::table('media_section')->where('id',$id)->delete();

          return response()->json(['success'=>'Benefits data deleted successfully!!!']);
         }

         

         public function certificate(){

           $id=Auth::id();
           $admin=Admin::where('id',$id)->get();

           $data['name']=$admin[0]->name;

           $certificate=DB::table('certificate')->get();
           $data['certificate']=$certificate;

           $allbanner=DB::table('banner_image')->get();
           $data['allbanner']=$allbanner;
         


          return view('admin.certificate',$data);

         }


          public function add_certificate(){
         
              return view('admin.add_certificate');
          }
          public function store_certificate(Request $request){
   
               $request->validate([

                  'file' => 'required',
      
                  ]);

                 $file=$request->file('file');
             $filename=' ';
       
         foreach($file as $key =>$f) {

             $destinationPath='uploads';
             $filename=time().'_'.$f->getClientOriginalName();
   
             $f->move($destinationPath,$filename);

             DB::table('certificate')->insert(['image'=>$filename]);
             
             
             }
 
              return redirect('admin/certificate')->with('error','your image insert sucessfully!!');
          } 

    /*------------gallary data----------------*/

      public function delete_certificate($id){

          $gallary=DB::table('certificate')->where('id', $id)->get();


          if ($gallary[0]->image!=''){

             unlink(public_path("/uploads/".$gallary[0]->image));
            }

           DB::table('certificate')->where('id', $id)->delete();

           return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);


          }


          public function csr_banner(){

           $id=Auth::id();
           $admin=Admin::where('id',$id)->get();

           $data['name']=$admin[0]->name;


           $allbanner=DB::table('banner_image')->get();
           $data['allbanner']=$allbanner;
         

          return view('admin.csr_banner',$data);

         }
         public function csr_description(){


            $id=Auth::id();
            $admin=Admin::where('id',$id)->get();

            $data['name']=$admin[0]->name;

            $csr_description=DB::table('csr_description')->get();
            $data['csr_description']=$csr_description;
         
            return view('admin.csr_description',$data);


          }

          


         public function update_csr_description(){

             $csr_description=DB::table('csr_description')->get();
             $data['id']=$csr_description[0]->id;
             $data['title']=$csr_description[0]->title;
             $data['description']=$csr_description[0]->description;
      
           return view('admin.update_csr_description',$data);


          }

       public function store_update_csr_description(Request $request,$id){


          $error=$request->validate([

             'title' => 'required',
            'description' => 'required',
                 
          ]);
       
         $title=$request->input('title');
         $description=$request->input('description');
 
        DB::table('csr_description')->where('id', $id)->update(['title'=>$title,'description'=>$description]);

        return redirect('admin/csr_description')->with('error','The CSR page description has been updated sucessfully' );

    }
    public function csr_initiative(){

        $id=Auth::id();
            $admin=Admin::where('id',$id)->get();

            $data['name']=$admin[0]->name;

            $csr_initiative=DB::table('csr_initiative')->get();
            $data['csr_initiative']=$csr_initiative;

             $csr_initiative_image=DB::table('csr_initiative_image')->get();
            $data['csr_initiative_image']=$csr_initiative_image;
         
   
       return view('admin.csr_initiative',$data);


    }

     public function add_csr_initiative(){


        return view('admin.add_csr_initiative');


      
      }

   public function store_csr_initiative(Request $request){

        $error=$request->validate([
 
             'title' => 'required',
             'main_title' => 'required',
             'description' => 'required',
                 
           ]);
       
         $title=$request->input('title');
         $main_title=$request->input('main_title');
         $description=$request->input('description');
         $file=$request->file('file');


         DB::table('csr_initiative')->insert(['title'=>$title,'main_title'=>$main_title,'description'=>$description]);

          $csr_initiative_id=DB::table('csr_initiative')->max('id');

        
           if($file !=''){

              $filename='';
       
           foreach($file as $key =>$f){

                     $destinationPath='uploads';
                     $filename=time().'_'.$f->getClientOriginalName();
           
                     $f->move($destinationPath,$filename);

                     DB::table('csr_initiative_image')->insert(['image'=>$filename,'csr_initiative_id'=>$csr_initiative_id]);           
           
                }
           }
     
        return redirect('admin/csr_initiative')->with('error','The CSR Initiative has been inserted sucessfully' );

      }


          public function update_csr_initiative($id){

             $csr_initiative=DB::table('csr_initiative')->get();
             $data['id']=$csr_initiative[0]->id;
             $data['title']=$csr_initiative[0]->title;
             $data['main_title']=$csr_initiative[0]->main_title;
             $data['description']=$csr_initiative[0]->description;


            $csr_initiative_image=DB::table('csr_initiative_image')->where('csr_initiative_id',$id)->get();
            $data['csr_initiative_image']=$csr_initiative_image;
         
        
      
           return view('admin.update_csr_initiative',$data);


          }

          public function update_csr_initiative_image($id){


            $csr_initiative_image=DB::table('csr_initiative_image')->where('id',$id)->get();
   
             $data['csr_initiative_image']=$csr_initiative_image[0]->image;
             $data['id']=$csr_initiative_image[0]->id;

             return view('admin.update_csr_image',$data);

          }


          public function store_csr_initiative_image(Request $request, $id){


          $csr_initiative_image=DB::table('csr_initiative_image')->where('id',$id)->get();
          $csr_initiative_id=$csr_initiative_image[0]->csr_initiative_id;


           $file=$request->file('image');

        
            $imagename='';

             if($file){
         
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
                
               $file->move($destinationPath,$imagename);

               DB::table('csr_initiative_image')->where('id', $id)->update(['image'=>$imagename]);

              if($request->input('oldimage')!='') {

                    unlink(public_path("/uploads/".$request->input('oldimage')));  
                 }
               }
            
              return redirect('admin/update_csr_initiative/'.$csr_initiative_id);



          }

          public function store_update_csr_initiative(Request $request, $id){

               $error=$request->validate([
 
             'title' => 'required',
             'main_title' => 'required',
             'description' => 'required',
                 
           ]);
       
         $title=$request->input('title');
         $main_title=$request->input('main_title');
         $description=$request->input('description');
         $file=$request->file('file');


         DB::table('csr_initiative')->where('id',$id)->update(['title'=>$title,'main_title'=>$main_title,'description'=>$description]);


           if($file !=''){


             $filename=' ';
       
               foreach($file as $key =>$f){

                   $destinationPath='uploads';
                   $filename=time().'_'.$f->getClientOriginalName();
         
                   $f->move($destinationPath,$filename);

                   DB::table('csr_initiative_image')->insert(['image'=>$filename,'csr_initiative_id'=>$id]);           
           
                }


           }

            
        return redirect('admin/csr_initiative')->with('error','The CSR Initiative has been updated sucessfully' );


          }

         public function delete_csr_initiative($id){

          $csr_image=DB::table('csr_initiative_image')->where('csr_initiative_id', $id)->get();

          if($csr_image !=''){

             foreach ($csr_image as $key => $csr){

                if($csr->image !=''){

                       unlink(public_path("/uploads/".$csr->image));
                
                   }

              
                }


             }

           
 
            DB::table('csr_initiative_image')->where('csr_initiative_id', $id)->delete();


            DB::table('csr_initiative')->where('id', $id)->delete();

          

           return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);



         }

  
  }
