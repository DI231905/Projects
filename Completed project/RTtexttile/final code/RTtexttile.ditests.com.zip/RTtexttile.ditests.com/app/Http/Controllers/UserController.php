<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function index(){

   


           $banner=DB::table('banner')->get();
           $data['banner']=$banner;

            $home_aboutus=DB::table('home_aboutus')->get();
             $data['home_image']=$home_aboutus[0]->image;
             $data['home_title']=$home_aboutus[0]->title;
             $data['home_description']=$home_aboutus[0]->description;



            $features=DB::table('features')->get();
            $data['features']=$features;

            $achive_target=DB::table('achive_target')->get();
            $data['achive_target']=$achive_target;

            $achieve_target_desc=DB::table('achieve_target_desc')->get();
            $data['achieve_title']=$achieve_target_desc[0]->title;
            $data['achieve_main_title']=$achieve_target_desc[0]->main_title;
            $data['achieve_description']=$achieve_target_desc[0]->description;

             $product_desc=DB::table('product_desc')->get();
              $data['product_title']=$product_desc[0]->title;
              $data['product_main_title']=$product_desc[0]->main_title;
              $data['product_description']=$product_desc[0]->description;

            $product=DB::table('product')->get();
            $data['product']=$product;








         $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;
         
    	    return view('welcome',$data);
    }


    public function about_us(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

        $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

            $address=DB::table('address')->where('admin_id',1)->get();
            $data['address']=$address;

           $about_section=DB::table('about_section')->get();
           $data['about_section']=$about_section;  

             $product=DB::table('product')->get();
            $data['product']=$product;
 

       return view('about',$data);


    }


     public function who_we_are(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

      $product=DB::table('product')->get();
      $data['product']=$product;

          $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;

          $who_we_are_desc=DB::table('who_we_are_desc')->get();
          $data['who_we_are_desc']=$who_we_are_desc[0]->description;
         

       return view('who_we_are',$data);

    }


     public function rt_story(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

      $product=DB::table('product')->get();
      $data['product']=$product;

          $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;

        
          $history_desciption=DB::table('history_desciption')->get();
           $data['history_desciption']=$history_desciption[0]->description;
           $data['history_title']=$history_desciption[0]->title;

           $history_data=DB::table('history_data')->get();
           $data['history_data']=$history_data;
         

       return view('rt_story',$data);

    }

     public function mission_vision(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

      $product=DB::table('product')->get();
      $data['product']=$product;


      $mission_vision=DB::table('mission_vision')->get();
      $data['mission_vision']=$mission_vision;



          $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;

          
          return view('mission_vision',$data);

    }


        public function media(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

      $product=DB::table('product')->get();
      $data['product']=$product;

          $media_section=DB::table('media_section')->get();
           $data['media_section']=$media_section;





          $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;

          
          return view('media',$data);

    }

        public function certification(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

      $product=DB::table('product')->get();
      $data['product']=$product;

         $certificate=DB::table('certificate')->get();
         $data['certificate']=$certificate;




          $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;

          
          return view('certificate',$data);

    }

      public function csr(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

      $product=DB::table('product')->get();
      $data['product']=$product;

   
          $csr_description=DB::table('csr_description')->get();
          $data['csr_description']=$csr_description[0]->description;

            $csr_initiative=DB::table('csr_initiative')->get();
            $data['csr_initiative']=$csr_initiative;

             $csr_initiative_image=DB::table('csr_initiative_image')->get();
             $data['csr_initiative_image']=$csr_initiative_image;
         
         




          $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;

          
          return view('csr',$data);

    }
       public function contact_us(){
           
              $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

           
           
/*
      $allbanner=DB::table('banner_image')->where('name','Contact Us')->get();
      $data['banner_image']=$allbanner[0]->image;*/

        $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;
           $product=DB::table('product')->get();
      $data['product']=$product;

          
          return view('contact_us',$data);

    }

    public function store_contact_us(Request $request){

       $error=$request->validate([

               'name'=>'required',
               'email'=>'required|email',
               'subject'=>'required',
               'description'=>'required'

           ]);

            $name=$request->input('name');

            $email=$request->input('email');
            $subject=$request->input('subject');
            $description=$request->input('description');

     
        $inquiry=DB::table('contact_us')->insert(['name'=>$name,'email'=>$email,'subject'=>$subject,'description'=>$description]);

    /* if($inquiry){

             $img_url = env('APP_URL')."/uploads/1641381228_logo.png";
       
             $meta['from_email']="ditest787@gmail.com";
             $meta['email']="apptest2303@gmail.com";
             $meta['subject']="New Get Started Inquiry";  
             $meta['image']= $img_url;
             $meta['email1']= $email;
              $meta['name']= $name;
             $meta['mobileno']= $number;
          
      
           Mail::send('email.getintouch', $meta, function($m) use($meta){
        
               $m->from($meta['FROM_EMAIL'],'New Get Started Inquiry');
               $m->to($meta['email']);
               $m->subject($meta['subject']); 
             });
       }*/

      return redirect('/contact_us')->with('error',' Inquiry submited succesfully!!!!');

    }


      public function product(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

      $product=DB::table('product')->get();
      $data['product']=$product;




          $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;

          
          return view('product',$data);

    }



      public function  product_detail($id){

     
         $product1=DB::table('product')->where('id',$id)->get();
             $data['p_name']=$product1[0]->name;
             $data['banner_image']=$product1[0]->banner_image;
             $data['product_image']=$product1[0]->product_image;
             $data['description']=$product1[0]->description;
             $data['specification']=$product1[0]->specification;
             $data['features']=$product1[0]->features;
             $data['application']=$product1[0]->application;
             
             $product=DB::table('product')->get();
            $data['product']=$product;

             

          $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

           $list=DB::table('admininfo')->where('id',1)->get();
        
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
      
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
           $data['phone_no']=$phone_no;

          $address=DB::table('address')->where('admin_id',1)->get();
          $data['address']=$address;

          
          return view('product_detail',$data);

    }
    
     public function search(Request $request){

         	$text = $request->input('text');



         	if($text !=''){

          $search_result=DB::table('product')->where('name', 'like', '%' . $text . '%')->get();

        }else{


        	   $search_result=DB::table('product')->get();
        


        }

          $total_row = $search_result->count();

          $output='';


      if($total_row > 0)
      {
        foreach($search_result as $row)
      {

        $output .= ' <a href="/product_detail/'.+$row->id.'">'.$row->name.'</a> ';
        }

      }
      else
      {
      
          $output .='<h6> Search data is not available...</h6>';

      }  
           return response($output);
         }

  






 

    
}
