<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Admin;
use Carbon\carbon;
use DB;
use Hash;
use \Crypt;
use Illuminate\support\facades\Auth;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class Admincontroller extends Controller{


   public function __construct(){

                $this->middleware('auth:admin');
        }

   public function home(){
 
       $admin=Auth::guard('admin')->user();

       
          $data['admin']=$admin;

         $data['site_url']= env('APP_URl');
         $data['metatitle']='home page';

         $id=Auth::id();
         $admin=Admin::where('id',$id)->get();

         $data['name']=$admin[0]->name;
         
             $product=DB::table('product')->get();
          $data['product']=$product;


         return view('admin.home',$data);
      
     } 

      

     /*----------- change password ---------------*/

      public function changepassword(){
       
         return view('admin.changepassword');
     }

      public function updatepassword(Request $request,$id){

          $error=$request->validate([
              'oldpassword' => 'required|string',
              'newpassword' => 'required|string|min:6',
           
              ]);

             $oldpassword=$request->input('oldpassword');
             $newpassword=$request->input('newpassword');

             $password=DB::table('admins')->where('id', $id)->get();

             $password1=$password[0]->password;

           if(Hash::check($oldpassword,$password1)){

               DB::table('admins')->where('id', $id)->update(['password'=>Hash::make($newpassword)]);

               return redirect('admin/home')->with('error','your password has been update sucessfully' );

               }else{

                return Redirect::back()->with('error','Your Old password is not correct!!!!');

            }
         }



         public function footer_data_list(){

                 $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;


           $footer_data=DB::table('footer_data')->get();
           $data['footer_data']=$footer_data;

       
           return view('admin.footeraboutlist',$data);

          }


        public function update_footer_data($id){

         $footer_data=DB::table('footer_data')->where('id',$id)->get();
         $data['image']=$footer_data[0]->image;
         $data['title']=$footer_data[0]->title;
         $data['id']=$footer_data[0]->id;
         $data['description']=$footer_data[0]->description;
                

          return view('admin.update_footer_about',$data);

          }

          public function delete_footer_data($id){

             DB::table('footer_tag')->where('id',$id)->delete();

             return response()->json([
                'success' => 'Record has been deleted successfully!'
             ]);


          }

          public function store_update_footer_data(Request $request, $id){

              $request->validate([

                   'title' => 'required',
                   'description' => 'required',
           
              ]);

              $title=$request->input('title');
              $description=$request->input('description');

              $file=$request->file('image');
  
              $imagename='';

              if($file){
         
                    $destinationPath='uploads';
                    $imagename=time().'_'.$file->getClientOriginalName();
                    $file->move($destinationPath,$imagename);
     
                   DB::table('footer_data')->where('id', $id)->update(['image'=>$imagename]);

               if($request->input('oldimage')!='') {

                     unlink(public_path("/uploads/".$request->input('oldimage')));  
                  }
               }

            

            DB::table('footer_data')->where('id', $id)->update(['title'=>$title,'description'=>$description]);
 
           return redirect('admin/footer_data_list')->with('error','Footer data updated sucessfully!');


           }

              public function admincontactview()
         {
            $id=Auth::id();

            $admin=Admin::where('id',$id)->get();
            $data['name']=$admin[0]->name;

            $admindata=DB::table('admininfo')->get();
            $data['admindata']=$admindata;

            $phone_no=DB::table('phone_no')->get();
            $data['phone_no']=$phone_no;

            $address=DB::table('address')->get();
            $data['address']=$address;

            return view('admin.admincontactview',$data);
         }
         public function updateadmincontact($id)
         {
           $list=DB::table('admininfo')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
          /* $data['phone']=$list[0]->phone;
           $data['address']=$list[0]->address;*/
           $data['opening_time']=$list[0]->opening_time;
           $data['opening_day']=$list[0]->opening_day;
           

           $data['company_type']=$list[0]->company_type;
           $data['company_certification']=$list[0]->company_certification;

           $phone_no=DB::table('phone_no')->get();
            $data['phone_no']=$phone_no;

            $address=DB::table('address')->get();
            $data['address']=$address;
           
           return view('admin.updateadmincontact',$data);
         }
         public function storeadmincontact(Request $request,$id)
         {

           $error=$request->validate([
             
              'name' => 'required',
              'email' => 'required',
              
              ]);
            

            $name=$request->input('name');
            $email=$request->input('email');

            $opening_day=$request->input('opening_day');
           
            $opening_time=$request->input('opening_time');
            $company_type=$request->input('company_type');
            $company_certification=$request->input('company_certification');
         

            $phone=$request->input('phone');
            $phones = explode(",", $phone);

             $address=$request->input('address');
             $addresses=$request->input('addresses');

             if($address !=''){

                DB::table('address')->insert(['address'=>$address, 'admin_id'=>$id]);


             }

             if($addresses !=''){


             foreach($addresses as $key => $a){

               DB::table('address')->insert(['address'=>$a, 'admin_id'=>$id]);
         
                }

              }

              if($phone !=''){

                  foreach($phones as $key => $p){

                    DB::table('phone_no')->insert(['phone'=>$p, 'admin_id'=>$id]);
        
                }

              }


            DB::table('admininfo')->where('id',$id)->update(['name'=>$name,'email'=>$email,'opening_time'=>$opening_time,'company_type'=>$company_type,'company_certification'=>$company_certification,'opening_day'=>$opening_day]);

            return redirect('admin/admincontactview')->with('error','Admin Contact Info Updated Successfully!!!');

         }


               public function delete_mobileno($id){

                  DB::table('phone_no')->where('id',$id)->delete();

                  return response()->json(['success'=>'Mobile deleted successfully!!!',]);



              }


               public function delete_address($id){

                  DB::table('address')->where('id',$id)->delete();

                  return response()->json(['success'=>'Mobile deleted successfully!!!',]);



              }
                   public function update_address($id){




              $address1= DB::table('address')->where('id',$id)->get();

              $data['address']=$address1[0]->address;
             $data['id']=$address1[0]->id;

              return view('admin.update_address',$data);


              }

             public function store_address(Request $request, $id){

            $error=$request->validate([
             
              'address' => 'required', 
             
              ]);

             $address1= DB::table('address')->where('id',$id)->get();
             $admin_id=$address1[0]->admin_id;

              $address=$request->address;

              DB::table('address')->where('id',$id)->update(['address'=>$address]);
            
       
              return redirect('admin/updateadmincontact/'.$admin_id);


              }





        
    }
   

  




