<!DOCTYPE html>
<html>
<head>
	<title>TRAVEL AGENCY</title>
	<link rel="stylesheet" type="text/css" href="/css/main-dashboard.css">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
	<div class="mobile-view">
        <div class="row">
            <div class="col-md-6 col-6 logo1">
              <img src="/image/logo.png" alt="avatar.jpg">
            </div>
            <div class="col-md-6 col-6">
            	<div class="mobile-menu">
                    <div id="mySidepanel" class="sidepanel">
     	                <div class="m_menu">
                	        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>  
                	        <div class="top-nav-wrapper">
                                <div class="top-nav">                       
                                    <div class="co_profile">
                                    	<div class="profile-img">
                                       <img src="/image/avatar.jpg" width="200">

                                    	</div>
                                    	<div class="user-details">
                                            <span id="more-details">John Doe<i class="fa fa-caret-down"></i></span>
                                        </div>
                                    </div>
                                    <div class="main-menu-content">
                                        <ul>
                                            <li class="more-details">
                                                <i class="fa fa-lock" aria-hidden="true"></i><a href="#">Logout</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="nav-slider"></div>
                                    <div class="hosting dash">
                                        <div class="hosting-btn nav-btn">Package list</div>
                                    </div>
                                    <div class="domains dash">
                                        <button class="domain-btn nav-btn">Contact List</button>
                                    </div>
                                    <div class="nav-slider"></div>
                                </div>
                            </div> 
                	    </div>
                    </div>
                    <button class="openbtn" onclick="openNav()">☰</button> 
                </div>
            </div>
        </div> 
    </div>
	<div class="row">
		<div class="col-xl-2 col-lg-3 col-md-6">
		    <div class="two">
                <div class="top-nav-wrapper">
                    <div class="top-nav">
                        <div class="logo">
                        	<img src="/image/logo.png">
                        </div>
                        <div class="co_profile">
                        	<div class="profile-img">
                        		<img src="/image/avatar.jpg" alt="avatar.jpg">
                        	</div>
                        	<div class="user-details">
                                <span id="more-details">John Doe<i class="fa fa-caret-down"></i></span>
                            </div>
                        </div>
                        <div class="main-menu-content">
                                  <ul>
                                      <li class="more-details">
                                          <i class="fa fa-lock" aria-hidden="true"></i><a href="{{route('adminlogout')}}">Logout</a>
                                      </li>
                                       <li class="more-details">
                                          <i class="fa fa-lock" aria-hidden="true"></i><a href="{{url('admin/changepwd')}}">Changepassword</a>
                                      </li>
                                       <li class="more-details">
                                          <i class="fa fa-lock" aria-hidden="true"></i><a href="{{ url('admin/addcountries') }}">Add countries and cities</a>
                                      </li>
                                  </ul>
                              </div>
                        <div class="nav-slider"></div>
                        <!-- <div class="dashboard dash">
                            <button class="active dashboard-btn nav-btn">Details List</button>
                        </div> -->
                        <div class="hosting dash">
                            <div class="hosting-btn nav-btn">Package list</div>
                        </div>
                        <!-- <div class="marketplace dash">
                            <button class="marketplace-btn nav-btn">Details Update</button>
                        </div> -->
                        <div class="domains dash">
                            <button class="domain-btn nav-btn">Contact List</button>
                        </div>
                        <div class="nav-slider"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-10 col-lg-9 col-md-12">
        	<div class="page mt-4 hosting-page title1">
                <div class="mt-5">
                	<div class="list1">
                        <h4 class="mb-4">Package list</h4>
                        <button class="btn1">ADD</button>
                    </div>
                    <div class="detail">
                	    <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Packages</th>
                                    <th>Type of Tour</th>
                                    <th>City</th>
                                    <th>Location</th>
                                    <th>Days</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>John Doe</td>
                                    <td>India</td>
                                    <td>Family Tour</td>
                                    <td>Family Tour</td>
                                    <td>Family Tour</td>
                                    <td>7</td>
                                    <td>Lorem ipsum dolor sit amet, consectetur blandit magna adipiscing elit</td>
                                    <td>10000</td>
                                    <td><button class="btn0 btn2">Update</button></td>
                                    <td><button class="btn3 btn0">Delete</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 

            <div class="page my-4 dashboard-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Details List</h4>
                    <div class="detail">
              

				        <div class="form">

                                 @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li  style="color:red;">{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif 
				            <form method="POST" action="{{url('admin/storepackagedata')}}" enctype="multipart/form-data">
                                 @csrf

					            <div class="part">
						            <div class="col-md-12 label">
						    	        <label>Image</label>
						            </div>
						            <div class="col-md-12">
						        	    <input type="file" id="image" name="image[]" value="" required multiple>
						        	   
						            </div>   
					            </div>
					            <div class="part">
					    	        <div class="col-md-12 label">
					    		        <label>Packages</label>
					    	        </div>
					    	        <div class="col-md-12 data">
					    	        	<select name="packages" >
					    	        		<option value="">Select Packages</option>
                                            <option name="India Packages" value="1">India Packages</option>
                                            <option name="International packages" value="2">International packages</option>
                                        </select>
                                    </div>
						        </div>   
						        <div class="part">
					    	        <div class="col-md-12 label">
					    		        <label>Type of Tour</label>
					    	        </div>
					    	        <div class="col-md-12 data">
					    	        	<select name="tour_type">
                        <option value=" " name="Select Tour Type" >Select Tour Type</option>
                         <option value="1" name="Honeymoon Packages">Honeymoon Packages</option>
                         <option value="2" name="  Family Tours">    Family Tours</option>
                        <option value="3" name="Religious Tours">Religious Tours</option>
                         <option value="4" name="Weekend Getaways">Weekend Getaways</option>
                        <option value="5" name="Wildlife Tours">Wildlife Tours</option>
                        <option value="6" name="Beach Packages">Beach Packages</option>
                       <option value="7" name="Summer Packages">Summer Packages</option>
                       <option value="8" name="Winter Packages">Winter Packages</option>
                        <option value="9" name="Luxury Packages">Luxury Packages</option>
                         <option value="10" name="Adventure Packages">Adventure Packages</option> 
                                        </select>
                                    </div>
						        </div>    
					            <div class="part">
						            <div class="col-md-12 label">
							            <label>Location</label>
						            </div>
						            <div class="col-md-12 data">
						            	<select name="country" id="country">
                                            <option value="">Select location</option>

                                       @foreach ($country as $c)
                                   <option value="{{ $c->id }}">{{ $c->name }}</option>
                                      @endforeach</select>
                                    </div>
						        </div>  
						        <div class="part">
						            <div class="col-md-12 label">
						            <div class="col-md-12 data">
                                        <label>City</label>
                                    </div>
                                        <select name="city" id="city">
                                            <option value="">Select City</option>
                                           
                                        </select> 
                                    </div>
                                </div>
					            <div class="part">
					    	        <div class="col-md-12 label">
					    	    	    <label>Days</label>
					    	        </div>
					    	        <div class="col-md-12 data">
					    	    	    <input type="text" placeholder="Enter Days" name="day" value="">
					    	        </div>   
					            </div>
					            <div class="part">
					            	<div class="col-md-12 label">
					            		<label>Price</label>
					            	</div>
					            	<div class="col-md-12 data">
					            		<input type="text" placeholder="Enter Price Number" name="price" value="">
					    	        </div>   
					            </div>
					            <div class="part part1">
					    	        <div class="col-md-12 label">
					    	    	    <label>Description</label>
					    	        </div>
					    	        <div class="col-md-12 data">
					    	    	    <textarea placeholder="Enter text.." name="discription" value=" "></textarea>
					    	        </div>   
					            </div>
					        </form>	
				            <div class="upload">
                                <button class="btn0">Upload</button>
                            </div>
                        </div>
                        <div class="text-editor">
                            <div id="summernote"></div>
                        </div>
                    </div>
                </div>
            </div>
  
            <div class="page mt-4 marketplace-page title1">
                <div class="mt-5">
                	<h4 class="mb-4">Details Update</h4>
                </div>
            </div>
  
            <div class="page mt-4 domain-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Contact List</h4>
                    <div class="detail">
                	    <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Subject</th>
                                    <th>Msg</th>
                                    <th>Delete</th>
                                    <th>View</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>John Doe</td>
                                    <td>john@example.com</td>
                                    <td>text</td>
                                    <td>hello</td>
                                    <td>Delete</td>
                                    <td>View</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 

            <div class="page mt-4 message-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Contact List</h4>
                    
                </div>
            </div> 
        </div>
    </div> 

</body>
</html>