<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
//use App\Models\User;
use Carbon\carbon;
use DB;
use Hash;
use \Crypt;
use Illuminate\support\facades\Auth;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class Admincontroller extends Controller{


 public function __construct(){

                $this->middleware('auth:admin');
        }

    public function home(){
 
       //open home page
      $admin=Auth::guard('admin')->user();
      $data['admin']=$admin;

      $data['site_url']= env('APP_URl');

      // $country=DB::table('countries')->orderBy('id','DESC')->paginate(100);

      $country = DB::table('countries')->get();
      $data['country']=$country;

      $package_detail=DB::table('package_detail')->get();

      $data['package_detail']=$package_detail;

      $admincontactdetail=DB::table('admincontactdetail')->get();

      $data['admincontactdetail']=$admincontactdetail;
       
      $contactus=DB::table('contact_us')->get();

      $data['contactus']=$contactus;

      $testimonial=DB::table('testimonial')->get();

      $data['testimonial']=$testimonial;

      $brochures=DB::table('brochures')->get();

      $data['brochures']=$brochures;





      $data['metatitle']='home page';
      return view('admin.home',$data);
    } 

     
    public function getcity($id){

      return json_encode( DB::table('cities')->where('country_id',$id)->get()->toArray());
     }


    public function addcountries(){

        $admin=Auth::guard('admin')->user();
        $data['admin']=$admin;

        $data['site_url']= env('APP_URl');
        

       return view('admin.addcountryview');
     }

     public function addcountriesdata(Request $request){
    
        $request->validate([
            'country' => 'required|string',
            'city' => 'required|string',
           
           ]);

       $countryname=$request->input('country');
       $cityname=$request->input('city');

       echo $countryname;
       echo $cityname;



       $country=DB::table('countries')->where('name',$countryname)->count();
       echo $country;

       if($country){

               $countrydata=DB::table('countries')->where('name',$countryname)->get();

                 $country_id=$countrydata[0]->id;

                   $citydata=DB::table('cities')->where('name',$cityname)->count();

                        if($citydata){

                          return redirect()->route('addcountriesview')->with('error','This country and city are already inserted.');

        
                         }else{

                           DB::table('cities')->insert(['name'=>$cityname,'country_id'=>$country_id]);

                            return redirect()->route('addcountriesview')->with('error','This city are inserted in list.');

                         }

       }else{
         
               DB::table('countries')->insert(['name'=>$countryname]);

                $countrydata=DB::table('countries')->where('name',$countryname)->get();

                 $country_id=$countrydata[0]->id;

                DB::table('cities')->insert(['name'=>$cityname,'country_id'=>$country_id]);

                return redirect()->route('addcountriesview')->with('error','This country and city are inserted in list.');


         }
       


     }
       

       public function addpackageview(){

       $country = DB::table('countries')->get();
       
        $data['country']=$country;
           //   $data['works']=$works;
        return view('admin.addpackagedetail',$data);

       
       }
    
   

    public function storepackagedata(Request $request){


        $request->validate([

            'packages' => 'required',
            'tittle' => 'required',
            'tour_type' => 'required',
            'country' => 'required',
            'city' => 'required',
            'days' => 'required',
            'price' => 'required',
            'description' => 'required',
            

        ]);
       
        $packagetype=$request->input('packages');
        $tittle = $request->input('tittle');
        $tour_type=$request->input('tour_type');
        $country=$request->input('country');
        $city=$request->input('city');
        $days=$request->input('days');
        $price=$request->input('price');
        $description=$request->input('description');
       

           echo "packagetype". $packagetype;
           echo " tourtype". $tour_type;
           echo "city ". $city;
           echo"country " .$country;
           echo"description " .$description;
           echo "days ". $request->input('days');
           echo"price " . $request->input('price');

         $file=$request->file('image');
        $imagename=' ';

        if ($file) {
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();

         $file->move($destinationPath,$imagename);
      
        }


          $country=DB::table('countries')->where('id', $country)->get();

             $country1=$country[0]->name;

                echo $country1;

                    $city=DB::table('cities')->where('id', $city)->get();
                    $city1=$city[0]->name;

                  echo $city1;


      DB::table('package_detail')->insert(['package_type'=>$packagetype ,'tittle'=>$tittle,'tour_type'=> $tour_type,'country'=>$country1, 'city'=> $city1,'days'=>$days, 'price'=>$price , 'description'=>$description, 'image'=>$imagename]);
       



        /* $file=$request->file('image');
         $imagename=' ';

         $last_id = DB::table('package_detail')->max('id'); 

         echo "last_id".$last_id;
         
       
         foreach ($file as $key =>$f) {

            $destinationPath='uploads';
            $imagename=time().'_'.$f->getClientOriginalName();
    
            $f->move($destinationPath,$imagename);

            DB::table('images')->insert(['packge_id'=>$last_id,'image'=>$imagename]);
             
         }*/

         return redirect('admin/home');
          
    }

     public function deletepackge($id){

      //delete image in database

          $package= DB::table('package_detail')->where('id', $id)->get();

         if ($package[0]->image!='') {

            unlink(public_path("/uploads/".$package[0]->image));

            }

      
        DB::table('package_detail')->where('id', $id)->delete();

        return redirect('admin/home');


    }
       public function updatepackageview($id){

        $country = DB::table('countries')->get();
        $data['country']=$country;


       $package = DB::table('package_detail')->where('id',$id)->get();
       
        //$work=DB::table('work')->where('id',$id)->get();
        $data['id']=$package[0]->id;
        $data['package']=$package[0]->package_type;
        $data['tittle']=$package[0]->tittle;
        $data['tour_type']=$package[0]->tour_type;
        $data['country']=$package[0]->country;
        $data['city']=$package[0]->city;
        $data['image']=$package[0]->image;
        $data['days']=$package[0]->days;
        $data['description']=$package[0]->description;
        $data['price']=$package[0]->price;

         
        return view('admin.updatepackageview',$data);

       
       }



   public function updatepackagedata(Request $request,$id){


   $request->validate([

            'packages' => 'required',
            'tittle' => 'required',
            'tour_type' => 'required',
            'country' => 'required',
            'city' => 'required',
            'days' => 'required',
            'price' => 'required',
            'description' => 'required',
            

        ]);
       
        $packagetype=$request->input('packages');
        $tittle = $request->input('tittle');
        $tour_type=$request->input('tour_type');
        $country=$request->input('country');
        $city=$request->input('city');
        $days=$request->input('days');
        $price=$request->input('price');
        $description=$request->input('description');


         $file=$request->file('image');
         $imagename=' ';

        if ($file) {
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('package_detail')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

            unlink(public_path("/uploads/".$request->input('oldimage')));

             }

           }

          DB::table('package_detail')->where('id', $id)->update(['package_type'=>$packagetype ,'tittle'=>$tittle,'tour_type'=> $tour_type,'country'=>$country, 'city'=> $city,'days'=>$days, 'price'=>$price , 'description'=>$description]);

           return redirect('admin/home');

  }

   
    

   /*  public function admincontactdetail(){

           return view('admin.admincontactdetail');

       }

    public function storeadmincontact(Request $request){


         $request->validate([

            'name' => 'required|string',
            'email' => 'required|email',
            'mobileno' => 'required',
            'address' => 'required',
           
            

        ]);
       

        $name=$request->input('name');
        $email = $request->input('email');
        $mobileNo=$request->input('mobileno');
        $address=$request->input('address');

        echo  $name;
        echo  $email;
        echo   $mobileNo;
        echo $address;
    


     DB::table('admincontactdetail')->insert(['name'=>$name ,'email'=>$email,'mobileno'=> $mobileNo,'address'=>$address]);
         
          
        return redirect('admin/admincontactdetail')->with('error','data inserted successfully!!!' );

       }

       public function deleteadmindetail($id){


         DB::table('admincontactdetail')->where('id', $id)->delete();

         return redirect('/admin/home');


       }
*/


       public function updateadmindetail($id){


       $admindetail=DB::table('admincontactdetail')->where('id', $id)->get();

        $data['id']=$admindetail[0]->id;
         $data['email']=$admindetail[0]->email;
        $data['name']=$admindetail[0]->name;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      

         return view('admin.updateadmindetailview',$data);


       }

       public function storeadmindetail(Request $request,$id){


         $request->validate([

            'name' => 'required|string',
            'email' => 'required|email',
            'mobileno' => 'required',
            'address' => 'required',
           
            

        ]);
       

        $name=$request->input('name');
        $email = $request->input('email');
        $mobileNo=$request->input('mobileno');
        $address=$request->input('address');

        echo  $name;
        echo  $email;
        echo   $mobileNo;
        echo $address;
    

       DB::table('admincontactdetail')->where('id',$id)->update(['name'=>$name ,'email'=>$email,'mobileno'=>$mobileNo,'address'=>$address]);
         
         return redirect('admin/home');

       }

      public function deletecontactus($id){
  
       DB::table('contact_us')->where('id', $id)->delete();

       return redirect('admin/home');

   }

    public function addtestimonial(){
  
    
       return view(' admin.testimonial');

   }

     public function storetestimonial(Request $request){
  
         $name=$request->input('name');
        $occupation = $request->input('occupation');
        $description=$request->input('description');
        
 
         $file=$request->file('image');
        $imagename=' ';

    echo $name;
    echo $occupation;
    echo $description;

        if ($file) {
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
          echo $imagename;
          $file->move($destinationPath,$imagename);
      
        }


    
  DB::table('testimonial')->insert(['name'=>$name ,'occupation'=>$occupation,'image'=>$imagename,'description'=>$description]);
    
       return redirect('admin/home');
   }


      public function deletetestimonial($id){

      

          $testimonial= DB::table('testimonial')->where('id', $id)->get();

         if ($testimonial[0]->image!='') {

            unlink(public_path("/uploads/".$testimonial[0]->image));

            }

      
        DB::table('package_detail')->where('id', $id)->delete();

        return redirect('admin/home');


    }


   

   public function updatetestimonial($id){

       

       $testimonial = DB::table('testimonial')->where('id',$id)->get();
       
       
        $data['id']= $testimonial[0]->id;
        $data['name']=$testimonial[0]->name;
        $data['occupation']=$testimonial[0]->occupation;
        $data['image']=$testimonial[0]->image;
        $data['description']=$testimonial[0]->description;
             
        return view('admin.updatetestimonial',$data);

       
       }
        public function storeupdatetestimonial(Request $request,$id){


        /* $request->validate([

            'name' => 'required|string',
            'email' => 'required|email',
            'mobileno' => 'required',
            'address' => 'required',    

        ]);*/
       

        $name=$request->input('name');
        $occupation = $request->input('occupation');
        $description=$request->input('description');

        $file=$request->file('image');
         $imagename=' ';

        if ($file) {
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('testimonial')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

            unlink(public_path("/uploads/".$request->input('oldimage')));

             }

           }
     
     
          DB::table('testimonial')->where('id',$id)->update(['name'=>$name ,'occupation'=>$occupation,'description'=>$description]);
    
         
         return redirect('admin/home');

       }
        public function changepassword(){
      
     
      return view('admin.changepassword');
    }

     public function createpassword(Request $request,$id){

         $request->validate([
            'oldpassword' => 'required|string',
            'newpassword' => 'required|string|min:8',
           
           ]);

         $oldpassword=$request->input('oldpassword');
         $newpassword=$request->input('newpassword');

             $password=DB::table('admins')->where('id', $id)->get();

             $password1=$password[0]->password;

             if(Hash::check($oldpassword,$password1)){

               DB::table('admins')->where('id', $id)->update(['password'=>Hash::make($newpassword)]);

              return Redirect::back()->with('error','your password has been update sucessfully' );

             }else{

                return Redirect::back()->with('error','Your Old password is not correct!!!!');

            }
        }

        public function addbrochures()
        {
            return view('admin.addbrochures');
        }

        public function storebrochures(Request $request){

               $request->validate([

            'name' => 'required|string',
            'image' => 'required',
             ]);



         $name=$request->input('name');
         $file=$request->file('image');
        $imagename=' ';
        if ($file) {
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
          echo $imagename;
          $file->move($destinationPath,$imagename);
      
         }
    
       DB::table('brochures')->insert(['name'=>$name ,'image'=>$imagename,]);
    
       return redirect('admin/home');


        }

          public function deletebrochures($id){

          $brochures= DB::table('brochures')->where('id', $id)->get();

         if ($brochures[0]->image!='') {

            unlink(public_path("/uploads/".$brochures[0]->image));

            }

      
        DB::table('brochures')->where('id', $id)->delete();

        return redirect('admin/home');


    }





  
  
}



