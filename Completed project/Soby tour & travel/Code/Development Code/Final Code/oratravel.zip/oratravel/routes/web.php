<?php

use Illuminate\Support\Facades\Route;

use \App\Http\Controllers\userController;
 use \App\Http\Controllers\Admincontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::get('/','\App\Http\Controllers\userController@index');

Route::get('/aboutview','\App\Http\Controllers\userController@aboutview');
Route::get('/tourlist','\App\Http\Controllers\userController@tourlist');
//Route::get('/search','\App\Http\Controllers\userController@search')->name('search');
Route::get('/Domesticpackages','\App\Http\Controllers\userController@indiantour');
Route::get('/Internationalpackages','\App\Http\Controllers\userController@internationaltour');
Route::get('/Visa','\App\Http\Controllers\userController@visapage');
Route::get('/Passportinquire','\App\Http\Controllers\userController@passportinquire');
Route::get('/Gallery','\App\Http\Controllers\userController@Gallery');
Route::get('/Contact','\App\Http\Controllers\userController@Contact');
Route::get('travel-search','\App\Http\Controllers\userController@travel_search')->name('travel.search');
Route::get('/Brochure','\App\Http\Controllers\userController@brochure');


Route::post('/Visainquirefrom','\App\Http\Controllers\userController@Visainquirefrom');
Route::post('/usercontact','\App\Http\Controllers\userController@usercontact');
Route::post('/viewgallary/{id}','\App\Http\Controllers\userController@usercontact');





/////////////////////////// Admin panel///////////////////////
 Route::prefix('admin')->group(function(){

 	    
Route::get('/login','\App\Http\Controllers\Auth\Adminlogincontroller@login');

Route::post('/login','\App\Http\Controllers\Auth\Adminlogincontroller@authenticate')->name('login');
Route::get('/logout','\App\Http\Controllers\Auth\Adminlogincontroller@logout')->name('adminlogout');


//forget password

Route::get('/forgetpassword','\App\Http\Controllers\Auth\Adminlogincontroller@forgetpassword')->name('forgetpassword');
Route::post('/resetpassword','\App\Http\Controllers\Auth\Adminlogincontroller@resetpassword')->name('resetpassword');
  Route::get('/updatepassword/{id}','\App\Http\Controllers\Auth\Adminlogincontroller@updatepasswordview');
 Route::post('/createnewpassword','\App\Http\Controllers\Auth\Adminlogincontroller@createnewpassword')->name('createnewpassword');

 //change password

 /*Route::get('/changepassword','\App\Http\Controllers\Auth\Adminlogincontroller@changepassword');
 Route::post('/createpassword/{id}','\App\Http\Controllers\Auth\Adminlogincontroller@createpassword');*/


Route::get('/home', '\App\Http\Controllers\Admin\Admincontroller@home');

  
  //insert new country and city
 Route::get('/getcity/{id}','\App\Http\Controllers\Admin\Admincontroller@getcity');
 Route::get('/addcountries','\App\Http\Controllers\Admin\Admincontroller@addcountries')->name('addcountriesview');
Route::post('/addcountriesdata','\App\Http\Controllers\Admin\Admincontroller@addcountriesdata')->name('addcountriesdata');
 
 //insert update and delete tour package

 Route::get('/addpackageview','\App\Http\Controllers\Admin\Admincontroller@addpackageview');
  Route::post('/storepackagedata','\App\Http\Controllers\Admin\Admincontroller@storepackagedata')->name('storepackagedata');

 Route::get('/deletepackge/{id}','\App\Http\Controllers\Admin\Admincontroller@deletepackge');
 Route::get('/updatepackageview/{id}','\App\Http\Controllers\Admin\Admincontroller@updatepackageview');
 Route::post('/updatepackagedata/{id}','\App\Http\Controllers\Admin\Admincontroller@updatepackagedata');


Route::get('/deletecontactus/{id}','\App\Http\Controllers\Admin\Admincontroller@deletecontactus'); 

Route::get('/updateadmindetail/{id}','\App\Http\Controllers\Admin\Admincontroller@updateadmindetail');
Route::post('/storeadmindetail/{id}','\App\Http\Controllers\Admin\Admincontroller@storeadmindetail');

Route::get('/addtestimonial','\App\Http\Controllers\Admin\Admincontroller@addtestimonial');
Route::post('/storetestimonial','\App\Http\Controllers\Admin\Admincontroller@storetestimonial')->name('storetestimonialdetail');

Route::get('/deletetestimonial/{id}','\App\Http\Controllers\Admin\Admincontroller@deletetestimonial'); 
Route::get('/updatetestimonial/{id}','\App\Http\Controllers\Admin\Admincontroller@updatetestimonial');
Route::post('/storeupdatetestimonial/{id}','\App\Http\Controllers\Admin\Admincontroller@storeupdatetestimonial');

Route::get('/changepassword','\App\Http\Controllers\Admin\Admincontroller@changepassword');
 Route::post('/createpassword/{id}','\App\Http\Controllers\Admin\Admincontroller@createpassword');

Route::get('/addbrochures','\App\Http\Controllers\Admin\Admincontroller@addbrochures');
Route::post('/storebrochures','\App\Http\Controllers\Admin\Admincontroller@storebrochures');
Route::get('/deletebrochures/{id}','\App\Http\Controllers\Admin\Admincontroller@deletebrochures'); 

 }); 

 Route::get('travel-clear', function() {

   Artisan::call('cache:clear');
   Artisan::call('config:clear');
   Artisan::call('config:cache');
   Artisan::call('view:clear');
   return "Cleared!";

});




