<!DOCTYPE html>
<html>
<head>
	<title>TRAVEL AGENCY</title>
	<link rel="stylesheet" type="text/css" href="css/Travel_contact.css">
	<link rel="stylesheet" type="text/css" href="css/Travel_header-footer.css">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="icon" type="image/png" href="image/flaticon.png">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
	<div class="co_part-1">
        <div class="container fix-part-1">
            <div class="part-1">
                <a href="<?php echo e(url('/')); ?>"><img src="image/logo-2.png"></a>
            </div>
            <div class="menu1">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                <div class="dropdown hover">
                    <div class="menu">
                        <div class="package1">Packages</div>
                    </div>      
                    <ul class="submenu">
                        <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                        <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                    </ul>
                </div>
                <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
            </div>
            <div class="mobile-menu">
                <div id="mySidepanel" class="sidepanel">
                    <div class="m_menu">
                         <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-times" aria-hidden="true"></i></a>     
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                        <div class="dropdown hover">
                            <div class="menu">
                                <a href="">Packages</a>
                            </div>      
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                                <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                            </ul>
                        </div>
                        <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                        <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                        <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                        <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                        <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
                    </div>
                </div>
              <button class="openbtn" onclick="openNav()"><i class="fa fa-bars" aria-hidden="true"></i></button>
            </div>
        </div>
    </div>
    <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/breadcrumb-bg.jpg">
    	    </div>
    	    <div class="about">
    		    <div class="container">
                    <h2>Contact</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Contact</li>
                    </ul>
                </div>
    	    </div>
    	</div>
    </div>
    <div class="co_part-3">
	    <div class="fix-part-3">
	    	<div class="part-3">
	    		<div class="set-part-3">
	    			<div class="contact-icon">
	    				<i class="fa fa-map"></i>
	    			</div>
	    			<div class="add">
	    				<h2>our office:</h2>
	    				<p><?php echo e($address); ?></p>
	    			</div>
	    		</div>
	    		<div class="set-part-3">
	    			<div class="contact-icon">
	    				<i class="fa fa-phone"></i>
	    			</div>
	    			<div class="add">
	    				<h2>contact number:</h2>
                        <div class="add1">
	    				<p><?php echo nl2br(e($mobileno)); ?></p>
                    </div>
	    			</div>
	    		</div>
	    		<div class="set-part-3">
	    			<div class="contact-icon">
	    				<i class="fa fa-envelope"></i>
	    			</div>
	    			<div class="add">
	    				<h2>Email us:</h2>
	    				<p><?php echo e($email); ?></p>
	    			</div>
	    		</div>
	    	</div>
              <?php if(session()->has('error')): ?>
                   <div id="hideDiv" class="alert alert-success">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
	    	<form  method="POST" action="<?php echo e(url('/usercontact')); ?>" class="form">
                  <?php echo csrf_field(); ?>
	    		<div class="port">
	    			<div class="text">
	    				<input type="text" placeholder="Name" name="name" value="">
	    			</div>
	    		</div>
	    		<div class="port">
	    			<div class="text">
	    				<input type="text" placeholder="Email" name="email" value="">
	    			</div>
	    		</div>
	    		<div class="port">
	    			<div class="text">
	    				<input type="text" placeholder="Subject" name="sub" value="">
	    			</div>
	    		</div>
	    		<div class="text1">
	    			<textarea placeholder="Your Message" name="description" value=""></textarea>
	    		</div>
    			<div class="sub">
    				<input type="submit" value="Send Message">
    			</div>
    		</form>
    	</div>
    </div>
    <div class="map">
    	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3734.4556071177058!2d72.92726631487625!3d20.610277986226617!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be0e8274e22fad7%3A0xf72cd8f8383154ce!2sSoby%20Tour%20%26%20Travels!5e0!3m2!1sen!2sin!4v1624014752326!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">
                    <div class="main-footer">
                        <h2 class="title1"><a href="index.html"><img src="image/logo-2.png"></a></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur repudiandae quisquam adipisci asperiores, ipsum ipsa repellat assumenda dolor perspiciatis.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-12">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Company</h2>
                            <div class="footer-widget">
                                <ul>
                                   <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/aboutview')); ?>">About</a></li>
                                
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">All Package</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Contact')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Service</h2>
                            <div class="footer-widget">
                                <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">Various Tour</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Visa')); ?>">Visa</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Passportinquire')); ?>">Passport Inquires</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                        <li><i class="fa fa-home" aria-hidden="true"></i>
                             <p> <?php echo e($address); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                            <p><a href="tel:<?php echo nl2br(e($mobileno)); ?>"><?php echo nl2br(e($mobileno)); ?></a></p></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                 <span>Sobytour&travels Theme © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                  <li><a href="https://www.facebook.com/Soby-tour-and-travels-546125568809837/"><i class="fa fa-facebook-square"></i></a></li>
                    <li><a href="https://www.instagram.com/sobytourandtravels/"><i class="fa fa-instagram"></i></a></li>
            
                </ul>
            </div>
        </div>
        </div>
    </div>
    <a class="up-btn" href="#"></a>
    <style type="text/css">
        .add1{

            width: 50%!important;
        }

        .no{

            width: 50%!important;
        }

    </style>


    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

    <script type="text/javascript">
    	 function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

          $(function() {
setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

});

    	var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  }
            else {
                btn.removeClass('show1');
            } 
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        }); 

    
    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\oratravel\resources\views/contact.blade.php ENDPATH**/ ?>