<!DOCTYPE html>
<html>
<head>
    <title>TRAVEL AGENCY</title>
    <link rel="stylesheet" type="text/css" href="/css/main-dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body"> 
                       
    <div class="page my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">ADD TESTIMONIAL</h4>
            <div class="detail">
                <div class="form">

                      <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 
                 <form  action="<?php echo e(url('admin/storetestimonial')); ?>" enctype="multipart/form-data" method="POST" >
                         <?php echo csrf_field(); ?>
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Image</label>
                            </div>
                            <div class="col-md-12">
                                 <input type="file" id="image" name="image" value="" required >
                                <img src="/image/2.jpg" width="40" height="40">
                             </div>   
                        </div>
                     
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Name</label>
                            </div>
                          <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Name" name="name" value="">
                          </div>
                       </div>
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Occupation</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Occupation" name="occupation" value="">
                            </div>   
                        </div>
                        <div class="part part1">
                            <div class="col-md-12 label">
                                <label>Description</label>
                            </div>
                            <div class="col-md-12 data">
                                <textarea placeholder="Enter text.." name="description" value=" "></textarea>
                            </div>   
                        </div>

                        <div class="upload">
                        <button class="btn0">Upload</button> 
                        <a href="<?php echo e(url('admin/home')); ?>">Back to Home?</a>       
                    </div>
                    </form> 
                    
                        
                </div>
               
            </div>
        </div>
    </div>
         

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

    $(document).ready(function(){
        $(".btn1").click(function(){
            $(".dashboard-page").show();
            $(".hosting-page").hide();
        });

        $(".user-details").click(function(){
            $(".main-menu-content").slideToggle("slow");
        })
    });

     $(document).ready(function(){


            $('select[name="country"]').on('change',function(){

                var id=$(this).val();
 
          if(id){
                $.ajax({

                     url:'getcity/'+id,
                     type:'GET',
                   dataType:'json',
                   success:function(data){

                    console.log(data);

                  /*  var json = JSON.stringify(data);
                      console.log(json);
                    */
                     $('select[name="city"]').empty();

                    $.each(data,function(key,value){

                       $('select[name="city"]')
                       
                     .append('<option value="'+value.id+'">'+value.name+'</option>');

                     });

                   }

                }); 
              }else{

                          $('select[name="city"]').empty();
              }
               
            });
       
        });   

   
    

</script>
</body>
</html><?php /**PATH D:\xampp\htdocs\oratravel\resources\views/admin/testimonial.blade.php ENDPATH**/ ?>