<!DOCTYPE html>
<html>
<head>
	<title>TRAVEL AGENCY</title>
	<link rel="stylesheet" type="text/css" href="css/Travel_gallery.css">
	<link rel="stylesheet" type="text/css" href="css/Travel_header-footer.css">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
	<link rel="icon" type="image/png" href="image/flaticon.png">
	 <meta name="viewport" content="width=device-width, initial-scale=1">
	
</head>
<body class="body">
	<div class="co_part-1">
        <div class="container fix-part-1">
            <div class="part-1">
                <a href="<?php echo e(url('/')); ?>"><img src="image/logo-2.png"></a>
            </div>
            <div class="menu1">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                <div class="dropdown hover">
                    <div class="menu">
                        <div class="package1">Packages</div>
                    </div>      
                    <ul class="submenu">
                        <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                        <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                    </ul>
                </div>
                <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
            </div>
            <div class="mobile-menu">
                <div id="mySidepanel" class="sidepanel">
                    <div class="m_menu">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a>    
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                        <div class="dropdown hover">
                            <div class="menu">
                                <a href="">Packages</a>
                            </div>      
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                                <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                            </ul>
                        </div>
                        <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                        <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                        <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                        <div class="dropdown hover">
                            <div class="menu">
                                <a href="#">Tour Brochure</a>
                            </div>      
                            <ul class="submenu">
                                <li><a href="https://moderntoursandtravels.com/wp-content/uploads/2020/10/SPECIAL-EXPRESS-AND-SUPER-SAVER-PRAVASO-2020.pdf">Short Tour brochure</a></li>
                                <li><a href="https://moderntoursandtravels.com/wp-content/uploads/2020/10/SPECIAL-EXPRESS-AND-SUPER-SAVER-PRAVASO-2020.pdf">Long Tour brochure</a></li>
                                <li><a href="https://moderntoursandtravels.com/wp-content/uploads/2020/10/SPECIAL-EXPRESS-AND-SUPER-SAVER-PRAVASO-2020.pdf">Special Tour packages</a></li>
                                <li><a href="https://moderntoursandtravels.com/wp-content/uploads/2020/10/SPECIAL-EXPRESS-AND-SUPER-SAVER-PRAVASO-2020.pdf">Summer Tour Packages</a></li>
                            </ul>
                        </div>
                        <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
                    </div>
                </div>
                <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
            </div>
        </div>
    </div>
    <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/breadcrumb-bg7.jpg">
    	    </div>
    	    <div class="about">
    		    <div class="container">
                    <h2>Gallery</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Gallery</li>
                    </ul>
                </div>
    	    </div>
    	</div>
    </div>
    <div class="co_gallery">
        <div class="container">
            <div class="gallery">
            <a href="image/dubai.jpeg" data-lightbox="homePortfolio">
                <img src="image/dubai.jpeg"/>
            </a>
            <a href="image/england.jpeg" data-lightbox="homePortfolio" class="vertical">
                <img src="image/england.jpeg"/>
            </a>
            <a href="image/netherlands-tour.jpg" data-lightbox="homePortfolio" class="horizontal">
                <img src="image/netherlands-tour.jpg"/>
            </a>
            <a href="https://youtu.be/JPe2mwq96cw" data-lightbox="homePortfolio">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/JPe2mwq96cw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </a>
            <a href="image/surfering.jpg" data-lightbox="homePortfolio">
                <img src="image/surfering.jpg"/>
            </a>      
            <a href="image/luxury.jpg" data-lightbox="homePortfolio" class="big">
                <img src="image/luxury.jpg"/>
            </a>      
            <a href="image/weekend.jpg" data-lightbox="homePortfolio">
                <img src="image/weekend.jpg"/>
            </a>      
            <a href="image/religious.jpg" data-lightbox="homePortfolio" class="vertical">
                <img src="image/religious.jpg"/>
            </a>      
            <a href="image/lonely-yacht.jpg" data-lightbox="homePortfolio">
                <img src="image/lonely-yacht.jpg"/>
            </a>      
            <a href="image/maldives.jpg" data-lightbox="homePortfolio" class="horizontal">
                <img src="image/maldives.jpg"/>
            </a>      
            <a href="image/netherland.jpeg" data-lightbox="homePortfolio">
                <img src="image/netherland.jpeg"/>
            </a>      
            <a href="image/american-tour.jpg" data-lightbox="homePortfolio" class="big">
              <img src="image/american-tour.jpg"/>
            </a>      
            <a href="image/china.jpeg" data-lightbox="homePortfolio">
                <img src="image/china.jpeg"/>
            </a>      
            <a href="image/norway.jpg" data-lightbox="homePortfolio" class="horizontal">
                <img src="image/norway.jpg"/>
            </a>      
            <a href="image/photo.jpeg" data-lightbox="homePortfolio">
                <img src="image/photo.jpeg"/>
            </a>
        </div>
        </div>
    </div>
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">
                    <div class="main-footer">
                        <h2 class="title1"><a href="index.html"><img src="image/logo-2.png"></a></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur repudiandae quisquam adipisci asperiores, ipsum ipsa repellat assumenda dolor perspiciatis.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-12">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Company</h2>
                            <div class="footer-widget">
                                 <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/aboutview')); ?>">About</a></li>
                                
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">All Package</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Contact')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Service</h2>
                            <div class="footer-widget">
                                <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">Various Tour</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Visa')); ?>">Visa</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Passportinquire')); ?>">Passport Inquires</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                       <li><i class="fa fa-home" aria-hidden="true"></i>
                             <p> <?php echo e($address); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                             <p><a href="tel:<?php echo nl2br(e($mobileno)); ?>"><?php echo nl2br(e($mobileno)); ?></a></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                 <span>Sobytour&travels Theme © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="https://www.facebook.com/Soby-tour-and-travels-546125568809837/"><i class="fa fa-facebook-square"></i></a></li>
                    <li><a href="https://www.instagram.com/sobytourandtravels/"><i class="fa fa-instagram"></i></a></li>
            
                </ul>
            </div>
        </div>
        </div>
    </div>
    <a class="up-btn" href="#"></a>
        
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox-plus-jquery.min.js"></script>
    <script type="text/javascript">
         function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  }
            else {
                btn.removeClass('show1');
            } 
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        }); 

        

    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\oratravel\resources\views/gallery.blade.php ENDPATH**/ ?>