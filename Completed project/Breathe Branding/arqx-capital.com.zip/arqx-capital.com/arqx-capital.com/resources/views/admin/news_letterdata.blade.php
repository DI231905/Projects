@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">GET IN TOUCH</h4>
                       
                    </div>
                    <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                  
                                    <th>Email</th>
                                    <th>Mobile Number</th>   
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           @foreach($news_letter as $f)
                             <tbody>
                             
                               <tr class="letter_{{$f->id}}">
                                    
                                     <td>
                                      {{$f->email}}
                                    </td>
                                   
                                    <td>
                                    {{ $f->number }}
                                    </td>
                                 
                                    <td>
                                 <button class="btn3 btn0" onclick="deleteletter({{$f->id}})"><i class="fal fa-trash-alt"></i></button>
                                 </td>
                                          
                                  
                                </tr>
                                
                            </tbody>
                            @endforeach
                           
                        </table>
                    </div>
                 </div>
                 <script type="text/javascript">
                   

  function deleteletter($id){
    // alert('i am here');

     if(confirm("do you want delete this data ?")){
             $.ajax({

                url:'delete_get_in_touch/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.letter_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
       

                 </script>
                 

       @endsection