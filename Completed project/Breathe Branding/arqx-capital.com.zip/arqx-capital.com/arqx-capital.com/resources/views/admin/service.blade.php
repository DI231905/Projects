@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Services</h4>
                  <button class="btn1"><a href="{{url('admin/add_service')}}" style="color:black;">ADD</a></button>
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>   
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                        
                             <tbody>
                               @foreach($servicedata as $s)
                               <tr class="service_{{$s->id}}">
                                  
                                    <td><img src="/uploads/{{$s->image}}" height="100px" width="100px">
                                      <br/>{{$s->image}}</td>

                                    <td>{{$s->title}}</td>

                                    <td>{!!$s->description!!}</td> 
    
                               <td>
                                <button class="btn0 btn2"><a href="{{url('admin/update_service')}}/{{$s->id}}"><i class="fal fa-pencil"></i></a></button>
                              </td>
                              <td>
                                <button class="btn3 btn0" onclick="deleteservice({{$s->id}})"><i class="fal fa-trash-alt"></i></a></button>
                              </td> 
                              
                            
                               </tr>
                                @endforeach 
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>

        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
      <script type="text/javascript">
        
         function deleteservice($id){

     if(confirm("do you want delete this data ?")){
             $.ajax({

                url:'delete_service/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.service_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      } 

         $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
 
      </script>

       @endsection