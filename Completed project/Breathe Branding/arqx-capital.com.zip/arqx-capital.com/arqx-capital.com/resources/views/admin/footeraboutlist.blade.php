@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
             <div class="mt-5">
                    <h4 class="mb-4"> Footer About Us  </h4>
                     <div class="detail table-responsive">
                       <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Title</th>
                                  
                                    <th>Description</th>
                                   
                                </tr>
                            </thead>
                               @foreach($footer_data as $fa)
                             <tbody>
                                
                                <tr>


                                    <td>
                                         <img src="/uploads/{{$fa->image}}" width="300" height="180"><br>
                                    </td>

                                     <td>
                                           {{$fa->title}}
                                    </td>



                                    <td>
                                        {!! $fa->description !!}
                                    </td>
                                
                    
                                  
                               <td><button class="btn0 btn2"><a href="{{url('admin/update_footer_data')}}/{{$fa->id}}" ><i class="fal fa-pencil"></i></a></button></td>
                                   
                               
                            </tbody>
                            @endforeach
                        </table>
                    </div>
                 </div>
           
              </div> 
           </div>
           @endsection

           
         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">
        
        

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    
