@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">GET STARTED FORM DATA</h4>
                       
                    </div>
                    <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                   <th>First Name</th>
                                   <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Mobile Number</th>  
                                     <th>Message</th>  
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           @foreach($inquiry as $f)
                             <tbody>
                             
                               <tr class="letter_{{$f->id}}">

                                    <td>
                                      {{$f->fname}}
                                    </td>
                                      <td>
                                      {{$f->lname}}
                                    </td>
                                    
                                     <td>
                                      {{$f->email}}
                                    </td>
                                   
                                    <td>
                                    {{ $f->mobileno }}
                                    </td>

                                     <td>
                                    {{ $f->description }}
                                    </td>
                                 
                                    <td>
                                 <button class="btn3 btn0" onclick="deleteletter({{$f->id}})"><i class="fal fa-trash-alt"></i></button>
                                 </td>
                                          
                                  
                                </tr>
                                
                            </tbody>
                            @endforeach
                           
                        </table>
                    </div>
                 </div>
                 <script type="text/javascript">
                   

  function deleteletter($id){
    // alert('i am here');

     if(confirm("do you want delete this data ?")){
             $.ajax({

                url:'delete_get_started/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.letter_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
       

                 </script>
                 

       @endsection