@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">GET IN TOUCH</h4>
                       
                    </div>
                    <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile Number</th>   
                                    <th>Message</th>   
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           @foreach($get_in_touch as $f)
                             <tbody>
                             
                               <tr class="letter_{{$f->id}}">

                                    <td>
                                      {{$f->name}}
                                    </td>
                                    
                                     <td>
                                      {{$f->email}}
                                    </td>
                                   
                                    <td>
                                    {{ $f->number }}
                                    </td>
                                    <td>
                                    {{ $f->message }}
                                    </td>
                                 
                                    <td>
                                 <button class="btn3 btn0" onclick="delete_get_in_touch_data({{$f->id}})"><i class="fal fa-trash-alt"></i></button>
                                 </td>
                                          
                                  
                                </tr>
                                
                            </tbody>
                            @endforeach
                           
                        </table>
                    </div>
                 </div>
                 <script type="text/javascript">
                   

  function delete_get_in_touch_data($id){
    // alert('i am here');

     if(confirm("do you want delete this data ?")){
             $.ajax({

                url:'delete_contact_us/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.letter_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
       

                 </script>
                 

       @endsection