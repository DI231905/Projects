	
@extends('layouts.app')

@section('content')



	<div class="co-banner1">

		   @foreach($allbanner as $a)
            @if($a->name == 'About Us')
        <img src="uploads/{{$a->image}}">
        <div class="container_11">
            <h1>{{$a->name}}</h1>
            <ul class="breadcrumb1">
                <li><a href="{{url('/')}}"><img src="image/house.png"> Home</a></li>
                <li>/</li>
                <li>{{$a->name}}</li>
            </ul>
        </div>
        @endif
       @endforeach
    </div>
    <div class="co_inner-about">
    	<div class="container">
    		<div class="inner-about-content">
    			<h2>{{$title}}</h2>
    			<p>{!!$description!!}</p>
    		</div>
    		<div class="about-service">
    			<div class="row">

    				@foreach($benefitdata as $b)

    				<div class="col-lg-4 col-md-6 col-12">
    					<div class="inner-about-service">
    						<img src="uploads/{{$b->image}}">
    						<div class="about-service-content">
    							<h2>{{$b->title}}</h2>
    							<p>{{$b->description}}</p>
    						</div>
    					</div>
    				</div>

    				@endforeach
    				
    			</div>
    		</div>
    	</div>
    </div>
    <div class="co_inner-service co_why">
		<div class="container">
			<h2>Why Choose Us ?</h2>
			<div class="row">
				@foreach($whychdata as $w)
				<div class="col-lg-3 col-md-6 col-12">
					<div class="inner-service">
						<img src="uploads/{{$w->image}}">
						<h3>{{$w->title}}</h3>
						<p>{{$w->description}}</p>
					</div>
				</div>
				@endforeach
				
			</div>
		</div>
	</div>
	<div class="co_performance">
		<div class="container">
			<div class="row row1">
				<div class="col-lg-7 col-md-6 col-12">
					<div class="about-content">
						<h2>{{$title}}</h2>
						<!-- <p>We have best-in-class funds tuned not just for tracking the benchmark, but for beating them.</p> -->
                        <p>{!! $description !!}</p>
					</div>
				</div>
				<div class="col-lg-5 col-md-6 col-12">
					<div class="performance-img">
						<img src="uploads/{{$image}}">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="co_team">
        <div class="container">
            <div class="team_details">
              <h2>OUR TEAM</h2>
            </div>
            <div class="row row__1 team-slider">
                
             @foreach($team as $t)  
                <div class="col-lg">
                     <div class="team_main">
                          <div class="team_img">
                               <img src="/uploads/{{$t->image}}">
                          </div>
                          <div class="team-overlay">
                              <p>{!! $t->description !!}</p>
                          </div>
                          <div class="team-bottom">
                              <h4>{{$t->name}}</h4>
                              <p>{{$t->occupation}}</p>
                          </div>
                     </div>
                </div>
                @endforeach
                
                
               <!-- <div class="col-lg">
                     <div class="team_main">
                          <div class="team_img">
                               <img src="/image/team2.jpg">
                          </div>
                          <div class="team-overlay">
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus, hic. Ipsum blanditiis, adipisci.</p>
                          </div>
                          <div class="team-bottom">
                              <h4>Sandra Schaad</h4>
                              <p>Chief Compliance Officer</p>
                          </div>
                     </div>
                </div>
                <div class="col-lg">
                     <div class="team_main">
                          <div class="team_img">
                               <img src="/image/team3.jpg">
                          </div>
                          <div class="team-overlay">
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus, hic. Ipsum blanditiis, adipisci.</p>
                          </div>
                          <div class="team-bottom">
                              <h4>Claude Tendon</h4>
                              <p>Deputy Chief Investment Officer</p>
                          </div>
                     </div>
                </div>
                <div class="col-lg">
                     <div class="team_main">
                          <div class="team_img">
                               <img src="/image/team4.jpg">
                          </div>
                          <div class="team-overlay">
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus, hic. Ipsum blanditiis, adipisci.</p>
                          </div>
                          <div class="team-bottom">
                              <h4>Benjamin Pourrat</h4>
                              <p>Chief Risk Officer</p>
                          </div>
                     </div>
                </div>-->
             <!--   <div class="col-lg">
                     <div class="team_main">
                          <div class="team_img">
                               <img src="/image/team2.jpg">
                          </div>
                          <div class="team-overlay">
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus, hic. Ipsum blanditiis, adipisci.</p>
                          </div>
                          <div class="team-bottom">
                              <h4>Sakib Anderson</h4>
                              <p>CEO & Founder</p>
                          </div>
                     </div>
                </div>-->
            </div>
        </div>
    </div>
	<div class="co_get">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-12">
					<div class="get-in">
						<h1>get in touch with us</h1>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-12">
					<div class="get-form">

						<div class="message" id="hideDiv"> </div>

						 <div class="alert alert-danger print-error-msg" style="display:none">
                          <ul></ul>
                          </div>
						<form method="post" class="news_letter">
							 {{ csrf_field() }}
							<div class="row">
							    <div class="col-lg-12 col-md-12 col-12 inner-get">
                                 <div id="loading-bar-spinner" class="spinner"><div class="spinner-icon"></div></div>
							    	<div class="get_1">
							    	<input type="text" placeholder="Enter Email" name="email" id="email">
							    	 @if($errors->has('email')) <p class="error_mes">{{ $errors->first('email') }}</p> @endif
							    	</div>
							    </div>
							    <div class="col-lg-12 col-md-12 col-12 inner-get">
							    	<div class="get_1 get_2">
							    		<input type="text" placeholder="Enter Phone Number" name="number" id="number">

							    		@if($errors->has('number')) <p class="error_mes">{{ $errors->first('number') }}</p> @endif

							    	</div>
							    </div>

							     <div class="col-lg-12 col-md-12 col-12 inner-get">
							    	<div class="get_1 get_2">
							    		<button class="submit">Submit</button>
							    	</div>
							    </div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<style>
	    
/*----------------------team-section------------------*/
  .co_team{
    position: relative;
    padding: 60px 0;
    background-color: #F7F8FA !important;
  }
  .team_main{
    overflow: hidden;
    position: relative;
    border-radius: 17px;
  }
  .team_details {
    width: 70%;
    margin: 0px auto 60px;
  }
  .team_details h2 {
    font-size: 28px;
    font-weight: bold;
    line-height: 35px;
    text-align: center;
    text-transform: uppercase;
    color: #140958;
    margin-bottom: 25px;
  }
  .team_details p{
    text-align: center;
    color: rgb(20, 9, 88);
    font-family: Inter, sans-serif;
    font-size: 18px;
    letter-spacing: 0.81px;
    text-align: center;
  }
  .team-bottom {
    background-color: #fff !important;
    padding:20px 30px;
    position: relative;
    z-index: 9;
    text-align: center;
    height:115px;
  }
  .team-bottom h4 {
    color: #0263f6;
    font-weight: bold;
    font-size: 20px;
    margin:0;
    padding-bottom:5px;
  }
  .team-bottom p{
    margin: 0;
    font-size: 15px;
  }
  .team_main:after {
      content: "";
      height: 3px;
      position: absolute;
      left: 0;
      bottom: -3px;
      width: 0;
      background: rgb(20, 9, 88);
      transition: all 0.4s ease 0s;
  }
  .team_img img {
      width: 100%;
  }
  .team-overlay {
      height: 100%;
      padding:100px 20px 0 30px;
      position: absolute;
      top: -100%;
      transition: all 300ms ease-in-out 0s;
      width: 100%;
      color: #fff !important;
      text-align: center;
      background:#72bafa;
  }
  .team-overlay p {
    font-size: 14px;
}
  .team_main:hover .team-overlay {
      top: 0;
      transition: all 1s ease;
  }
  .row__1{
    display: flex;
  }
  .slide-arrow5 {
    position: absolute;
    width: 34px;
    height: 34px;
    line-height: 34px;
    background: #0263f6;
    color: #fff;
    text-align: center;
    font-size:19px;
    cursor: pointer;
    border: 1px solid #0263f6;
    border-radius: 5px;
    padding-top:6px;
}
.next-arrow5 {
    right: -29px;
    top: 150px;
}
.prev-arrow5 {
    top: 150px;
    left: -29px;
    z-index: 99;
}
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script type="text/javascript" src="js/home.js"></script>
      <script type="text/javascript">
     $('.team-slider').slick({
          autoplay: true,
          autoplaySpeed: 1500,
            slidesToShow: 4,
            slidesToScroll: 1,
            dots: false,
            arrows: true,
            focusOnSelect: true,
            prevArrow: '<div class="service-arrow5 slide-arrow5 prev-arrow5"><i class="far fa-chevron-left"></i></div>',
            nextArrow: '<div class="service-arrow5 slide-arrow5 next-arrow5"><i class="far fa-chevron-right"></i></div>',
            responsive: [
                {
                  breakpoint: 1024,
                  settings: {
                    slidesToShow:3,
                    slidesToScroll: 1,
                    adaptiveHeight: true,
                    arrows : false,
                  },
                },
                {
                  breakpoint: 600,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows:false,
                  },
                },
            ],
        });
      </script>
    <script type="text/javascript">
        $('.counter-count').each(function () {
            $(this).prop('Counter',0).animate({
                Counter: $(this).text()
                }, {          
                //chnage count up speed here
                duration: 4000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });



        $(document).ready(function() {
          $(".submit").click(function(e){
            e.preventDefault();
         
            var _token = $("input[name='_token']").val();  
            var email = $('#email').val();
            var number = $('#number').val();
             
            $.ajax({
                url: '/storedata',
                type:'POST',
                data: {_token:_token,email:email,number:number},


                  beforeSend: function(){
                      $('#loading-bar-spinner').show();


                      $('#overlay').fadeIn()

                    

                          },
                      complete: function(){
                        $('#loading-bar-spinner').hide();

                        
                        },

                success: function(data) {
                    if($.isEmptyObject(data.error)){
                   
                         $('.message').text('data submitted sucessfully!!!!');
                          $('.message').css('color', 'white');
                           $('.message').delay(5000).fadeOut(3000); 

                          $( '.news_letter' ).each(function(){
                          this.reset();
                        });  

                           
                    }else{



                    	if(data.status==202){


                    		 $('.message').text('User is not available, Please Complete your Registration !');
                    		  $('.message').css('color', 'red');
                    		   $('.message').delay(3000).fadeOut(3000); 

                     $( '.news_letter' ).each(function(){
                          this.reset();
                        });   

                           

                    	}else{

                    		   printErrorMsg(data.error);

                         $('.alert').delay(3000).fadeOut(3000);  



                    	}



                     
                        

                    }
                }
            });
       
        }); 
       
        function printErrorMsg (msg) {
            $(".print-error-msg").find("ul").html('');
            $(".print-error-msg").css('display','block');
            $.each( msg, function( key, value ) {
                $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
            });
        }
    });




    </script>

	@endsection