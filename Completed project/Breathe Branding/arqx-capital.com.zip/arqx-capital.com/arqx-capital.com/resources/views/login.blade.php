<html>
<head>
	<meta charset="utf-8">
	<title>ARQX</title>
	<link rel="stylesheet" type="text/css" href="css/home1.css">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="icon" href="image/logo.jpg">
	<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div class="co_login">
        <div class="row row1">
            <div class="col-lg-6 col-md-6 col-12">
                <div class="login-inner">
                    <div class="set-login">
                        <div class="logo1">
                            <a href="{{url('/')}}"><img src="image/logo.jpg"></a>
                        </div>
                        <h3>Sign into your account</h3>
                        <form method="post" action="{{url('/authenticate')}}">
                              {{ csrf_field() }}

                                   @if ($message = Session::get('error'))
            <div  id="hideDiv1" class="alert alert-success alert-block" >
                <!--     <input type="text" class="close" data-dismiss="alert"></input> -->
                <strong style="padding-top : 5px !important; display: inline-block;">{{ $message }}</strong>
             </div>
           @endif



    
          @if ($message = Session::get('success'))
            <div  id="hideDiv" class="alert alert-danger alert-block" >
                <!--     <input type="text" class="close" data-dismiss="alert"></input> -->
                <strong style="padding-top : 5px !important; display: inline-block;">{{ $message }}</strong>
             </div>
           @endif

                            <div class="text_1">
                                <input type="email" placeholder="Email Address" name="email">
                                  @if($errors->has('email')) <p class="error_mes">{{ $errors->first('email') }}</p> @endif
                            </div>
                            <div class="text_1">
                                <input type="password" placeholder="Password" name="password">
                                @if($errors->has('password')) <p class="error_mes">{{ $errors->first('password') }}</p> @endif
                            </div>
                            <ul class="row">
                                <li>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" value="1">remember me
                                        </label>
                                    </div>
                                </li>
                                <li class="forgot">
                                    <a href="{{url('/forget_password')}}">Forgot Password?</a>
                                 </li>
                            </ul>
                            <div class="submit-btn">
                                <input type="submit" value="Login">
                            </div>
                        </form>
                        <div class="extra-login clearfix">
                            <span>Or Login With</span>
                        </div>
                        <div class="social-list">
                            <a href="{{ url('auth/facebook') }}" class="facebook-bg">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                           <!--  <a href="#" class="twitter-bg">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="#" class="linkedin-bg">
                                <i class="fab fa-linkedin-in"></i>
                            </a> -->
                            <a href="{{ url('auth/google') }}" class="google-bg">
                                <i class="fab fa-google"></i>
                            </a>
                        </div>
                        <p class="forgot">Don't have an account? <a href="{{url('/registration')}}"> Register Here</a></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12 login_1">
                <img src="uploads/{{$image}}">
                <div class="login-bg">
                    <div class="login-info">
                         <div class="title_1">
                            <div>{{$title}}</div>
                            <div class="word can">
                                <span>a</span>
                                <span>r</span>
                                <span>q</span>
                                <span>x</span>
                            </div>
                            <div class="word will">
                                <span>a</span>
                                <span>r</span>
                                <span>q</span>
                                <span>x</span>
                            </div>
                            <div class="word thrive">
                                <span>a</span>
                                <span>r</span>
                                <span>q</span>
                                <span>x</span>
                            </div>
                        </div>
                        <p>{{$description}}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">



      $(function() {
                 setTimeout(function() {$("#hideDiv").fadeOut(1500); }, 3000)

             });

        $(function() {
                 setTimeout(function() {$("#hideDiv1").fadeOut(1500); }, 3000)

             });




        


    </script>



</body>
</html>