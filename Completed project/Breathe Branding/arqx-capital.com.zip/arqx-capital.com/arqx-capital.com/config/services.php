<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],
    
      'facebook' => [
        'client_id' => '2857663117859112',
        'client_secret' => '0db82d65dc23c42fb18e3fce8294db09',
        'redirect' => 'https://arqx-capital.com/auth/facebook/callback',
    ],
    
     'google' => [
        'client_id' => '945609068945-6j2bd9jt4ip6011odcab8lalf7akobj1.apps.googleusercontent.com',
        'client_secret' => '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',
        'redirect' => 'https://arqx-capital.com/auth/google/callback',
    ],
    
    

];
