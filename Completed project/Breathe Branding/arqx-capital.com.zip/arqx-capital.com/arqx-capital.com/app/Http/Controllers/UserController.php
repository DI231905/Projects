<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;

class UserController extends Controller
{
    public function index(){

     $features=DB::table('features')->get();
     $data['features']=$features;

       $home_aboutus=DB::table('home_aboutus')->get();
       $data['title']=$home_aboutus[0]->title;
       $data['description']=$home_aboutus[0]->description;

       $home_aboutus_image=DB::table('home_aboutus_image')->get();
       $data['image1']=$home_aboutus_image[0]->image;
       $data['image2']=$home_aboutus_image[1]->image;
       $data['image3']=$home_aboutus_image[2]->image;
       $data['image4']=$home_aboutus_image[3]->image;

       $key_feature=DB::table('key_feature')->get();
       $data['key_feature']=$key_feature;

       $features_description=DB::table('features_description')->get();
       $data['features_description']=$features_description;


       $skillsetdata=DB::table('skillset')->get();
       $data['skillsetdata']=$skillsetdata;

       $achive_target=DB::table('achive_target')->get();
       $data['achive_target']=$achive_target;


        $invesment_process=DB::table('invesment_process')->get();
        $data['image']=$invesment_process[0]->image;
        $data['title']=$invesment_process[0]->title;


        $invesment_process_step=DB::table('invesment_process_step')->get();
        $data['invesment_process_step']=$invesment_process_step;


           $banner=DB::table('banner')->get();
           $data['banner']=$banner;

           $more_maintitle=DB::table('more_maintitle')->get();
           $data['more_maintitle']=$more_maintitle;


      $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

         $list=DB::table('admininfo')->where('id',1)->get();
           $data['admin_email']=$list[0]->email;
           $data['admin_phone']=$list[0]->phone;
           $data['admin_address']=$list[0]->address;
           $data['admin_facebook']=$list[0]->facebook;
           $data['admin_instagram']=$list[0]->instagram;
           $data['admin_twitter']=$list[0]->twitter;
           $data['admin_linkedin']=$list[0]->linkedin;
 
         
    	return view('welcome',$data);
    }


    public function about_us(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;


       $benefitdata=DB::table('benefits')->get();
       $data['benefitdata']=$benefitdata;

       $whychdata=DB::table('whychooseus')->get();
       $data['whychdata']=$whychdata;

       $perfdata=DB::table('performance')->get();
       $data['title']=$perfdata[0]->title;
       $data['image']=$perfdata[0]->image;
       $data['description']=$perfdata[0]->description;

        $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

             $list=DB::table('admininfo')->where('id',1)->get();
           $data['admin_email']=$list[0]->email;
           $data['admin_phone']=$list[0]->phone;
           $data['admin_address']=$list[0]->address;
           $data['admin_facebook']=$list[0]->facebook;
           $data['admin_instagram']=$list[0]->instagram;
           $data['admin_twitter']=$list[0]->twitter;
           $data['admin_linkedin']=$list[0]->linkedin;

         $aboutdescription=DB::table('aboutdescription')->where('id',1)->get();
         $data['description']=$aboutdescription[0]->description;
         $data['title']=$aboutdescription[0]->title;
         
          $team=DB::table('team')->get();
          $data['team']= $team;
       
       return view('about',$data);


    }

     public function service(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;


       $service_aboutus=DB::table('service_aboutus')->get();
       $data['title']=$service_aboutus[0]->title;
       $data['name']=$service_aboutus[0]->name;
       $data['description']=$service_aboutus[0]->description;

       $service_aboutus_image=DB::table('service_aboutus_image')->get();
       $data['image1']=$service_aboutus_image[0]->image;
       $data['image2']=$service_aboutus_image[1]->image;
       $data['image3']=$service_aboutus_image[2]->image;
       $data['image4']=$service_aboutus_image[3]->image;
       $data['image5']=$service_aboutus_image[4]->image;

       $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

        $servicedata=DB::table('service')->get();
        $data['servicedata']=$servicedata;

            $list=DB::table('admininfo')->where('id',1)->get();
           $data['admin_email']=$list[0]->email;
           $data['admin_phone']=$list[0]->phone;
           $data['admin_address']=$list[0]->address;
           $data['admin_facebook']=$list[0]->facebook;
           $data['admin_instagram']=$list[0]->instagram;
           $data['admin_twitter']=$list[0]->twitter;
           $data['admin_linkedin']=$list[0]->linkedin;
 

       return view('service',$data);

    }

     public function market(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

      $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

             $list=DB::table('admininfo')->where('id',1)->get();
           $data['admin_email']=$list[0]->email;
           $data['admin_phone']=$list[0]->phone;
           $data['admin_address']=$list[0]->address;
           $data['admin_facebook']=$list[0]->facebook;
           $data['admin_instagram']=$list[0]->instagram;
           $data['admin_twitter']=$list[0]->twitter;
           $data['admin_linkedin']=$list[0]->linkedin;
 

       return view('market',$data);

    }


      public function blogs(){

      $allbanner=DB::table('banner_image')->get();
      $data['allbanner']=$allbanner;

       $blogdata=DB::table('blog')->get();
        $data['blogdata']=$blogdata;

      $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

             $list=DB::table('admininfo')->where('id',1)->get();
           $data['admin_email']=$list[0]->email;
           $data['admin_phone']=$list[0]->phone;
           $data['admin_address']=$list[0]->address;
           $data['admin_facebook']=$list[0]->facebook;
           $data['admin_instagram']=$list[0]->instagram;
           $data['admin_twitter']=$list[0]->twitter;
           $data['admin_linkedin']=$list[0]->linkedin;
 

       return view('blogs',$data);

    }

      public function contact_us(){

      $allbanner=DB::table('banner_image')->where('name','Contact Us')->get();
      $data['banner_image']=$allbanner[0]->image;

       $footer_data=DB::table('footer_data')->where('id',1)->get();
         $data['footer_image']=$footer_data[0]->image;
         $data['footer_title']=$footer_data[0]->title;
         $data['footer_description']=$footer_data[0]->description;

             $list=DB::table('admininfo')->where('id',1)->get();
           $data['admin_email']=$list[0]->email;
           $data['admin_phone']=$list[0]->phone;
           $data['admin_address']=$list[0]->address;
           $data['admin_facebook']=$list[0]->facebook;
           $data['admin_instagram']=$list[0]->instagram;
           $data['admin_twitter']=$list[0]->twitter;
           $data['admin_linkedin']=$list[0]->linkedin;

         $contact_us_desc=DB::table('contact_us_desc')->where('id',1)->get();
         $data['title']=$contact_us_desc[0]->title;
         $data['description']=$contact_us_desc[0]->description;
       

           
 

       return view('contact_us',$data);

    }

       public function storedata(Request $request){


/*
       $request->validate([
            'password' => 'required|min:6',
            'confirm_password' => 'required|same:password',
        ]);

       echo $password1 =$request->input('password');


         $password=Hash::make($password1);



      /*
           User::where('id', $id)->update(['password' => $password]);*/

         /*  DB::table('users')->where('id',$id)->update(['password' => $password]);

        return redirect('login')->with('error', 'Reset password successfully !!!!');*/



        $validator = Validator::make($request->all(), [
          
            'email' => 'required|email',
            'number' => 'required',
       
         ]);

          if($validator->fails()){

          return response()->json(['error'=>$validator->errors()->all()]);
        }

       $email=$request->email;
       $number=$request->number;

    
        $inquiry=DB::table('news_letter')->insert(['email'=>$email, 'number'=>$number]);


        if($inquiry){
            $img_url = env('APP_URL')."/uploads/1641381228_logo.png";
       
             $meta['FROM_EMAIL']="n.treand@arqx-capital.com";
             $meta['email']="n.treand@arqx-capital.com";
             $meta['subject']="Get In Touch Inquiry";  
             $meta['image']= $img_url;
             $meta['email1']= $email;
             $meta['mobileno']= $number;
          
      
           Mail::send('email.getintouch1', $meta, function($m) use($meta){
        
               $m->from($meta['FROM_EMAIL'],'Get In Touch Inquiry');
               $m->to($meta['email']);
               $m->subject($meta['subject']); 
             });

             $meta['FROM_EMAIL']="n.treand@arqx-capital.com";
             $meta['email']="$email";
             $meta['subject']="New Get Started Inquiry";  
            
          
      
           Mail::send('email.clientmail', $meta, function($m) use($meta){
        
               $m->from($meta['FROM_EMAIL'],'Inquiry submitted successfully');
               $m->to($meta['email']);
               $m->subject($meta['subject']); 
             });


       return response()->json(['success'=>'Registration successfully completed..']);

         }
       }

         public function store_get_in_touch(Request $request){

          $error=$request->validate([

               'name'=>'required',
               'number'=>'required',
               'email'=>'required|email',
               'Message'=>'required'


           ]);

           $name=$request->input('name');
           $number=$request->input('number');
           $email=$request->input('email');
           $Message=$request->input('Message');

     $inquiry=DB::table('get_in_touch')->insert(['name'=>$name,'email'=>$email, 'number'=>$number,'Message'=>$Message]);

     if($inquiry){

             $img_url = env('APP_URL')."/uploads/1641381228_logo.png";
       
             $meta['FROM_EMAIL']="n.treand@arqx-capital.com";
             $meta['email']="n.treand@arqx-capital.com";
             $meta['subject']="New Get Started Inquiry";  
             $meta['image']= $img_url;
             $meta['email1']= $email;
              $meta['name']= $name;
             $meta['mobileno']= $number;
          
      
           Mail::send('email.getintouch', $meta, function($m) use($meta){
        
               $m->from($meta['FROM_EMAIL'],'New Get Started Inquiry');
               $m->to($meta['email']);
               $m->subject($meta['subject']); 
             });

             $meta['FROM_EMAIL']="ditest787@gmail.com";
             $meta['email']="$email";
             $meta['subject']="New Get in touch Inquiry";  
            
          
      
           Mail::send('email.clientmail', $meta, function($m) use($meta){
        
               $m->from($meta['FROM_EMAIL'],'Inquiry submitted successfully');
               $m->to($meta['email']);
               $m->subject($meta['subject']); 
             });



     }


      return redirect('/contact_us')->with('error',' data submitted succcesfully!!!!');




         }

         public function search(Request $request){

         	$text = $request->input('text');



         	if($text !=''){

          $search_result=DB::table('blog')->where('title', 'like', '%' . $text . '%')->orWhere('date', 'like', '%' . $text . '%')->get();

        }else{


        	   $search_result=DB::table('blog')->get();


        }

          $total_row = $search_result->count();

          $output='';


      if($total_row > 0)
      {
        foreach($search_result as $row)
      {

        $output .= '
           <div class="col-lg-4 col-md-6 col-12">
              <div class="blog">
                <div class="blog-img">
                  <img src="uploads/'.$row->image.'">
                </div>
                <div class="blog-content">';



               $date1=date('F j, Y', strtotime($row->date)); //June, 2017

               

             $output .= '<h6>'.$date1.'</h6>
                  <h3>'.$row->title.'</h3>
                  <p>'.$row->description.'</p>
                </div>
              </div>
           </div>';
        }

      }
      else
      {
      
          $output .='<h3> Search data is not available...</h3>';

      }  
           return response($output);
         }
     

     public function getinquiry(Request $request){

        $validator = Validator::make($request->all(), [
          
            'email' => 'required|email',
            'fname' => 'required',
            'lname' => 'required',
            'mobileno' => 'required',
       
        ]);

          if($validator->fails()){

          return response()->json(['error'=>$validator->errors()->all()]);
        }

         $email=$request->email;
         $mobileno=$request->mobileno;
         $fname=$request->fname;
         $lname=$request->lname;
         $description=$request->description;
         
      


       $inquiry=DB::table('inquiry')->insert(['email'=>$email,'mobileno'=>$mobileno,'fname'=>$fname,'lname'=>$lname,'description'=>$description,]);

       if($inquiry){


             $img_url = env('APP_URL')."/uploads/1641381228_logo.png";
       
             $meta['FROM_EMAIL']="n.treand@arqx-capital.com";
             $meta['email']="n.treand@arqx-capital.com";
             $meta['subject']="New Get Started Inquiry";  
             $meta['image']= $img_url;
             $meta['email1']= $email;
              $meta['name']= $fname;
             $meta['mobileno']= $mobileno;
          
      
           Mail::send('email.inquiry', $meta, function($m) use($meta){
        
               $m->from($meta['FROM_EMAIL'],'New Get Started Inquiry');
               $m->to($meta['email']);
               $m->subject($meta['subject']); 
             });

             $meta['FROM_EMAIL']="n.treand@arqx-capital.com";
             $meta['email']="$email";
             $meta['subject']="New Get Started Inquiry";  
            
          
      
           Mail::send('email.clientmail', $meta, function($m) use($meta){
        
               $m->from($meta['FROM_EMAIL'],'Inquiry submitted successfully');
               $m->to($meta['email']);
               $m->subject($meta['subject']); 
             });



         return response()->json(['success'=>'Registration successfully completed..']);


       }


     }

     public function privacy(){

      return view('privacy');
      
     }

     public function terms(){

      return view('terms');

     }
     
     public function download(){
         
            
            
           $id=DB::table('brochure')->max('id');
  
       $application= DB::table('brochure')->where('id',$id)->get();
       
     
        $resume=$application[0]->image;

           $file="./uploads/".$resume;
        return Response::download($file);


/*         return response()->download('/uploads/'.$resume);*/

         
         
     }




 

    
}
