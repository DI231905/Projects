<?php $__env->startSection('content'); ?>

<style type="text/css">
.banner-slider{
    margin-bottom: 0!important;
}
.banner-slider .slick-slide {
    height: auto!important;
}
.banner-section{
    position: relative;
}
</style>
<div class="co_banner">
      <div class="banner-slider">

        <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <div class="banner-section">
                    <div class="banner-img">
                        <img src="uploads/<?php echo e($b->image); ?>">
                    </div>
                    <div class="banner-content">
                        <h1><?php echo e($b->title); ?></h1>

                        
                     <?php $__currentLoopData = $more_maintitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                         <?php if($m->banner_id == $b->id): ?>

                        <p><?php echo e($m->more_maintitle); ?></p>

                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a href="#"><span>learn more</span> <i class="fal fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <!--  <div>
                <div class="banner-section">
                    <div class="banner-img">
                        <img src="image/banner.png">
                    </div>
                    <div class="banner-content">
                        <h1>dIVERSIFIED MARKETS & ASSET CLASSES</h1>
                        <p>Investments are globally diversified to bring out maximum yield with low risk strategies</p>
                        <a href="#"><span>learn more</span> <i class="fal fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div>
                <div class="banner-section">
                    <div class="banner-img">
                        <img src="image/banner.png">
                    </div>
                    <div class="banner-content">
                        <h1>CAPITAL PROTECTION STRATEGIES</h1>
                        <p>We preserve the value you’ve created through a qualitative approach</p>
                        <a href="#"><span>learn more</span> <i class="fal fa-arrow-right"></i></a>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
    <div class="co_inner-service">
        <div class="container">
            <div class="row">

                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-12">
                    <div class="inner-service">
                        <img src="uploads/<?php echo e($f->icon_image); ?>">
                        <h3><?php echo e($f->title); ?></h3>
                        <p><?php echo e($f->description); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
        </div>
    </div>
    <div class="co_about">
        <div class="container">
            <div class="row row1">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="about-img">
                        <div class="col-lg-4 col-md-4 col-4">
                            <img src="uploads/<?php echo e($image1); ?>">
                        </div>
                        <div class="col-lg-4 col-md-4 col-4">
                            <img src="uploads/<?php echo e($image2); ?>" class="ab-1">
                            <img src="uploads/<?php echo e($image3); ?>" class="ab-2">
                        </div>
                        <div class="col-lg-4 col-md-4 col-4">
                            <img src="uploads/<?php echo e($image4); ?>">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="about-content">
                        <h2><?php echo e($title); ?></h2>
                       <!--  <p>We have best-in-class funds tuned not just for tracking the benchmark, but for beating them.</p> -->
                        <p><?php echo $description; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_quote">
        <div class="container">
            <div class="row row1">
         <?php $__currentLoopData = $key_feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="inner-quote">
                     
                        <h3><?php echo e($kf->title); ?></h3>
                      
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="quote-slider">
                    <?php $__currentLoopData = $features_description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($kf->id==$fd->key_features_id): ?>
                        <div><p><?php echo e($fd->description); ?></p></div>

                        <?php endif; ?>


                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
        </div>
    </div>
    <div class="co_service">
        <div class="container">
            <h2 class="title">OUR SKILLSET</h2>
            <div class="row">
                <?php $__currentLoopData = $skillsetdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="services">
                        <div class="services-img">
                            <img src="uploads/<?php echo e($s->image); ?>">
                        </div>
                        <div class="services-content">
                            <h3><?php echo e($s->title); ?></h3>
                            <p><?php echo e($s->description); ?></p>
                            <a href="#">read more <i class="fal fa-long-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </div>
        </div>
    </div>
    <div class="co_count">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $achive_target; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($key==0): ?>

                <div class="col-lg-3 col-md-3 col-6 count">
                    <div class="count-up">
                        <p><span class=""><?php echo e($at->value); ?><span></p>
                        <h3><?php echo e($at->title); ?></h3>
                    </div>
                </div>

                <?php else: ?> 
                <div class="col-lg-3 col-md-3 col-6 count">
                    <div class="count-up">
                        <p><span class="counter-count"><?php echo e($at->value); ?><span></p>
                        <h3><?php echo e($at->title); ?></h3>
                    </div>
                </div>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </div>
        </div>
    </div>
    <div class="co_invest">
        <div class="container">
            <div class="row row1">
                <div class="col-lg-6 col-md-6 col-12 order_03">
                    <div class="invest">
                        <h2><?php echo e($title); ?></h2>

                        <?php $__currentLoopData = $invesment_process_step; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="inner_invest">
                            <div class="invest-number">
                                <h6><?php echo e($key+1); ?></h6>
                            </div>
                            <div class="invest-content">
                                <h3><?php echo e($ip->title); ?></h3>
                                <p><?php echo e($ip->description); ?></p>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12 order_04">
                    <div class="invest-img">
                        <img src="uploads/<?php echo e($image); ?>">
                    </div>
                    <div class="invest-bg">
                        <img src="image/invest-bg.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arqx2.ditests.com\resources\views/welcome.blade.php ENDPATH**/ ?>