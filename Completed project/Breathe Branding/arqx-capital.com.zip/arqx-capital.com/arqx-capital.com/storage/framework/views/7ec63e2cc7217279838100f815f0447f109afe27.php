


<?php $__env->startSection('content'); ?>

<div class="co-banner1">
        <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'Markets'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"><img src="image/house.png"> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
        <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="market">
        <div class="container">
            <div class="market_div">
               <!--  <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-2 p-0">
                            <div class="inner_market">
                                <span>Balance</span>
                                <p>17,610,230</p>
                            </div>
                        </div>
                        <div class="col-md-2 p-0">
                            <div class="inner_market">
                                <span>Invested</span>
                                <p>2,320,000</p>
                            </div>
                        </div>
                        <div class="col-md-2 p-0">
                            <div class="inner_market">
                                <span>Gain</span>
                                <p class="text-success">+12,270</p>
                            </div>
                        </div>
                        <div class="col-md-2 p-0">
                            <div class="inner_market">
                                <span>Loss</span>
                                <p class="text-danger">-0.15%</p>
                            </div>
                        </div>
                        <div class="col-md-4 p-0">
                            <div class="inner_market border-0 total">
                                <span>Total Equity</span>
                                <p>19,930,230</p>
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="co_graph">
                    <div class="row graph">
                        <div class="col-lg-9 col-md-8 gp_1">
                            <div class="inner_graph">
                                <div class="row row1">
                                    <div class="col-lg-6 col-md-12 col-12">
                                        <div class="graph-name">
                                            <h4>ihsg</h4>
                                            <h6>6375.10 <sub>+8 (0.24%)</sub></h6>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-12">
                                        <div class="all_buttons">
                                            <button class="active">day</button>
                                            <button>week</button>
                                            <button>month</button>
                                            <button>year</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="set_chart">
                                    <div id="chart"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4 p-0">
                            <div class="add-symbol">
                                <h6><i class="fal fa-plus"></i> add symbol</h6>
                            </div>
                            <div class="r-section1">
                                <div class="d-flex row1">
                                    <div class="set_01">
                                        <div class="set-balance">
                                            <!--<h6>smi</h6>-->
                                             <h6>Brent</h6>
                                            <h2>1,200</h2>
                                        </div>
                                    </div>
                                    <div class="set_01">
                                        <div class="stock-graph">
                                            <div class="graph-img">
                                                <img src="image/pulse.png">
                                            </div>
                                            <p>-0.12%</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex row1">
                                    <div class="set_01">
                                        <div class="set-balance">
                                            <!--<h6>ni</h6>-->
                                             <h6>Copper</h6>
                                            <h2>1,200</h2>
                                        </div>
                                    </div>
                                    <div class="set_01">
                                        <div class="stock-graph">
                                            <div class="graph-img">
                                                <img src="image/pulse.png">
                                            </div>
                                            <p>-0.12%</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex row1">
                                    <div class="set_01">
                                        <div class="set-balance">
                                            <h6>Gold</h6>
                                            <!-- <h6>fi</h6>-->
                                            <h2>1,200</h2>
                                        </div>
                                    </div>
                                    <div class="set_01">
                                        <div class="stock-graph">
                                            <div class="graph-img">
                                                <img src="image/pulse.png">
                                            </div>
                                            <p>-0.12%</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex row1">
                                    <div class="set_01">
                                        <div class="set-balance">
                                            <h6>Nadsdaq</h6>
                                             <!--<h6>gi</h6>-->
                                            <h2>1,200</h2>
                                        </div>
                                    </div>
                                    <div class="set_01">
                                        <div class="stock-graph">
                                            <div class="graph-img">
                                                <img src="image/pulse.png">
                                            </div>
                                            <p>-0.12%</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex row1">
                                    <div class="set_01">
                                        <div class="set-balance">
                                            <h6>S&P</h6>
                                            <!--<h6>gi</h6>-->
                                            <h2>1,200</h2>
                                        </div>
                                    </div>
                                    <div class="set_01">
                                        <div class="stock-graph">
                                            <div class="graph-img">
                                                <img src="image/pulse.png">
                                            </div>
                                            <p>-0.12%</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script type="text/javascript" src="js/home.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('button').click(function(){
                $('button').removeClass("active");
                $(this).addClass("active");
            });
        }); 
        
        var options = {
            chart: {
                height: 320,
                type: "area"
            },
            dataLabels: {
              enabled: false
            },
            series: [
              {
                name: "Series 1",
                data: [10, 30, 53, 45, 30, 41, 59]
              }
            ],
            fill: {
                type: "gradient",
                gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.7,
                    opacityTo: 0.9,
                    stops: [0, 90, 100]
                }
            },
            xaxis: {
                categories: [
                    "Mon",
                    "Tue",
                    "Wed",
                    "Thu",
                    "Fri",
                    "Sat",
                    "Sun"
                ]
            }
        };
        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();

    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arqxca5/arqx-capital.com/resources/views/market.blade.php ENDPATH**/ ?>