<html>
<head>
	<meta charset="utf-8">
	<title>ARQX</title>
	<link rel="stylesheet" type="text/css" href="/css/home1.css">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="icon" href="image/logo.jpg">
	<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div class="co_login">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-12">
                <div class="login-inner">
                    <div class="set-login">
                        <div class="logo1">
                            <a href="index.html"><img src="image/logo.jpg"></a>
                        </div>
                        <h3>CREATE AN ACCOUNT</h3>
                        <form method="post" action="<?php echo e(url('/storeuser')); ?>">
                              <?php echo e(csrf_field()); ?>

                            <div class="text_1">
                                <input type="name" placeholder="Full Name" name="name" >
                                    <?php if($errors->has('name')): ?> <p class="error_mes"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
                            </div>
                            <div class="text_1">
                                <input type="text" placeholder="Email Address" name="email">
                                    <?php if($errors->has('email')): ?> <p class="error_mes"><?php echo e($errors->first('email')); ?></p> <?php endif; ?>
                            </div>
                            <div class="text_1">
                                <input type="Password" placeholder="Enter Password" name="password">
                                    <?php if($errors->has('password')): ?> <p class="error_mes"><?php echo e($errors->first('password')); ?></p> <?php endif; ?>
                            </div>
                            <div class="text_1">
                                <input type="Password" placeholder="Enter Repeat Password" name="confirm_password">
                                    <?php if($errors->has('confirm_password')): ?> <p class="error_mes"><?php echo e($errors->first('confirm_password')); ?></p> <?php endif; ?>
                            </div>
                            <ul class="row">
                                <li>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                          <input type="checkbox" class="form-check-input" name="terms_condition" value="1">I Agree To The terms Of Service
                                        </label>
                                         <?php if($errors->has('terms_condition')): ?> <p class="error_mes"><?php echo e($errors->first('terms_condition')); ?></p> <?php endif; ?>
                                    </div>
                                </li>
                            </ul>
                            <div class="submit-btn">
                                <input type="submit" value="register">
                            </div>
                        </form>
                        <p class="forgot">Already a member? <a href="<?php echo e(url('/login')); ?>"> Login here</a></p>
                    </div>
                </div>
            </div>
             <div class="col-lg-6 col-md-6 col-12 login_1">
                <img src="uploads/<?php echo e($image); ?>">
                <div class="login-bg">
                    <div class="login-info">
                         <div class="title_1">
                            <div><?php echo e($title); ?></div>
                            <div class="word can">
                                <span>a</span>
                                <span>r</span>
                                <span>q</span>
                                <span>x</span>
                            </div>
                            <div class="word will">
                                <span>a</span>
                                <span>r</span>
                                <span>q</span>
                                <span>x</span>
                            </div>
                            <div class="word thrive">
                                <span>a</span>
                                <span>r</span>
                                <span>q</span>
                                <span>x</span>
                            </div>
                        </div>
                        <p><?php echo e($description); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/registration.blade.php ENDPATH**/ ?>