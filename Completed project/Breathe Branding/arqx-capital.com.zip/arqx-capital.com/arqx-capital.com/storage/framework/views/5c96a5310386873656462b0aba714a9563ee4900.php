

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4">About Description</h4>
                  
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            
                             <tbody>
                               <?php $__currentLoopData = $about_descr_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                  <tr><br>
                                    <div class="data">
                                      <b>Title</b>
                                  </div>

                                    </tr>
                                    <tr>

                                       <div class="data">
                                     <?php echo e($a->title); ?>

                                    </div><br>
                                    </tr>

                                    <tr><br>
                                      
                                      <div class="data">
                                      <b>Description</b>
                                  </div>

                                    </tr>
                                    <tr>

                                     <div class="data">
                                     <?php echo $a->description; ?>

                                    </div><br>
                                      
                                    </tr>    
     
                                <tr>

                                <button class="btn0 btn2"><a href="<?php echo e(url('/admin/update_about_descr')); ?>/<?php echo e($a->id); ?>">Update</a></button>
                              </tr>
                            
                            
                               
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>

        <style type="text/css">
    .data{

      margin-left: 25px;
    }
  </style>
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">
        
       


       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>


     

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ARQX\resources\views/admin/aboutdescr.blade.php ENDPATH**/ ?>