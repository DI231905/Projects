

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">FEATURES LIST</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addfeatures')); ?>">ADD</a></button>
                    </div>
                    <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Icon Image</th>

                                  
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="features_<?php echo e($f->id); ?>">
                                    <td>

                                     <img src="/uploads/<?php echo e($f->icon_image); ?>" width="120" height="100"><br>
                                       <?php echo e($f->icon_image); ?>  
                                        
                                         
                                    </td>

                                    

                                    

                                     <td>
                                      <?php echo e($f->title); ?>

                                    </td>
                                   
                                    <td>
                                    <?php echo e($f->description); ?>

                                    </td>


                                   <td>

                                     <button class="btn0 btn2"><a href="<?php echo e(url('admin/updatefeatures')); ?>/<?php echo e($f->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              
                                   </td>
                                    <td>
                                 <button class="btn3 btn0" onclick="deletefeatures(<?php echo e($f->id); ?>)"><i class="fal fa-trash-alt"></i></button>
                                 </td>
                                          
                                  
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>
                 <script type="text/javascript">
                   

  function deletefeatures($id){
    // alert('i am here');

     if(confirm("do you want delete this Feature ?")){
             $.ajax({

                url:'deletefeatures/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.features_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
       

                 </script>
                 

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arqx2.ditests.com\resources\views/admin/featureslist.blade.php ENDPATH**/ ?>