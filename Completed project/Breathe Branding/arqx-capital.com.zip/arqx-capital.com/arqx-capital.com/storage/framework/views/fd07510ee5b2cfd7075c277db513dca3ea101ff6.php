

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Admin Contact Info</h4>
                  
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>   
                                    <th>Email</th>
                                    <th>Phone</th> 
                                    <th>Address</th>
                                    <th>Facebook</th>   
                                    <th>Instagram</th>
                                    <th>Twitter</th> 
                                    <th>LinkedIn</th>
                                   
                                </tr>
                            </thead>
                        
                             <tbody>
                               
                               <tr class="">
                                  <?php $__currentLoopData = $admindata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($a->name); ?></td>

                                    <td><?php echo e($a->email); ?></td>

                                    <td><?php echo e($a->phone); ?></td> 

                                    <td><?php echo e($a->address); ?></td>

                                    <td><?php echo e($a->facebook); ?></td>
                                    
                                    <td><?php echo e($a->instagram); ?></td>

                                     <td><?php echo e($a->twitter); ?></td>
                                    
                                    <td><?php echo e($a->linkedin); ?></td>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                             <td>
                                <button class="btn0 btn2"><a href="<?php echo e(url('/admin/updateadmincontact')); ?>/<?php echo e($a->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              </td>
                              
                            
                                </tr>
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

             $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

              }); 
        
         function deletehomebanner($id){

     if(confirm("do you want delete this banner ?")){
             $.ajax({

                url:'deletehomebannerdata/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.banner_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
      </script>

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/admin/admincontactview.blade.php ENDPATH**/ ?>