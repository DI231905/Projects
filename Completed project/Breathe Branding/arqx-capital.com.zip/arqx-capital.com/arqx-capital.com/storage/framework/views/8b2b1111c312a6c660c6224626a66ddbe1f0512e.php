

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Our Performance</h4>
                  
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                          
                              
                             <tbody>
                               <?php $__currentLoopData = $perfdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr><br>

                               <h5 class="data">Image</h5>

                               </tr>

                               <tr>
                                
                                <img class="data" src="/uploads/<?php echo e($s->image); ?>" height="250px" width="400px">
                                <br/>

                                 <div class="data">

                                    
                                     <?php echo e($s->image); ?>

                                  
                                   </div>

                               </tr><br>

                                <tr>

                                  <h5 class="data"> Title </h5>

                               

                               </tr>
                               <tr> 

                                  <div class="data">

                                    
                                    <?php echo e($s->title); ?>

                                  
                                   </div>
                                   
                               </tr>
                               <tr><br>

                               <h5 class="data">Description</h5>
                                
                               </tr>
                               <tr>

                                  <div class="data">

                                    
                                     <?php echo $s->description; ?>

                                  
                                   </div>
                                   
                                 
                                  
                               </tr>
                                  
                                   
                  
                                   
                                 <tr class="data">
                                <button class="btn0 btn2"><a href="<?php echo e(url('admin/update_performance')); ?>/<?php echo e($s->id); ?>">Update</a></button>
                            
                      
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>

       <style type="text/css">
    .data{

      margin-left: 25px;
    }

  </style>
    
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(3000); }, 3000)

             });


     
        
        
        
      
      </script>

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arqx2.ditests.com\resources\views/admin/performance.blade.php ENDPATH**/ ?>