

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Services</h4>
                  <button class="btn1"><a href="<?php echo e(url('admin/add_service')); ?>" style="color:black;">ADD</a></button>
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>   
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                        
                             <tbody>
                               <?php $__currentLoopData = $servicedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="service_<?php echo e($s->id); ?>">
                                  
                                    <td><img src="/uploads/<?php echo e($s->image); ?>" height="100px" width="100px">
                                      <br/><?php echo e($s->image); ?></td>

                                    <td><?php echo e($s->title); ?></td>

                                    <td><?php echo $s->description; ?></td> 
    
                               <td>
                                <button class="btn0 btn2"><a href="<?php echo e(url('admin/update_service')); ?>/<?php echo e($s->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              </td>
                              <td>
                                <button class="btn3 btn0" onclick="deleteservice(<?php echo e($s->id); ?>)"><i class="fal fa-trash-alt"></i></a></button>
                              </td> 
                              
                            
                               </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>

        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
      <script type="text/javascript">
        
         function deleteservice($id){

     if(confirm("do you want delete this data ?")){
             $.ajax({

                url:'delete_service/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.service_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      } 

         $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
 
      </script>

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arqx2.ditests.com\resources\views/admin/service.blade.php ENDPATH**/ ?>