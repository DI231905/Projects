


<?php $__env->startSection('content'); ?>

<div class="co_banner co_contact">
		<img src="uploads/<?php echo e($banner_image); ?>" class="contact-img">
		<div class="container">
			<div class="inner-contact">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-12">
						<div class="set-contact">
							<p><?php echo $description; ?></p>
							<h2 class="footer-title">Contact Us</h2>
			    		    <ul class="con-home">
                                <li><img src="image/house.png">
                                    <p><?php echo e($admin_address); ?></p>
                                </li>
                                <li><img src="image/email.png">
                                    <p><a href="mailto:<?php echo e($admin_email); ?>"><?php echo e($admin_email); ?></a></p>    
                                </li>
                                <li><img src="image/telephone.png">
                                    <p><a href="tel:<?php echo e($admin_phone); ?>"><?php echo e($admin_phone); ?></a></p>
                                </li>
                            </ul>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-12">
						<div class="contact_form">
<!--
							  <?php if($message = Session::get('error')): ?>
           <div id="hideDiv"class="alert alert-success alert-block" >

           <strong style=" padding-top : 5px !important; display: inline-block;"><?php echo e($message); ?></strong>
           </div>
                      <?php endif; ?>-->

							<h2><?php echo e($title); ?></h2>
							<form action="<?php echo e(url('/store_get_in_touch')); ?>" method="post">
								 <?php echo e(csrf_field()); ?>

								<div class="row">
								    <div class="col-lg-6 col-md-12 col-12 set-contact1">
								    	<div class="contact_1">
								    		<input type="text" placeholder="Enter Name" name="name">
								    		<?php if($errors->has('name')): ?> <p class="error_mes"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
								    	</div>
								    </div>
								    <div class="col-lg-6 col-md-12 col-12 set-contact1">
								    	<div class="contact_1">
								    		<input type="number" placeholder="Enter Phone Number" name="number">

								    		<?php if($errors->has('number')): ?> <p class="error_mes"><?php echo e($errors->first('number')); ?></p> <?php endif; ?>
								    	</div>
								    </div>
								    <div class="col-lg-12 col-md-12 col-12 set-contact1">
								    	<div class="contact_1">
								    		<input type="email" placeholder="Enter Email" name="email">
								    		<?php if($errors->has('email')): ?> <p class="error_mes"><?php echo e($errors->first('email')); ?></p> <?php endif; ?>
								    	</div>
								    </div>
								    <div class="col-lg-12 col-md-12 col-12 set-contact1">
									<div class="contact_1">
										<input type="text" placeholder="Message" name="Message">
										<?php if($errors->has('Message')): ?> <p class="error_mes"><?php echo e($errors->first('Message')); ?></p> <?php endif; ?>
									</div>
								    </div>
								    <div class="col-lg-12 col-md-12 col-12 set-contact1">
								    	<div class="contact_1 submit">
								    		<input type="submit" value="submit">
								    	</div>
								    </div>
							    </div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="map">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2761.1511501758346!2d6.119222915785369!3d46.20744809156154!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478c64c868c128e5%3A0x860af76bc1416b3a!2sAll.%20Pic-Pic%202%2C%201203%20Gen%C3%A8ve%2C%20Switzerland!5e0!3m2!1sen!2sin!4v1640322951825!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
			</div>
		</div>
	</div>
	<style type="text/css">
		
 #pageMessages {
    position: fixed;
    top: 10%;
    right: 15px;
    width: 23%;
    text-align: center;
    z-index: 999999999;
}
	</style>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<script type="text/javascript">
	
	
	
	function createAlert(title, summary, details, severity, dismissible, autoDismiss, appendToId) {
  var iconMap = {
    info: "fa fa-info-circle",
    success: "fa fa-thumbs-up",
    warning: "fa fa-exclamation-triangle",
    danger: "fa ffa fa-exclamation-circle"
  };

  var iconAdded = false;

  var alertClasses = ["alert", "animated", "flipInX"];
  alertClasses.push("alert-" + severity.toLowerCase());

  if (dismissible) {
    alertClasses.push("alert-dismissible");
  }

  var msgIcon = $("<i />", {
    "class": iconMap[severity] // you need to quote "class" since it's a reserved keyword
  });

  var msg = $("<div />", {
    "class": alertClasses.join(" ") // you need to quote "class" since it's a reserved keyword
  });

  if (title) {
    var msgTitle = $("<h4 />", {
      html: title
    }).appendTo(msg);
    
    if(!iconAdded){
      msgTitle.prepend(msgIcon);
      iconAdded = true;
    }
  }

  if (summary) {
    var msgSummary = $("<strong />", {
      html: summary
    }).appendTo(msg);
    
    if(!iconAdded){
      msgSummary.prepend(msgIcon);
      iconAdded = true;
    }
  }

  if (details) {
    var msgDetails = $("<p />", {
      html: details
    }).appendTo(msg);
    
    if(!iconAdded){
      msgDetails.prepend(msgIcon);
      iconAdded = true;
    }
  }
  

  if (dismissible) {
    var msgClose = $("<span />", {
      "class": "close", // you need to quote "class" since it's a reserved keyword
      "data-dismiss": "alert",
      html: "<i class='fa fa-times-circle'></i>"
    }).appendTo(msg);
  }
  
  $('#' + appendToId).prepend(msg);
  
  if(autoDismiss){
    setTimeout(function(){
      msg.addClass("flipOutX");
      setTimeout(function(){
        msg.remove();
      },1000);
    }, 5000);
  }
}

		
		 $(function() {
                 setTimeout(function() { $("#pageMessages").fadeOut(1500); }, 3000)

             });

	</script>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arqxca5/arqx-capital.com/resources/views/contact_us.blade.php ENDPATH**/ ?>