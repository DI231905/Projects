

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">

  	  <div class="mt-5">
                       <div class="list1">
                        <h4 class="mb-4">Home Page About Us</h4>
                        
                       </div>

                     <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                  <!--   <th>Image</th>
                                    <th>Mission</th>
                                    <th>Value</th>
                                    <th>Promise</th> -->
                                    <th>Images</th>
                                </tr>
                            </thead>
                         
                             <tbody>
                              <?php $__currentLoopData = $home_aboutus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                	 <?php $__currentLoopData = $home_aboutus_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                	   <?php if($ha->id == $hi->home_aboutus_id): ?>

                                        <td>
                                           <img src="/uploads/<?php echo e($hi->image); ?>" width="200" height="200"><br>

                                           <?php echo e($hi->image); ?>  
                                        </td>
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 </tr> <br>
                                       
                                  <div class="data">
                                      <b>Title</b>
                                  </div>

                                   
                                   <div class="data">
                              
                                    <?php echo e($ha->title); ?>


                                  </div> <br>
                                                                      
                                   <div  class="data">
                                     <b>Description</b>
                                    </div>
                                    <div class="data">

                                    
                                       <?php echo $ha->description; ?>

                                  
                                   </div><br>
                                   <tr>
                                   
                                    <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/update_home_about_us')); ?>/<?php echo e($ha->id); ?>">Update</a></button></td>
                                  </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </table>
                    </div>

                  </div>

  </div>

   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(3000); }, 3000)

             });


     
        
        
        
      
      </script>

  <style type="text/css">
  	.data{

  		margin-left: 25px;
  	}

  </style>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arqx2.ditests.com\resources\views/admin/home_about_us.blade.php ENDPATH**/ ?>