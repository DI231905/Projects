<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\Admincontroller;
use App\Http\Controllers\Auth\Adminlogincontroller;
use App\Http\Controllers\Admin\HomeController;
use App\Http\Controllers\Admin\AboutUsController;
use App\Http\Controllers\Admin\ServiceController;
use App\Http\Controllers\Admin\MarketController;
use App\Http\Controllers\Admin\BlogsController;
use App\Http\Controllers\Admin\ContactUsController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\SocialController;







/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[UserController::class, 'index']);
Route::get('/about_us',[UserController::class, 'about_us']);
Route::get('/service',[UserController::class, 'service']);
Route::get('/market',[UserController::class, 'market']);
Route::get('/blogs',[UserController::class, 'blogs']);
Route::get('/contact_us',[UserController::class, 'contact_us']);
Route::get('/login',[AuthController::class, 'login']);
Route::post('/authenticate',[AuthController::class, 'authenticate']);
Route::get('/download',[UserController::class, 'download']);



Route::get('/registration',[AuthController::class, 'register']);
Route::post('/storeuser',[AuthController::class, 'storeuser']);
Route::get('/logout',[AuthController::class, 'logout']);

Route::get('/forget_password',[AuthController::class, 'forget_password']);
Route::post('/reset_password_url',[AuthController::class, 'reset_password_url']);
Route::get('/reset_password_view/{id}',[AuthController::class, 'reset_password_view']);
Route::post('/reset_password/{id}',[AuthController::class, 'reset_password']);
Route::post('/storedata',[UserController::class, 'storedata']);
Route::post('/store_get_in_touch',[UserController::class, 'store_get_in_touch']);
Route::get('/search',[UserController::class, 'search']);
Route::post('/getinquiry',[userController::class, 'getinquiry']);
Route::get('/privacy',[UserController::class, 'privacy']);
Route::get('/terms',[UserController::class, 'terms']);

Route::get('auth/facebook', [SocialController::class, 'facebookRedirect']);

Route::get('auth/facebook/callback', [SocialController::class, 'loginWithFacebook']);

Route::get('auth/google', [SocialController::class, 'redirectToGoogle']);
Route::get('auth/google/callback', [SocialController::class, 'handleGoogleCallback']);


Route::prefix('admin')->group(function(){

Route::get('/login',[Adminlogincontroller::class, 'login']);
Route::post('/login',[Adminlogincontroller::class, 'authenticate'])->name('login');
Route::get('/logout',[Adminlogincontroller::class, 'logout'])->name('adminlogout');


Route::get('/forgetpasswordview',[Adminlogincontroller::class, 'forgetpasswordview'])->name('forgetpasswordview');
Route::post('/resetpasswordlink',[Adminlogincontroller::class, 'resetpasswordlink'])->name('resetpasswordlink');

Route::get('/resetpasswordview/{id}',[Adminlogincontroller::class, 'resetpasswordview'])->name('resetpasswordview');
Route::post('/resetpassword/{id}',[Adminlogincontroller::class, 'resetpassword'])->name('resetpassword');

Route::get('/changepassword',[Admincontroller::class, 'changepassword']);
Route::post('/updatepassword/{id}',[Admincontroller::class, 'updatepassword']);

Route::get('/home',[Admincontroller::class, 'home']);

Route::get('/viewBannerlist',[HomeController::class, 'viewBannerlist']);
Route::get('/addhomebanner',[HomeController::class, 'addhomebanner']);
Route::post('/storehomebanner',[HomeController::class,'storehomebanner']);
Route::get('/updatebanner/{id}',[HomeController::class, 'updatebanner']);
Route::post('/storeupdatebanner/{id}',[HomeController::class, 'storeupdatebanner']);
Route::get('/deletemaintitle/{id}',[HomeController::class,'deletemaintitle']);
Route::get('/deletehomebannerdata/{id}',[HomeController::class, 'deletehomebanner']);


Route::get('/viewFeaturelist',[HomeController::class, 'viewFeaturelist']);                                                  
Route::get('/addfeatures',[HomeController::class, 'addfeatures']);
Route::post('/storefeatures',[HomeController::class, 'storefeatures']);
Route::get('/deletefeatures/{id}',[HomeController::class, 'deletefeatures']);
Route::get('/updatefeatures/{id}',[HomeController::class, 'updatefeatures']);
Route::post('/storeupdatefeatures/{id}',[HomeController::class, 'storeupdatefeatures']);


Route::get('/home_about_us',[HomeController::class, 'home_about_us']);
Route::get('/update_home_about_us/{id}',[HomeController::class, 'update_home_about_us']);
Route::get('/update_home_about_image/{id}',[HomeController::class, 'update_home_about_us_image']);
Route::post('/store_home_about_image/{id}',[HomeController::class, 'store_home_about_image']);
Route::post('/store_home_aboutus/{id}',[HomeController::class, 'store_home_aboutus']);



Route::get('/key_features',[HomeController::class, 'key_features']);
Route::get('/update_key_features/{id}',[HomeController::class, 'update_key_features']);
Route::post('/store_key_features/{id}',[HomeController::class, 'store_key_features']);
Route::get('/delete_description/{id}',[HomeController::class, 'delete_description']);


Route::get('/achieve_target',[HomeController::class, 'achieve_target']); 
Route::get('/add_achieve_target',[HomeController::class, 'add_achieve_target']); 
Route::post('/store_achieve_target',[HomeController::class, 'store_achieve_target']); 
Route::get('/delete_achieve_target/{id}',[HomeController::class, 'delete_achieve_target']);  
Route::get('/update_achieve_target/{id}',[HomeController::class, 'update_achieve_target']);  
Route::post('/store_update_achieve_target/{id}',[HomeController::class, 'store_update_achieve_target']); 


Route::get('/investment_process',[HomeController::class, 'investment_process']); 
Route::get('/update_investment_process/{id}',[HomeController::class, 'update_investment_process']);
Route::post('/store_investment_process/{id}',[HomeController::class, 'store_investment_process']); 


Route::get('/add_investment_process',[HomeController::class, 'add_investment_process']); 
Route::post('/store_investment_process_step',[HomeController::class, 'store_investment_process_step']); 
Route::get('/delete_process_step/{id}',[HomeController::class, 'delete_process_step']); 
Route::get('/update_process_step/{id}',[HomeController::class, 'update_process_step']);  
Route::post('/store_update_process_step/{id}',[HomeController::class, 'store_update_process_step']);  


Route::get('/aboutusBannerlist',[AboutUsController::class, 'aboutusBannerlist']);
Route::get('/updatebannerimg/{id}',[AboutUsController::class,'updatebannerimg']);
Route::post('/storeupdatebannerimg/{id}',[AboutUsController::class,'storeupdatebannerimg']);

Route::get('/view_about_descr',[AboutUsController::class, 'view_about_descr']);
Route::get('/update_about_descr/{id}',[AboutUsController::class,'update_about_descr']);
Route::post('/storeupdate_about_descr/{id}',[AboutUsController::class, 'storeupdate_about_descr']);





Route::get('/view_skillset',[HomeController::class, 'view_skillset']);
Route::get('/add_new_skillset',[HomeController::class, 'add_new_skillset']);
Route::post('/store_skillset',[HomeController::class, 'store_skillset']);
Route::get('/update_skillset/{id}',[HomeController::class,'update_skillset']);
Route::post('/store_update_skillset/{id}',[HomeController::class, 'store_update_skillset']);
Route::get('/delete_skillset/{id}',[HomeController::class, 'delete_skillset']);


Route::get('/view_benefits',[AboutUsController::class, 'view_benefits']);
Route::get('/add_benefits',[AboutUsController::class, 'add_benefits']);
Route::post('/store_benefits',[AboutUsController::class, 'store_benefits']);
Route::get('/update_benefits/{id}',[AboutUsController::class,'update_benefits']);
Route::post('/store_update_benefits/{id}',[AboutUsController::class, 'store_update_benefits']);
Route::get('/delete_benefits/{id}',[AboutUsController::class, 'delete_benefits']);

Route::get('/view_whychooseus',[AboutUsController::class, 'view_whychooseus']);
Route::get('/add_whychooseus',[AboutUsController::class, 'add_whychooseus']);
Route::post('/store_whychooseus',[AboutUsController::class, 'store_whychooseus']);
Route::get('/update_whychooseus/{id}',[AboutUsController::class,'update_whychooseus']);
Route::post('/store_update_whychooseus/{id}',[AboutUsController::class, 'store_update_whychooseus']);
Route::get('/delete_whychooseus/{id}',[AboutUsController::class, 'delete_whychooseus']);

Route::get('/view_performance',[AboutUsController::class, 'view_performance']);
Route::get('/update_performance/{id}',[AboutUsController::class,'update_performance']);
Route::post('/store_update_performance/{id}',[AboutUsController::class, 'store_update_performance']);


Route::get('/servicesBannerlist',[ServiceController::class, 'servicesBannerlist']);



Route::get('/view_service',[ServiceController::class, 'view_service']);
Route::get('/add_service',[ServiceController::class, 'add_service']);
Route::post('/store_service',[ServiceController::class, 'store_service']);
Route::get('/update_service/{id}',[ServiceController::class,'update_service']);
Route::post('/store_update_service/{id}',[ServiceController::class, 'store_update_service']);
Route::get('/delete_service/{id}',[ServiceController::class, 'delete_service']);


Route::get('/service_about_us',[ServiceController::class, 'service_about_us']);
Route::get('/update_service_about_us/{id}',[ServiceController::class, 'update_service_about_us']);
Route::get('/update_service_about_image/{id}',[ServiceController::class, 'update_service_about_us_image']);
Route::post('/store_service_about_image/{id}',[ServiceController::class, 'store_service_about_image']);
Route::post('/store_service_aboutus/{id}',[ServiceController::class, 'store_service_aboutus']);


Route::get('/marketBannerlist',[MarketController::class, 'marketBannerlist']);
Route::get('/blogsBannerlist',[BlogsController::class, 'blogsBannerlist']);
Route::get('/ContactUsBannerlist',[ContactUsController::class, 'ContactUsBannerlist']);


Route::get('/footer_data_list',[Admincontroller::class,'footer_data_list']);
Route::get('/update_footer_data/{id}',[Admincontroller::class,'update_footer_data']);
Route::post('/store_update_footer_data/{id}',[Admincontroller::class,'store_update_footer_data']);

Route::get('/admincontactview',[Admincontroller::class, 'admincontactview']);
Route::get('/updateadmincontact/{id}',[Admincontroller::class,'updateadmincontact']);
Route::post('/storeadmincontact/{id}',[Admincontroller::class, 'storeadmincontact']);


Route::get('/viewblog',[BlogsController::class, 'viewblog']);
Route::get('/addblog',[BlogsController::class, 'addblog']);
Route::post('/storeblog',[BlogsController::class, 'storeblog']);
Route::get('/updateblog/{id}',[BlogsController::class,'updateblog']);
Route::post('/storeupdateblog/{id}',[BlogsController::class, 'storeupdateblog']);
Route::get('/deleteblog/{id}',[BlogsController::class, 'deleteblog']);

Route::get('/view_get_in_touch',[AboutUsController::class, 'view_get_in_touch']);
Route::get('/delete_get_in_touch/{id}',[AboutUsController::class, 'delete_get_in_touch']);

Route::get('/view_contact_us_msg',[ContactUsController::class, 'view_contact_us_msg']);
Route::get('/delete_contact_us/{id}',[ContactUsController::class, 'delete_contact_us']);

Route::get('/view_contact_desc',[ContactUsController::class, 'view_contact_desc']);
Route::get('/update_contact_desc/{id}',[ContactUsController::class,'update_contact_desc']);
Route::post('/storeupdate_contact_desc/{id}',[ContactUsController::class, 'storeupdate_contact_desc']);

Route::get('/view_get_started',[Admincontroller::class, 'view_get_started']);
Route::get('/delete_get_started/{id}',[Admincontroller::class, 'delete_get_started']);

Route::get('/viewloginpage',[Admincontroller::class, 'viewloginpage']);
Route::get('/updateloginpage/{id}',[Admincontroller::class,'updateloginpage']);
Route::post('/storeupdateloginpage/{id}',[Admincontroller::class, 'storeupdateloginpage']);

Route::get('/userlist',[Admincontroller::class, 'userlist']);
Route::get('/delete_user/{id}',[Admincontroller::class, 'delete_user']);

Route::get('/viewbrochure',[Admincontroller::class, 'viewbrochure']);
Route::get('/addbrochure',[Admincontroller::class, 'addbrochure']);
Route::post('/storebrochure',[Admincontroller::class, 'storebrochure']);
Route::get('/updatebrochure/{id}',[Admincontroller::class,'updatebrochure']);
Route::post('/storeupdatebrochure/{id}',[Admincontroller::class, 'storeupdatebrochure']);
Route::get('/deletebrochure/{id}',[Admincontroller::class, 'deletebrochure']);

Route::get('/teamview',[Admincontroller::class, 'teamview']);
Route::get('/addteam',[Admincontroller::class, 'addteam']);
Route::post('/storeteam',[Admincontroller::class, 'storeteam']);
Route::get('/updateteam/{id}',[Admincontroller::class,'updateteam']);
Route::post('/storeupdateteam/{id}',[Admincontroller::class, 'storeupdateteam']);
Route::get('/deleteteam/{id}',[Admincontroller::class, 'deleteteam']);



 }); 

