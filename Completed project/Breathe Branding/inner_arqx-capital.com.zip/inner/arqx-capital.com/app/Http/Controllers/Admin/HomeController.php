<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;

class HomeController extends Controller
{

	 public function __construct(){

                $this->middleware('auth:admin');
        }



     /*-------    banner list view -----------  */

        public function viewBannerlist(){

          $id=Auth::id();
          $admin=Admin::where('id',$id)->get();

     
           $data['name']=$admin[0]->name;

           $banner=DB::table('banner')->get();
           $data['banner']=$banner;

           $more_maintitle=DB::table('more_maintitle')->get();
           $data['more_maintitle']=$more_maintitle;

           return view('admin.homebannerlistView',$data);
 
         }

        public function addhomebanner(){

           return view('admin.addhomeBanner');
 
         }

        public function storehomebanner(Request $request){

            $error=$request->validate([

              'title' => 'required',
              'image' => 'required',
               
            ]);
       
           $title=$request->input('title');
           $file=$request->file('image');
           $maintitle=$request->input('short_description');
           $maintitles=$request->input('short_descriptions') ;
       
           $imagename='';
        
           if ($file){
          
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
               $file->move($destinationPath,$imagename);
       
              }

            DB::table('banner')->insert(['title'=>$title ,'image'=>$imagename]);

            $last_id = DB::table('banner')->max('id'); 

            $maintitle=$request->input('short_description');

            if($maintitle!=""){

              DB::table('more_maintitle')->insert(['more_maintitle'=>$maintitle,'banner_id'=>$last_id]);

              }

           $maintitles=$request->input('short_descriptions');

            if($maintitles!=null){
            
              for($i=0; $i<count($maintitles); $i++){

                   $maintitles_info=$maintitles[$i];

                   if($maintitles_info!=""){

                   DB::table('more_maintitle')->insert(['more_maintitle'=>$maintitles_info,'banner_id'=>$last_id]);
                }
  
              }
           }
           return redirect('admin/viewBannerlist')->with('error',' Add home page banner data succcesfully!!!!');

         }

       public function updatebanner($id){

         $banner= DB::table('banner')->where('id', $id)->get();

         $data['id']=$banner[0]->id;
         $data['title']=$banner[0]->title;
         $data['image']=$banner[0]->image;

         $more_maintitle=DB::table('more_maintitle')->where('banner_id', $id)->get();
         $data['more_maintitle']=$more_maintitle;
   
         return view('admin.updatehomebanner',$data);

        }

       public function deletemaintitle($id){

         $more_maintitle=DB::table('more_maintitle')->where('id', $id)->get();
         $banner_id=$more_maintitle[0]->banner_id;

         DB::table('more_maintitle')->where('id',$id)->delete();

         return redirect('admin/updatebanner/'.$banner_id);

        }    

       public function storeupdatebanner(Request $request ,$id){

           $request->validate([

             'title' => 'required',
               
           ]);
       
           $title=$request->input('title');
           $file=$request->file('image');

           $maintitle=$request->input('short_description');
           $maintitles=$request->input('short_descriptions') ;
  
           $imagename='';

            if($file){
         
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
               $file->move($destinationPath,$imagename);

               DB::table('banner')->where('id', $id)->update(['image'=>$imagename]);

              if($request->input('oldimage')!='') {

                    unlink(public_path("/uploads/".$request->input('oldimage')));  
                 }
              }

            DB::table('banner')->where('id', $id)->update(['title'=>$title ]);

           if($maintitle!=''){
   
              DB::table('more_maintitle')->insert(['more_maintitle'=>$maintitle,'banner_id'=>$id]);

             }

            if($maintitles!=null){
            
              for($i=0; $i<count($maintitles); $i++){

                    $maintitles_info=$maintitles[$i];

                   DB::table('more_maintitle')->insert(['more_maintitle'=>$maintitles_info,'banner_id'=>$id]);
  
                }
            }

           return redirect('admin/viewBannerlist')->with('error',' update home page banner data succcesfully!!!!');
 
          }

       public function deletehomebanner($id){

           $banner= DB::table('banner')->where('id', $id)->get();

           if($banner[0]->image!='') {

               unlink(public_path("/uploads/".$banner[0]->image));

               }

           DB::table('banner')->where('id', $id)->delete();

           DB::table('more_maintitle')->where('banner_id', $id)->delete();

           return response()->json([
            'success' => 'Record has been deleted successfully!'
           ]);

        }


        public function viewFeaturelist(){

        	  $id=Auth::id();
          $admin=Admin::where('id',$id)->get();

     
           $data['name']=$admin[0]->name;


           $features=DB::table('features')->get();
           $data['features']=$features;

           return view('admin.featureslist',$data);


        }

           public function addfeatures(){
  
        return view('admin.addfeatures');

       }

        public function storefeatures(Request $request){


        $error=$request->validate([

             'title' =>'required',
             'icon_image'=>'required',  
             'description'=>'required', 

        ]);
       
         $title=$request->input('title');
         $file=$request->file('icon_image');
         $description=$request->input('description');

     

           $imagename='';
        
           if($file){
          
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
               $file->move($destinationPath,$imagename);
       
              }

              $imagename1='';
       

         DB::table('features')->insert(['title'=>$title,'icon_image'=>$imagename,'description'=>$description]);
       
          return redirect('admin/viewFeaturelist')->with('error','your features has been inserted sucessfully' );
          
    }


     public function deletefeatures($id){


     	   $features=DB::table('features')->where('id', $id)->get();

           if($features[0]->icon_image!='') {

               unlink(public_path("/uploads/".$features[0]->icon_image));

               }

      
        DB::table('features')->where('id', $id)->delete();

      return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);

    }

      public function updatefeatures($id){

    

      $features= DB::table('features')->where('id', $id)->get();
       
        //$work=DB::table('work')->where('id',$id)->get();
        $data['id']=$features[0]->id;
        $data['title']=$features[0]->title;
        $data['icon_image']=$features[0]->icon_image;
        $data['description']=$features[0]->description;
       
        return view('admin.updatefeatures',$data);

       
       }

  public function storeupdatefeatures(Request $request,$id){


     $error=$request->validate([

            'title' => 'required', 
            'description' => 'required',
           
           
        ]);
       
         $title=$request->input('title');
         $file=$request->file('icon_image');
         $description=$request->input('description');


             $imagename='';

            if($file){
         
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
               $file->move($destinationPath,$imagename);

               DB::table('features')->where('id', $id)->update(['icon_image'=>$imagename]);

              if($request->input('oldimage')!='') {

                    unlink(public_path("/uploads/".$request->input('oldimage')));  
                 }
              }

    
 
          DB::table('features')->where('id', $id)->update(['title'=>$title,'description'=>$description]);

           return redirect('admin/viewFeaturelist')->with('error','your features has been updated sucessfully' );

    }

         public function home_about_us(){


        	  $id=Auth::id();
             $admin=Admin::where('id',$id)->get();


            $data['name']=$admin[0]->name;

             $home_aboutus=DB::table('home_aboutus')->get();
             $data['home_aboutus']=$home_aboutus;

             $home_aboutus_image=DB::table('home_aboutus_image')->get();
             $data['home_aboutus_image']=$home_aboutus_image;
         
    	   return view('admin.home_about_us',$data);
       }

        public function update_home_about_us($id){

             $home_aboutus=DB::table('home_aboutus')->get();
             $data['id']=$home_aboutus[0]->id;
             $data['title']=$home_aboutus[0]->title;
             $data['description']=$home_aboutus[0]->description;

             $home_aboutus_image=DB::table('home_aboutus_image')->get();
             $data['home_aboutus_image']=$home_aboutus_image;
         
    	   return view('admin.update_home_aboutus',$data);
       }

       public function update_home_about_us_image($id){

          $home_aboutus_image=DB::table('home_aboutus_image')->where('id',$id)->get();
          $data['image']=$home_aboutus_image[0]->image;

          $data['id']=$id;

          return view('admin.update_home_aboutus_img',$data);

       }

         public function store_home_about_image(Request $request,$id){

          $home_aboutus_image=DB::table('home_aboutus_image')->where('id',$id)->get();
          $home_aboutus_id=$home_aboutus_image[0]->home_aboutus_id;


           $file=$request->file('image');


         
            $imagename='';

            if($file){
         
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
                
                echo $imagename;

          

               $file->move($destinationPath,$imagename);

               DB::table('home_aboutus_image')->where('id', $id)->update(['image'=>$imagename]);

              if($request->input('oldimage')!='') {

                    unlink(public_path("/uploads/".$request->input('oldimage')));  
                 }
              }


              return redirect('admin/update_home_about_us/'.$home_aboutus_id);
         


       }

       public function store_home_aboutus(Request $request, $id){


       	  $error=$request->validate([

              'title' => 'required',
              'description' => 'required',
               
            ]);

       	   $title=$request->input('title');
       
         $description=$request->input('description');
        

         DB::table('home_aboutus')->where('id',$id)->update(['title'=>$title,'description'=>$description]);
       
          return redirect('admin/home_about_us')->with('error',' Home about us data has been updated sucessfully !!' );
          

       }

       public function key_features(){


       	    $id=Auth::id();
             $admin=Admin::where('id',$id)->get();


            $data['name']=$admin[0]->name;

             $key_feature=DB::table('key_feature')->get();
             $data['key_feature']=$key_feature;

             $features_description=DB::table('features_description')->get();
             $data['features_description']=$features_description;


        return view('admin.key_features',$data);

       }

       public function update_key_features($id){



             $key_feature=DB::table('key_feature')->where('id',$id)->get();
             $data['title']=$key_feature[0]->title;
              $data['id']=$key_feature[0]->id;

             $features_description=DB::table('features_description')->get();
             $data['features_description']=$features_description;

              return view('admin.update_key_features',$data);

       }

      

       public function  delete_description($id){

     	 $features_description=DB::table('features_description')->where('id', $id)->get();
         $key_features_id=$features_description[0]->key_features_id;

         DB::table('features_description')->where('id',$id)->delete();

         return redirect('admin/update_key_features/'.$key_features_id);

       }

      
         public function  store_key_features(Request $request ,$id){

           $error=$request->validate([

             'title' => 'required',
               
           ]);
       
           $title=$request->input('title');
          
           $description=$request->input('description');
           $descriptions=$request->input('descriptions') ;
  
           

            DB::table('key_feature')->where('id', $id)->update(['title'=>$title ]);

           if($description!=''){
   
              DB::table('features_description')->insert(['description'=>$description,'key_features_id'=>$id]);

             }

            if($descriptions!=null){
            
              for($i=0; $i<count($descriptions); $i++){

                    $descriptions_info=$descriptions[$i];

                   DB::table('features_description')->insert(['description'=>$descriptions_info,'key_features_id'=>$id]);
  
                }
            }

           return redirect('admin/key_features')->with('error',' update key Features data succcesfully!!!!');
 
          }



        public function view_skillset()
        
         {
          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

          $skillsetdata=DB::table('skillset')->get();
          $data['skillsetdata']=$skillsetdata;

          return view('admin.ourskillset',$data);
         }



          public function add_new_skillset()
         {
           return view('admin.addskillset');
         }

         public function store_skillset(Request $request)
         {
           $error=$request->validate([

               'image'=>'required',
               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);
       
           }
           DB::table('skillset')->insert(['title'=>$title,'description'=>$description,'image'=>$imagename]);

           return redirect('admin/view_skillset')->with('error','Our skillset data inserted successfully!!!');

         }

         public function delete_skillset($id)
         {
          $list=DB::table('skillset')->where('id',$id)->get();
          $image=$list[0]->image;

          if($image!='')
          {
               unlink(public_path('/uploads/'.$image));
          }

          DB::table('skillset')->where('id',$id)->delete();

          return response()->json(['success'=>'Skillset data deleted successfully!!!']);
         }

         public function update_skillset($id)
         {
           $list=DB::table('skillset')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['title']=$list[0]->title;
           $data['image']=$list[0]->image;
           $data['description']=$list[0]->description;
           
           return view('admin.updateskillset',$data);
         }

         public function store_update_skillset(Request $request,$id)
         {
           $error=$request->validate([

               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $oldimage=$request->input('oldimage');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);

               DB::table('skillset')->where('id',$id)->update(['image'=>$imagename]);

               if($oldimage!='')
                {
                  unlink(public_path('/uploads/'.$oldimage));
                }
       
           }
           DB::table('skillset')->where('id',$id)->update(['title'=>$title,'description'=>$description]);

           return redirect('admin/view_skillset')->with('error','Our skillset data updated successfully!!!');

         }

     






          public function achieve_target(){


          	  $id=Auth::id();
             $admin=Admin::where('id',$id)->get();


            $data['name']=$admin[0]->name;

             $achive_target=DB::table('achive_target')->get();
             $data['achive_target']=$achive_target;

        return view('admin.achive_target',$data);



          }

          

             public function add_achieve_target(){

           return view('admin.add_achieve_target');
 
         }

        public function store_achieve_target(Request $request){

            $error=$request->validate([

              'title' => 'required',
              'value' => 'required',
               
            ]);
       
           $title=$request->input('title');
       
           $value=$request->input('value');
       
     
           DB::table('achive_target')->insert(['title'=>$title ,'value'=>$value]);

           return redirect('admin/achieve_target')->with('error','Achieve target data inserted succcesfully!!!!');

         }

         public function delete_achieve_target($id){


    
        DB::table('achive_target')->where('id', $id)->delete();

       return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);


         }

          public function update_achieve_target($id){

           $achive_target=DB::table('achive_target')->where('id',$id)->get();

             $data['title']=$achive_target[0]->title;
              $data['value']=$achive_target[0]->value;
               $data['id']=$achive_target[0]->id;

          
              return view('admin.update_achieve_target',$data);

       }

           public function store_update_achieve_target(Request $request,$id){

            $error=$request->validate([

              'title' => 'required',
              'value' => 'required',
               
            ]);
       
           $title=$request->input('title');
       
           $value=$request->input('value');
       
     
           DB::table('achive_target')->where('id',$id)->update(['title'=>$title ,'value'=>$value]);

           return redirect('admin/achieve_target')->with('error','Achieve target data updated succcesfully!!!!');

         }


         public function investment_process(){

          $id=Auth::id();
          $admin=Admin::where('id',$id)->get();

          $data['name']=$admin[0]->name;
         	
          $invesment_process=DB::table('invesment_process')->get();
          $data['invesment_process']=$invesment_process;


          $invesment_process_step=DB::table('invesment_process_step')->get();
          $data['invesment_process_step']=$invesment_process_step;


         	return view('admin.investment_process',$data);
         }

         public function update_investment_process($id){


          $invesment_process=DB::table('invesment_process')->where('id',$id)->get();
          $data['id']=$invesment_process[0]->id;
          $data['title']=$invesment_process[0]->title;
          $data['image']=$invesment_process[0]->image;

           return view('admin.update_invesment_process',$data);



         }

         public function store_investment_process(Request $request,$id){


             $error=$request->validate([

             'title' => 'required',
               
           ]);
       
           $title=$request->input('title');
           $file=$request->file('image');


           $imagename='';

            if($file){
         
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
               $file->move($destinationPath,$imagename);

               DB::table('invesment_process')->where('id', $id)->update(['image'=>$imagename]);

              if($request->input('oldimage')!= null) {

                    unlink(public_path("/uploads/".$request->input('oldimage')));  
                 }
              }

            DB::table('invesment_process')->where('id', $id)->update(['title'=>$title ]);

         

           return redirect('admin/investment_process')->with('error',' update Invesment process data succcesfully!!!!');


         }

        public function add_investment_process(){

           return view('admin.add_invesment_process_step');
 
         }

        public function store_investment_process_step(Request $request){

            $error=$request->validate([

              'title' => 'required',
              'description' => 'required',
               
            ]);
       
           $title=$request->input('title');
       
           $description=$request->input('description');
       
     
           DB::table('invesment_process_step')->insert(['title'=>$title ,'description'=>$description]);

           return redirect('admin/investment_process')->with('error','Invesment process step data inserted succcesfully!!!!');

         }

         public function delete_process_step($id){

          DB::table('invesment_process_step')->where('id', $id)->delete();

          return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);


         }

         public function update_process_step($id){

          $invesment_process_step=DB::table('invesment_process_step')->where('id',$id)->get();
          $data['title']=$invesment_process_step[0]->title;
            $data['id']=$invesment_process_step[0]->id;
          $data['description']=$invesment_process_step[0]->description;


          return view('admin.update_process_step',$data);


         }

          public function store_update_process_step(Request $request,$id){

            $error=$request->validate([

              'title' => 'required',
              'description' => 'required',
               
            ]);
       
           $title=$request->input('title');
       
           $description=$request->input('description');
       
           DB::table('invesment_process_step')->where('id',$id)->update(['title'=>$title ,'description'=>$description]);

           return redirect('admin/investment_process')->with('error','Invesment process step data updated succcesfully!!!!');

         }



}
