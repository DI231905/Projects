<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\User;
use Carbon\carbon;
use DB;
use Hash;
use \Crypt;
use Illuminate\support\facades\Auth;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class Admincontroller extends Controller{


   public function __construct(){

                $this->middleware('auth:admin');
        }

   public function home(){
 
       $admin=Auth::guard('admin')->user();

       
          $data['admin']=$admin;

         $data['site_url']= env('APP_URl');
         $data['metatitle']='home page';

         $id=Auth::id();
         $admin=Admin::where('id',$id)->get();

         $data['name']=$admin[0]->name;

         $data['user']=User::count();

         $data['inquiry']=DB::table('inquiry')->count();

          $data['blog']=DB::table('blog')->count();
       

         return view('admin.home',$data);
      
     } 

      

     /*----------- change password ---------------*/

      public function changepassword(){
       
         return view('admin.changepassword');
     }

      public function updatepassword(Request $request,$id){

          $error=$request->validate([
              'oldpassword' => 'required|string',
              'newpassword' => 'required|string|min:6',
           
              ]);

             $oldpassword=$request->input('oldpassword');
             $newpassword=$request->input('newpassword');

             $password=DB::table('admins')->where('id', $id)->get();

             $password1=$password[0]->password;

           if(Hash::check($oldpassword,$password1)){

               DB::table('admins')->where('id', $id)->update(['password'=>Hash::make($newpassword)]);

               return redirect('admin/home')->with('error','your password has been update sucessfully' );

               }else{

                return Redirect::back()->with('error','Your Old password is not correct!!!!');

            }
         }



         public function footer_data_list(){

                 $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;


           $footer_data=DB::table('footer_data')->get();
           $data['footer_data']=$footer_data;

       
           return view('admin.footeraboutlist',$data);

          }


        public function update_footer_data($id){

         $footer_data=DB::table('footer_data')->where('id',$id)->get();
         $data['image']=$footer_data[0]->image;
         $data['title']=$footer_data[0]->title;
         $data['id']=$footer_data[0]->id;
         $data['description']=$footer_data[0]->description;
                

          return view('admin.update_footer_about',$data);

          }

          public function delete_footer_data($id){

             DB::table('footer_tag')->where('id',$id)->delete();

             return response()->json([
                'success' => 'Record has been deleted successfully!'
             ]);


          }

          public function store_update_footer_data(Request $request, $id){

              $request->validate([

                   'title' => 'required',
                   'description' => 'required',
           
              ]);

              $title=$request->input('title');
              $description=$request->input('description');

              $file=$request->file('image');
  
              $imagename='';

              if($file){
         
                    $destinationPath='uploads';
                    $imagename=time().'_'.$file->getClientOriginalName();
                    $file->move($destinationPath,$imagename);
     
                   DB::table('footer_data')->where('id', $id)->update(['image'=>$imagename]);

               if($request->input('oldimage')!='') {

                     unlink(public_path("/uploads/".$request->input('oldimage')));  
                  }
               }

            

            DB::table('footer_data')->where('id', $id)->update(['title'=>$title,'description'=>$description]);
 
           return redirect('admin/footer_data_list')->with('error','Footer data updated sucessfully!');


           }

              public function admincontactview()
         {
            $id=Auth::id();

            $admin=Admin::where('id',$id)->get();
            $data['name']=$admin[0]->name;

            $admindata=DB::table('admininfo')->get();
            $data['admindata']=$admindata;

            return view('admin.admincontactview',$data);
         }
         public function updateadmincontact($id)
         {
           $list=DB::table('admininfo')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['name']=$list[0]->name;
           $data['email']=$list[0]->email;
           $data['phone']=$list[0]->phone;
           $data['address']=$list[0]->address;
           $data['facebook']=$list[0]->facebook;
           $data['instagram']=$list[0]->instagram;
           $data['twitter']=$list[0]->twitter;
           $data['linkedin']=$list[0]->linkedin;
           return view('admin.updateadmincontact',$data);
         }
         public function storeadmincontact(Request $request,$id)
         {

           $error=$request->validate([
             
              'name' => 'required',
              'email' => 'required',
              'phone' => 'required',
              'address' => 'required',
              
              
              ]);
            

            $name=$request->input('name');
            $email=$request->input('email');
            $phone=$request->input('phone');
            $address=$request->input('address');
            $facebook=$request->input('facebook');
            $instagram=$request->input('instagram');
            $twitter=$request->input('twitter');
            $linkedin=$request->input('linkedin');

            DB::table('admininfo')->where('id',$id)->update(['name'=>$name,'email'=>$email,'phone'=>$phone,'address'=>$address,'facebook'=>$facebook,'instagram'=>$instagram,'twitter'=>$twitter,'linkedin'=>$linkedin]);

            return redirect('admin/admincontactview')->with('error','Admin Contact Info Updated Successfully!!!');

         }

          public function view_get_started(){

           $inquiry=DB::table('inquiry')->get();
           $data['inquiry']=$inquiry;

            $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

            return view('admin.get_started_data', $data);


         }

          public function delete_get_started($id){

           DB::table('inquiry')->where('id',$id)->delete();
         
          
          return response()->json(['success'=>'Why choose us data deleted successfully!!!']);

         }

         public function viewloginpage()
         {
          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

          $loginpagedata=DB::table('loginpage')->get();
          $data['loginpagedata']=$loginpagedata;

          return view('admin.loginpage',$data);
         }

         
         public function deleteloginpage($id)
         {
          $list=DB::table('loginpage')->where('id',$id)->get();
          $image=$list[0]->image;

          if($image!='')
          {
               unlink(public_path('/uploads/'.$image));
          }

          DB::table('loginpage')->where('id',$id)->delete();

          return response()->json(['success'=>'loginpage data deleted successfully!!!']);
         }

         public function updateloginpage($id)
         {
           $list=DB::table('loginpage')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['title']=$list[0]->title;
           $data['image']=$list[0]->image;
           $data['description']=$list[0]->description;
           
           return view('admin.updateloginpage',$data);
         }

         public function storeupdateloginpage(Request $request,$id)
         {
           $error=$request->validate([

               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $oldimage=$request->input('oldimage');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);

               DB::table('loginpage')->where('id',$id)->update(['image'=>$imagename]);

               if($oldimage!='')
                {
                  unlink(public_path('/uploads/'.$oldimage));
                }
       
           }
           DB::table('loginpage')->where('id',$id)->update(['title'=>$title,'description'=>$description]);

           return redirect('admin/viewloginpage')->with('error','Loginpage data updated successfully!!!');

         }

         public function userlist(){

          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;


            $user=User::get();
            $data['user']=$user;

       
              return view('admin.userlist',$data);
         }

         public function viewbrochure()
         {
          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

          $brochuredata=DB::table('brochure')->get();
          $data['brochuredata']=$brochuredata;

          return view('admin.brochure',$data);
         }

         public function addbrochure()
         {
          return view('admin.addbrochure');
         }

         public function storebrochure(Request $request)
         {
          $error=$request->validate([

               'image'=>'required',
               
           ]);

          
           $image=$request->file('image');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);
       
           }
           DB::table('brochure')->insert(['image'=>$imagename]);

           return redirect('admin/viewbrochure')->with('error','Brochure data inserted successfully!!!');

         }

         public function updatebrochure($id)
         {
           $list=DB::table('brochure')->where('id',$id)->get();
           $data['id']=$list[0]->id; 
           $data['image']=$list[0]->image;
           return view('admin.updatebrochure',$data);
         }

         public function storeupdatebrochure(Request $request,$id)
         {

           $image=$request->file('image');
           $oldimage=$request->input('oldimage');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);

               DB::table('brochure')->where('id',$id)->update(['image'=>$imagename]);

               if($oldimage!='')
                {
                  unlink(public_path('/uploads/'.$oldimage));
                }
       
           }

           return redirect('admin/viewbrochure')->with('error','Brochure data updated successfully!!!');

         }

         public function deletebrochure($id)
         {
          $list=DB::table('brochure')->where('id',$id)->get();
          $image=$list[0]->image;

          if($image!='')
          {
               unlink(public_path('/uploads/'.$image));
          }

          DB::table('brochure')->where('id',$id)->delete();

          return response()->json(['success'=>'Brochure data deleted successfully!!!']);
         }
         
           public function delete_user($id)
         {
       
          DB::table('users')->where('id',$id)->delete();

          return response()->json(['success'=>'user data deleted successfully!!!']);
         }
         
         
             public function teamview()
          {
          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

          $team=DB::table('team')->get();
          $data['team']=$team;

          return view('admin.teamlist',$data);
         }



          public function addteam()
         {
          return view('admin.addteam');
         }

         public function storeteam(Request $request)
         {
          $error=$request->validate([

               'image'=>'required',
               'name'=>'required',
               'description'=>'required',
               'occupation'=>'required'

           ]);

           $name=$request->input('name');
           $description=$request->input('description');

           $occupation=$request->input('occupation');
        

           $image=$request->file('image');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);
       
           }
           DB::table('team')->insert(['name'=>$name,'description'=>$description,'image'=>$imagename,'occupation'=>$occupation]);

           return redirect('admin/teamview')->with('error','Team data inserted successfully!!!');

         }

         public function deleteteam($id)
         {
          $list=DB::table('team')->where('id',$id)->get();
          $image=$list[0]->image;

          if($image!='')
          {
               unlink(public_path('/uploads/'.$image));
          }

          DB::table('team')->where('id',$id)->delete();

          return response()->json(['success'=>'Blog data deleted successfully!!!']);
         }

         public function updateteam($id)
         {
           $list=DB::table('team')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['name']=$list[0]->name;
           $data['image']=$list[0]->image;
           $data['occupation']=$list[0]->occupation;
           $data['description']=$list[0]->description;
           
           return view('admin.updateteam',$data);
         }

         public function storeupdateteam(Request $request,$id)
         {
           $error=$request->validate([

               'name'=>'required',
               'occupation'=>'required',
               'description'=>'required'

           ]);

           $name=$request->input('name');
           $occupation=$request->input('occupation');
           $description=$request->input('description');
           $image=$request->file('image');
           $oldimage=$request->input('oldimage');
           $imagename='';

      

           if($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);

               DB::table('team')->where('id',$id)->update(['image'=>$imagename]);

               if($oldimage!='')
                {
                  unlink(public_path('/uploads/'.$oldimage));
                }
       
            }
           DB::table('team')->where('id',$id)->update(['name'=>$name,'description'=>$description,'occupation'=>$occupation]);

           return redirect('admin/teamview')->with('error','Team member data updated successfully!!!');

         }



         
         




        
    }
   

  




