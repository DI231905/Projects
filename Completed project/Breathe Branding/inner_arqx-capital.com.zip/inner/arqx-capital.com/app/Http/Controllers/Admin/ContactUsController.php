<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;

class ContactUsController extends Controller
{


       public function __construct(){

                $this->middleware('auth:admin');
        }

    public function ContactusBannerlist(){

           $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $allbanner=DB::table('banner_image')->get();
           $data['allbanner']=$allbanner;
         

             return view('admin.ContactusBannerlist',$data);
 
         }

           public function view_contact_us_msg(){

           $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $get_in_touch=DB::table('get_in_touch')->get();
           $data['get_in_touch']=$get_in_touch;
         

             return view('admin.get_in_touch',$data);
 
         }

             public function delete_contact_us($id){

           DB::table('get_in_touch')->where('id',$id)->delete();
         
          
          return response()->json(['success'=>'data deleted successfully!!!']);

         }

        public function view_contact_desc()
         {
            $id=Auth::id();

            $admin=Admin::where('id',$id)->get();
            $data['name']=$admin[0]->name;

            $contact_us_desc=DB::table('contact_us_desc')->get();
            $data['contact_us_desc']=$contact_us_desc;

            return view('admin.contact_us_desc',$data);
         }
         public function update_contact_desc($id)
         {
           $list=DB::table('contact_us_desc')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['title']=$list[0]->title;
           $data['description']=$list[0]->description;
          
           return view('admin.update_contact_us_desc',$data);
         }
         public function storeupdate_contact_desc(Request $request,$id)
         {

           $error=$request->validate([
             
              'title' => 'required',
              'description' => 'required',
             
              
              ]);
            
            $title=$request->input('title');
            $description=$request->input('description');
            
            DB::table('contact_us_desc')->where('id',$id)->update(['title'=>$title,'description'=>$description]);

            return redirect('admin/view_contact_desc')->with('error','Contact us description Info Updated Successfully!!!');

         }




         

         
}
