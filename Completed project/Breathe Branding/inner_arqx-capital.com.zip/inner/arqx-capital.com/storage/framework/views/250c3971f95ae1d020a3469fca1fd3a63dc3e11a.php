

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">GET IN TOUCH</h4>
                       
                    </div>
                    <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                  
                                    <th>Email</th>
                                    <th>Mobile Number</th>   
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $news_letter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="letter_<?php echo e($f->id); ?>">
                                    
                                     <td>
                                      <?php echo e($f->email); ?>

                                    </td>
                                   
                                    <td>
                                    <?php echo e($f->number); ?>

                                    </td>
                                 
                                    <td>
                                 <button class="btn3 btn0" onclick="deleteletter(<?php echo e($f->id); ?>)"><i class="fal fa-trash-alt"></i></button>
                                 </td>
                                          
                                  
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>
                 <script type="text/javascript">
                   

  function deleteletter($id){
    // alert('i am here');

     if(confirm("do you want delete this data ?")){
             $.ajax({

                url:'delete_get_in_touch/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.letter_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
       

                 </script>
                 

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/admin/news_letterdata.blade.php ENDPATH**/ ?>