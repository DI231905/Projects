

<?php $__env->startSection('content'); ?>



            <div class="row new_1">

            	   <div class="col-lg-3 col-6">
                  <div class="small-box bg-warning">
                    <div class="inner">
                      <h3><?php echo e($user); ?></h3>
                      <p>User Registrations</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-user-plus"></i>
                    </div>
                    <a href="<?php echo e(url('admin/userlist')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <div class="col-lg-3 col-6">
                  <div class="small-box bg-info">
                    <div class="inner">
                      <h3><?php echo e($inquiry); ?></h3>
                      <p>Inquiries</p>
                    </div>
                    <div class="icon">
                     <i class="fas fa-info-square"></i>
                    </div>
                    <a href="<?php echo e(url('admin/view_get_started')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <div class="col-lg-3 col-6">
                  <div class="small-box bg-success">
                    <div class="inner">
                      <h3><?php echo e($blog); ?></h3>
                      <p>Blogs</p>
                    </div>
                    <div class="icon">
                    <i class="fab fa-blogger"></i>
                    </div>
                    <a href="<?php echo e(url('admin/viewblog')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
             
                <div class="col-lg-3 col-6">
                  <div class="small-box bg-danger">
                    <div class="inner">
                      <h3>1</h3>
                      <p>Brochure</p>
                    </div>
                    <div class="icon">
                     <i class="far fa-file-alt"></i>
                    </div>
                    <a href="<?php echo e(url('admin/viewbrochure')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
            </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ARQX\resources\views/admin/home.blade.php ENDPATH**/ ?>