

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4">Team</h4>
                  <button class="btn1"><a href="<?php echo e(url('admin/addteam')); ?>" style="color:black;">ADD</a></button>
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>  
                                    <th>Name</th>  
                                    <th>Occupation</th>  
                                    <th>Description</th>  
                                    <th>Update</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                        
                             <tbody>
                               <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="team_<?php echo e($s->id); ?>">
                                  
                                <td><img src="/uploads/<?php echo e($s->image); ?>" style="height: 120px;width: 120px"> <br><?php echo e($s->image); ?></td>

                                 <td><?php echo e($s->name); ?></td>

                                  <td><?php echo e($s->occupation); ?></td>

                                   <td><?php echo $s->description; ?></td>
                                  
                                 <td>
                                <button class="btn0 btn2"><a href="<?php echo e(url('admin/updateteam')); ?>/<?php echo e($s->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              </td>
                             <td>
                                <button class="btn3 btn0" onclick="deletebroch(<?php echo e($s->id); ?>)"><i class="fal fa-trash-alt"></i></a></button>
                              </td> 
                            
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">



           $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
        
         function deletebroch($id){

     if(confirm("do you want delete this data ?")){
             $.ajax({

                url:'deleteteam/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.team_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
      </script>

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arqxca5/arqx-capital.com/resources/views/admin/teamlist.blade.php ENDPATH**/ ?>