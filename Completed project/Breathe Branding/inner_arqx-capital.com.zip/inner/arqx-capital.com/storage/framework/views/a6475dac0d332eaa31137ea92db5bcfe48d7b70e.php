

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">



 <div class="mt-5">
                   
                   <h4 class="mb-4">INVESTMENT PROCESS SECTION </h4>
                    
                    <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Title</th> 
                                   
                                    <th>Image</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $invesment_process; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                             <tbody>
                             
                               <tr>
                                    <td>
                                      <?php echo e($ip->title); ?>

                                    </td>

                                     
                                    <td>

                                       <img src="/uploads/<?php echo e($ip->image); ?>" width="120" height="100"><br>
                                       <?php echo e($ip->image); ?>  
                                         
                                    </td>
    
                                 <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/update_investment_process')); ?>/<?php echo e($ip->id); ?>">Update</a></button></td>
                                   
                                </tr>
                                
                            </tbody>
                          
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>



          <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">INVESTMENT PROCESS STEP</h4>
                        <button class="btn1"><a  style="color: black"  href="<?php echo e(url('admin/add_investment_process')); ?>">ADD</a></button>
                    </div>
                    <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Step no</th>
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $invesment_process_step; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$is): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="step_<?php echo e($is->id); ?>">

                                    <td>
                                      <?php echo e($key+1); ?>

                                    </td>
                                            
                                     <td>
                                      <?php echo e($is->title); ?>

                                    </td>
                                   
                                    <td>
                                    <?php echo e($is->description); ?>

                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/update_process_step')); ?>/<?php echo e($is->id); ?>">Update</a></button></td>
                                    <td><button class="btn3 btn0" onclick="delete_process_step(<?php echo e($is->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>
                 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                 <script type="text/javascript">
                   

  function delete_process_step($id){
    // alert('i am here');

     if(confirm("do you want delete this step ?")){
             $.ajax({

                url:'delete_process_step/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.step_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    
       

              
                 

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arqx2.ditests.com\resources\views/admin/investment_process.blade.php ENDPATH**/ ?>