


<?php $__env->startSection('content'); ?>


<div class="co-banner1">
       <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'Services'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"><img src="image/house.png"> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
        <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="co_service">
		<div class="container">
			<div class="col-xl-12">
				<div class="row service_detail align-items-center mb-5">
					<div class="col-xl-6 col-md-6 col-12">
						<h2><?php echo e($name); ?></h2>
					</div>
					<div class="col-xl-6 col-md-6 col-12 text-right">
						<button class="download"><a href="<?php echo e(url('/download')); ?>" style="color:white; text-decoration: none" >Download our Investment Brochure</a></button>
					</div>
				</div>
			</div>
			<div class="col-xl-12">
				<div class="row row1 content_1">
					<div class="col-lg-6 col-md-12 col-12 order_05">
						<div class="about-content">
							<h2><?php echo e($title); ?></h2>
							<p><?php echo $description; ?></p>
						</div>
					</div>
					<div class="col-lg-6 col-md-12 col-12 order_06">
						<div class="row inner_service1">
							<div class="col-lg-4 col-md-4 col-4 pr-2">
								<img src="uploads/<?php echo e($image1); ?>" class="mb-3 s1">
								<img src="uploads/<?php echo e($image2); ?>" class="s2">
							</div>
							<div class="col-lg-4 col-md-4 col-4 pl-2">
								<img src="uploads/<?php echo e($image3); ?>" class="s3" >
								
							</div>
							<div class="col-lg-4 col-md-4 col-4 pl-0">
								<img src="uploads/<?php echo e($image4); ?>" class="mb-3 s2">
								<img src="uploads/<?php echo e($image5); ?>" class="s1">
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>
    <div class="co_inner-about">
    	<div class="container">
    		<div class="about-service">
    			<div class="row">
    				<?php $__currentLoopData = $servicedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				<div class="col-lg-4 col-md-6 col-12 mb-4">
    					<div class="inner-about-service">
    						<img src="uploads/<?php echo e($s->image); ?>">
    						<div class="about-service-content service-content1">
    							<h2><?php echo e($s->title); ?></h2>
    							<p><?php echo $s->description; ?></p>
    						</div>
    					</div>
    				</div>

    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				
    			</div>
    		</div>
    	</div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/service.blade.php ENDPATH**/ ?>