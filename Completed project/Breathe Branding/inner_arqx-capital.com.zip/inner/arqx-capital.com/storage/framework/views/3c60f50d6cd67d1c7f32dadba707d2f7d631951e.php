

<?php $__env->startSection('content'); ?>



            <div class="row new_1">

            	   <div class="col-lg-3 col-md-3 col-6 padding_1">
                  <div class="small-box bg-warning">
                    <div class="inner">
                      <h3><?php echo e($user); ?></h3>
                      <p>User Registrations</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-user-plus"></i>
                    </div>
                    <a href="<?php echo e(url('admin/userlist')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
             <div class="col-lg-3 col-md-3 col-6 padding_1">
                  <div class="small-box bg-info">
                    <div class="inner">
                      <h3><?php echo e($inquiry); ?></h3>
                      <p>Inquiries</p>
                    </div>
                    <div class="icon">
                     <i class="fas fa-info-square"></i>
                    </div>
                    <a href="<?php echo e(url('admin/view_get_started')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <div class="col-lg-3 col-md-3 col-6 padding_1">
                  <div class="small-box bg-success">
                    <div class="inner">
                      <h3><?php echo e($blog); ?></h3>
                      <p>Blogs</p>
                    </div>
                    <div class="icon">
                    <i class="fab fa-blogger"></i>
                    </div>
                    <a href="<?php echo e(url('admin/viewblog')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
             
               <div class="col-lg-3 col-md-3 col-6 padding_1">
                  <div class="small-box bg-danger">
                    <div class="inner">
                      <h3>1</h3>
                      <p>Brochure</p>
                    </div>
                    <div class="icon">
                     <i class="far fa-file-alt"></i>
                    </div>
                    <a href="<?php echo e(url('admin/viewbrochure')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
            </div>
            
              <style>
               @media  only screen and (min-width: 1024px) and (max-width: 1260px){
                .padding_1{
                  padding-left: 0 !important;
                }
                .small-box>.inner {
                    padding: 15px;
                }
                .small-box h3, .small-box p {
                    font-size: 17px;
                }
                .small-box .icon>i {
                    font-size: 30px;
                }

              }

              @media  only screen and (min-width: 768px) and (max-width: 1023px){
                       .small-box h3, .small-box p {
                           font-size: 17px;
                           margin: 0;
                           padding-top: 11px;
                       }
                       .small-box>.inner {
                           padding: 11px;
                       }
                       .small-box .icon>i {
                           font-size: 36px;
                       }
                       .padding_1 {
                           padding-left: 0;
                       }
                       }
       
                @media  only screen and (max-width: 767px){
                    .page-content .col-lg-3.col-md-3.col-6.padding_1 {
                           height: 136px;
                       }
                       .row.new_1 {
                           margin: 0 0px;
                       }
                       .small-box>.inner {
                           padding: 12px;
                       }
                       .small-box h3, .small-box p {
                           font-size: 15px;
                           margin: 0;
                           padding-top: 10px;
                       }
                       .small-box .icon>i {
                           font-size: 26px;
                       }
                       }
                       @media  only screen and (max-width: 320px){
                         .small-box h3, .small-box p {
                           font-size: 14px;
                       }
                       .col-lg-3.col-md-3.col-6.padding_1 {
                           padding-left: 5px;
                           padding-right: 5px;
                       }
                       }
                       </style>
          

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/admin/home.blade.php ENDPATH**/ ?>