	


<?php $__env->startSection('content'); ?>



	<div class="co-banner1">

		   <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'About Us'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"><img src="image/house.png"> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
        <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="co_inner-about">
    	<div class="container">
    		<div class="inner-about-content">
    			<h2>A Reliability Hypothesis</h2>
    			<p>In the grand scheme of things, we’re a young firm. However, we have a few very seasoned principles. We’re composed of a group of people with direct operational experience in the sectors we invest in, enabling deeper insight and ultimately, higher returns for our clients. ARQX Capital executes the reliability hypothesis, aiming to be your dependable partner in navigating global markets.</p>
    		</div>
    		<div class="about-service">
    			<div class="row">

    				<?php $__currentLoopData = $benefitdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    				<div class="col-lg-4 col-md-6 col-12">
    					<div class="inner-about-service">
    						<img src="uploads/<?php echo e($b->image); ?>">
    						<div class="about-service-content">
    							<h2><?php echo e($b->title); ?></h2>
    							<p><?php echo e($b->description); ?></p>
    						</div>
    					</div>
    				</div>

    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				
    			</div>
    		</div>
    	</div>
    </div>
    <div class="co_inner-service co_why">
		<div class="container">
			<h2>Why Choose Us ?</h2>
			<div class="row">
				<?php $__currentLoopData = $whychdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-3 col-md-6 col-12">
					<div class="inner-service">
						<img src="uploads/<?php echo e($w->image); ?>">
						<h3><?php echo e($w->title); ?></h3>
						<p><?php echo e($w->description); ?></p>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>
		</div>
	</div>
	<div class="co_performance">
		<div class="container">
			<div class="row row1">
				<div class="col-lg-7 col-md-6 col-12">
					<div class="about-content">
						<h2><?php echo e($title); ?></h2>
						<!-- <p>We have best-in-class funds tuned not just for tracking the benchmark, but for beating them.</p> -->
                        <p><?php echo $description; ?></p>
					</div>
				</div>
				<div class="col-lg-5 col-md-6 col-12">
					<div class="performance-img">
						<img src="uploads/<?php echo e($image); ?>">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="co_get">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-12">
					<div class="get-in">
						<h1>get in touch with us</h1>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-12">
					<div class="get-form">

						<div class="message" id="hideDiv"> </div>

						 <div class="alert alert-danger print-error-msg" style="display:none">
                          <ul></ul>
                          </div>
						<form method="post" class="news_letter">
							 <?php echo e(csrf_field()); ?>

							<div class="row">
							    <div class="col-lg-12 col-md-12 col-12 inner-get">
                                 <div id="loading-bar-spinner" class="spinner"><div class="spinner-icon"></div></div>
							    	<div class="get_1">
							    	<input type="text" placeholder="Enter Email" name="email" id="email">
							    	 <?php if($errors->has('email')): ?> <p class="error_mes"><?php echo e($errors->first('email')); ?></p> <?php endif; ?>
							    	</div>
							    </div>
							    <div class="col-lg-12 col-md-12 col-12 inner-get">
							    	<div class="get_1 get_2">
							    		<input type="text" placeholder="Enter Phone Number" name="number" id="number">

							    		<?php if($errors->has('number')): ?> <p class="error_mes"><?php echo e($errors->first('number')); ?></p> <?php endif; ?>

							    	</div>
							    </div>

							     <div class="col-lg-12 col-md-12 col-12 inner-get">
							    	<div class="get_1 get_2">
							    		<button class="submit">Submit</button>
							    	</div>
							    </div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script type="text/javascript" src="js/home.js"></script>
    <script type="text/javascript">
        $('.counter-count').each(function () {
            $(this).prop('Counter',0).animate({
                Counter: $(this).text()
                }, {          
                //chnage count up speed here
                duration: 4000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });



        $(document).ready(function() {
          $(".submit").click(function(e){
            e.preventDefault();
         
            var _token = $("input[name='_token']").val();  
            var email = $('#email').val();
            var number = $('#number').val();
             
            $.ajax({
                url: '/storedata',
                type:'POST',
                data: {_token:_token,email:email,number:number},


                  beforeSend: function(){
                      $('#loading-bar-spinner').show();


                      $('#overlay').fadeIn()

                    

                          },
                      complete: function(){
                        $('#loading-bar-spinner').hide();

                        
                        },

                success: function(data) {
                    if($.isEmptyObject(data.error)){
                   
                         $('.message').text('data submitted sucessfully!!!!');
                          $('.message').css('color', 'white');
                           $('.message').delay(5000).fadeOut(3000); 

                          $( '.news_letter' ).each(function(){
                          this.reset();
                        });  

                           
                    }else{



                    	if(data.status==202){


                    		 $('.message').text('User is not available, Please Complete your Registration !');
                    		  $('.message').css('color', 'red');
                    		   $('.message').delay(3000).fadeOut(3000); 

                     $( '.news_letter' ).each(function(){
                          this.reset();
                        });   

                           

                    	}else{

                    		   printErrorMsg(data.error);

                         $('.alert').delay(3000).fadeOut(3000);  



                    	}



                     
                        

                    }
                }
            });
       
        }); 
       
        function printErrorMsg (msg) {
            $(".print-error-msg").find("ul").html('');
            $(".print-error-msg").css('display','block');
            $.each( msg, function( key, value ) {
                $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
            });
        }
    });




    </script>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ARQX\resources\views/about.blade.php ENDPATH**/ ?>