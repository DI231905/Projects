

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Key Features List</h4>
                 <!--  <button class="btn1"><a href="<?php echo e(url('admin/addhomebanner')); ?>" style="color:black;">ADD</a></button> -->
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    
                                   
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $key_feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="">
                                    

                                     <td>
                                      <?php echo e($k->title); ?>

                                    </td>

                                     <td>
                                      <?php $__currentLoopData = $features_description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($k->id == $fd->key_features_id): ?>
                                        <li><?php echo $fd->description; ?></li>
                                        <?php endif; ?>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>

                                   <td>

                                     <button class="btn0 btn2"><a href="<?php echo e(url('admin/update_key_features')); ?>/<?php echo e($k->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              
                                 </td>
                              
                            
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
          </div>
      </div>
           

       <?php $__env->stopSection(); ?>

         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">
        
        

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/admin/key_features.blade.php ENDPATH**/ ?>