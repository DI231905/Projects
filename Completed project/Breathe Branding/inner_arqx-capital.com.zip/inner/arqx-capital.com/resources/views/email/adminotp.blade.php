<!doctype html>
<html lang="en-US">

<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <title> </title>
    <meta name="description" content="New Account Email Template.">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <style type="text/css">
        a:hover {text-decoration: underline !important;}
    </style>
</head>
<style type="text/css">
img{
    position: absolute;
    top: 107px;
    left: 50%;
    transform: translateX(-50%);
}
</style>
<body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0">
    <!-- 100% body table -->
    <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"
        style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
        <tr>
            <td>
                <table style="background-color: #f2f3f8; max-width:670px; margin:0 auto;" width="100%" border="0"
                    align="center" cellpadding="0" cellspacing="0">
                    <tr>
                        <td style="height:80px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td style="text-align:center;">
                        </td>
                    </tr>
                    <tr>
                        <td style="height:20px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td>
                            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0"
                                style="max-width:670px; background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);">
                                <tr>
                                    <td style="height:40px;">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="padding:0px 35px 0px;">
                                        <h1 style="color:#7a7a7a; font-weight:700; margin:0;font-size:40px;padding-bottom: 10px; padding-top: 10px; font-family:'Rubik',sans-serif;"><b>PASSWORD RESET</b>
                                        </h1>

                                        <h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:24px;line-height: 1.5;margin: 20px 0 30px;font-family:'Rubik',sans-serif;">You're receiving this e-mail because you requested a password reset for your<span style="color: #140958;font-weight:700;font-size: 30px;"> ARQX Capital SA</span> account. 
                                        </h1>
                                        <p style="font-size: 20px;margin-bottom:0;">OTP for RESET PASSWORD is :<span style="font-weight:700; font-size: 26px">{{$token}}</span></p>
                                        <div class="account_btn">
                                            <button style="margin:40px 0;padding: 13px 45px;background-color: #0263f6;border: none;border-radius: 7px;"><a href="{{url('admin/resetpasswordview')}}/{{$id}}" style="font-size: 20px; color:white;text-decoration: none;">Reset My password</a></button>
                                        </div>
                                        <p style="font-size:20px;width:90%;margin: 0 auto;line-height: 1.5;">If you did not forgot your password you can safely ignore this email. </p>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height:40px;">&nbsp;</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="height:20px;">&nbsp;</td>
                    </tr>
                    <tr>
                        
                    </tr>
                    <tr>
                        <td style="height:80px;">&nbsp;</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <!--/100% body table-->
</body>

</html>