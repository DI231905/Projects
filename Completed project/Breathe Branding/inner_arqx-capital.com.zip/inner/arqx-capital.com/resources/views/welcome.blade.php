@extends('layouts.app')

@section('content')

<style type="text/css">
.banner-slider{
    margin-bottom: 0!important;
}
.banner-slider .slick-slide {
    height: auto!important;
}
.banner-section{
    position: relative;
}
</style>
<div class="co_banner">
      <div class="banner-slider">

        @foreach($banner as $b)
            <div>
                <div class="banner-section">
                    <div class="banner-img">
                        <img src="uploads/{{$b->image}}">
                    </div>
                    <div class="banner-content">
                        <h1>{{$b->title}}</h1>

                        
                     @foreach($more_maintitle as $m)

                         @if($m->banner_id == $b->id)

                        <p>{{$m->more_maintitle }}</p>

                        @endif

                        @endforeach
                        <a href="#"><span>learn more</span> <i class="fal fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            @endforeach
           <!--  <div>
                <div class="banner-section">
                    <div class="banner-img">
                        <img src="image/banner.png">
                    </div>
                    <div class="banner-content">
                        <h1>dIVERSIFIED MARKETS & ASSET CLASSES</h1>
                        <p>Investments are globally diversified to bring out maximum yield with low risk strategies</p>
                        <a href="#"><span>learn more</span> <i class="fal fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div>
                <div class="banner-section">
                    <div class="banner-img">
                        <img src="image/banner.png">
                    </div>
                    <div class="banner-content">
                        <h1>CAPITAL PROTECTION STRATEGIES</h1>
                        <p>We preserve the value you’ve created through a qualitative approach</p>
                        <a href="#"><span>learn more</span> <i class="fal fa-arrow-right"></i></a>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
    <div class="co_inner-service">
        <div class="container">
            <div class="row">

                @foreach($features as $f)
                <div class="col-lg-4 col-md-4 col-12">
                    <div class="inner-service">
                        <img src="uploads/{{$f->icon_image}}">
                        <h3>{{$f->title}}</h3>
                        <p>{{$f->description}}</p>
                    </div>
                </div>
                @endforeach
              
            </div>
        </div>
    </div>
    <div class="co_about">
        <div class="container">
            <div class="row row1">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="about-img">
                        <div class="col-lg-4 col-md-4 col-4">
                            <img src="uploads/{{$image1}}">
                        </div>
                        <div class="col-lg-4 col-md-4 col-4">
                            <img src="uploads/{{$image2}}" class="ab-1">
                            <img src="uploads/{{$image3}}" class="ab-2">
                        </div>
                        <div class="col-lg-4 col-md-4 col-4">
                            <img src="uploads/{{$image4}}">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="about-content">
                        <h2>{{$title}}</h2>
                       <!--  <p>We have best-in-class funds tuned not just for tracking the benchmark, but for beating them.</p> -->
                        <p>{!! $description !!}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_quote">
        <div class="container">
            <div class="row row1">
         @foreach($key_feature as $kf)
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="inner-quote">
                     
                        <h3>{{$kf->title}}</h3>
                      
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="quote-slider">
                    @foreach($features_description as $fd)

                        @if($kf->id==$fd->key_features_id)
                        <div><p>{{$fd->description}}</p></div>

                        @endif


                     @endforeach
                       
                    </div>
                </div>
            </div>
        @endforeach
             
        </div>
    </div>
    <div class="co_service">
        <div class="container">
            <h2 class="title">OUR SKILLSET</h2>
            <div class="row">
                @foreach($skillsetdata as $s)
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="services">
                        <div class="services-img">
                            <img src="uploads/{{$s->image}}">
                        </div>
                        <div class="services-content">
                            <h3>{{$s->title}}</h3>
                            <p>{{$s->description}}</p>
                            <a href="#">read more <i class="fal fa-long-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                @endforeach
               
            </div>
        </div>
    </div>
    <div class="co_count">
        <div class="container">
            <div class="row">
                @foreach($achive_target as $key=>$at)

                @if($key==0)

                <div class="col-lg-3 col-md-3 col-6 count">
                    <div class="count-up">
                        <p><span class="">{{$at->value}}<span></p>
                        <h3>{{$at->title}}</h3>
                    </div>
                </div>

                @else 
                <div class="col-lg-3 col-md-3 col-6 count">
                    <div class="count-up">
                        <p><span class="counter-count">{{$at->value}}<span></p>
                        <h3>{{$at->title}}</h3>
                    </div>
                </div>
                @endif

                @endforeach
               
            </div>
        </div>
    </div>
    <div class="co_invest">
        <div class="container">
            <div class="row row1">
                <div class="col-lg-6 col-md-6 col-12 order_03">
                    <div class="invest">
                        <h2>{{$title}}</h2>

                        @foreach($invesment_process_step as $key=>$ip)
                        <div class="inner_invest">
                            <div class="invest-number">
                                <h6>{{$key+1}}</h6>
                            </div>
                            <div class="invest-content">
                                <h3>{{$ip->title}}</h3>
                                <p>{{$ip->description}}</p>
                            </div>
                        </div>

                        @endforeach
                      
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12 order_04">
                    <div class="invest-img">
                        <img src="uploads/{{$image}}">
                    </div>
                    <div class="invest-bg">
                        <img src="image/invest-bg.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
      @endsection