@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">

  	  <div class="mt-5">
                       <div class="list1">
                        <h4 class="mb-4">Home Page About Us</h4>
                        
                       </div>

                     <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                  <!--   <th>Image</th>
                                    <th>Mission</th>
                                    <th>Value</th>
                                    <th>Promise</th> -->
                                    <th>Images</th>
                                </tr>
                            </thead>
                         
                             <tbody>
                              @foreach($home_aboutus as $ha)
                                <tr>
                                	 @foreach($home_aboutus_image as $hi)

                                	   @if($ha->id == $hi->home_aboutus_id)

                                        <td>
                                           <img src="/uploads/{{$hi->image}}" width="200" height="200"><br>

                                           {{$hi->image}}  
                                        </td>
                                      @endif
                                    @endforeach

                                 </tr> <br>
                                       
                                  <div class="data">
                                      <b>Title</b>
                                  </div>

                                   
                                   <div class="data">
                              
                                    {{$ha->title}}

                                  </div> <br>
                                                                      
                                   <div  class="data">
                                     <b>Description</b>
                                    </div>
                                    <div class="data">

                                    
                                       {!!$ha->description!!}
                                  
                                   </div><br>
                                   <tr>
                                   
                                    <td><button class="btn0 btn2"><a href="{{url('admin/update_home_about_us')}}/{{$ha->id}}">Update</a></button></td>
                                  </tr>
                                
                            </tbody>
                            @endforeach
                          
                        </table>
                    </div>

                  </div>

  </div>

   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(3000); }, 3000)

             });


     
        
        
        
      
      </script>

  <style type="text/css">
  	.data{

  		margin-left: 25px;
  	}

  </style>
  @endsection