@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">



 <div class="mt-5">
                   
                   <h4 class="mb-4">INVESTMENT PROCESS SECTION </h4>
                    
                    <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Title</th> 
                                   
                                    <th>Image</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                           @foreach($invesment_process as $ip)
                           
                             <tbody>
                             
                               <tr>
                                    <td>
                                      {{$ip->title}}
                                    </td>

                                     
                                    <td>

                                       <img src="/uploads/{{$ip->image}}" width="120" height="100"><br>
                                       {{$ip->image}}  
                                         
                                    </td>
    
                                 <td><button class="btn0 btn2"><a href="{{url('admin/update_investment_process')}}/{{$ip->id}}"><i class="fal fa-pencil"></i></a></button></td>
                                   
                                </tr>
                                
                            </tbody>
                          
                            @endforeach
                           
                        </table>
                    </div>
                 </div>



          <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">INVESTMENT PROCESS STEP</h4>
                        <button class="btn1"><a  style="color: black"  href="{{url('admin/add_investment_process')}}">ADD</a></button>
                    </div>
                    <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Step no</th>
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           @foreach($invesment_process_step as $key=>$is)
                             <tbody>
                             
                               <tr class="step_{{$is->id}}">

                                    <td>
                                      {{$key+1}}
                                    </td>
                                            
                                     <td>
                                      {{$is->title}}
                                    </td>
                                   
                                    <td>
                                    {{ $is->description }}
                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="{{url('admin/update_process_step')}}/{{$is->id}}"><i class="fal fa-pencil"></i></a></button></td>
                                    <td><button class="btn0 btn3" onclick="delete_process_step({{$is->id}})"><i class="fal fa-trash-alt" aria-hidden="true"></button></td>
                                </tr>
                                
                            </tbody>
                            @endforeach
                           
                        </table>
                    </div>
                 </div>
                 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                 <script type="text/javascript">
                   

  function delete_process_step($id){
    // alert('i am here');

     if(confirm("do you want delete this step ?")){
             $.ajax({

                url:'delete_process_step/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.step_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    
       

              
                 

       @endsection