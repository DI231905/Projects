@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Key Features List</h4>
                 <!--  <button class="btn1"><a href="{{url('admin/addhomebanner')}}" style="color:black;">ADD</a></button> -->
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    
                                   
                                </tr>
                            </thead>
                           @foreach($key_feature as $k)
                             <tbody>
                             
                               <tr class="">
                                    

                                     <td>
                                      {{$k->title }}
                                    </td>

                                     <td>
                                      @foreach( $features_description as $fd)
                                        @if($k->id == $fd->key_features_id)
                                        <li>{!!$fd->description!!}</li>
                                        @endif
                                     @endforeach
                                    </td>

                                   <td>

                                     <button class="btn0 btn2"><a href="{{url('admin/update_key_features')}}/{{$k->id}}"><i class="fal fa-pencil"></i></a></button>
                              
                                 </td>
                              
                            
                                </tr>
                                
                            </tbody>
                            @endforeach
                           
                        </table>
                    </div>
          </div>
      </div>
           

       @endsection

         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">
        
        

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    