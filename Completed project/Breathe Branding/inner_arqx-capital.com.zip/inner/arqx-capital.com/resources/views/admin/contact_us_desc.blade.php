@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4">Contact Us Page Description</h4>
                  
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            
                             <tbody>
                               @foreach($contact_us_desc as $a)
                               
                                  <tr><br>
                                    <div class="data">
                                      <b>Title</b>
                                  </div>

                                    </tr>
                                    <tr>

                                       <div class="data">
                                     {{$a->title}}
                                    </div><br>



                  

                                    </tr>

                                    <tr><br>
                                      
                                      <div class="data">
                                      <b>Description</b>
                                  </div>

                                    </tr>
                                    <tr>

                                     <div class="data">
                                     {!!$a->description!!}
                                    </div><br>
                                      

                                    </tr>
                                  
                                   

                                   
     
                                <tr>

                                <button class="btn0 btn2"><a href="{{url('admin/update_contact_desc')}}/{{$a->id}}">Update</a></button>
                              </tr>
                            
                            
                               
                                @endforeach 
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>

        <style type="text/css">
    .data{

      margin-left: 25px;
    }
</style>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">
        
       


       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>


       @endsection