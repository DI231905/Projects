@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Our Performance</h4>
                  
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                          
                              
                             <tbody>
                               @foreach($perfdata as $s)
                               <tr><br>

                               <h5 class="data">Image</h5>

                               </tr>

                               <tr>
                                
                                <img class="data" src="/uploads/{{$s->image}}" height="250px" width="400px">
                                <br/>

                                 <div class="data">

                                    
                                     {{$s->image}}
                                  
                                   </div>

                               </tr><br>

                                <tr>

                                  <h5 class="data"> Title </h5>

                               

                               </tr>
                               <tr> 

                                  <div class="data">

                                    
                                    {{$s->title}}
                                  
                                   </div>
                                   
                               </tr>
                               <tr><br>

                               <h5 class="data">Description</h5>
                                
                               </tr>
                               <tr>

                                  <div class="data">

                                    
                                     {!!$s->description!!}
                                  
                                   </div>
                                   
                                 
                                  
                               </tr>
                                  
                                   
                  
                                   
                                 <tr class="data">
                                <button class="btn0 btn2"><a href="{{url('admin/update_performance')}}/{{$s->id}}">Update</a></button>
                            
                      
                                </tr>
                                @endforeach 
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>

       <style type="text/css">
    .data{

      margin-left: 25px;
    }

  </style>
    
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(3000); }, 3000)

             });


     
        
        
        
      
      </script>

       @endsection