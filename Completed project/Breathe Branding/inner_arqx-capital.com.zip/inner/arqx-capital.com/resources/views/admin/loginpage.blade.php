@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4"> Login- Registration Page</h4>
                  
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>   
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                        
                             <tbody>
                               @foreach($loginpagedata as $s)
                               <tr class="sk_{{$s->id}}">
                                  
                                    <td><img src="/uploads/{{$s->image}}" height="100px" width="100px">
                                      <br/>{{$s->image}}</td>

                                    <td>{{$s->title}}</td>

                                    <td>{{$s->description}}</td> 

                                    
                                   
                             <td>
                                <button class="btn0 btn2"><a href="{{url('admin/updateloginpage')}}/{{$s->id}}"><i class="fal fa-pencil"></i></a></button>
                              </td>
                             
                            
                                </tr>
                                @endforeach 
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>
       <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
      <script type="text/javascript">


         $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
 
      </script>


       @endsection