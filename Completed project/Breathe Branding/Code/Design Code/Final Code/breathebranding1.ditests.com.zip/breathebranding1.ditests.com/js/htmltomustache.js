/*----------- Header Section -------------------*/
    var header = {
        "logo": "logo-1.png",
        "logo-link": "index.html",
        "search": "search product here",
        "search-btn": "search",
        "userimg": "user.png",
        "login": [{
                "menulink": "BB_signup.html",
                "menu": "register"
            },
            {
                "menulink": "BB_login.html",
                "menu": "login"
            },
            {
                "menulink": "BB_wishlist.html",
                "menu": "wish list (0)"
            },
            {
                "menulink": "BB_cart.html",
                "menu": "shopping cart"
            },
            {
                "menulink": "BB_checkout.html",
                "menu": "checkout"
            }

        ],
        "language-title": "language",
        "language": [{
                "lan-img": "en-gb.png",
                "lan-title": "english"
            },
            {
                "lan-img": "ar.png",
                "lan-title": "Arabic"
            }
        ],
        "currency-title": "currency",
        "currency": [{
                "curr-icon": "fal fa-euro-sign"
            },
            {
                "curr-icon": "fal fa-pound-sign"
            },
            {
                "curr-icon": "fal fa-dollar-sign"
            }
        ],

        "cart-img": "shopping-cart.png",
        "cartTotal": "0.00",
        "bag": "Your Bag",
        "cart-box": "Your shopping cart is empty!",
        "menutitle": [
            {
                "menulink": "index.html",
                "menutitle": "Home"
            },
            {
                "menulink": "BB_contact.html",
                "menutitle": "contact"
            },
            {
                "menulink": "BB_blog.html",
                "menutitle": "blog"
            }
        ],
        "menu": [{
            "menulink": "#",
            "menu": "Drinkware",
            "innermenu": [{
                    "menulink": "BB_product-list.html",
                    "menu": "Sports-water bottles"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Events & Festivals"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Copper & Vacuum insulation"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "On-the-go"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Ceramics"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Glassware"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Coffee & Tea"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Gift sets & Packaging"
                }

            ]
        },
        {
            "menulink": "#",
            "menu": "Sports and Leisure",
            "innermenu": [{
                    "menulink": "BB_product-list.html",
                    "menu": "Sunglasses"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Balls"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Fitness & Sport"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Beach Balls"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Outdoor Items"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Beach Items"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Cycling accessories"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Travel Accessories"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Binoculars"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "BBQ Accessories"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Picnic Accessories"
                }
            ]
        },
        {
            "menulink": "#",
            "menu": "Home & Kitchen",
            "innermenu": [{
                    "menulink": "BB_product-list.html",
                    "menu": "Home Accessories"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Aprons"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Wine Accessories"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Chef's Knives"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Lunch Boxes"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Candles"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Kitchen Linen"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Bottle Openers & Accessories"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Kitchenware"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Cutting Boards"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Serving Sets"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Glasses & Carafes"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Clocks & Weather Stations"
                }
            ]
        },
        {
            "menulink": "#",
            "menu": "Bags",
            "innermenu": [{
                    "menulink": "BB_product-list.html",
                    "menu": "Cooler bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Travel Accessories"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Wallets & Card Wallets"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Backpacks"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Laptop & Tablet bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Shopping & Tote Bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Conference bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Messenger & Shoulder Bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Sport & Gym bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Trolleys & Suitcases"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Drawstring Bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Cotton Bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Toiletry Bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Travel bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Sailor Bags"
                },
                {
                    "menulink": "BB_product-list.html",
                    "menu": "Foldable Bags"
                }
            ]
        },
        {
            "menulink": "#",
            "menu": "Toys & Games",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Outdoor Games"
                },
                {
                    "menulink": "#",
                    "menu": "Bubble Blowers"
                },
                {
                    "menulink": "#",
                    "menu": "Indoor Games"
                },
                {
                    "menulink": "#",
                    "menu": "Colouring Sets for Kids"
                }
            ]
        },
        {
            "menulink": "#",
            "menu": "Tools & Car Accessories",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Reflective Items"
                },
                {
                    "menulink": "#",
                    "menu": "Multitools"
                },
                {
                    "menulink": "#",
                    "menu": "Safety Vests"
                },
                {
                    "menulink": "#",
                    "menu": "Car Accessories"
                },
                {
                    "menulink": "#",
                    "menu": "Pocket Knives"
                },
                {
                    "menulink": "#",
                    "menu": "Lamps"
                },
                {
                    "menulink": "#",
                    "menu": "Tool sets"
                }
            ]
        },
        {
            "menulink": "#",
            "menu": "Technology ",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Telephone & Tablet Accessories"
                },
                {
                    "menulink": "#",
                    "menu": "Gadgets"
                },
                {
                    "menulink": "#",
                    "menu": "Earbuds"
                },
                {
                    "menulink": "#",
                    "menu": "Speakers"
                },
                {
                    "menulink": "#",
                    "menu": "Headphones"
                },
                {
                    "menulink": "#",
                    "menu": "Computer Accessories"
                },
                {
                    "menulink": "#",
                    "menu": "Powerbanks"
                },
                {
                    "menulink": "#",
                    "menu": "USB Flash Drives"
                },
                {
                    "menulink": "#",
                    "menu": "USB Hubs"
                },
                {
                    "menulink": "#",
                    "menu": "Cameras"
                },
                {
                    "menulink": "#",
                    "menu": "Wireless Charging"
                },
                {
                    "menulink": "#",
                    "menu": "Smartwatches"
                },
                {
                    "menulink": "#",
                    "menu": "Virtual Reality"
                }
            ]
        },
        {
            "menulink": "#",
            "menu": "Umbrellas ",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Rain Ponchos"
                },
                {
                    "menulink": "#",
                    "menu": "Folding Umbrellas"
                },
                {
                    "menulink": "#",
                    "menu": "Standard Umbrellas"
                },
                {
                    "menulink": "#",
                    "menu": "Golf Umbrellas"
                },
                {
                    "menulink": "#",
                    "menu": "Special Umbrellas"
                },
                {
                    "menulink": "#",
                    "menu": "Storm Umbrellas"
                }

            ]
        },
        {
            "menulink": "#",
            "menu": "Popular  ",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Sunglasses"
                },
                {
                    "menulink": "#",
                    "menu": "Ballpoint Pens"
                },
                {
                    "menulink": "#",
                    "menu": "Shopping & Tote Bags"
                },
                {
                    "menulink": "#",
                    "menu": "Water Bottles"
                },
                {
                    "menulink": "#",
                    "menu": "Keychains & Keyrings"
                }
            ]
        },
        {
            "menulink": "#",
            "menu": "Health & Personal Care  ",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "First Aid Kits"
                },
                {
                    "menulink": "#",
                    "menu": "Personal Care"
                },
                {
                    "menulink": "#",
                    "menu": "Toiletry Bags"
                },
                {
                    "menulink": "#",
                    "menu": "Lip Balms"
                },
                {
                    "menulink": "#",
                    "menu": "Wellness & Manicure Sets"
                },
                {
                    "menulink": "#",
                    "menu": "Towels & Bathrobes"
                },
                {
                    "menulink": "#",
                    "menu": "Hot & Cold Packs"
                },
                {
                    "menulink": "#",
                    "menu": "Protection"
                }
            ]
        },
        {
            "menulink": "#",
            "menu": "Giveaways ",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Keychains & Keyrings"
                },
                {
                    "menulink": "#",
                    "menu": "Stress Balls"
                },
                {
                    "menulink": "#",
                    "menu": "Lanyards"
                },
                {
                    "menulink": "#",
                    "menu": "Badge Holders"
                },
                {
                    "menulink": "#",
                    "menu": "Wristbands"
                }

            ]
        },
        {
            "menulink": "#",
            "menu": "Office  ",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Business Card Holders"
                },
                {
                    "menulink": "#",
                    "menu": "Desk Accessories"
                },
                {
                    "menulink": "#",
                    "menu": "Notebooks"
                },
                {
                    "menulink": "#",
                    "menu": "Sticky Notes"
                },
                {
                    "menulink": "#",
                    "menu": "Portfolios"
                },
                {
                    "menulink": "#",
                    "menu": "Moleskine"
                },
                {
                    "menulink": "#",
                    "menu": "Laptop & Tablet bags"
                },
                {
                    "menulink": "#",
                    "menu": "Calculators"
                }

            ]
        },
        {
            "menulink": "#",
            "menu": "Pens & Writing  ",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Ballpoint Pens"
                },
                {
                    "menulink": "#",
                    "menu": "Rollerball Pens"
                },
                {
                    "menulink": "#",
                    "menu": "Colouring sets"
                },
                {
                    "menulink": "#",
                    "menu": "Pencils"
                },
                {
                    "menulink": "#",
                    "menu": "Pen sets"
                },
                {
                    "menulink": "#",
                    "menu": "Markers"
                },
                {
                    "menulink": "#",
                    "menu": "Fountain Pens"
                },
                {
                    "menulink": "#",
                    "menu": "Other Pens & Writing Accessories"
                }

            ]
        },
        {
            "menu": "Gift Packaging"
        },
        {
            "menulink": "#",
            "menu": "Apparel",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Headwear"
                },
                {
                    "menulink": "#",
                    "menu": "Textile Accessories"
                },
                {
                    "menulink": "#",
                    "menu": "Aprons"
                },
                {
                    "menulink": "#",
                    "menu": "Pencils"
                },
                {
                    "menulink": "#",
                    "menu": "T-shirts"
                },
                {
                    "menulink": "#",
                    "menu": "Polos"
                },
                {
                    "menulink": "#",
                    "menu": "Pullovers"
                },
                {
                    "menulink": "#",
                    "menu": "Jackets"
                },
                {
                    "menulink": "#",
                    "menu": "Sweaters"
                },
                {
                    "menulink": "#",
                    "menu": "Bodywarmers"
                },
                {
                    "menulink": "#",
                    "menu": "Fleece"
                },
                {
                    "menulink": "#",
                    "menu": "Shirts"
                }

            ]
        },
        {
            "menulink": "#",
            "menu": "Paper (paper printed products)",
            "innermenu": [{
                    "menulink": "#",
                    "menu": "Sticky Notes"
                },
                {
                    "menulink": "#",
                    "menu": "Desk pads"
                },
                {
                    "menulink": "#",
                    "menu": "Notepads"
                },
                {
                    "menulink": "#",
                    "menu": "Memo Blocks"
                },
                {
                    "menulink": "#",
                    "menu": "Notebooks"
                }


            ]
        }
        ],
        "singlemenuList": [
            {
                "menulink": "index.html",
                "menutitle": "Home"
            },
            {
                "menulink": "BB_blog.html",
                "menutitle": "blog"
            },
            {
                "menulink": "BB_contact.html",
                "menutitle": "contact"
            }
        ],
        "mobile-cart-img":"shopping-cart11.png",
        "mobile-userimg": "user-1.png"
    };

 /*----------- Footer Section -------------------*/
    var footer = {

        "footerTitle": "Get in touch",
        "contactTitle": "Contact info",
        "subscribe-title": "Subscribe",
        "serviceTitle": "CUSTOMER SERVICE",
        "subscribeBtn": "Subscribe",
        "emailPlaceholder": "Enter E-mail Hear...",
        "copy_txt": "Copyright © Roadthemes. All Rights Reserved.",
        "copy_img": "payment.png",
        "contactInfo": [{
                "title": "Jurain,Dhaka Bangladesh",
                "icon": "fa fa-home",
                "link": ""
            },
            {
                "title": "websitename@mail.com",
                "icon": "fa fa-envelope",
                "link": "mailto:websitename@mail.com"
            },
            {
                "title": "+1234321321",
                "icon": "fa fa-phone",
                "link": "tel:+1234321321"
            }

        ],
        "socialIcon": [{
                "icon": "fab fa-facebook-f",
                "link": "#"
            },
            {
                "icon": "fab fa-twitter",
                "link": "#"
            },
            {
                "icon": "fab fa-linkedin-in",
                "link": "#"
            },
            {
                "icon": "fab fa-instagram",
                "link": "#"
            }
        ],
        "service": [{
                "title": "Help & FAQs",
                "icon": "far fa-wifi-1",
                "link": "#"
            },
            {
                "title": "Order Tracking",
                "icon": "far fa-wifi-1 wifi",
                "link": "#"
            },
            {
                "title": "Shipping & Delivery",
                "icon": "far fa-wifi-1",
                "link": "#"
            },
            {
                "title": "Login",
                "icon": "far fa-wifi-1",
                "link": "BB_login.html"
            }
        ],
        "subscribe": [{
            "title": "SUBSCRIBE NEWSLETTER",
            "detail": "Get all the latest information on Events, Sales and Offers. Sign up for newsletter today"
        }]
    };
    
/*----------- Homepage Banner Section -------------------*/
    var banner = {
        "banner": [
            {
                "class": "active",
                "title": "Bottles For Your Next School Event",
                "detail": "Make your brand visible in a stylish fashion.",
                "text": "shop now",
                "link": "#",
                "imgurl": "image/11-1.png"
            },
            {

                "title": "Printed Caps And Hats",
                "detail": "Make your brand visible in a stylish fashion.",
                "text": "shop now",
                "link": "#",
                "imgurl": "image/13-1.png"
            },
            {

                "title": "Let T-Shirts Spread Your Story",
                "detail": "Upload your brand name, logo and design. Choose from a variant of t-shirt colors and print methods.",
                "text": "shop now",
                "link": "#",
                "imgurl": "image/15.png"
            }
        ]
    }; 

/*----------- Homepage Service Section -------------------*/

    var service = {
        "shows": [{
                "class": "fad fa-truck",
                "title": "FREE SHIPPING & RETURN",
                "description": "Free shipping on all orders over $99."
            },
            {
                "class": "far fa-usd-circle",
                "title": "MONEY BACK GUARANTEE",
                "description": "100% money back guarantee"
            }, {
                "class": "fas fa-history",
                "title": "ONLINE SUPPORT 24/7",
                "description": "Lorem ipsum dolor sit amet."
            }
        ]
    };

/*----------- Homepage Testimonial Section -------------------*/

    var testimonial = {
        "shows1": [{

                "name": "Mr.Abbu",
                "position": "Senior Manager",
                "description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the dummy text ever since the 1500s, when an unknown printer took a galley of type only five centuries"

            },
            {
                "name": "Mr.Abbu",
                "position": "Senior Manager",
                "description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the dummy text ever since the 1500s, when an unknown printer took a galley of type only five centuries"
            }, {
                "name": "Mr.Abbu",
                "position": "Senior Manager",
                "description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the dummy text ever since the 1500s, when an unknown printer took a galley of type only five centuries"
            }
        ]
    };

/*----------- Homepage Feature Product Section -------------------*/

    var featureProduct = {
        "title": "Featured Products",
        "featured": [
        {
            "productimg": "product-7.jpg",
            "productlink": "BB_add-cart.html",
            "quick_btn": "Quick View",
            "quick_btn_link": "#",
            "title": "Kivi 10W limestone/cork wireless charging pad",
            "product_price": "120.30"
        },
        {
            "productimg": "product-8.jpg",
            "productlink": "BB_add-cart.html",
            "quick_btn": "Quick View",
            "quick_btn_link": "#",
            "title": "IM ballpoint pen",
            "product_price": "50.60"
        },
        {
            "productimg": "product-9.jpg",
            "productlink": "BB_add-cart.html",
            "quick_btn": "Quick View",
            "quick_btn_link": "#",
            "title": "Renzo 30 cm plastic ruler",
            "product_price": "40.00"
        },
        {
            "productimg": "product-10.jpg",
            "productlink": "BB_add-cart.html",
            "quick_btn": "Quick View",
            "quick_btn_link": "#",
            "title": "Darton 6 panel sandwich cap",
            "product_price": "110.10"
        },
        {
            "productimg": "product-11.jpg",
            "productlink": "BB_add-cart.html",
            "quick_btn": "Quick View",
            "quick_btn_link": "#",
            "title": "Open full zip hooded sweater",
            "product_price": "100.00"
        },
        {
            "productimg": "product-12.jpg",
            "productlink": "BB_add-cart.html",
            "quick_btn": "Quick View",
            "quick_btn_link": "#",
            "title": "Ace short sleeve kids t-shirt",
            "product_price": "250.60"
        },
        {
            "productimg": "product-2.jpg",
            "productlink": "BB_add-cart.html",
            "quick_btn": "Quick View",
            "quick_btn_link": "#",
            "title": "Coma 6000 mAh wireless power bank",
            "product_price": "150.60"
        },
        {
            "productimg": "product-2.jpg",
            "productlink": "BB_add-cart.html",
            "quick_btn": "Quick View",
            "quick_btn_link": "#",
            "title": "Coma 6000 mAh wireless power bank",
            "product_price": "150.60"
        },
        {
            "productimg": "product-2.jpg",
            "productlink": "BB_add-cart.html",
            "quick_btn": "Quick View",
            "quick_btn_link": "#",
            "title": "Coma 6000 mAh wireless power bank",
            "product_price": "150.60"
        }
        ]
    };

/*----------- Add to Cart Modal -------------------*/

    var cartModal = {
        "title": "MEN'S SOFT STYLE LONG SLEEVE T-SHIRT",
        "product-price": "40.50",
        "detail": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius nunc id varius nunc.",
        "policy": [{
                "title": "1 Year AL Jazeera Brand Warranty",
                "icon": "far fa-check-circle"
            },
            {
                "title": "30 Day Return Policy",
                "icon": "far fa-sync"
            },
            {
                "title": "Cash on Delivery available",
                "icon": "fal fa-euro-sign"
            }
        ],
        "color_title": "color",
        "qty_title": "Qty",
        "sizeList": [
            {
                "label": "XS",
                "name": "value1",
                "id": "value1"
            },
            {
                "label": "S",
                "name": "value1",
                "id": "value1"
            },
            {
                "label": "M",
                "name": "value1",
                "id": "value1"
            },
            {
                "label": "L",
                "name": "value1",
                "id": "value1"
            },
            {
                "label": "XL",
                "name": "value1",
                "id": "value1"
            },
            {
                "label": "2XL",
                "name": "value1",
                "id": "value1"
            },
            {
                "label": "3XL",
                "name": "value1",
                "id": "value1"
            }
        ],
        "cart_btn": "Add to Cart",
        "design_btn": "start designing"
    };

/*----------- Size Modal -------------------*/
    var sizeModal = {
            "colorTitle":"SELECT color",
            "colorList":[
            {
                "id":"color-1",
                "name":"color",
                "value":"color-1",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg",
                "checked":"checked"
            },
            {
                "id":"color-2",
                "name":"color",
                "value":"color-2",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id":"color-3",
                "name":"color",
                "value":"color-3",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id":"color-4",
                "name":"color",
                "value":"color-4",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id":"color-5",
                "name":"color",
                "value":"color-5",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id":"color-6",
                "name":"color",
                "value":"color-6",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id":"color-7",
                "name":"color",
                "value":"color-7",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            }
            ],
            "sizeTitle":"SELECT SIZE",
            "sizeList":[
            { "size":"XS"},
            { "size":"S"},
            { "size":"M"},
            { "size":"L"},
            { "size":"XL"},
            { "size":"2XL"},
            { "size":"3XL"}
            ],
            "qtyTitle":"SELECT qty",
            "doneBtn":"Done"
    };   

/*----------- Homepage Blog Section -------------------*/

    var blog = {
        "blogtitle": "Latest News",
        "blog": [
            {
                "blogimg": "blog.jpg",
                "date": "29",
                "month": "jun",
                "calender": "29 jun 2020",
                "comment": "18 comments",
                "title": "Turpis at eleifend ps mi elit Aenean",
                "detail": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.",
                "text": "Read More",
                "link": "BB_singleblog.html"
            },
            {
                "blogimg": "blog1.jpg",
                "date": "29",
                "month": "jun",
                "calender": "29 jun 2020",
                "comment": "18 comments",
                "title": "Lorem ipsum dolor sit amet",
                "detail": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.",
                "text": "Read More",
                "link": "BB_singleblog.html"
            },
            {
                "blogimg": "blog2.jpg",
                "date": "29",
                "month": "jun",
                "calender": "29 jun 2020",
                "comment": "18 comments",
                "title": "Praesent iaculis tortor viverra",
                "detail": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.",
                "text": "Read More",
                "link": "BB_singleblog.html"
            }
            
            ]
    };

/*----------- Wishlist Page Section -------------------*/
    var wishlist = {
         "thead": [{
            "head": "Image"
        },
        {
            "head": "Product Name"
        },
        {
            "head": "Until Price"
        },
        {
            "head": "Qty"
        },
        {
            "head": "Size"
        },
        {
            "head": "Total"
        },
        {
            "head": "Add To Cart"
        },
        {
            "head": ""
        }
        ],
        "tablebody": [{
            "productImg": "product-1.jpg",
            "productName": "sleeve kids t-shirt",
            "productPrice": "60.00",
            "productSize": "M",
            "productTotalPrice": "70.00",
            "productCartBtn": "add to cart"
        },
        {
            "productImg": "product-3.jpg",
            "productName": "Allen sunglasses",
            "productPrice": "50.00",
            "productSize": "-",
            "productTotalPrice": "80.00",
            "productCartBtn": "add to cart"
        },
        {
            "productImg": "product-5.jpg",
            "productName": "cloth in pouch",
            "productPrice": "70.00",
            "productSize": "-",
            "productTotalPrice": "90.00",
            "productCartBtn": "add to cart"
        }

        ]
    };

/*----------- Inner Page Banner Section -------------------*/

/*----------- wishlist Banner Section -------------------*/
    var innerpageBanner = {
        "wishlistBanner":[
                {
                    "pagetitle": "wishlist",
                    "title": "Home",
                    "link": "index.html"
                }
            ]
    };

/*----------- Contact Banner Section -------------------*/
    var contactBanner = {
            "contactBanner":[
                {
                    "pagetitle": "Contact Us",
                    "title": "Home",
                    "link": "index.html"
                }
            ]
    };

/*----------- Cart Banner Section -------------------*/
    var cartBanner = {
            "cartBanner":[
                {
                    "pagetitle": "cart",
                    "title": "Home",
                    "link": "index.html"
                }
            ]
    }; 

/*----------- Contact Detail Page Section -------------------*/
    var contactDetail = {
        "contactdetail": [{
            "title": "PHONE",
            "detail": "+1234321321",
            "icon": "fas fa-headphones-alt"
        },
        {
            "title": "Address",
            "detail": "Jurain,Dhaka Bangladesh",
            "icon": "fas fa-map-marked-alt"
        },
        {
            "title": "EMAIL",
            "detail": "websitename@mail.com",
            "icon": "fas fa-envelope-open-text"
        }
        ]
    };

/*----------- Cart Page -------------------*/
    var cart = {
        "thead": [{
            "head": "Image"
        },
        {
            "head": "Product Name"
        },
        {
            "head": "Until Price"
        },
        {
            "head": "Qty"
        },
        {
            "head": "Size"
        },
        {
            "head": "Total"
        },
        {
            "head": "Add To Cart"
        },
        {
            "head": ""
        }
        ],
        "tablebody": [{
            "productImg": "product-1.jpg",
            "productName": "sleeve kids t-shirt",
            "productPrice": "60.00",
            "productSize": "M",
            "productTotalPrice": "70.00",
            "productCartBtn": "add to cart"
        },
        {
            "productImg": "product-3.jpg",
            "productName": "Allen sunglasses",
            "productPrice": "50.00",
            "productSize": "-",
            "productTotalPrice": "80.00",
            "productCartBtn": "add to cart"
        },
        {
            "productImg": "product-5.jpg",
            "productName": "cloth in pouch",
            "productPrice": "70.00",
            "productSize": "-",
            "productTotalPrice": "90.00",
            "productCartBtn": "add to cart"
        }

        ],
        "couponBtn": "Apply Coupon",
        "updateBtn": "Update Cart",
        "cartTotalTitle": "Cart Totals",
        "cartTotal": [{
            "cartTitle": "Cart Subtotal",
            "cartText": "486.30"
        },
        {
            "cartTitle": "Shipping and Handing",
            "cartText": "Free Shipping"
        },
        {
            "cartTitle": "Vat",
            "cartText": "00.00"
        }
        ],
        "cartTitle": "Order Total",
        "cartText": "486.30",
        "checkoutBtn": "Proceed to checkout"
    };

/*----------- Single Blog Page  -------------------*/
    var singleBlog = {
        "title": "Turpis at eleifend ps mi elit Aenean",
        "calender": "29 jun 2020",
        "comment": "18 comments",
        "blogimg": "single-img.webp",
        "detail": " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur malesuada malesuada metus ut placerat. Cras a porttitor quam, eget ornare sapien. In sit amet vulputate metus. Nullam eget rutrum nisl. Sed tincidunt lorem sed maximus interdum. Interdum et malesuada fames ac ante ipsum primis in faucibus. Aenean scelerisque efficitur mauris nec tincidunt. Ut cursus leo mi, eu ultricies magna faucibus id.",
        "blogformTitle":"LEAVE A REPLY",
        "blogForm":[
            {
                "label": "Your name : ",
                "type":"text",
                "name":"name",
                "placeholder":"Enter Your Name"
            },
            {
                "label": "E-MAIL :",
                "type":"email",
                "name":"email",
                "placeholder":"Enter Your Email"
            }
        ],
        "textareaLabel": "YOUR COMMENT :",
        "textareaType":"text",
        "textareaName":"comment",
        "textareaPlaceholder":"Write a comments",
        "submitBtn":"submit",
        "sidepostTitle":"Popular Posts",
        "post": [{
                "blogimg": "img-1",
                "date": "Jun 20, 2021",
                "detail": "Lorem ipsum dolor sit amet"
            },
            {
                "blogimg": "img-2",
                "date": "Jun 20, 2021",
                "detail": "On the other hand we provide denounce with righteous"
            },
            {
                "blogimg": "img-3",
                "date": "Jun 20, 2021",
                "detail": "On the other hand we provide denounce with righteous"
            }
        ],
        "archive_title": "Archives",
        "archive": [{
                "date": "January 2021",
                "link": "#"
            },
            {
                "date": "February 2021",
                "link": "#"
            },
            {
                "date": "March 2021",
                "link": "#"
            }
        ],
        "tag_title": "Tags",
        "tag": [{
                "tagtitle": "General",
                "value": "10"
            },
            {
                "tagtitle": "Design",
                "value": "15"
            },
            {
                "tagtitle": "Branding",
                "value": "10"
            },
            {
                "tagtitle": "Modern",
                "value": "12"
            },
            {
                "tagtitle": "Blog",
                "value": "7"
            },
            {
                "tagtitle": "Quotes",
                "value": "3"
            }
        ]

    };  
    
/*----------- Blog Page  -------------------*/

    var blogList = {
         "blog": [
        {
                "blogimg": "blog.jpg",
                "date": "29",
                "month": "jun",
                "calender": "29 jun 2020",
                "comment": "18 comments",
                "title": "Turpis at eleifend ps mi elit Aenean",
                "detail": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.",
                "text": "Read More",
                "link": "BB_singleblog.html"
            },
            {
                "blogimg": "blog1.jpg",
                "date": "29",
                "month": "jun",
                "calender": "29 jun 2020",
                "comment": "18 comments",
                "title": "Lorem ipsum dolor sit amet",
                "detail": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.",
                "text": "Read More",
                "link": "BB_singleblog.html"
            },
            {
                "blogimg": "blog2.jpg",
                "date": "29",
                "month": "jun",
                "calender": "29 jun 2020",
                "comment": "18 comments",
                "title": "Praesent iaculis tortor viverra",
                "detail": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.",
                "text": "Read More",
                "link": "BB_singleblog.html"
            },
            {
                "blogimg": "blog2.jpg",
                "date": "29",
                "month": "jun",
                "calender": "29 jun 2020",
                "comment": "18 comments",
                "title": "Praesent iaculis tortor viverra",
                "detail": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.",
                "text": "Read More",
                "link": "BB_singleblog.html"
            }

        ]
    };                  

/*----------- Sidebar Blog Page  -------------------*/

    var blogSidebar = {
        "sidepostTitle":"Popular Posts",
        "post": [{
                "blogimg": "img-1",
                "date": "Jun 20, 2021",
                "detail": "Lorem ipsum dolor sit amet"
            },
            {
                "blogimg": "img-2",
                "date": "Jun 20, 2021",
                "detail": "On the other hand we provide denounce with righteous"
            },
            {
                "blogimg": "img-3",
                "date": "Jun 20, 2021",
                "detail": "On the other hand we provide denounce with righteous"
            }
        ],
        "archive_title": "Archives",
        "archive": [{
                "date": "January 2021",
                "link": "#"
            },
            {
                "date": "February 2021",
                "link": "#"
            },
            {
                "date": "March 2021",
                "link": "#"
            }
        ],
        "tag_title": "Tags",
        "tag": [{
                "tagtitle": "General",
                "value": "10"
            },
            {
                "tagtitle": "Design",
                "value": "15"
            },
            {
                "tagtitle": "Branding",
                "value": "10"
            },
            {
                "tagtitle": "Modern",
                "value": "12"
            },
            {
                "tagtitle": "Blog",
                "value": "7"
            },
            {
                "tagtitle": "Quotes",
                "value": "3"
            }
        ]
    };

/*----------- Homepage New Arrival Section -------------------*/

    var newArrival = {
        "title": "New Arrivals",
        "arrival": [{
                "productimg": "product-1.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "Ace short sleeve kids t-shirt",
                "product_price": "250.60.00",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-2.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "Coma 6000 mAh wireless power bank",
                "product_price": "150.60",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-3.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "Allen sunglasses",
                "product_price": "25.60",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-4.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "H2O Base Tritan™ 650 ml spout lid sport bottle",
                "product_price": "150.60",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-5.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "Clear microfiber cleaning cloth in pouch",
                "product_price": "100.00",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-12.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "H2O Pulse® 600 ml dome lid sport bottle & infuser",
                "product_price": "150.60",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-6.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "Yogi lanyard detachable buckle break-away closure",
                "product_price": "90.60",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-7.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "Kivi 10W limestone/cork wireless charging pad",
                "product_price": "120.30",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-8.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "IM ballpoint pen",
                "product_price": "50.60",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-9.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "Renzo 30 cm plastic ruler",
                "product_price": "40.00",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-10.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "Darton 6 panel sandwich cap",
                "product_price": "110.10",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            },
            {
                "productimg": "product-11.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "productName": "Open full zip hooded sweater",
                "product_price": "100.00",
                "tooltip_title": "Add to Wish List",
                "tooltip_icon": "far fa-heart",
                "tooltip_link": "BB_wishlist.html"
            }

        ]
    };

/*----------- Add Cart Page -------------------*/

/*----------- Review Section -------------------*/
    var review = {
        "tab1": "Product details",
        "tab2": "Reviews (2)",
        "tab1_detail": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        "review_title": "2 reviews for Men's Soft Style Long Sleeve T-Shirt",
        "comment": [{
                "userimg": "avatar1.jpg",
                "username": "John Doe",
                "comment-date": "Novemeber 15, 2019",
                "comment-txt": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip."
            },
            {
                "userimg": "avatar2.jpg",
                "username": "John Doe",
                "comment-date": "Novemeber 15, 2019",
                "comment-txt": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip."
            }
        ]
    };

/*----------- Contact Page -------------------*/

/*-------- Contact Form --------------*/
    var contactForm = {
        "contactTitle": "Get in touch with us",
        "formTitle": "Contact Form",
        "contactForm": [
            {
                "label": "Your Name",
                "type": "text",
                "placeholder": "Name",
                "name": "name",
                "id": "name",
                "dataError": "Please enter your name"
            },
            {
                "label": "Your Email",
                "type": "email",
                "placeholder": "Email",
                "name": "email",
                "id": "email",
                "dataError": "Please enter your email"
            },
            {
                "label": "Phone Number",
                "type": "text",
                "placeholder": "Phone",
                "name": "phone_number",
                "id": "phone_number",
                "dataError": "Please enter your number"
            },
            {
                "label": "Your Subject",
                "type": "text",
                "placeholder": "Your Subject",
                "name": "msg_subject",
                "id": "msg_subject",
                "dataError": "Please enter your subject"
            }        
        ],
        "textarea": [
            {
                "label": "Your Message",
                "placeholder": "Your Message",
                "name": "message",
                "id": "message",
                "dataError": "Write your message"
            }
        ],
        "acceptText":"Accept",
        "termText":"Terms & Conditions",
        "termLink":"terms-condition.html",
        "privacyText":"Privacy Policy.",
        "privacyLink":"privacy-policy.html",
        "messageBtn":"Send Message"
    };  
    
/*----------- Delivery Page  -------------------*/

/*-------- Delivery Banner ---------*/

    var deliveryBanner = {
        "pagetitle": "Address",
        "title": "Home",
        "link": "index.html"
    };

/*----------- Delivery Address -------------------*/
    var deliveryAddress = {
        "addressHead": "Select delivery address",
        "addressBtn": "Add new address",

        "addressList": [{
                "addressTitle": "default address",
                "infoTitle": "Personal Information",
                "name": "Patel Sandhya",
                "email": "psandhya791@gmail.com",
                "number": "1234567890",
                "address": "Address",
                "addressDetail": "Shop No. 19, Shree Vinayak Homes Apartment,Opp. I.T.I Bilimora, Gujarat - 396325",
                "payText": "Pay on Delivery not available",
                "removeBtn": "Remove",
                "editBtn": "Edit"

            },
            {
                "addressTitle": "OTHER ADDRESS",
                "infoTitle": "Personal Information",
                "name": "Patel Feni",
                "email": "patelfeni123@gmail.com",
                "number": "1234567890",
                "address": "Address",
                "addressDetail": "Shop No. 19, Shree Vinayak Homes Apartment,Opp. I.T.I surat, Gujarat - 396325",
                "payText": "Pay on Delivery not available",
                "removeBtn": "Remove",
                "editBtn": "Edit"
            
            }

        ],
        "cartTotalTitle": "Cart Totals",
        "cartTotal": [{
                "cartTitle": "Ace short sleeve kids t-shirt",
                "cartText": "250.60"
            },
            {
                "cartTitle": "Allen sunglasses",
                "cartText": "25.60"
            },
            {
                "cartTitle": "Darton 6 panel sandwich cap",
                "cartText": "110.10"
            },
            {
                "cartTitle": "Open full zip hooded sweater",
                "cartText": "100.00"
            }
        ],
        "cartTotalHead": [{
                "cartTitleHead": "Total",
                "cartTextHead": "486.30"
            },
            {
                "cartTitleHead": "Discount",
                "cartTextHead": "0"
            },
            {
                "cartTitleHead": "Convenience Fee",
                "cartTextHead": "Free"
            },
            {
                "cartTitleHead": "Sub Total",
                "cartTextHead": "486.30"
            }

        ],
        "continueBtn": "Continue"
    }; 

/*------- Delivery page Add Address Modal -------*/
    var addAdress = {
        "modalTitle": "ADD NEW ADDRESS",
        "detailTitle": "Personal Information",
        "fnamePlaceholder": "First name",
        "lnamePlaceholder": "Last name",
        "emailPlaceholder": "Email address",
        "phonePlaceholder": "Phone Number",
        "AddTitle":"Address",
        "hPlaceholder": "House number and street name",
        "apartPlaceholder": "Apartment, suite, unit etc. (optional)",
        "cityTitle": "Town/City",
        "cityPlaceholder": "City",
        "stateTitle": "State",
        "stateList": [
            {
               "stateTitle":"Select State"
            },
            {
               "stateTitle":"Afghanistan" 
            },
            {
               "stateTitle":"Albania" 
            },
            { 
                "stateTitle":"Argentina" 
            },
            { 
                "stateTitle":"Australia" 
            },
            { 
                "stateTitle":"Bangladesh" 
            },
            { 
                "stateTitle":"Belize" 
            },
            { 
                "stateTitle":"Bhutan" 
            },
            { 
                "stateTitle":"Canada" 
            },
            { 
                "stateTitle":"Colombia" 
            },
            { 
                "stateTitle":"France" 
            },
            { 
                "stateTitle":"Germany" 
            },
            { 
                "stateTitle":"Greece" 
            }
        ],
        "zipTitle": "Zip",
        "zipPlaceholder": "Zip",
        "addressBtn": "Add address"
    };                 

/*----------- Delivery page Edit Address Modal -------------------*/
    var editAddress = {
        "editmodalTitle": "edit ADDRESS",
        "detailTitle": "Personal Information",
        "fnamePlaceholder": "First name",
        "lnamePlaceholder": "Last name",
        "emailPlaceholder": "Email address",
        "phonePlaceholder": "Phone Number",
        "AddTitle":"Address",
        "hPlaceholder": "House number and street name",
        "apartPlaceholder": "Apartment, suite, unit etc. (optional)",
        "cityTitle": "Town/City",
        "cityPlaceholder": "City",
        "stateTitle": "State",
        "stateList": [
            {
               "stateTitle":"Select State"
            },
            {
               "stateTitle":"Afghanistan" 
            },
            {
               "stateTitle":"Albania" 
            },
            { 
                "stateTitle":"Argentina" 
            },
            { 
                "stateTitle":"Australia" 
            },
            { 
                "stateTitle":"Bangladesh" 
            },
            { 
                "stateTitle":"Belize" 
            },
            { 
                "stateTitle":"Bhutan" 
            },
            { 
                "stateTitle":"Canada" 
            },
            { 
                "stateTitle":"Colombia" 
            },
            { 
                "stateTitle":"France" 
            },
            { 
                "stateTitle":"Germany" 
            },
            { 
                "stateTitle":"Greece" 
            }
        ],
        "zipTitle": "Zip",
        "zipPlaceholder": "Zip",
        "saveBtn": "Save address"
    };


/*----------- Checkout Page  -------------------*/

/*-------- Checkout Banner ---------*/

    var checkoutBanner = {
       "pagetitle": "Checkout",
        "title": "Home",
        "link": "index.html"
    };  
    
/*-------- Checkout section ---------*/

    var checkoutForm = {
       "returnTitle": "Returning customer?",
        "returnLink": " Click here to login",
        "formTitle": "Please login your accont.",
        "loginBtn": "login",
        "remember": "Remember me",
        "password": "Lost your password?",
        "couponTitle": "Have a coupon? ",
        "couponLink": "Click here to enter your code",
        "couponformTitle": "If you have a coupon code, please apply it below.",
        "couponBtn": "Apply Coupon",

        "modalTitle": "Billing Details",
        "detailTitle": "Personal Information",
        "fnamePlaceholder": "First name",
        "lnamePlaceholder": "Last name",
        "emailPlaceholder": "Email address",
        "phonePlaceholder": "Phone Number",
        "AddTitle":"Address",
        "hPlaceholder": "House number and street name",
        "apartPlaceholder": "Apartment, suite, unit etc. (optional)",
        "cityTitle": "Town/City",
        "cityPlaceholder": "City",
        "stateTitle": "State",
        "stateList": [
            {
               "stateTitle":"Select State"
            },
            {
               "stateTitle":"Afghanistan" 
            },
            {
               "stateTitle":"Albania" 
            },
            { 
                "stateTitle":"Argentina" 
            },
            { 
                "stateTitle":"Australia" 
            },
            { 
                "stateTitle":"Bangladesh" 
            },
            { 
                "stateTitle":"Belize" 
            },
            { 
                "stateTitle":"Bhutan" 
            },
            { 
                "stateTitle":"Canada" 
            },
            { 
                "stateTitle":"Colombia" 
            },
            { 
                "stateTitle":"France" 
            },
            { 
                "stateTitle":"Germany" 
            },
            { 
                "stateTitle":"Greece" 
            }
        ],
        "zipTitle": "Zip",
        "zipPlaceholder": "Zip",
        "checkText": "Create an account?",
        "noteText": "Order Notes (optional)",
        "notePlaceholder": "Notes about your order, e.g. special notes for delivery.",
        "submitBtn": "Submit"
    };

/*-------- Add to cart Banner ---------*/

    var addtocartBanner = {
         "title": "Home",
        "link": "index.html",
        "title2": "Apparel",
        "link2": "#",
        "pagetitle": "T-shirts"
    };


/*-------- Add to cart Product Section ---------*/

    var cartSection = {
        "title": "MEN'S SOFT STYLE LONG SLEEVE T-SHIRT",
        "product-price": "40.50",
        "detail": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius nunc id varius nunc.",
        "policy": [{
                "title": "1 Year AL Jazeera Brand Warranty",
                "icon": "far fa-check-circle"
            },
            {
                "title": "30 Day Return Policy",
                "icon": "far fa-sync"
            },
            {
                "title": "Cash on Delivery available",
                "icon": "fal fa-euro-sign"
            }
        ],
        "color_title": "color",
        "colorList": [
            {
                "id": "color-2",
                "name": "color2",
                "value": "color-2",
                "checked": "checked",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-11",
                "name": "color11",
                "value": "color-11",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            }
        ],
        "qty_title": "Qty",
        "sizeList": [
            {
                "label": "xs",
                "id": "value1",
                "name": "value1"
            },
            {
                "label": "s",
                "id": "value2",
                "name": "value2"
            },
            {
                "label": "M",
                "id": "value3",
                "name": "value3"
            },
            {
                "label": "L",
                "id": "value4",
                "name": "value4"
            },
            {
                "label": "XL",
                "id": "value5",
                "name": "value5"
            },
            {
                "label": "2XL",
                "id": "value6",
                "name": "value6"
            },
            {
                "label": "3XL",
                "id": "value7",
                "name": "value7"
            }
        ],
        "cart_btn": "Add to Cart",
        "design_btn": "start designing"
    }; 
    
/*-------- Blog Banner ---------*/

    var blogBanner = {
       "pagetitle": "Blogs",
        "title": "Home",
        "link": "index.html"
    };    

/*-------- Payment Banner ---------*/

    var paymentBanner = {
       "pagetitle": "Payment",
        "title": "Home",
        "link": "index.html"
    }; 
    
/*----------- Payment Method section -------------------*/
    var paymentMethod = {
        "paymenttitle": "Payment Method",
        "paymentMethod": [{
                "methodTab": "home",
                "methodName": "CASH ON DELIVERY",
                "activeClass": "active"
            },
            {
                "methodTab": "profile",
                "methodName": "CREDIT/DEBIT CARD"
            },
            {
                "methodTab": "messages",
                "methodName": "PHONEPE/GOOGLE PAY/BHIM UPI"
            },
            {
                "methodTab": "settings",
                "methodName": "NET BANKING"
            }
        ],
        "payTitle": "Pay on delivery",
        "payText": "Pay on Delivery payment option is not available for your shipping address",
        "cardTitle": "CREDIT/ DEBIT CARD",
        "cardName": "Card number",
        "cardNumber": "Name on Card",
        "cardDate": "Valid Thru (MM/YY)",
        "cardCVV": "CVV",
        "payBtn": "Pay Now",
        "upiTitle": "Pay using UPI",
        "bankingTitle": "Net banking",
        "phonepay": "PhonePe",
        "phoneLogo": "Phone-pe-logo.png",
        "googlepayLogo": "google-pay1.png",
        "upiLogo": "UPI_logo_PNG.png",
        "googlepay": "Google Pay",
        "upiId": "Enter UPI ID",
        "axisBank": "Axis Bank",
        "hdfcBank": "HDFC Bank",
        "sbiBank": "SBI",
        "bankList": [{
                "bankName": "Other Banks"
            },
            {
                "bankName": "Airtel payments bank"
            },
            {
                "bankName": "Andhra Bank"
            },
            {
                "bankName": "Bank of Baroda Corporate"
            },
            {
                "bankName": "Bank of Baroda Retail Accounts"
            },
            {
                "bankName": "Bank of India"
            },
            {
                "bankName": "Bank of Maharashtra"
            },
            {
                "bankName": "Punjab National Bank [Retail]"
            },
            {
                "bankName": "ICICI Bank"
            },
            {
                "bankName": "Kotak"
            },
            {
                "bankName": "Union Bank of India"
            },
            {
                "bankName": "YES Bank"
            }
        ],
        "cartTotalTitle": "Cart Totals",
        "cartTotal": [{
                "cartTitle": "Ace short sleeve kids t-shirt",
                "cartText": "250.60"
            },
            {
                "cartTitle": "Allen sunglasses",
                "cartText": "25.60"
            },
            {
                "cartTitle": "Darton 6 panel sandwich cap",
                "cartText": "110.10"
            },
            {
                "cartTitle": "Open full zip hooded sweater",
                "cartText": "100.00"
            }
        ],
        "cartTotalHead": [{
                "cartTitleHead": "Total",
                "cartTextHead": "486.30"
            },
            {
                "cartTitleHead": "Free",
                "cartTextHead": "486.30"
            },
            {
                "cartTitleHead": "Total",
                "cartTextHead": "486.30"
            }
        ]
    }; 
    
/*----------- Login Page -------------------*/
    var loginForm = {
        "logo": "logo-1.png",
        "logoLink": "index.html",
        "loginTitle": "welcome!",
        "loginText": "Use your credentials to access",
        "emailPlaceholder": "Enter your email",
        "passwordPlaceholder": "Enter your password",
        "loginBtn": "login",
        "forgotPassword": "Forgot your password?",
        "resetText": "reset here",
        "resetLink": "BB_reset.html",
        "registerTitle": "Don't have any account?",
        "registerText": "register here",
        "registerLink": "BB_signup.html",
        "copyText": "Organe | © Copyright by",
        "copyLinkText": "Mironcoder",
        "copyLink": "#"
    };             

/*----------- Reset Form -------------------*/
    var resetForm = {
        "logo": "logo-1.png",
        "logoLink": "index.html",
        "title": "Worried?",
        "text": "No Problem! Just Follow The Simple Way",
        "emailPlaceholder": "Enter your email",
        "resetBtn": "get reset link",
        "registertext": "Already Have An Account?",
        "backText": "Go Back To",
        "loginText": "login here",
        "loginLink": "BB_login.html",
        "copyText": "Organe | © Copyright by",
        "copyLinkText": "Mironcoder",
        "copyLink": "#"
    };

/*----------- SignUp Form -------------------*/
    var signupForm = {
            "logo": "logo-1.png",
            "logoLink": "index.html",
            "joinTitle": "Join Now!",
            "signText": "Setup A New Account In A Minute",
            "namePlaceholder": "Enter Your Name",
            "emailPlaceholder": "Enter your email",
            "passwordPlaceholder": "Enter your password",
            "RepeatpassPlaceholder": "Enter Your Repeat Password",
            "registerBtn": "REGISTER",
            "registertext": "Already Have An Account?",
            "loginText": "login here",
            "loginLink": "BB_login.html",
            "copyText": "Organe | © Copyright by",
            "copyLinkText": "Mironcoder",
            "copyLink": "#"
    }; 
    
/*----------- Request A quote Page  -------------------*/

/*-------- Request A quote Banner ---------*/

    var quoteBanner = {
        "pagetitle": "Request A Quote",
        "title": "Home",
        "link": "index.html"
    };

/*-------- Request A quote Form ---------*/
    var quoteForm = {
         "formList": [
            {
                "label":"First Name:",
                "type":"text",
                "name":"f_name"  
            },
            {
                "label":"Last Name:",
                "type":"text",
                "name":"l_name"  
            } ,
            {
                "label":"Email Address:",
                "type":"email",
                "name":"email"  
            } ,
            {
                "label":"Phone Number:",
                "type":"number",
                "name":"number"  
            }
        ],
        "textarea": [
            {
                "label": "Address:",            
                "name": "add"
            }
        ],
        "city": [
            {
                "label": "City:",   
                "type":"text",         
                "name": "city"
            }
        ],
        "dropdowmList": [
            {
               "label": "Country", 
                "dropdowmListItem": [
                    {
                        "item":"Select country"
                    },
                    {
                        "item":"United Kingdom"
                    },
                    {
                        "item":"London"
                    },
                    {
                        "item":"United States"
                    }
                ]
            },
            {
               "label": "State", 
                "dropdowmListItem": [
                    {
                        "item":"Select State"
                    },
                    {
                        "item":"Aberdeenshire"
                    },
                    {
                        "item":"Anglesey"
                    },
                    {
                        "item":"Angus"
                    },
                    {
                        "item":"Antrim"
                    },
                    {
                        "item":"Argyll"
                    },
                    {
                        "item":"Armagh"
                    },
                    {
                        "item":"Avon"
                    },
                    {
                        "item":"Ayrshire"
                    },
                    {
                        "item":"Banffshire"
                    },
                    {
                        "item":"Bedfordshire"
                    },
                    {
                        "item":"Berkshire"
                    },
                    {
                        "item":"Berwickshire"
                    },
                    {
                        "item":"Buckinghamshire"
                    },
                    {
                        "item":"Bute"
                    },
                    {
                        "item":"Caithness"
                    },
                    {
                        "item":"Cambridgeshire"
                    },
                    {
                        "item":"Carmarthenshire"
                    },
                    {
                        "item":"Channel Islands"
                    },
                    {
                        "item":"Cheshire"
                    },
                    {
                        "item":"Clackmannanshire"
                    },
                    {
                        "item":"Cleveland"
                    },
                    {
                        "item":"Clwyd"
                    },
                    {
                        "item":"Conwy"
                    },
                    {
                        "item":"Cornwall"
                    },
                    {
                        "item":"Cumbria"
                    },
                    {
                        "item":"Denbighshire"
                    },
                    {
                        "item":"Derbyshire"
                    },
                    {
                        "item":"Devon"
                    },
                    {
                        "item":"Dorset"
                    },
                    {
                        "item":"Down"
                    },
                    {
                        "item":"Dumfriesshire"
                    },
                    {
                        "item":"Dunbartonshire"
                    },
                    {
                        "item":"Durham"
                    },
                    {
                        "item":"Dyfed"
                    },
                    {
                        "item":"East Lothian"
                    },
                    {
                        "item":"East Riding of Yorkshire"
                    },
                    {
                        "item":"East Sussex"
                    },
                    {
                        "item":"Essex"
                    },
                    {
                        "item":"Fermanagh"
                    },
                    {
                        "item":"Fife"
                    },
                    {
                        "item":"Flintshire"
                    },
                    {
                        "item":"Gloucestershire"
                    },
                    {
                        "item":"Greater Manchester"
                    },
                    {
                        "item":"Guernsey"
                    },
                    {
                        "item":"Gwent"
                    },
                    {
                        "item":"Gwynedd"
                    },
                    {
                        "item":"Hampshire"
                    },
                    {
                        "item":"Herefordshire"
                    },
                    {
                        "item":"Hertfordshire"
                    },
                    {
                        "item":"Inverness-shire"
                    },
                    {
                        "item":"Isle of Man"
                    },
                    {
                        "item":"Isle of Wight"
                    },
                    {
                        "item":"Jersey"
                    },
                    {
                        "item":"Kent"
                    },
                    {
                        "item":"Kincardineshire"
                    },
                    {
                        "item":"Kinross-shire"
                    },
                    {
                        "item":"Kirkcudbrightshire"
                    },
                    {
                        "item":"Lanarkshire"
                    },
                    {
                        "item":"Lancashire"
                    },
                    {
                        "item":"Leicestershire"
                    },
                    {
                        "item":"Lincolnshire"
                    },
                    {
                        "item":"London"
                    },
                    {
                        "item":"Londonderry"
                    },
                    {
                        "item":"Merseyside"
                    },
                    {
                        "item":"Mid Glamorgan"
                    },
                    {
                        "item":"Middlesex"
                    },
                    {
                        "item":"Midlothian"
                    },
                    {
                        "item":"Monmouthshire"
                    },
                    {
                        "item":"Moray"
                    },
                    {
                        "item":"Nairnshire"
                    },
                    {
                        "item":"Neath Port Talbot"
                    },
                    {
                        "item":"Norfolk"
                    },
                    {
                        "item":"North Humberside"
                    },
                    {
                        "item":"North Yorkshire"
                    },
                    {
                        "item":"Northamptonshire"
                    },
                    {
                        "item":"Northumberland"
                    },
                    {
                        "item":"Nottinghamshire"
                    },
                    {
                        "item":"Orkney"
                    },
                    {
                        "item":"Oxfordshire"
                    },
                    {
                        "item":"Peeblesshire"
                    },
                    {
                        "item":"Pembrokeshire"
                    },
                    {
                        "item":"Perthshire"
                    },
                    {
                        "item":"Powys"
                    },
                    {
                        "item":"Renfrewshire"
                    },
                    {
                        "item":"Ross-shire"
                    },
                    {
                        "item":"Roxburghshire"
                    },
                    {
                        "item":"Rutland"
                    },
                    {
                        "item":"Selkirkshire"
                    },
                    {
                        "item":"Shetland"
                    },
                    {
                        "item":"Shropshire"
                    },
                    {
                        "item":"Somerset"
                    },
                    {
                        "item":"South Glamorgan"
                    },
                    {
                        "item":"South Humberside"
                    },
                    {
                        "item":"South Yorkshire"
                    },
                    {
                        "item":"Staffordshire"
                    },
                    {
                        "item":"Stirlingshire"
                    },
                    {
                        "item":"Suffolk"
                    },
                    {
                        "item":"Surrey"
                    },
                    {
                        "item":"Sutherland"
                    },
                    {
                        "item":"Tyne and Wear"
                    },
                    {
                        "item":"Tyrone"
                    },
                    {
                        "item":"Warwickshire"
                    },
                    {
                        "item":"West Glamorgan"
                    },
                    {
                        "item":"West Lothian"
                    },
                    {
                        "item":"West Midlands"
                    },
                    {
                        "item":"West Sussex"
                    },
                    {
                        "item":"West Yorkshire"
                    },
                    {
                        "item":"Western Isles"
                    },
                    {
                        "item":"Wigtownshire"
                    },
                    {
                        "item":"Wiltshire"
                    },
                    {
                        "item":"Worcestershire"
                    },
                    {
                        "item":"Wrexham"
                    }
                ]
            }
        ],
        "Postcode": [
            {
                "label": "Postcode",                      
                "name": "Postcode"
            }
        ],
         "quoteOption": [
            {
                "option1": "I KNOW THE PRODUCT I WANT",                      
                "option2": "I'M NOT SURE OF MY PRODUCT"
            }
        ],
        "selectPro": "select product",  
        "openProductBtn": "open product selector",
        "ProductName": "Product Name",  
        "ProductDetail": "Men's Soft Style Long Sleeve T-Shirt",
        "ProductImageTitle": "Product Image",  
        "ProductImage": "cart-1.jpg",
        "colorTitle": "color",
        "colorList": [
            {
                "id": "color-1",
                "name": "color",
                "value": "color-1",
                "checked": "checked",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-2",
                "name": "color-2",
                "value": "color-2",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-3",
                "name": "color-3",
                "value": "color-3",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-4",
                "name": "color-4",
                "value": "color-4",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-5",
                "name": "color-5",
                "value": "color-5",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-6",
                "name": "color-6",
                "value": "color-6",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-7",
                "name": "color-7",
                "value": "color-7",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
             {
                "id": "color-8",
                "name": "color-8",
                "value": "color-8",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
             {
                "id": "color-9",
                "name": "color-9",
                "value": "color-9",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
             {
                "id": "color-10",
                "name": "color-10",
                "value": "color-10",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-11",
                "name": "color-11",
                "value": "color-11",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
        ],
        "sizeTitle": "Product sizing",
        "sizeList": [
            {
                "label": "xs",
                "id": "value1",
                "name": "value1"
            },
            {
                "label": "s",
                "id": "value2",
                "name": "value2"
            },
            {
                "label": "M",
                "id": "value3",
                "name": "value3"
            },
            {
                "label": "L",
                "id": "value4",
                "name": "value4"
            },
            {
                "label": "XL",
                "id": "value5",
                "name": "value5"
            },
            {
                "label": "2XL",
                "id": "value6",
                "name": "value6"
            },
            {
                "label": "3XL",
                "id": "value7",
                "name": "value7"
            }
        ],
        "quantityTitle": "Quantity",
        "colorDisplay":[
            {
                "id":"color-2",
                "name":"color-2",
                "value":"color-2",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg",
                "quantity":"Qty:2",
                "size":"size:S"

            },
            {
                "id":"color-11",
                "name":"color-11",
                "value":"color-11",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg",
                "quantity":"Qty: 5",
                "size":"size: XL"
            }
        ],
        "option2Title":"Product Details",
        "textareaPlaceholder":"Please enter your quote request here....",
        "decorationProcess":[
            {
                "id":"radio-1",
                "name":"optradio",
                "value":"option-1",
                "checked":"checked",
                "process":"Digital Printing"
            },
            {
                "id":"radio-2",
                "name":"optradio",
                "value":"option-2",           
                "process":"Sublimation"
            },
            {
                "id":"radio-3",
                "name":"optradio",
                "value":"option-3",            
                "process":"Embroidery"
            },
            {
                "id":"radio-4",
                "name":"optradio",
                "value":"option-4",            
                "process":"Screen Printing"
            },
            {
                "id":"radio-5",
                "name":"optradio",
                "value":"option-5",            
                "process":"Full Color Transfer"
            }
        ],
        "uploadArtText":"Upload Artworks",
        "uploadArtBtn":"Add Another Piece of Artwork",
        "widthText":"Desired Width",
        "unit":"cm",
        "heightText":"Desired Height",
        "removeBtn":"remove",
        "deliveryText":"Need Delivery By",
        "sendBtn":"send request"  
    };  
    
/*----------- Select Product Modal -------------------*/
    var productListModal = {
        "modalTitle":"SELECT PRODUCT",
        "menu": [
            {
                "menulink": "#",
                "menu": "T-shirts",
                "subMenu": [
                    {
                        "menulink": "#",
                        "menu": "Good"
                    },
                    {
                        "menulink": "#",
                        "menu": "Better"
                    },
                    {
                        "menulink": "#",
                        "menu": "Best"
                    },
                    {
                        "menulink": "#",
                        "menu": "Performance"
                    },
                    {
                        "menulink": "#",
                        "menu": "Long Sleeve"
                    },
                    {
                        "menulink": "#",
                        "menu": "Tanks & V-Necks"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Ladies",
                "subMenu": [
                    {
                        "menulink": "#",
                        "menu": "T-shirts"
                    },
                    {
                        "menulink": "#",
                        "menu": "Performance"
                    },
                    {
                        "menulink": "#",
                        "menu": "Long Sleeve"
                    },
                    {
                        "menulink": "#",
                        "menu": "V-Necks"
                    }
                    
                ]
            }
        ],
        "productList": [
                    {
                       "productName": "Men's Soft Style Long Sleeve T-Shirt",
                       "productImg": "s-product1.jpg",
                       "useBtn": "use this product",
                       "descrptiontitle": "Decription",
                        "productDescription": [
                            {
                                "detailItem": "Deluxe 30s Soft style yarns",
                            },
                            {
                                "detailItem": "Seamless twin needle 3/4 collar",
                            },
                            {
                                "detailItem": "Taped neck and shoulders",
                            },
                            {
                                "detailItem": "Rolled forward shoulders for better fit",
                            },
                            {
                                "detailItem": "Hemmed sleeves",
                            },
                            {
                                "detailItem": "Twin needle sleeve and bottom hems",
                            },
                            {
                                "detailItem": "Quarter-turned to eliminate centre crease",
                            }
                        ],
                        "colorTitle":"Color",
                        "colorList": [
                            {
                                "id": "color-1",
                                "name": "color1",
                                "value": "color-1",
                                 "checked": "checked",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-2",
                                "name": "color2",
                                "value": "color-2",
                               
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-3",
                                "name": "color3",
                                "value": "color-3",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-4",
                                "name": "color4",
                                "value": "color-4",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-5",
                                "name": "color5",
                                "value": "color-5",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-6",
                                "name": "color6",
                                "value": "color-6",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-7",
                                "name": "color7",
                                "value": "color-7",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-8",
                                "name": "color8",
                                "value": "color-8",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-9",
                                "name": "color9",
                                "value": "color-9",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-10",
                                "name": "color10",
                                "value": "color-10",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-11",
                                "name": "color11",
                                "value": "color-11",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            }
                        ],
                        "sizeTitle":"Size",
                        "sizeList": [
                            {
                                "label": "xs",
                                "id": "value1",
                                "name": "value1",
                                "checked": "checked"
                            },
                            {
                                "label": "S",
                                "id": "value1",
                                "name": "value1"
                                
                            },
                            {
                                "label": "M",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "L",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "XL",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "2XL",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "3XL",
                                "id": "value1",
                                "name": "value1"
                            }
                        ]
                    },
                    {
                       "productName": "Men's Soft-Style™ T-Shirt - 64000",
                       "productImg": "s-product2.jpg",
                       "useBtn": "use this product",
                       "descrptiontitle": "Decription",
                        "productDescription": [
                            {
                                "detailItem": "Deluxe 30s Soft style yarns",
                            },
                            {
                                "detailItem": "Seamless twin needle 3/4 collar",
                            },
                            {
                                "detailItem": "Taped neck and shoulders",
                            },
                            {
                                "detailItem": "Rolled forward shoulders for better fit",
                            },
                            {
                                "detailItem": "Hemmed sleeves",
                            },
                            {
                                "detailItem": "Twin needle sleeve and bottom hems",
                            },
                            {
                                "detailItem": "Quarter-turned to eliminate centre crease",
                            }
                        ],
                        "colorTitle":"Color",
                        "colorList": [
                            {
                                "id": "color-1",
                                "name": "color1",
                                "value": "color-1",
                                 "checked": "checked",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-2",
                                "name": "color2",
                                "value": "color-2",
                               
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-3",
                                "name": "color3",
                                "value": "color-3",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-4",
                                "name": "color4",
                                "value": "color-4",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-5",
                                "name": "color5",
                                "value": "color-5",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-6",
                                "name": "color6",
                                "value": "color-6",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-7",
                                "name": "color7",
                                "value": "color-7",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            }
                            
                        ],
                        "sizeTitle":"Size",
                        "sizeList": [
                            {
                                "label": "xs",
                                "id": "value1",
                                "name": "value1",
                                "checked": "checked"
                            },
                            {
                                "label": "S",
                                "id": "value1",
                                "name": "value1"
                                
                            },
                            {
                                "label": "M",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "L",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "XL",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "2XL",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "3XL",
                                "id": "value1",
                                "name": "value1"
                            }
                        ]
                    },
                    {
                       "productName": "Men's Soft Style V-Neck T-Shirt - 64V00",
                       "productImg": "s-product3.jpg",
                       "useBtn": "use this product",
                       "descrptiontitle": "Decription",
                        "productDescription": [
                            {
                                "detailItem": "Deluxe 30s Soft style yarns",
                            },
                            {
                                "detailItem": "Seamless twin needle 3/4 collar",
                            },
                            {
                                "detailItem": "Taped neck and shoulders",
                            },
                            {
                                "detailItem": "Rolled forward shoulders for better fit",
                            },
                            {
                                "detailItem": "Hemmed sleeves",
                            },
                            {
                                "detailItem": "Twin needle sleeve and bottom hems",
                            },
                            {
                                "detailItem": "Quarter-turned to eliminate centre crease",
                            }
                        ],
                        "colorTitle":"Color",
                        "colorList": [
                            {
                                "id": "color-5",
                                "name": "color5",
                                "value": "color-5",
                                 "checked": "checked",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-6",
                                "name": "color6",
                                "value": "color-6",
                               
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-7",
                                "name": "color7",
                                "value": "color-7",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-8",
                                "name": "color8",
                                "value": "color-8",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-9",
                                "name": "color9",
                                "value": "color-9",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-10",
                                "name": "color10",
                                "value": "color-10",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-11",
                                "name": "color11",
                                "value": "color-11",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            }
                            
                        ],
                        "sizeTitle":"Size",
                        "sizeList": [
                            {
                                "label": "xs",
                                "id": "value1",
                                "name": "value1",
                                "checked": "checked"
                            },
                            {
                                "label": "S",
                                "id": "value1",
                                "name": "value1"
                                
                            },
                            {
                                "label": "M",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "L",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "XL",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "2XL",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "3XL",
                                "id": "value1",
                                "name": "value1"
                            }
                        ]
                    },
                    {
                       "productName": "Men's Soft Style Long Sleeve T-Shirt",
                       "productImg": "s-product1.jpg",
                       "useBtn": "use this product",
                       "descrptiontitle": "Decription",
                        "productDescription": [
                            {
                                "detailItem": "Deluxe 30s Soft style yarns",
                            },
                            {
                                "detailItem": "Seamless twin needle 3/4 collar",
                            },
                            {
                                "detailItem": "Taped neck and shoulders",
                            },
                            {
                                "detailItem": "Rolled forward shoulders for better fit",
                            },
                            {
                                "detailItem": "Hemmed sleeves",
                            },
                            {
                                "detailItem": "Twin needle sleeve and bottom hems",
                            },
                            {
                                "detailItem": "Quarter-turned to eliminate centre crease",
                            }
                        ],
                        "colorTitle":"Color",
                        "colorList": [
                            {
                                "id": "color-1",
                                "name": "color1",
                                "value": "color-1",
                                 "checked": "checked",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-2",
                                "name": "color2",
                                "value": "color-2",
                               
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-3",
                                "name": "color3",
                                "value": "color-3",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-4",
                                "name": "color4",
                                "value": "color-4",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-5",
                                "name": "color5",
                                "value": "color-5",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-6",
                                "name": "color6",
                                "value": "color-6",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-7",
                                "name": "color7",
                                "value": "color-7",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                             {
                                "id": "color-8",
                                "name": "color8",
                                "value": "color-8",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-9",
                                "name": "color9",
                                "value": "color-9",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-10",
                                "name": "color10",
                                "value": "color-10",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            },
                            {
                                "id": "color-11",
                                "name": "color11",
                                "value": "color-11",
                                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
                            }
                            
                        ],
                        "sizeTitle":"Size",
                        "sizeList": [
                            {
                                "label": "xs",
                                "id": "value1",
                                "name": "value1",
                                "checked": "checked"
                            },
                            {
                                "label": "S",
                                "id": "value1",
                                "name": "value1"
                                
                            },
                            {
                                "label": "M",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "L",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "XL",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "2XL",
                                "id": "value1",
                                "name": "value1"
                            },
                            {
                                "label": "3XL",
                                "id": "value1",
                                "name": "value1"
                            }
                        ]
                    }
        ]
    };  
    
/*----------- Product List Page -------------------*/

/*-------- Product List Banner ----------*/
    var productlistBanner = {
            "pagetitle": "Product List",
            "title": "Home",
            "link": "index.html"
    };

/*-------- Product List Section ----------*/
    var productList = {
        "searchTitle": "search",
        "categoriesTitle": "Categories",
        "menu": [
            {
                "menulink": "#",
                "menu": "Drinkware",
                "innermenu": [{
                        "menulink": "BB_product-list.html",
                        "menu": "Sports-water bottles"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Events & Festivals"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Copper & Vacuum insulation"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "On-the-go"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Ceramics"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Glassware"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Coffee & Tea"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Gift sets & Packaging"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Sports and Leisure",
                "innermenu": [{
                        "menulink": "BB_product-list.html",
                        "menu": "Sunglasses"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Balls"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Fitness & Sport"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Beach Balls"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Outdoor Items"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Beach Items"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Cycling accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Travel Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Binoculars"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "BBQ Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Picnic Accessories"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Home & Kitchen",
                "innermenu": [{
                        "menulink": "BB_product-list.html",
                        "menu": "Home Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Aprons"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Wine Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Chef's Knives"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Lunch Boxes"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Candles"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Kitchen Linen"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Bottle Openers & Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Kitchenware"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Cutting Boards"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Serving Sets"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Glasses & Carafes"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Clocks & Weather Stations"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Bags",
                "innermenu": [{
                        "menulink": "BB_product-list.html",
                        "menu": "Cooler bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Travel Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Wallets & Card Wallets"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Backpacks"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Laptop & Tablet bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Shopping & Tote Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Conference bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Messenger & Shoulder Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Sport & Gym bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Trolleys & Suitcases"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Drawstring Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Cotton Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Toiletry Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Travel bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Sailor Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Foldable Bags"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Toys & Games",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Outdoor Games"
                    },
                    {
                        "menulink": "#",
                        "menu": "Bubble Blowers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Indoor Games"
                    },
                    {
                        "menulink": "#",
                        "menu": "Colouring Sets for Kids"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Tools & Car Accessories",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Reflective Items"
                    },
                    {
                        "menulink": "#",
                        "menu": "Multitools"
                    },
                    {
                        "menulink": "#",
                        "menu": "Safety Vests"
                    },
                    {
                        "menulink": "#",
                        "menu": "Car Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pocket Knives"
                    },
                    {
                        "menulink": "#",
                        "menu": "Lamps"
                    },
                    {
                        "menulink": "#",
                        "menu": "Tool sets"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Technology ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Telephone & Tablet Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Gadgets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Earbuds"
                    },
                    {
                        "menulink": "#",
                        "menu": "Speakers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Headphones"
                    },
                    {
                        "menulink": "#",
                        "menu": "Computer Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Powerbanks"
                    },
                    {
                        "menulink": "#",
                        "menu": "USB Flash Drives"
                    },
                    {
                        "menulink": "#",
                        "menu": "USB Hubs"
                    },
                    {
                        "menulink": "#",
                        "menu": "Cameras"
                    },
                    {
                        "menulink": "#",
                        "menu": "Wireless Charging"
                    },
                    {
                        "menulink": "#",
                        "menu": "Smartwatches"
                    },
                    {
                        "menulink": "#",
                        "menu": "Virtual Reality"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Umbrellas ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Rain Ponchos"
                    },
                    {
                        "menulink": "#",
                        "menu": "Folding Umbrellas"
                    },
                    {
                        "menulink": "#",
                        "menu": "Standard Umbrellas"
                    },
                    {
                        "menulink": "#",
                        "menu": "Golf Umbrellas"
                    },
                    {
                        "menulink": "#",
                        "menu": "Special Umbrellas"
                    },
                    {
                        "menulink": "#",
                        "menu": "Storm Umbrellas"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Popular  ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Sunglasses"
                    },
                    {
                        "menulink": "#",
                        "menu": "Ballpoint Pens"
                    },
                    {
                        "menulink": "#",
                        "menu": "Shopping & Tote Bags"
                    },
                    {
                        "menulink": "#",
                        "menu": "Water Bottles"
                    },
                    {
                        "menulink": "#",
                        "menu": "Keychains & Keyrings"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Health & Personal Care  ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "First Aid Kits"
                    },
                    {
                        "menulink": "#",
                        "menu": "Personal Care"
                    },
                    {
                        "menulink": "#",
                        "menu": "Toiletry Bags"
                    },
                    {
                        "menulink": "#",
                        "menu": "Lip Balms"
                    },
                    {
                        "menulink": "#",
                        "menu": "Wellness & Manicure Sets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Towels & Bathrobes"
                    },
                    {
                        "menulink": "#",
                        "menu": "Hot & Cold Packs"
                    },
                    {
                        "menulink": "#",
                        "menu": "Protection"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Giveaways ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Keychains & Keyrings"
                    },
                    {
                        "menulink": "#",
                        "menu": "Stress Balls"
                    },
                    {
                        "menulink": "#",
                        "menu": "Lanyards"
                    },
                    {
                        "menulink": "#",
                        "menu": "Badge Holders"
                    },
                    {
                        "menulink": "#",
                        "menu": "Wristbands"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Office  ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Business Card Holders"
                    },
                    {
                        "menulink": "#",
                        "menu": "Desk Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Notebooks"
                    },
                    {
                        "menulink": "#",
                        "menu": "Sticky Notes"
                    },
                    {
                        "menulink": "#",
                        "menu": "Portfolios"
                    },
                    {
                        "menulink": "#",
                        "menu": "Moleskine"
                    },
                    {
                        "menulink": "#",
                        "menu": "Laptop & Tablet bags"
                    },
                    {
                        "menulink": "#",
                        "menu": "Calculators"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Pens & Writing  ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Ballpoint Pens"
                    },
                    {
                        "menulink": "#",
                        "menu": "Rollerball Pens"
                    },
                    {
                        "menulink": "#",
                        "menu": "Colouring sets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pencils"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pen sets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Markers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Fountain Pens"
                    },
                    {
                        "menulink": "#",
                        "menu": "Other Pens & Writing Accessories"
                    }

                ]
            },
            {
                "menu": "Gift Packaging"
            },
            {
                "menulink": "#",
                "menu": "Apparel",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Headwear"
                    },
                    {
                        "menulink": "#",
                        "menu": "Textile Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Aprons"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pencils"
                    },
                    {
                        "menulink": "#",
                        "menu": "T-shirts"
                    },
                    {
                        "menulink": "#",
                        "menu": "Polos"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pullovers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Jackets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Sweaters"
                    },
                    {
                        "menulink": "#",
                        "menu": "Bodywarmers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Fleece"
                    },
                    {
                        "menulink": "#",
                        "menu": "Shirts"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Paper (paper printed products)",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Sticky Notes"
                    },
                    {
                        "menulink": "#",
                        "menu": "Desk pads"
                    },
                    {
                        "menulink": "#",
                        "menu": "Notepads"
                    },
                    {
                        "menulink": "#",
                        "menu": "Memo Blocks"
                    },
                    {
                        "menulink": "#",
                        "menu": "Notebooks"
                    }


                ]
            }
        ],
        "priceTitle": "Price",
        "sizeTitle": "Size" ,
        "sizeList": [
        {
                "label": "XS",
                "checked": "checked"
            },
            {
                "label": "S"
            },
            {
                "label": "M"
            },
            {
                "label": "XS"
            },
            {
                "label": "L"
            },
            {
                "label": "XL"
            },
            {
                "label": "2XL"
            },
            {
                "label": "3XL"
            }
        ] ,
        "colorTitle": "color",
        "colorList": [
            {
                "id": "color-1",
                "name": "color",
                "value": "color-1",
                "checked": "checked",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-2",
                "name": "color-2",
                "value": "color-2",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-3",
                "name": "color-3",
                "value": "color-3",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-4",
                "name": "color-4",
                "value": "color-4",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-5",
                "name": "color-5",
                "value": "color-5",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-6",
                "name": "color-6",
                "value": "color-6",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-7",
                "name": "color-7",
                "value": "color-7",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
             {
                "id": "color-8",
                "name": "color-8",
                "value": "color-8",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
             {
                "id": "color-9",
                "name": "color-9",
                "value": "color-9",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
             {
                "id": "color-10",
                "name": "color-10",
                "value": "color-10",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-11",
                "name": "color-11",
                "value": "color-11",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
        ],
           "featuredTitle": "FEATURED PRODUCTS",
        "productList": [
        {
                "productListItem": [{
                        "productImg": "f-1.jpg",
                        "productName": "Flared Shift Dress",
                        "productPrice": "40.00"
                    },
                    {
                        "productImg": "f-2.jpg",
                        "productName": "Belts",
                        "productPrice": "20.00"
                    },
                    {
                        "productImg": "f-1.jpg",
                        "productName": "Smart Music Box",
                        "productPrice": "100.00"
                    }
                ]
            },
            {
                "productListItem": [{
                        "productImg": "f-3.webp",
                        "productName": "Smart Music Box",
                        "productPrice": "100.00"
                    },
                    {
                        "productImg": "f-1.jpg",
                        "productName": "Flared Shift Dress",
                        "productPrice": "40.00"
                    },
                    {
                        "productImg": "f-2.jpg",
                        "productName": "Belts",
                        "productPrice": "20.00"
                    }
                ]
            }

        ],
         "featured": [
            {
                "productimg": "product-7.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "title": "Kivi 10W limestone/cork wireless charging pad",
                "product_price": "120.30"
            },
            {
                "productimg": "product-8.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "title": "IM ballpoint pen",
                "product_price": "50.60"
            },
            {
                "productimg": "product-9.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "title": "Renzo 30 cm plastic ruler",
                "product_price": "40.00"
            },
            {
                "productimg": "product-10.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "title": "Darton 6 panel sandwich cap",
                "product_price": "110.10"
            },
            {
                "productimg": "product-11.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "title": "Open full zip hooded sweater",
                "product_price": "100.00"
            },
            {
                "productimg": "product-12.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "title": "Ace short sleeve kids t-shirt",
                "product_price": "250.60"
            },
            {
                "productimg": "product-2.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "title": "Coma 6000 mAh wireless power bank",
                "product_price": "150.60"
            },
            {
                "productimg": "product-2.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "title": "Coma 6000 mAh wireless power bank",
                "product_price": "150.60"
            },
            {
                "productimg": "product-2.jpg",
                "productlink": "BB_add-cart.html",
                "quick_btn": "Quick View",
                "quick_btn_link": "#",
                "title": "Coma 6000 mAh wireless power bank",
                "product_price": "150.60"
            }
        ],
        "sortByTitle": "sort by",
        "sortByList":[
            {
               "sortByListItem": "Short by Best Sell", 
               "value":"1",
               "selected":"selected"
            },
            {
               "sortByListItem": "Short by New Item", 
               "value":"2"
            },
            {
               "sortByListItem": "Short by Popularity", 
               "value":"3"
            },
            {
               "sortByListItem": "Short by Average review", 
               "value":"4"
            }
        ],
        "showTitle": "Show",
        "showList":[
            {
               "showItem": "9", 
               "selected":"selected",
               "value":"1"
            },
            {
               "showItem": "25", 
               "value":"2"
            },
            {
               "showItem": "50", 
               "value":"3"
            },
            {
               "showItem": "75", 
               "value":"4"
            }
        ]

    };  
    
/*-------- Product List Sidebar Mobile Menu ----------*/  
    var productListMobile = {
        "searchTitle": "search",
        "categoriesTitle": "Categories",
        "menu": [
            {
                "menulink": "#",
                "menu": "Drinkware",
                "innermenu": [{
                        "menulink": "BB_product-list.html",
                        "menu": "Sports-water bottles"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Events & Festivals"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Copper & Vacuum insulation"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "On-the-go"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Ceramics"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Glassware"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Coffee & Tea"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Gift sets & Packaging"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Sports and Leisure",
                "innermenu": [{
                        "menulink": "BB_product-list.html",
                        "menu": "Sunglasses"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Balls"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Fitness & Sport"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Beach Balls"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Outdoor Items"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Beach Items"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Cycling accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Travel Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Binoculars"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "BBQ Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Picnic Accessories"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Home & Kitchen",
                "innermenu": [{
                        "menulink": "BB_product-list.html",
                        "menu": "Home Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Aprons"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Wine Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Chef's Knives"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Lunch Boxes"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Candles"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Kitchen Linen"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Bottle Openers & Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Kitchenware"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Cutting Boards"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Serving Sets"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Glasses & Carafes"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Clocks & Weather Stations"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Bags",
                "innermenu": [{
                        "menulink": "BB_product-list.html",
                        "menu": "Cooler bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Travel Accessories"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Wallets & Card Wallets"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Backpacks"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Laptop & Tablet bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Shopping & Tote Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Conference bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Messenger & Shoulder Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Sport & Gym bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Trolleys & Suitcases"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Drawstring Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Cotton Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Toiletry Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Travel bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Sailor Bags"
                    },
                    {
                        "menulink": "BB_product-list.html",
                        "menu": "Foldable Bags"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Toys & Games",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Outdoor Games"
                    },
                    {
                        "menulink": "#",
                        "menu": "Bubble Blowers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Indoor Games"
                    },
                    {
                        "menulink": "#",
                        "menu": "Colouring Sets for Kids"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Tools & Car Accessories",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Reflective Items"
                    },
                    {
                        "menulink": "#",
                        "menu": "Multitools"
                    },
                    {
                        "menulink": "#",
                        "menu": "Safety Vests"
                    },
                    {
                        "menulink": "#",
                        "menu": "Car Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pocket Knives"
                    },
                    {
                        "menulink": "#",
                        "menu": "Lamps"
                    },
                    {
                        "menulink": "#",
                        "menu": "Tool sets"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Technology ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Telephone & Tablet Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Gadgets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Earbuds"
                    },
                    {
                        "menulink": "#",
                        "menu": "Speakers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Headphones"
                    },
                    {
                        "menulink": "#",
                        "menu": "Computer Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Powerbanks"
                    },
                    {
                        "menulink": "#",
                        "menu": "USB Flash Drives"
                    },
                    {
                        "menulink": "#",
                        "menu": "USB Hubs"
                    },
                    {
                        "menulink": "#",
                        "menu": "Cameras"
                    },
                    {
                        "menulink": "#",
                        "menu": "Wireless Charging"
                    },
                    {
                        "menulink": "#",
                        "menu": "Smartwatches"
                    },
                    {
                        "menulink": "#",
                        "menu": "Virtual Reality"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Umbrellas ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Rain Ponchos"
                    },
                    {
                        "menulink": "#",
                        "menu": "Folding Umbrellas"
                    },
                    {
                        "menulink": "#",
                        "menu": "Standard Umbrellas"
                    },
                    {
                        "menulink": "#",
                        "menu": "Golf Umbrellas"
                    },
                    {
                        "menulink": "#",
                        "menu": "Special Umbrellas"
                    },
                    {
                        "menulink": "#",
                        "menu": "Storm Umbrellas"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Popular  ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Sunglasses"
                    },
                    {
                        "menulink": "#",
                        "menu": "Ballpoint Pens"
                    },
                    {
                        "menulink": "#",
                        "menu": "Shopping & Tote Bags"
                    },
                    {
                        "menulink": "#",
                        "menu": "Water Bottles"
                    },
                    {
                        "menulink": "#",
                        "menu": "Keychains & Keyrings"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Health & Personal Care  ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "First Aid Kits"
                    },
                    {
                        "menulink": "#",
                        "menu": "Personal Care"
                    },
                    {
                        "menulink": "#",
                        "menu": "Toiletry Bags"
                    },
                    {
                        "menulink": "#",
                        "menu": "Lip Balms"
                    },
                    {
                        "menulink": "#",
                        "menu": "Wellness & Manicure Sets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Towels & Bathrobes"
                    },
                    {
                        "menulink": "#",
                        "menu": "Hot & Cold Packs"
                    },
                    {
                        "menulink": "#",
                        "menu": "Protection"
                    }
                ]
            },
            {
                "menulink": "#",
                "menu": "Giveaways ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Keychains & Keyrings"
                    },
                    {
                        "menulink": "#",
                        "menu": "Stress Balls"
                    },
                    {
                        "menulink": "#",
                        "menu": "Lanyards"
                    },
                    {
                        "menulink": "#",
                        "menu": "Badge Holders"
                    },
                    {
                        "menulink": "#",
                        "menu": "Wristbands"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Office  ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Business Card Holders"
                    },
                    {
                        "menulink": "#",
                        "menu": "Desk Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Notebooks"
                    },
                    {
                        "menulink": "#",
                        "menu": "Sticky Notes"
                    },
                    {
                        "menulink": "#",
                        "menu": "Portfolios"
                    },
                    {
                        "menulink": "#",
                        "menu": "Moleskine"
                    },
                    {
                        "menulink": "#",
                        "menu": "Laptop & Tablet bags"
                    },
                    {
                        "menulink": "#",
                        "menu": "Calculators"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Pens & Writing  ",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Ballpoint Pens"
                    },
                    {
                        "menulink": "#",
                        "menu": "Rollerball Pens"
                    },
                    {
                        "menulink": "#",
                        "menu": "Colouring sets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pencils"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pen sets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Markers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Fountain Pens"
                    },
                    {
                        "menulink": "#",
                        "menu": "Other Pens & Writing Accessories"
                    }

                ]
            },
            {
                "menu": "Gift Packaging"
            },
            {
                "menulink": "#",
                "menu": "Apparel",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Headwear"
                    },
                    {
                        "menulink": "#",
                        "menu": "Textile Accessories"
                    },
                    {
                        "menulink": "#",
                        "menu": "Aprons"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pencils"
                    },
                    {
                        "menulink": "#",
                        "menu": "T-shirts"
                    },
                    {
                        "menulink": "#",
                        "menu": "Polos"
                    },
                    {
                        "menulink": "#",
                        "menu": "Pullovers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Jackets"
                    },
                    {
                        "menulink": "#",
                        "menu": "Sweaters"
                    },
                    {
                        "menulink": "#",
                        "menu": "Bodywarmers"
                    },
                    {
                        "menulink": "#",
                        "menu": "Fleece"
                    },
                    {
                        "menulink": "#",
                        "menu": "Shirts"
                    }

                ]
            },
            {
                "menulink": "#",
                "menu": "Paper (paper printed products)",
                "innermenu": [{
                        "menulink": "#",
                        "menu": "Sticky Notes"
                    },
                    {
                        "menulink": "#",
                        "menu": "Desk pads"
                    },
                    {
                        "menulink": "#",
                        "menu": "Notepads"
                    },
                    {
                        "menulink": "#",
                        "menu": "Memo Blocks"
                    },
                    {
                        "menulink": "#",
                        "menu": "Notebooks"
                    }


                ]
            }
        ],
        "priceTitle": "Price",
        "sizeTitle": "Size" ,
        "sizeList": [
        {
                "label": "XS",
                "checked": "checked"
            },
            {
                "label": "S"
            },
            {
                "label": "M"
            },
            {
                "label": "XS"
            },
            {
                "label": "L"
            },
            {
                "label": "XL"
            },
            {
                "label": "2XL"
            },
            {
                "label": "3XL"
            }
        ] ,
        "colorTitle": "color",
        "colorList": [
            {
                "id": "color-1",
                "name": "color",
                "value": "color-1",
                "checked": "checked",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-2",
                "name": "color-2",
                "value": "color-2",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-3",
                "name": "color-3",
                "value": "color-3",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-4",
                "name": "color-4",
                "value": "color-4",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-5",
                "name": "color-5",
                "value": "color-5",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-6",
                "name": "color-6",
                "value": "color-6",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-7",
                "name": "color-7",
                "value": "color-7",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
             {
                "id": "color-8",
                "name": "color-8",
                "value": "color-8",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
             {
                "id": "color-9",
                "name": "color-9",
                "value": "color-9",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
             {
                "id": "color-10",
                "name": "color-10",
                "value": "color-10",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
            {
                "id": "color-11",
                "name": "color-11",
                "value": "color-11",
                "colorImg":"https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/check-icn.svg"
            },
        ],
           "featuredTitle": "FEATURED PRODUCTS",
        "productList": [
        {
                "productListItem": [{
                        "productImg": "f-1.jpg",
                        "productName": "Flared Shift Dress",
                        "productPrice": "40.00"
                    },
                    {
                        "productImg": "f-2.jpg",
                        "productName": "Belts",
                        "productPrice": "20.00"
                    },
                    {
                        "productImg": "f-1.jpg",
                        "productName": "Smart Music Box",
                        "productPrice": "100.00"
                    }
                ]
            },
            {
                "productListItem": [{
                        "productImg": "f-3.webp",
                        "productName": "Smart Music Box",
                        "productPrice": "100.00"
                    },
                    {
                        "productImg": "f-1.jpg",
                        "productName": "Flared Shift Dress",
                        "productPrice": "40.00"
                    },
                    {
                        "productImg": "f-2.jpg",
                        "productName": "Belts",
                        "productPrice": "20.00"
                    }
                ]
            }

        ]

    };  
    
/*----------- Decoration Page -------------------*/

    var productDecoration = {
        "settingTitle": "Settings",
        "resetTitle": "Reset",
        "resetText": "You can choose to add unlimited fext or Image below.",
        "addTitle": "Add Text",
        "text": "Text",
        "font": "Font",
        "defaultFont": "Arial",
         "fontList": [
            {
                "fontName":"Arial"
            },
            {
                "fontName":"Impact"
            },
            {
                "fontName":"Lobster"
            },
            {
                "fontName":"Indie Flower"
            },
            {
                "fontName":"Gloria Hallelujah"
            }
        ],
         "color": "Color",
        "defaultColor": "Red",
        "colorList": [
            {
                "colorName":"Black"
            },
            {
                "colorName":"White"
            },
            {
                "colorName":"Red"
            },
            {
                "colorName":"Orange"
            },
            {
                "colorName":"Blue"
            },
            {
                "colorName":"Green"
            },
            {
                "colorName":"Aqua"
            }
        ],
         "addBtn": "Add Text",
        "addImage": "Add Image",
        "uploadOption1": "from Library",
        "uploadOption2": "Upload Image",
        "fileList": "Supported files: JPG, JPEG, PNG",
        "optionTitle": "location",
        "optionList": [
            {
                "optionOnclickImage":"cart-33.jpg",
                "optionImage":"cart-1.jpg",
                "optionName":"Front"
            },
            {
                "optionOnclickImage":"cart-31.jpg",
                "optionImage":"cart-3.jpg",
                "optionName":"back"
            },
            {
                "optionOnclickImage":"cart-32.jpg",
                "optionImage":"cart-4.jpg",
                "optionName":"Left Sleeve"
            },
            {
                "optionOnclickImage":"cart-33.jpg",
                "optionImage":"cart-5.jpg",
                "optionName":"right Sleeve"
            }
        ],
        "editmainTitle": "EDIT",
        "editText": "Select object to edit or Add new object from left menu.",
        "editTitle": "EDIT : Text",
        "cartBtn":"Add To Cart",

        "libraryTitle":"Choose our high-quality image to add",
        "libraryImgList":[
            {
                "libraryImg":"https://blog.spoongraphics.co.uk/wp-content/uploads/2010/badge/chrisspooner-emblem.png",
            },
            {
                "libraryImg":"http://static.freepik.com/free-photo/tribal-star-shape-vector_91-3339.jpg",
            },
            {
                "libraryImg":"http://cdn.vectorstock.com/i/composite/26,74/apple-shape-vector-752674.jpg",
            },
            {
                "libraryImg":"http://static.freepik.com/free-photo/tribal-star-shape-vector_91-3339.jpg",
            },
            {
                "libraryImg":"https://blog.spoongraphics.co.uk/wp-content/uploads/2010/badge/chrisspooner-emblem.png",
            }
        ],

        "removeBtn":"Remove Object",
        "delConfirmText":"Are you sure you want to remove this object?",
        "cancelBtn":"Cancel",
        "deleteBtn":"Delete !"
    };                       