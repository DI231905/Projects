<!DOCTYPE html>
<html>
<head>
  <title>Text Tiles</title>
  <link rel="stylesheet" type="text/css" href="/css/home.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
   <link rel="icon" type="image/png" href="image/logo1.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">


    <div class="main-header" id="dynamic">
        <div class="subheader">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="social-icon">
                           
                            <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($p->id==1): ?>

                            <a href="<?php echo e($p->phone); ?>"><i class="fas fa-phone-alt"></i><span><?php echo e($p->phone); ?></span></a>
                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </li>
                            <li><a href="<?php echo e($fb_url); ?>"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="<?php echo e($india_mart_url); ?>"> <img src="/image/m.png"></a> </li>
                        </ul>   
                    </div>
                </div>
            </div>
        </div>
         <div class="co_header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-6">
                        <div class="logo">
                            <img src="/image/logo.png">
                        </div>
                        <div class="logo1">
                            <img src="/image/logo.png">
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-9 col-6">
                        <div class="menu">
                             <a class="active_1" href="<?php echo e(url('/')); ?>">Home</a>
                           <!--  <a href="<?php echo e(url('/About')); ?>">About</a> -->
                            <a href="<?php echo e(url('/Texttile')); ?>">Products</a>
                            <a href="<?php echo e(url('/Career')); ?>">Career</a>
                            <a href="<?php echo e(url('/ContactUs')); ?>">Contact Us</a>
                        </div>
                        <div class="mobile-menu">
                        <div id="mySidepanel" class="sidepanel">
                            <div class="m_menu">
                                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a>    
                                <a class="link" href="<?php echo e(url('/')); ?>">Home</a>
                                <a class="link"href="<?php echo e(url('/Texttile')); ?>">Product</a>
                                <a class="link" href="<?php echo e(url('/Career')); ?>">Career</a>
                                <a class="link" href="<?php echo e(url('/ContactUs')); ?>">Contact Us</a>
                            </div>
                        </div>
                        <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                    </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
<div class="combo">
  <?php echo $__env->yieldContent('content'); ?>
</div>

    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">
                    <div class="main-footer">
                        <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="/image/logo1.png"></a></h2>
                        <p>We assure to provide hassle-free services and aim for long-term business relationships.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-12">
                    <div class="row">
                        <div class="col-md-6 col-6">
                            <h2 class="title1">Company</h2>
                            <div class="footer-widget">
                                <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i>  <a href="<?php echo e(url('/Career')); ?>">Career</a></li>
                                
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="#">All Product</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/ContactUs')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-6">
                            <h2 class="title1">Services</h2>
                            <div class="footer-widget">
                                <ul>
                                   <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/')); ?>">We Export Globally</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                        <li><i class="fa fa-home" aria-hidden="true"></i>
                            <p><?php echo nl2br(e($address)); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                         <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                            <p><a href="tel: <?php echo e($p->phone); ?>"><?php echo e($p->phone); ?></a></p>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                   
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Raj Synthetics  © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                      <ul class="social-icon">
                        
                            <li><a href="<?php echo e($fb_url); ?>"><i style="color: black" class="fab fa-facebook-f"></i></a></li>
                            <li><a href="<?php echo e($india_mart_url); ?>"> <img src="/image/m.png"></a> </li>
                            
                        </ul>   
            </div>
        </div>
        </div>
    </div>
    <div class="copy">
        <a class="up-btn" href="#">
            <span class="far fa-angle-up"></span>
        </a>
    </div>


    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script>
    <script type="text/javascript">
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });

        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });


        $(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

        $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

   
    </script>

   </body>
 </html><?php /**PATH C:\xampp\htdocs\rajsynthetics\resources\views/layouts/app.blade.php ENDPATH**/ ?>