

<?php $__env->startSection('content'); ?>
<div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/breadcrumb-bg.jpg">
    	    </div>
    	    <div class="about1">
    	    	<div class="container">
    		        <h2>Contact</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">Contact</li>
    		        </ul>
    		    </div>
    	    </div>
    	</div>
    </div>
    <div class="co_part-3">
	    <div class="container">
	    	<div class="part-3">
	    		<div class="set-part-3">
	    			<div class="contact-icon">
	    				<i class="fa fa-map"></i>
	    			</div>
	    			<div class="add">
	    				<h2>our office:</h2>
	    				<p><?php echo e($address); ?></p>
	    			</div>
	    		</div>
	    		<div class="set-part-3">
	    			<div class="contact-icon">
	    				<i class="fa fa-phone"></i>
	    			</div>
	    			<div class="add">
	    				<h2>contact number:</h2>

	    				  <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <p><?php echo e($p->phone); ?></p>      

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          


	    				
	    			</div>
	    		</div>
	    		<div class="set-part-3">
	    			<div class="contact-icon">
	    				<i class="fa fa-envelope"></i>
	    			</div>
	    			<div class="add">
	    				<h2>Email us:</h2>
	    				<p><?php echo e($email); ?></p>
	    			</div>
	    		</div>
	    	</div>
    	</div>
    </div>
      <?php if($message = Session::get('error')): ?>
            <div  id="hideDiv" class="alert alert-success alert-block" >
                <!--     <input type="text" class="close" data-dismiss="alert"></input> -->
                <strong style="padding-top : 5px !important; display: inline-block;"><?php echo e($message); ?></strong>
             </div>
           <?php endif; ?>

    <div class="co_form1">
    	<div class="container">
    		<div class="row">

    			<?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 
    			<div class="col-lg-6 col-md-6 col-12">
    				<h2>Contact Us</h2>
    				<form class="form" action="<?php echo e(url('/Contactusfrom')); ?>" method="post">
    					<?php echo csrf_field(); ?>
	    		        <div class="port">
	    			        <div class="text2">
	    				        <input type="text" placeholder="Name" name="name" value="" required>
	    			        </div>
	    		        </div>
	    		        <div class="port">
	    		        	<div class="text2">
	    		        		<input type="text" placeholder="Email" name="email" value="" required>
	    		        	</div>
	    		        </div>
	    		        <div class="port">
	    		        	<div class="text2">
	    		        		<input type="text" placeholder="Subject" name="subject" value="" required>
	    		        	</div>
	    		        </div>
	    		        <div class="text1">
	    		        	<textarea placeholder="Your Message" name="description" value="" required></textarea>
	    		        </div>
    			        <div class="sub">
    			        	<input type="submit" value="Send Message">
    			        </div>
    		        </form>
    			</div>
    			<div class="col-lg-6 col-md-6 col-12">
    				<div class="map1">
    	                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d119066.41264385462!2d72.75225630862496!3d21.15934583206193!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04e59411d1563%3A0xfe4558290938b042!2sSurat%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1624450314562!5m2!1sen!2sin"  style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
    			</div>
    		</div>
    	</div>
    </div>

     <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rajsynthetics\resources\views/contactus.blade.php ENDPATH**/ ?>