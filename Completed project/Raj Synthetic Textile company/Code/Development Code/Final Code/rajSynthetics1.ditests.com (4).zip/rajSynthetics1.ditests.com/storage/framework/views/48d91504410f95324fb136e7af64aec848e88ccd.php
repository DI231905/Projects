

<?php $__env->startSection('content'); ?>
<div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/career-bg.jpg">
    	    </div>
    	    <div class="about1">
    	    	<div class="container">
    		        <h2>Career</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">Career</li>
    		        </ul>
    		    </div>
    	    </div>
    	</div>
</div>
	<div class="co_enquiry1">
		  <?php if($errors->any()): ?>
						<div class="alert alert-danger">
							<ul>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li  style="color:red;"><?php echo e($error); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					<?php endif; ?> 

	 <?php if(session()->has('error')): ?>
				   <div class="alert alert-success">
						<?php echo e(session()->get('error')); ?>

					</div>
				<?php endif; ?>

		<div class="container">
			<h2>Apply Now</h2>
			<form  method="POST" action="<?php echo e(url('/Application')); ?>" enctype="multipart/form-data"  class="enquiry-form">
				 <?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-12">
						<div class="text">
							<label>Name <b>*</b></label>
							<input type="text" placeholder="Enter Name" name="name" value="" required>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-12">
						<div class="text">
							<label>Enter Email <b>*</b></label>
							<input type="email" placeholder="Enter Email" name="email" value="" required>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-12">
						<div class="text">
							<label>Apply for <b>*</b></label>
							<input type="text" placeholder="Apply for" name="position" value="" required>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-12">
						<div class="text">
						 <label>Contact Number  <b>*</b></label>
						  <input type="number" placeholder="Contact Number " name="mobileno" value="" required>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-12">
						<div class="text">
							<label>Experiance <b>*</b></label>
							<input type="number" placeholder="Experiance" name="experience" value="" required>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-12">
						<div class="text">
							<label for="myfile">Select a file:</label>
							<input type="file" id="myfile" name="file" required>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-12">
						<div class="text">
							<label>Message <b>*</b></label>
							<textarea placeholder="Message" name="description" required></textarea>
						</div>
					</div>
				</div>
				<div class="button">
                    <span class="more"><input type="Submit" value="Submit" name=""></span>
                </div>
			</form>
		</div>
	</div>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/rajSynthetics1.ditests.com/resources/views/career.blade.php ENDPATH**/ ?>