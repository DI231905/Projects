

<?php $__env->startSection('content'); ?>

 <div class="co_part-2">
        <div class="fix-part-2">
            <div class="img1">
                <img src="image/breadcrumb-bg.jpg">
            </div>
            <div class="about1">
                <h2>About</h2>
                <ul type="none">
                    <li>Home</li>
                    <li><span class="fa fa-angle-right"></span></li>
                    <li class="bt">About</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="co_detail">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="detail-img">
                        <img src="image/about1_img1.jpg">
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="detail-info">
                        <h6>WHO WE ARE</h6>
                        <h2>An Ultimate Textile Brand in Market since 1970</h2>
                        <p>Indian weavers of designer of furnishing fabrics is a textile manufacturer founded in 1970 and renowned for new and stylish interpretations of natural & organic fabrics.</p>
                    </div>
                    <div class="detail-img-info">
                        <img src="image/about1_img2.jpg">
                        <h4>Our Fabric Textiles Services Manufacture Found In 1996</h4>
                    </div>
                    <ul class="checkbox">
                        <li>
                            <i class="far fa-check"></i>
                            <span>We check for your current dental situation and decide treatment</span>
                        </li>
                        <li>
                            <i class="far fa-check"></i>
                            <span>Our specialists will take care of your smile with dedication</span>
                        </li>
                        <li>
                            <i class="far fa-check"></i>
                            <span>We run periodic check-ups to ensure your teeth are good</span>
                        </li>
                    </ul>
                    <div class="button b-about">
                            <span class="more more1"><a href="<?php echo e(url('/Texttile')); ?>">More Details</a></span>
                            <span class="get1"><a href="<?php echo e(url('/ContactUs')); ?>">Contact</a></span>  
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
    <div class="co_vision">
        <div class="container">
            <div class="row">
                <div class="main-vision">
                    <div class="vision vision1">
                        <h2>Vision</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    </div>
                </div>
                <div class="main-vision">
                    <div class="vision">
                        <img src="image/vision1.jpg">
                    </div>
                </div>
                <div class="main-vision">
                    <div class="vision">
                        <img src="image/vision2.jpg">
                    </div>
                </div>
                <div class="main-vision">
                    <div class="vision vision2">
                        <h2>Mission</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
	
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rajsynthetics\resources\views/Aboutview.blade.php ENDPATH**/ ?>