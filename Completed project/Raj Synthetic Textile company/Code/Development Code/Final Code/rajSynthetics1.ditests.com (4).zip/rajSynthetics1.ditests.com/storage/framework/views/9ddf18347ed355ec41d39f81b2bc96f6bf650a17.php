

<?php $__env->startSection('content'); ?>
    <div class="co_part-2">
        <div class="fix-part-2">
            <div class="img1">
                <img src="image/dry-fruit.jpg">
            </div>
            <div class="about1">
                <div class="container">
                    <h2>Products</h2>
                    <ul type="none">
                       <li>Home</li>
                       <li><span class="fa fa-angle-right"></span></li>
                       <li class="bt">Saffroind Products</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_product1">
    	<div class="container">
            <div class="row">

             <?php $__currentLoopData = $saffroindproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span href="/uploads/<?php echo e($sp->image); ?>" data-toggle="lightbox" data-gallery="gallery" class="col-lg-4 col-md-6 col-12">
                    <div class="product-list">
                        <img src="/uploads/<?php echo e($sp->image); ?>" class="img-fluid">
                        <div class="product-info">
                            <h2><?php echo e($sp->name); ?></h2>
                            <div class="product-price">
                                <span> INR <?php echo e($sp->price); ?></span>
                                <!-- <del>$46.00</del> -->
                            </div>
                        </div>
                    </div>
                </span>
               
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
               
            </div> 

            <div class="custom_pagination text-center">
            <?php echo e($saffroindproduct->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
     
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rajsynthetics\resources\views/saffroindproduct.blade.php ENDPATH**/ ?>