<!DOCTYPE html>
<html>
<head>
    <title>Raj Synthetics</title>
    <link rel="stylesheet" type="text/css" href="/css/admin.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">       
      <link rel="icon" type="image/png" href="/image/logo1.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li  style="color:red;"><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?> 
    <div class="main-form">
        <div class="form">
            <h2>  UPDATE ADMIN CONTACT DETAIL</h2>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(url('admin/storeadmindetail')); ?>/<?php echo e($id); ?>" class="form1">
              <?php echo csrf_field(); ?>

                <div class="email">
                    <div class="icon">
                       <i class="fa fa-user" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Name" name="name" value="<?php echo e($name); ?>" required>
                    </div>  
                </div>
                <div class="email">
                    <div class="icon">
                       <i class="fa fa-envelope-o" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Email" name="email" value="<?php echo e($email); ?>" required>
                    </div>  
                </div>

                   <div class="part">
                            <div class="col-md-12 label">
                                <label>Already inserted mobile no</label>
                            </div>
                            <div class="col-md-12 data">


                            <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <label class="badge bg-info  tag_<?php echo e($m->id); ?>"><?php echo e($m->phone); ?><a> <i class="fa fa-times" aria-hidden="true" onclick="delete_mobile(<?php echo e($m->id); ?>)"></i></a> </label><br>
                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                            </div>   
                          </div>

                

                <div class="email">
                    <div class="icon">
                       <i class="fa fa-phone" aria-hidden="true"></i>
                    </div>
                    <div class="text">  

                          <input type="text" placeholder="Enter Phone number" name="phone"data-role="tagsinput" >
                    </div> 
                </div>
                <div class="email">
                    <div class="icon">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <textarea placeholder="Enter here... " name="address" value="<?php echo e($address); ?>"required><?php echo e($address); ?></textarea>
                    </div> 
                </div>

                   <div class="email">
                    <div class="icon">
                       <i class="fa fa-facebook" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Facebook Url" name="fb_url" value="<?php echo e($fb_url); ?>" required>
                    </div>  
                </div>
                <div class="email">
                    <div class="icon">
                       <i class="fa fa-indiamart" aria-hidden="true"></i>
                    </div>
                    <div class="text">
                         <input type="text" placeholder="Indiamart Url" name="india_mart_url" value="<?php echo e($india_mart_url); ?>" required>
                    </div>  
                </div>


                <div class="forgot">
                    <a href="<?php echo e(url('admin/home')); ?>">Back to Home ?</a>
                </div>
                    <button class="btn" name="submit">submit</button>
            </form>
        </div>
    </div>
  
              <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css" rel="stylesheet" />
   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.js"></script>
   <script type="text/javascript">

      function delete_mobile($id){

     if(confirm("do you want delete this mobile number ?")){
             $.ajax({

                url:'delete_mobileno/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.tag_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  




   </script>

    <style type="text/css">

    

      
      .bootstrap-tagsinput .tag {
    margin-right: 2px;
    color: black !important;
    background: #17a2b8!important;
}

.bootstrap-tagsinput {
  width: 95%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #858a8e;
    position: relative;
    /* margin-left: 16px; */
    height: 25px;
    border-radius: 7px;
    border-top-left-radius: 0px;
    border-bottom-left-radius: 0px;
}

.bg-info {
    background-color: #17a2b8!important;
    height: 30px !important;
    line-height: 24px!important;
   
}

.part {
    text-align: left;
    margin-top: 20px;
}
    </style>
</body>
</html><?php /**PATH C:\xampp\htdocs\rajsynthetics\resources\views/admin/updateadmindetailview.blade.php ENDPATH**/ ?>