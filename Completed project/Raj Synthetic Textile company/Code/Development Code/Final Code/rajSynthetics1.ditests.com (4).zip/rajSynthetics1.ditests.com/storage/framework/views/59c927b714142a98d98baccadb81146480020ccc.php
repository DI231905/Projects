

<?php $__env->startSection('content'); ?>

<div class="co_inner-banner">
		<img src="/uploads/<?php echo e($banner_image); ?>">
	</div>
	<div class="co_product-detail">
		<div class="container">
			<div class="inner_pdetail">
				<h2><?php echo e($name); ?></h2>
				<div class="row">
					<div class="col-lg-7 col-md-7 order_01">
						<div class="product-prg">
							<?php echo $description; ?>

                            <div class="button"><a href="<?php echo e(url('/ContactUs')); ?>"><span>Send Enquiry Now</span></a></div>
						</div>
					</div>
					<div class="col-lg-5 col-md-5 order_02">
						<div class="product-detail-img">
							<img src="/uploads/<?php echo e($product_image); ?>">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/rajSynthetics1.ditests.com/resources/views/chemical_product_detail.blade.php ENDPATH**/ ?>