@extends('layouts.app')

@section('content')

    
    <div class="co_inner-banner">
        <img src="image/textile_products.jpg">
    </div>
    <div class="co_product-packet">
        <div class="container">
            <div class="inner-product-packet">
                <h1>Textile Products</h1>
                <div class="row">

                     <div class="col-lg-12 col-md-12 col-12 main-packet">

                         <div class="product-packet bg_1">
                 

                          @foreach ($texttileproduct as $tp)   
                       
                          <a href="{{url('textile_product_detail')}}/{{$tp->id}}">{{$tp->name}}</a>
                                           
                        @endforeach

                         </div>

                       </div>


                </div>
            
        </div>
    </div>
    <style type="text/css">
       .product-packet.bg_1 a {
    background: #f1f1f1;
 
    width: 32%;
    margin: 0 7px 0 7px;
}

.bg_1 {
     background: transparent; 
    margin-top: 20px;
    display: flex;
    flex-wrap: wrap;
   
}
.co_footer:before {
    top: 10px;
}
@media only screen and (min-width: 768px) and (max-width: 1023px){
.co_footer:before {
    top: -12px;
}
}
@media only screen and (max-width: 767px){
   .co_footer:before {
    top: -7px;
}
}

    </style>
   
   @endsection

