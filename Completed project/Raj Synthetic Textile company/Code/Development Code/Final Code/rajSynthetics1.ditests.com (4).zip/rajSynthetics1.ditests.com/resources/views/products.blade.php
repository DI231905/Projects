@extends('layouts.app')

@section('content')

	<div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/product-bg.jpg">
    	    </div>
    	    <div class="about1">
    		    <h2>Products</h2>
    		    <ul type="none">
    			    <li>Home</li>
    			    <li><span class="fa fa-angle-right"></span></li>
    			    <li class="bt">Products</li>
    		    </ul>
    	    </div>
    	</div>
    </div>
    <div class="co_product1">
    	<div class="container">
            <div class="row">
                <span href="image/product-1.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                	<div class="product-list">
                        <img src="image/product-1.jpg" class="img-fluid">
                        <div class="product-info">
                            <h2>Yarns</h2>
                            <div class="product-price">
                                <span>$32.00</span>
                                <del>$46.00</del>
                            </div>
                        </div>
                    </div>
                </span>
                <span href="image/product-2.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                	<div class="product-list">
                        <img src="image/product-2.jpg" class="img-fluid">
                        <div class="product-info">
                            <h2>Polyester Yarns</h2>
                            <div class="product-price">
                                <span>$32.00</span>
                                <del>$46.00</del>
                            </div>
                        </div>
                    </div>
                </span>
                <span href="image/product-3.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                	<div class="product-list">
                        <img src="image/product-3.jpg" class="img-fluid">
                        <div class="product-info">
                            <h2>Dyed Yarns</h2>
                            <div class="product-price">
                                <span>$32.00</span>
                                <del>$46.00</del>
                            </div>
                        </div>
                    </div>
                </span>
                <span href="image/product-3.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                	<div class="product-list">
                        <img src="image/product-3.jpg" class="img-fluid">
                        <div class="product-info">
                            <h2>Dyed Yarns</h2>
                            <div class="product-price">
                                <span>$32.00</span>
                                <del>$46.00</del>
                            </div>
                        </div>
                    </div>
                </span>
                <span href="image/product-1.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                	<div class="product-list">
                        <img src="image/product-1.jpg" class="img-fluid">
                        <div class="product-info">
                            <h2>Yarns</h2>
                            <div class="product-price">
                                <span>$32.00</span>
                                <del>$46.00</del>
                            </div>
                        </div>
                    </div>
                </span>
                <span href="image/product-2.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                	<div class="product-list">
                        <img src="image/product-2.jpg" class="img-fluid">
                        <div class="product-info">
                            <h2>Polyester Yarns</h2>
                            <div class="product-price">
                                <span>$32.00</span>
                                <del>$46.00</del>
                            </div>
                        </div>
                    </div>
                </span>
                <span href="image/product-1.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                	<div class="product-list">
                        <img src="image/product-1.jpg" class="img-fluid">
                        <div class="product-info">
                            <h2>Yarns</h2>
                            <div class="product-price">
                                <span>$32.00</span>
                                <del>$46.00</del>
                            </div>
                        </div>
                    </div>
                </span>
                <span href="image/product-2.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                	<div class="product-list">
                        <img src="image/product-2.jpg" class="img-fluid">
                        <div class="product-info">
                            <h2>Polyester Yarns</h2>
                            <div class="product-price">
                                <span>$32.00</span>
                                <del>$46.00</del>
                            </div>
                        </div>
                    </div>
                </span>
                <span href="image/product-3.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                	<div class="product-list">
                        <img src="image/product-3.jpg" class="img-fluid">
                        <div class="product-info">
                            <h2>Dyed Yarns</h2>
                            <div class="product-price">
                                <span>$32.00</span>
                                <del>$46.00</del>
                            </div>
                        </div>
                    </div>
                </span>
            </div>     
        </div>
    </div>
   @endsection
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script>
    <script type="text/javascript">
    	$(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });

        $(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

        $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });
    </script>