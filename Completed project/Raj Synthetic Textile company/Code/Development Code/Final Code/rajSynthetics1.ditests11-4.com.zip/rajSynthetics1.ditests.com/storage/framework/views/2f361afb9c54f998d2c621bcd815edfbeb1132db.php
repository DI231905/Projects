<!DOCTYPE html>
<html>
<head>
    <title>Raj Synthetics</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css">
    <link rel="icon" type="image/png" href="image/logo1.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">



</head>
<body class="body">
   <div class="main-header" id="dynamic">
        <div class="subheader">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="social-icon">
                            <li>

                            <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($p->id==1): ?>

                            <a href="<?php echo e($p->phone); ?>"><i class="fas fa-phone-alt"></i><span><?php echo e($p->phone); ?></span></a>
                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </li>
                            <li><a href="https://wa.me/916355197413?text="><i class="fab fa-whatsapp"></i></a></li>
                            <li><a href="<?php echo e($fb_url); ?>"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="http://www.linkedin.com/in/raj-synthetic-443a00235"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="<?php echo e($india_mart_url); ?>"> <img src="image/m1.png"></a> </li>
                            
                        </ul>   
                    </div>
                </div>
            </div>
        </div>
        <div class="co_header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-6">
                        <div class="logo">
                           <a href="<?php echo e(url('/')); ?>"><img src="/image/logo.png"></a>
                           
                        </div>
                        <div class="logo1">
                             <a href="<?php echo e(url('/')); ?>"><img src="/image/logo.png"></a>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-9 col-6">
                        <div class="menu">
                             <a  href="<?php echo e(url('/')); ?>">Home</a>
                           <!--  <a href="<?php echo e(url('/About')); ?>">About</a> -->
                            <a href="<?php echo e(url('/product_category')); ?>">Products</a>
                            <a href="<?php echo e(url('/Career')); ?>">Career</a>
                            <a href="<?php echo e(url('/ContactUs')); ?>">Contact Us</a>
                        </div>
                        <div class="mobile-menu">
                        <div id="mySidepanel" class="sidepanel">
                            <div class="m_menu">
                                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a>    
                                <a class="link" href="<?php echo e(url('/')); ?>">Home</a>
                                <a class="link"href="<?php echo e(url('/product_category')); ?>">Product</a>
                                <a class="link" href="<?php echo e(url('/Career')); ?>">Career</a>
                                <a class="link" href="<?php echo e(url('/ContactUs')); ?>">Contact Us</a>
                            </div>
                        </div>
                        <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                    </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
    <div class="co_banner">
        <div class="slideshow">
            <div class="slider">
                <div class="item">
                    <img src="image/banner-1.jpg">
                    <div class="banner-content">
                        <h4>Exporter & Importer</h4>
                        <h2>Of High <span>Quality Fibres & Yarns</span></h2>
                        <!-- <h4>PTA, MEG, Polymers, Fuel Oil, SBR & PBR</h4> -->
                        <div class="button"><a href="#"><span>know more</span></a></div>
                    </div>
                </div>
               <div class="item">
                    <img src="image/banner-2.jpg">
                    <div class="banner-content">
                        <h4>Exporter & Importer</h4>
                        <h2>Of High <span>Quality Fibres & Yarns</span></h2>
                        <!-- <h4>PTA, MEG, Polymers, Fuel Oil, SBR & PBR</h4> -->
                        <div class="button"><a href="#"><span>know more</span></a></div>
                    </div>
                </div>
                <div class="item">
                    <img src="image/banner-3.jpg">
                    <div class="banner-content">
                        <h4>Exporter & Importer</h4>
                        <h2>Of High <span>Quality Fibres & Yarns</span></h2>
                        <!-- <h4>PTA, MEG, Polymers, Fuel Oil, SBR & PBR</h4> -->
                        <div class="button"><a href="#"><span>know more</span></a></div>
                    </div>
                </div> 
                 <div class="item">
                    <img src="image/banner-4.jpg">
                    <div class="banner-content">
                        <h4>Exporter & Importer</h4>
                        <h2>Of High <span>Quality Fibres & Yarns</span></h2>
                        <!-- <h4>PTA, MEG, Polymers, Fuel Oil, SBR & PBR</h4> -->
                        <div class="button"><a href="#"><span>know more</span></a></div>
                    </div>
                </div> 
            </div>
        </div>
    </div>
    <div class="co_service">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="service">
                        <div class="icon">
                            <img src="image/service-3.png">
                        </div>
                        <h2>We Export Globally</h2>
                        <p>Raj Synthetics is a leading export textile service providers globally.</p>   
                    </div>
                </div>
            </div>
        </div>
    </div>


        

    <div class="co_about">
        <div class="container">
            <div class="row set-about">
                <div class="col-lg-6 col-md-7 col-12">
                    <div class="detail-info">
                        <h6>WHO WE ARE</h6>
                        <h2>An Inducting Agent</h2>
                        <p>Raj Synthetics is one of the oldest Yarn merchants and Commission Agent of Surat, Gujarat.</p>
                        <p>We have always worked towards achieving excellence in the wholesale business. With changing times we have always managed to provide quintessential business through research, experience, innovation and technology.At Raj Synthetics, we are a team of highly motivated, dedicated and skilled individuals. Our team is backed up with years of experience and directed with market analysis.This brings for us and our customers, new business possibilities and mutual growth.We assure to provide hassle free services and aim for long term business relationships.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-5 col-12 set-about1">
                    <div class="about-img">
                        <img src="image/img1.jpg">
                    </div>  
                </div>
            </div>
        </div>  
    </div>
   <!-- <div class="co_product">
        <div class="container">
            <h1>Products</h1>
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="product-img">
                        <a href="<?php echo e(url('/Texttile')); ?>"><img src="image/product-1.jpg"></a>
                        <div class="product-name">
                            <h2>Textiles Product</h2>
                           
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="product-img">
                        <a href="<?php echo e(url('/Chemical')); ?>"><img src="/image/chemical.jpg"></a>
                        <div class="product-name">
                            <h2>Chemicals Product</h2>
                           
                        </div>
                    </div>
                </div>
             
            </div>
        </div>
    </div>-->
    
    <div class="pro">
		<div class="container">
			<div class="head">
				<h3><span>Product</span> - Export Import Worldwide</h3>
				<p>Textile Products</p>
			</div>
			<div class="box">
				<div class="row">
					<div class="col-lg-6">
						<div class="p_img">
						       <a href="<?php echo e(url('/Texttile')); ?>"><img src="image/textile-products_img .jpg"></a>
						    
						<!--	<img src="image/textile-products_img .jpg">-->
						</div>
					</div>
					<div class="col-lg-6">
						<div class="p_details">
							<h6>Textile Products</h6>
							<div class="sub_pro">
								<ul>
									<li><i class="fad fa-dot-circle"></i>Polyester Yarn</li>
									<li><i class="fad fa-dot-circle"></i>PET Chips</li>
									<li><i class="fad fa-dot-circle"></i>Spandex Covered Yarn</li>
								</ul>
								<ul>
									<li><i class="fad fa-dot-circle"></i>Cotton Yarn</li>
									<li><i class="fad fa-dot-circle"></i>Viscose Yarn</li>
									<li><i class="fad fa-dot-circle"></i>Nylon Yarn 6 & 66</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
    
    
    
    
    
      <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 

     <?php if(session()->has('error')): ?>
                   <div class="alert alert-success">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
    <div class="co_enquiry">
        <div class="container">
            <h2>Quick Enquiry</h2>
            <form  method="POST" action="<?php echo e(url('/enquiry')); ?>" class="enquiry-form" >
                   <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="text">
                            <label>company Name <b>*</b></label>
                            <input type="text" placeholder="Company Name" name="cname" value="" required>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="text">
                            <label>Contact Person Name <b>*</b></label>
                            <input type="text" placeholder="Contact Person Name
                            " name="pname" value="" required>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="text">
                            <label>Enter Email <b>*</b></label>
                            <input type="email" placeholder="Enter Email" name="email" value="" required>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="text">
                            <label>Contact Number  <b>*</b></label>
                            <input type="number" placeholder="Contact Number " name="mobileno" value="" required>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="text">
                            <label>Country <b>*</b></label>
                            <select name="country" id="country">
                                <option>Select Country</option>
                                 <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      
                                         <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="text">
                            <label>Subject <b>*</b></label>
                            <input type="text" placeholder="Subject" name="subject" value="">
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-12">
                        <div class="text">
                            <label>Enquiry Details <b>*</b></label>
                            <textarea placeholder="Enquiry Details" name="details"></textarea>
                        </div>
                    </div>
                </div>
                <div class="button">
                    <span class="more"><input type="Submit" value="Submit" name=""></span>
                </div>
            </form>
        </div>
    </div>
    
    <div class="Expoter">
		<div class="container">
			<div class="ex_1">
				<h2>TRUSTED WORLDWIDE</h2>
				<h1>Exporter Since 2006</h1>
				<p>Kayavlon Impex Pvt. Ltd. is a leading government recognized Star Export House based in India with CRISIL & ISO 9001:2008 Certification in the field of Textiles & Fibers Products</p>
				<div class="button">
                    <span class="more"><input type="Submit" value="Submit" name=""></span>
                </div>
			</div>
		</div>
	</div>
    
    
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">
                    <div class="main-footer">
                        <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="image/logo1.png"></a></h2>
                        <p>We assure to provide hassle-free services and aim for long-term business relationships.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-12">
                    <div class="row">
                        <div class="col-md-6 col-6">
                            <h2 class="title1">Company</h2>
                            <div class="footer-widget">
                                <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i>  <a href="<?php echo e(url('/Career')); ?>">Career</a></li>
                                
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="#">All Product</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/ContactUs')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-6">
                            <h2 class="title1">Services</h2>
                            <div class="footer-widget">
                                <ul>
                                   <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/')); ?>">We Export Globally</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                        <li><i class="fa fa-home" aria-hidden="true"></i>
                            <p><?php echo nl2br(e($address)); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                        <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                            <p><a href="tel: <?php echo e($p->phone); ?>"><?php echo e($p->phone); ?></a></p>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                   
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Raj Synthetics  © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
              <ul class="social-icon">
                        
                            <li><a href="<?php echo e($fb_url); ?>"><i style="color: black" class="fab fa-facebook-f"></i></a></li>
                            <li><a href="<?php echo e($india_mart_url); ?>"> <img src="image/m.png"></a> </li>
                            
                        </ul>   
            </div>
        </div>
        </div>
    </div>
    <div class="copy">
        <a class="up-btn" href="#">
            <span class="far fa-angle-up"></span>
        </a>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
   <!-- 
    <script type="text/javascript">
      var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
      (function(){
      var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
      s1.async=true;
      s1.src='https://embed.tawk.to/6178e94786aee40a57388ba7/1fj04ug8g';
      s1.charset='UTF-8';
      s1.setAttribute('crossorigin','*');
      s0.parentNode.insertBefore(s1,s0);
      })();
</script>-->
     <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }


        $(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

        $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

         $('.slider').slick({
            autoplay: true,
            autoplaySpeed: 1200,
            draggable: true,
            arrows: true,
            dots: false,
            fade: true,
            speed: 1000,
            infinite: true,
            cssEase: 'cubic-bezier(0.7, 0, 0.3, 1)',
            touchThreshold: 100,
            prevArrow: '<div class="slide-arrow prev-arrow"><i class="far fa-chevron-left"></i></div>',
            nextArrow: '<div class="slide-arrow next-arrow"><i class="far fa-chevron-right"></i></div>'
        })
        
        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });

    </script>
   
   

</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/rajSynthetics1.ditests.com/resources/views/welcome.blade.php ENDPATH**/ ?>