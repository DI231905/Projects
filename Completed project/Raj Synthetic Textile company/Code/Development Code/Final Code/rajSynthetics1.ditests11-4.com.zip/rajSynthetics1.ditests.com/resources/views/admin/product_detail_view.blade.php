<!DOCTYPE html>
<html>
<head>
    <title>Raj Synthetics</title>
    <link rel="stylesheet" type="text/css" href="/css/main-dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css">
      <link rel="icon" type="image/png" href="/image/logo1.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
  
        
      
              <div class="page mt-4 marketplace-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Product Details View</h4>
                     <div class="detail">
                        <div class="detail__1">
                             <table class="table table-bordered table-striped">
                                  <tbody>
                                  <tr class="detail"><h3>Name</h3></tr>
                                  <tr class="detail">{{$name}}</tr>
                                  <tr class="detail"><h3>Banner Image</h3></tr>
                                  <tr class="detail"><img src="/uploads/{{$banner_image}}" height="200" width="250"></tr>
                                  <tr class="detail"><h3>Product Image</h3></tr>
                                    <tr class="detail"><img src="/uploads/{{$product_image}}" height="200" width="250"></tr>
                                  <tr class="detail"><h3>Description</h3></tr>
                                  <tr class="detail">{!! $description !!}</tr>
            
                                   </tbody>                   
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <style type="text/css">
              .detail {
                    padding-left: 25px!important;
                    padding-top: 20px;
                }
                .detail__1 h3 {
                        font-size: 21px;
                        margin: 0;
                        font-weight: 700;
                        padding-top: 20px;
                }
                    
                .detail__1 h2 {
                    padding-left: 0;
                    width: 80%;
                }
               .detail__1  p {
                    width: 79%;
                }
            </style>
           
       
  
</body>
</html>