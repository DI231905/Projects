<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/','\App\Http\Controllers\userController@index');
Route::get('/About','\App\Http\Controllers\userController@Aboutview');
//Route::get('/Products','\App\Http\Controllers\userController@Productsview');
Route::get('/Career','\App\Http\Controllers\userController@Careerview');
Route::get('/ContactUs','\App\Http\Controllers\userController@Contactus');
Route::get('/Texttile','\App\Http\Controllers\userController@Texttile');
Route::get('/product_category','\App\Http\Controllers\userController@product_category');
Route::get('/Chemical','\App\Http\Controllers\userController@Chemical');
Route::get('/textile_product_detail/{id}','\App\Http\Controllers\userController@textile_product_detail');
Route::get('/chemical_product_detail/{id}','\App\Http\Controllers\userController@chemical_product_detail');


//Route::get('/app','\App\Http\Controllers\userController@Contactus');


Route::post('/enquiry','\App\Http\Controllers\userController@enquiryform');
Route::post('/Application','\App\Http\Controllers\userController@applicationform');
Route::post('/Contactusfrom','\App\Http\Controllers\userController@contactusfrom');

           ///////////   Admin view /////////////////////


 Route::prefix('admin')->group(function(){

 	    
Route::get('/login','\App\Http\Controllers\Auth\Adminlogincontroller@login');

Route::post('/login','\App\Http\Controllers\Auth\Adminlogincontroller@authenticate')->name('login');
Route::get('/logout','\App\Http\Controllers\Auth\Adminlogincontroller@logout')->name('adminlogout');

Route::get('/home', '\App\Http\Controllers\Admin\Admincontroller@home');



//forget password

Route::get('/forgetpassword','\App\Http\Controllers\Auth\Adminlogincontroller@forgetpassword')->name('forgetpassword');
Route::post('/resetpassword','\App\Http\Controllers\Auth\Adminlogincontroller@resetpassword')->name('resetpassword');
  Route::get('/updatepassword/{id}','\App\Http\Controllers\Auth\Adminlogincontroller@updatepasswordview');
 Route::post('/createnewpassword','\App\Http\Controllers\Auth\Adminlogincontroller@createnewpassword')->name('createnewpassword');

  Route::get('/deletecontactus/{id}','\App\Http\Controllers\Admin\Admincontroller@deletecontactus'); 



 //change password

/* Route::get('/changepassword','\App\Http\Controllers\Auth\Adminlogincontroller@changepassword')->name('changepassword');
 Route::post('/createpassword/{id}','\App\Http\Controllers\Auth\Adminlogincontroller@createpassword');*/


   ///  update admin detail
Route::get('/updateadmindetail/{id}','\App\Http\Controllers\Admin\Admincontroller@updateadmindetail');
Route::post('/storeadmindetail/{id}','\App\Http\Controllers\Admin\Admincontroller@storeadmindetail');
  //delete inquiery from
Route::get('/deleteenquiry/{id}','\App\Http\Controllers\Admin\Admincontroller@deleteenquiry');
Route::get('/downloadpdf/{id}','\App\Http\Controllers\Admin\Admincontroller@/downloadpdf');
// delete  application

Route::get('/deleteapplication/{id}','\App\Http\Controllers\Admin\Admincontroller@deleteapplication');
Route::get('/addtextile','\App\Http\Controllers\Admin\Admincontroller@addtextile')->name('addtextilecategory');

 //insert new country and city
 /*Route::get('/getcity/{id}','\App\Http\Controllers\Admin\Admincontroller@getcity');*/
 
Route::post('/addcategorydata','\App\Http\Controllers\Admin\Admincontroller@addcategorydata')->name('addcategorydata');


//// texttile product

 Route::get('/addtexttileproduct','\App\Http\Controllers\Admin\Admincontroller@addtexttileproduct');
 Route::post('/storetexttiledata','\App\Http\Controllers\Admin\Admincontroller@storetexttiledata');
Route::get('/deletetexttileproduct/{id}','\App\Http\Controllers\Admin\Admincontroller@deletetexttileproduct');

 Route::get('/updatetexttileproduct/{id}','\App\Http\Controllers\Admin\Admincontroller@updatetexttileproduct');

 Route::post('/updatetexttiledata/{id}','\App\Http\Controllers\Admin\Admincontroller@updatetexttiledata');
 Route::get('/textile_product_detail_view/{id}','\App\Http\Controllers\Admin\Admincontroller@textile_product_detail_view');


 /////// saffroind product

Route::get('/add_chemical_product','\App\Http\Controllers\Admin\Admincontroller@add_chemical_product');
Route::post('/store_chemical_product','\App\Http\Controllers\Admin\Admincontroller@store_chemical_product');

Route::get('/delete_chemical_product/{id}','\App\Http\Controllers\Admin\Admincontroller@delete_chemical_product');

 Route::get('/update_chemical_product/{id}','\App\Http\Controllers\Admin\Admincontroller@update_chemical_product');

Route::post('/store_update_chemical_product/{id}','\App\Http\Controllers\Admin\Admincontroller@store_update_chemical_product');

Route::get('/chemical_product_detail_view/{id}','\App\Http\Controllers\Admin\Admincontroller@chemical_product_detail_view');

Route::get('/downloadpdf/{id}','\App\Http\Controllers\Admin\Admincontroller@downloadpdf');

Route::get('/changepassword','\App\Http\Controllers\Admin\Admincontroller@changepassword');
 Route::post('/createpassword/{id}','\App\Http\Controllers\Admin\Admincontroller@createpassword');

 Route::get('/updateadmindetail/delete_mobileno/{id}','\App\Http\Controllers\Admin\Admincontroller@delete_mobileno');





 }); 







