<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
//use App\Models\User;
use Carbon\carbon;
use DB;
use Hash;
use \Crypt;
use Response;
use Auth;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class Admincontroller extends Controller{


 public function __construct(){

                $this->middleware('auth:admin');
        }

    public function home(){
 
       //open home page
      $admin=Auth::guard('admin')->user();
      $data['admin']=$admin;

      $data['site_url']= env('APP_URl');

      
     $admincontactdetail=DB::table('admincontact')->get();

      $data['admincontactdetail']=$admincontactdetail;

          $phone_no=DB::table('phone_no')->get();
            $data['phone_no']=$phone_no;


       
      $contactus=DB::table('contact_us')->get();

      $data['contactus']=$contactus;

      $enquiry=DB::table('enquiry')->get();

      $data['enquiry']=$enquiry;

      $applicationform=DB::table('applicationform')->get();

      $data['applicationform']=$applicationform;


       $texttileproduct=DB::table('texttileproduct')->get();

      $data['texttileproduct']=$texttileproduct;

      $saffroindproduct=DB::table('chemicaldproduct')->get();

      $data['saffroindproduct']=$saffroindproduct;

      $data['metatitle']='home page';
      return view('admin.home',$data);   } 
    

      public function downloadpdf($id){
  
         $application= DB::table('applicationform')->where('id', $id)->get();
        $resume=$application[0]->resume;

         return response()->download('uploads/'.$resume);
     
      }

      public function addtexttileproduct(){
  
        return view('admin.addtexttileproduct');

       }


    public function storetexttiledata(Request $request){


        $request->validate([

            'name' => 'required',
            'banner_image' => 'required',
            'product_image' => 'required',
            'description'=>'required',
              ]);
       
        $name=$request->input('name');
        $file = $request->file('banner_image');
        $file1 = $request->file('product_image');
        $description=$request->input('description');
    
    
        $imagename=' ';

        if ($file) {
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();

         $file->move($destinationPath,$imagename); 

            }

        $imagename1=' ';

        if ($file1) {
          
          $destinationPath='uploads';
          $imagename1=time().'_'.$file1->getClientOriginalName();

         $file1->move($destinationPath,$imagename1); 

            }



         DB::table('texttileproduct')->insert(['name'=>$name,'banner_image'=>$imagename, 'product_image'=>$imagename1,'description'=> $description]);
       
          return redirect('admin/home')->with('error','Insert Textile Product successfully!!' );
           }


     public function deletetexttileproduct($id){

    
          $product= DB::table('texttileproduct')->where('id', $id)->get();

         if ($product[0]->banner_image!='') {

            unlink(public_path("/uploads/".$product[0]->banner_image));
           
            /*  unlink("/home/mzldwoswysm5/public_html/rajsynthetics1.ditests.com/uploads/".$product[0]->banner_image);
*/
            }

            if ($product[0]->product_image!='') {

            unlink(public_path("/uploads/".$product[0]->product_image));
         
          /*  unlink("/home/mzldwoswysm5/public_html/rajsynthetics1.ditests.com/uploads/".$product[0]->product_image);*/



            }

            DB::table('texttileproduct')->where('id', $id)->delete();



            return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);

       }

       public function  updatetexttileproduct($id){

       $product= DB::table('texttileproduct')->where('id', $id)->get();
       
     
        $data['id']=$product[0]->id;
        $data['name']=$product[0]->name;
        $data['banner_image']=$product[0]->banner_image;
        $data['product_image']=$product[0]->product_image;
        $data['description']=$product[0]->description;
       
        return view('admin.updatetexttileproduct',$data); 

         }



   public function updatetexttiledata(Request $request,$id){


   $request->validate([

            'name' => 'required',
            'description'=>'required',
           
        

        ]);
       
        $name=$request->input('name');
        $file = $request->file('banner_image');
        $file1 = $request->file('product_image');
        $description=$request->input('description');

        $imagename='';
        $imagename1='';
    

        if($file){
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('texttileproduct')->where('id', $id)->update(['banner_image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink(public_path("/uploads/".$request->input('oldimage')));
           
         /*    unlink("/home/mzldwoswysm5/public_html/rajSynthetics1.ditests.com/uploads/".$request->input('oldimage'));*/

             }

           }

          if($file1){
         
          $destinationPath='uploads';
          $imagename1=time().'_'.$file1->getClientOriginalName();
    
           $file->move($destinationPath,$imagename1);

           DB::table('texttileproduct')->where('id', $id)->update(['product_image'=>$imagename1]);

            if ($request->input('oldimage1')!='') {
                
                
             unlink(public_path("/uploads/".$request->input('oldimage1')));

              /*  unlink("/home/mzldwoswysm5/public_html/rajSynthetics1.ditests.com/uploads/".$request->input('oldimage1'));*/


             }

           }

          DB::table('texttileproduct')->where('id', $id)->update(['name'=>$name ,'description'=>$description]);

            return redirect('admin/home')->with('error','Update Textile Product successfully!!' );

    }

       public function textile_product_detail_view($id){

    
            $product= DB::table('texttileproduct')->where('id', $id)->get();
       
             $data['id']=$product[0]->id;
             $data['name']=$product[0]->name;
             $data['banner_image']=$product[0]->banner_image;
             $data['product_image']=$product[0]->product_image;
             $data['description']=$product[0]->description;

             return view('admin.product_detail_view',$data);

        }

        public function add_chemical_product(){
  
        return view('admin.addchemicalsproduct');

       }

        public function store_chemical_product(Request $request){
   
            $request->validate([

             'name' => 'required',
             'banner_image' => 'required',
             'product_image' => 'required',
             'description'=>'required',
              ]);
       
             $name=$request->input('name');
             $file = $request->file('banner_image');
             $file1 = $request->file('product_image');
             $description=$request->input('description');
    
    
             $imagename=' ';

             if ($file) {
               
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
     
                   $file->move($destinationPath,$imagename); 
     
              }

          $imagename1=' ';

            if ($file1) {
              
              $destinationPath='uploads';
              $imagename1=time().'_'.$file1->getClientOriginalName();

             $file1->move($destinationPath,$imagename1); 

                }



              DB::table('chemicaldproduct')->insert(['name'=>$name,'banner_image'=>$imagename, 'product_image'=>$imagename1,'description'=> $description]);
       
                return redirect('admin/home')->with('error','Insert chemical Product successfully!!' );
          
    }




     public function delete_chemical_product($id){


         $product= DB::table('chemicaldproduct')->where('id', $id)->get();

         if ($product[0]->banner_image!='') {

            unlink(public_path("/uploads/".$product[0]->banner_image));

            }

            if ($product[0]->product_image!='') {

            unlink(public_path("/uploads/".$product[0]->product_image));



            }

            DB::table('chemicaldproduct')->where('id', $id)->delete();



            return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);

    }

    public function chemical_product_detail_view($id){

   

    
            $product= DB::table('chemicaldproduct')->where('id', $id)->get();
       
             $data['id']=$product[0]->id;
             $data['name']=$product[0]->name;
             $data['banner_image']=$product[0]->banner_image;
             $data['product_image']=$product[0]->product_image;
             $data['description']=$product[0]->description;

             return view('admin.product_detail_view',$data);

        }


      public function update_chemical_product($id){

    

      $product= DB::table('chemicaldproduct')->where('id', $id)->get();
       
        //$work=DB::table('work')->where('id',$id)->get();
        $data['id']=$product[0]->id;
        $data['name']=$product[0]->name;
        $data['banner_image']=$product[0]->banner_image;
        $data['product_image']=$product[0]->product_image;
        $data['description']=$product[0]->description;
       
       
        return view('admin.updatechemicalproduct',$data);

       
       }

        public function store_update_chemical_product(Request $request,$id){

                    $request->validate([

                              'name' => 'required',
                              'description'=>'required',
                             
                          

                          ]);
                         
                          $name=$request->input('name');
                          $file = $request->file('banner_image');
                          $file1 = $request->file('product_image');
                          $description=$request->input('description');

                          $imagename='';
                          $imagename1='';
                      

                          if($file){
                           
                            $destinationPath='uploads';
                            $imagename=time().'_'.$file->getClientOriginalName();
                      
                             $file->move($destinationPath,$imagename);

                             DB::table('chemicaldproduct')->where('id', $id)->update(['banner_image'=>$imagename]);

                              if ($request->input('oldimage')!='') {

                               unlink(public_path("/uploads/".$request->input('oldimage')));

                               }

                             }

                            if($file1){
                           
                            $destinationPath='uploads';
                            $imagename1=time().'_'.$file1->getClientOriginalName();
                      
                             $file->move($destinationPath,$imagename1);

                             DB::table('chemicaldproduct')->where('id', $id)->update(['product_image'=>$imagename1]);

                              if ($request->input('oldimage1')!='') {

                               unlink(public_path("/uploads/".$request->input('oldimage1')));

                               }

                             }

                            DB::table('chemicaldproduct')->where('id', $id)->update(['name'=>$name ,'description'=>$description]);

                              return redirect('admin/home')->with('error','Update chemical Product successfully!!' );


                          }




       public function updateadmindetail($id){


       $admindetail=DB::table('admincontact')->where('id', $id)->get();

        $data['id']=$admindetail[0]->id;
        $data['email']=$admindetail[0]->email;
        $data['name']=$admindetail[0]->name;
        $data['address']=$admindetail[0]->address;
        $data['fb_url']=$admindetail[0]->fb_url;
        $data['india_mart_url']=$admindetail[0]->india_mart_url;


            $phone_no=DB::table('phone_no')->get();
            $data['phone_no']=$phone_no;

      

         return view('admin.updateadmindetailview',$data);


       }

             public function delete_mobileno($id){

                  DB::table('phone_no')->where('id',$id)->delete();

                  return response()->json(['success'=>'Mobile deleted successfully!!!',]);



              }

       public function storeadmindetail(Request $request,$id){


         $request->validate([

            'name' => 'required|string',
            'email' => 'required|email',
            'address' => 'required',
           
            

        ]);
       

        $name=$request->input('name');
        $email = $request->input('email');
        $mobileNo=$request->input('mobileno');
        $address=$request->input('address');
           $fb_url=$request->input('fb_url');
              $india_mart_url=$request->input('india_mart_url');



            $phone=$request->input('phone');
            $phones = explode(",", $phone);


              if($phone !=''){

                  foreach($phones as $key => $p){

                    DB::table('phone_no')->insert(['phone'=>$p, 'admin_id'=>$id]);
        
                }

              }



    

       DB::table('admincontact')->where('id',$id)->update(['name'=>$name ,'email'=>$email,'address'=>$address,'fb_url'=>$fb_url,'india_mart_url'=>$india_mart_url]);

        return redirect('admin/home')->with('error','Update Admin details successfully!!' );;
         
       /*  return redirect()->back()->with('error','data inserted successfully!!!' );
*/
       }

      public function deletecontactus($id){
  
       DB::table('contact_us')->where('id', $id)->delete();

         return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);

   }

     public function deleteenquiry($id){
  
       DB::table('enquiry')->where('id', $id)->delete();

        return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);

   }
    public function deleteapplication($id){



      $application= DB::table('applicationform')->where('id', $id)->get();

         if ($application[0]->resume!='') {

            unlink(public_path("/uploads/".$application[0]->resume));

            }

  
       DB::table('applicationform')->where('id', $id)->delete();

        return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);

   }




 /* public function addtextile(){

   return view ('admin.addtextileview'); //add textile category

  }

  public function addcategorydata(Request $request){

      $request->validate([

            'cname'=>'required',
            'description'=>'required',  //store texttile category
            'image' =>'required',
          

        ]);
       
        
        $name=$request->input('cname');
        $description=$request->input('description');
        $file=$request->file('image');
       

       $category=DB::table('texttilecatagory')->where('cname',$name)->count();

        if($category){

          return redirect()->route('addtextilecategory')->with('error','This category already inserted.');
   

        }else{
                 $imagename='';

                  if($file){

                   $destinationPath='uploads';
         
                   $imagename=time().'_'.$file->getClientOriginalName();
           
                   $file->move($destinationPath,$imagename);
      
                   }

             DB::table('texttilecatagory')->insert(['cname'=>$name ,'image'=>$imagename,'description'=>$description]);

            return redirect()->route('addtextilecategory')->with('error','This category inserted into a list.');

          }
    
       
       }
*/

        public function changepassword(){
       
      return view('admin.changepassword');
    }

     public function createpassword(Request $request,$id){

         $request->validate([
            'oldpassword' => 'required|string',
            'newpassword' => 'required|string|min:8',
           
           ]);

         $oldpassword=$request->input('oldpassword');
         $newpassword=$request->input('newpassword');

             $password=DB::table('admins')->where('id', $id)->get();

             $password1=$password[0]->password;

             if(Hash::check($oldpassword,$password1)){

               DB::table('admins')->where('id', $id)->update(['password'=>Hash::make($newpassword)]);

              return redirect('admin/home')->with('error','your password has been update sucessfully' );

             }else{

                return Redirect::back()->with('error','Your Old password is not correct!!!!');

            }
        }


 

  
  
}



