

<?php $__env->startSection('content'); ?>
<div class="co_inner-banner">
		<img src="image/product-bg.jpg">
	</div>
	<!--<div class="co_product">
        <div class="container">
            <h1 class="text-align-left">Products</h1>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
            <p> It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
            <div class="row mt-5">
                <div class="col-lg-6 col-md-6">
                    <div class="product-img">
                        <a href="<?php echo e(url('/Texttile')); ?>"><img src="image/product-1.jpg"></a>
                        <div class="product-name">
                            <h2>Textiles Product</h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="product-img">
                        <a href="<?php echo e(url('/Chemical')); ?>"><img src="/image/chemical.jpg"></a>
                        <div class="product-name">
                            <h2>Chemicals Product</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>-->
    <div class="pro">
		<div class="container">
			<div class="head">
				<h3><span>Product</span> - Export Import Worldwide</h3>
				<p>Textile Products</p>
			</div>
			<div class="box">
				<div class="row">
					<div class="col-lg-6">
						<div class="p_img">
						    <a href="<?php echo e(url('/Texttile')); ?>"><img src="image/textile-products_img .jpg"></a>
						
						</div>
					</div>
					<div class="col-lg-6">
						<div class="p_details">
							<h6>Textile Products</h6>
							<div class="sub_pro">
								<ul>
									<li><i class="fad fa-dot-circle"></i>Polyester Yarn</li>
									<li><i class="fad fa-dot-circle"></i>PET Chips</li>
									<li><i class="fad fa-dot-circle"></i>Spandex Covered Yarn</li>
								</ul>
								<ul>
									<li><i class="fad fa-dot-circle"></i>Cotton Yarn</li>
									<li><i class="fad fa-dot-circle"></i>Viscose Yarn</li>
									<li><i class="fad fa-dot-circle"></i>Nylon Yarn 6 & 66</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
            $('.menu a').click(function(){
                $('.menu a').removeClass("active_1");
                $(this).addClass("active_1");
            });
        });

         $(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });
	</script>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/rajSynthetics1.ditests.com/resources/views/product_category.blade.php ENDPATH**/ ?>