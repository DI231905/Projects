

<?php $__env->startSection('content'); ?>

    
    <div class="co_inner-banner">
        <img src="image/textile_products.jpg">
    </div>
    <div class="co_product-packet">
        <div class="container">
            <div class="inner-product-packet">
                <h1>Chemical Products</h1>
                <div class="row">

                     <div class="col-lg-4 col-md-4 col-12 main-packet">

                         <div class="product-packet bg_1">
                 

                          <?php $__currentLoopData = $chemicaldproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                       
                          <a href="<?php echo e(url('chemical_product_detail')); ?>/<?php echo e($tp->id); ?>"><?php echo e($tp->name); ?></a>
                                           
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                         </div>

                       </div>


                </div>
            
        </div>
    </div>
    <style type="text/css">
        .row{

            column-count: 3;
        }
        

    </style>
   
   <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rajsynthetics\resources\views/chemicalproduct.blade.php ENDPATH**/ ?>