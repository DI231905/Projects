<!DOCTYPE html>
<html>
<head>
    <title>Raj Synthetics</title>
    <link rel="stylesheet" type="text/css" href="/css/main-dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css">
      <link rel="icon" type="image/png" href="/image/logo1.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div class="mobile-view">
        <div class="row row1">
            <div class="col-md-6 col-6 logo1">
                <img src="/image/logo1.png">
            </div>
            <div class="col-md-6 col-6">
                <div class="mobile-menu">
                    <div id="mySidepanel" class="sidepanel">
                        <div class="m_menu">
                            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-times" aria-hidden="true"></i></a>  
                            <div class="top-nav-wrapper">
                                <div class="top-nav">                       
                                    <div class="co_profile">
                                        <div class="profile-img">
                                           
                                        </div>
                                        <div class="user-details">
                                            <span id="more-details">Raj Synthetics<i class="fa fa-caret-down"></i></span>
                                        </div>
                                    </div>
                                    <div class="main-menu-content">
                                        <ul>
                                              
                                          <!--  <li class="more-details">
                                             <i class=aria-hidden="true"></i><a href="<?php echo e(url('admin/addtextile')); ?>">add textile category</a>
                                           </li><br> -->

                                            <li class="more-details">
                                             <i class="" aria-hidden="true"></i><a href="<?php echo e(url('admin/changepassword')); ?>">change password</a>
                                           </li>



                                            <li class="more-details">
                                                <i class="fa fa-lock" aria-hidden="true"></i><a href="<?php echo e(route('adminlogout')); ?>">Logout</a>
                                            </li>


                                        </ul>

                                    </div>
                                    <div class="nav-slider"></div>
                                    <div class="hosting dash">
                                      <div class="hosting-btn nav-btn">Texttile product</div>
                                    </div>

                                     
                          <div class="dryfruit dash">
                            <div class="dryfruit-btn nav-btn">Chemicals Product</div>
                        </div>
                                    <div class="domains dash">
                                        <div class="domain-btn nav-btn">Contact List</div>
                                    </div>
                                     <div class="marketplace dash">
                            <div class="marketplace-btn nav-btn">Admin Detail List</div>
                        </div>
                         
                         <div class="manage-account dash">
                            <div class="manage-account-btn nav-btn">Career List</div>
                        </div>
                         <div class="message dash">
                            <div class="message-btn nav-btn">Enquiry List</div>
                        </div>
                        


                                    
                                    <div class="nav-slider"></div>
                                </div>
                            </div> 
                        </div>
                    </div>
                    <button class="openbtn" onclick="openNav()"><i class="fa fa-bars" aria-hidden="true"></i></button> 
                </div>
            </div>
        </div> 
    </div>
    <div class="row">
        <div class="col-xl-2 col-lg-3 col-md-6">
            <div class="two">
                <div class="top-nav-wrapper">
                    <div class="top-nav">
                        <div class="logo">
                            <img src="/image/logo1.png">
                        </div>
                        <div class="co_profile">
                            <div class="profile-img">
                               
                            </div>
                            <div class="user-details">
                                <span id="more-details">Raj Synthetics<i class="fa fa-caret-down"></i></span>
                            </div>
                        </div>
                        <div class="main-menu-content">
                                  <ul>

                                    <!--  <li class="more-details">
                                          <i class=aria-hidden="true"></i><a href="<?php echo e(route('addtextilecategory')); ?>">add textile category</a>
                                           </li><br> -->
                                     
                                      <li class="more-details">
                                         <i class="" aria-hidden="true"></i><a href="<?php echo e(url('admin/changepassword')); ?>">change password</a>
                                      </li><br>

                                             <li class="more-details">
                                          <i class="fa fa-lock" aria-hidden="true"></i><a href="<?php echo e(route('adminlogout')); ?>">Logout</a>
                                      </li>
                                  </ul>
                              </div>
                        <div class="nav-slider"></div>
                        <!-- <div class="dashboard dash">
                            <button class="active dashboard-btn nav-btn">Details List</button>
                        </div> -->
                        <div class="hosting dash">
                            <div class="hosting-btn nav-btn">Texttile product</div>
                        </div>
                        
                          <div class="dryfruit dash">
                            <div class="dryfruit-btn nav-btn">Chemicals Product</div>
                        </div>

                        <div class="domains dash">
                            <div class="domain-btn nav-btn">Contact List</div>
                        </div>
                        <div class="marketplace dash">
                            <div class="marketplace-btn nav-btn"> Admin Detail List</div>
                        </div>
                         <div class="manage-account dash">
                            <div class="manage-account-btn nav-btn">Career List</div>
                        </div>
                         <div class="message dash">
                            <div class="message-btn nav-btn"> Enquiry List</div>
                        </div>

                      
                       <!--   <div class="category dash">
                            <button class="category-btn nav-btn">Category List</button>
                        </div> -->


                        
                        <div class="nav-slider"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-10 col-lg-9 col-md-12">
        <?php if($message = Session::get('error')): ?>
            <div  id="hideDiv" class="alert alert-success alert-block" >
                <!--     <input type="text" class="close" data-dismiss="alert"></input> -->
                <strong style="padding-top : 5px !important; display: inline-block;"><?php echo e($message); ?></strong>
             </div>
           <?php endif; ?>
            <div class="page mt-4 marketplace-page title1">
                <div class="mt-5">
                    <h4 class="mb-4"> Admin Details List</h4>
                     <div class="detail">
                       <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile no</th>
                                    <th>Address</th>
                                    <th>Facebook url</th>
                                    <th>India Mart url</th>
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                                 <?php $__currentLoopData = $admincontactdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($ac->name); ?>

                                    </td>
                                

                                    <td>
                                          <?php echo e($ac->email); ?>

                                    </td>
                                    <td>
                                              
                                        <?php $__currentLoopData = $phone_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                          <?php if($ac->id== $p->admin_id): ?>

                                           <li><?php echo e($p->phone); ?></li>
                                        

                                          <?php endif; ?>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          

                                    </td>
                                    <td>
                                        <?php echo e($ac->address); ?>

                                   </td>
                                    <td>
                                        <?php echo e($ac->fb_url); ?>

                                   </td>
                                    <td>
                                        <?php echo e($ac->india_mart_url); ?>

                                   </td>
                                  
                             <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateadmindetail')); ?>/<?php echo e($ac->id); ?>">Update</a></button></td>
                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="page mt-4 hosting-page title1">
                <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4">Textile Product List</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addtexttileproduct')); ?>">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Banner Image</th>
                                    <th>Product Image</th>
                                    <th>Name</th>
                                    <th>View</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <tbody>
                            
                                 <?php $__currentLoopData = $texttileproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="texttile_<?php echo e($tp->id); ?>">
                                    <td>

                                      <img src="/uploads/<?php echo e($tp->banner_image); ?>" width="120" height="120">
                                        <?php echo e($tp->banner_image); ?>

                                    </td>

                                     <td>

                                      <img src="/uploads/<?php echo e($tp->product_image); ?>" width="120" height="120">
                                        <?php echo e($tp->product_image); ?>

                                    </td>
                                

                                    <td>
                                         <?php echo e($tp->name); ?>

                                    </td>
                                    <td>

                                        <button class="btn3 btn0"><a href="<?php echo e(url('admin/textile_product_detail_view')); ?>/<?php echo e($tp->id); ?>" >View</a></button>
                                       
                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updatetexttileproduct')); ?>/<?php echo e($tp->id); ?>" >Update</a></button></td>
                                    <td><button class="btn3 btn0"><a  onclick="delete_texttile_product(<?php echo e($tp->id); ?>)">Delete</a></button></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 
            <div class="page mt-4 domain-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Contact List</h4>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                   
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            
                                 <?php $__currentLoopData = $contactus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="conatct_<?php echo e($cu->id); ?>">
                                    <td>
                                        <?php echo e($cu->name); ?>

                                    </td>
                                

                                    <td>
                                         <?php echo e($cu->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($cu->subject); ?>

                                    </td>
                                    <td>
                                        <?php echo e($cu->description); ?>

                                   </td>
                        
                                    <td><button class="btn3 btn0"><a onclick="deletecontactus(<?php echo e($cu->id); ?>)">Delete</a></button></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>

            <div class="page mt-4 manage-account-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Career List</h4>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile No</th>
                                    <th>Position</th>
                                    <th>Experience</th>
                                    <th>Resume</th>
                                    <th>Message</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            
                                 <?php $__currentLoopData = $applicationform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $af): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="application_<?php echo e($af->id); ?>">
                                    <td>
                                        <?php echo e($af->name); ?>

                                    </td>
                                

                                    <td>
                                          <?php echo e($af->email); ?>

                                    </td>
                                    <td>
                                         <?php echo e($af->mobileno); ?>

                                    </td>
                                    <td>
                                        <?php echo e($af->position); ?>

                                   </td>
                                     <td>
                                        <?php echo e($af->experience); ?>

                                   </td>
                                     <td>

                                        <a href="<?php echo e(url('admin/downloadpdf')); ?>/<?php echo e($af->id); ?>"><?php echo e($af->resume); ?></a>
                                        
                                   </td>
                                     
                                     <td>
                                        <?php echo e($af->description); ?>

                                   </td>
                                    
                                    <td><button class="btn3 btn0"><a onclick="deleteapplication(<?php echo e($af->id); ?>)">Delete</a></button></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div> 

            <div class="page mt-4 message-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Enquiry List</h4>

                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Company Name</th>
                                    <th>person Name</th>
                                    <th>Email</th>
                                    <th>Mobile no</th>
                                    <th>country</th>
                                    <th>subject</th>
                                    <th>Message</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            
                                 <?php $__currentLoopData = $enquiry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="inquiry_<?php echo e($e->id); ?>">
                                    <td>
                                        <?php echo e($e->cname); ?>

                                    </td>

                                    <td>
                                          <?php echo e($e->pname); ?>

                                    </td>
                                    <td>
                                         <?php echo e($e->email); ?>

                                    </td>
                                    <td>
                                         <?php echo e($e->mobileno); ?>

                                   </td>
                                   <td>
                                         <?php echo e($e->country); ?>

                                   </td>
                                   <td>
                                         <?php echo e($e->subject); ?>

                              </td>
                                   <td>
                                         <?php echo e($e->details); ?>

                                   </td>
                        
                                    <td><button class="btn3 btn0"><a  onclick="deleteenquiry(<?php echo e($e->id); ?>)">Delete</a></button></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div> 

            <div class="page mt-4 dryfruit-page title1">
                  <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Chemicals Product List</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/add_chemical_product')); ?>" style="color:white">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                   <th>Banner Image</th>
                                    <th>Product Image</th>
                                    <th>Name</th>
                                    <th>View</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <tbody>
                            
                                 <?php $__currentLoopData = $saffroindproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr class="texttile_<?php echo e($sp->id); ?>">
                                    <td>

                                      <img src="/uploads/<?php echo e($sp->banner_image); ?>" width="120" height="120"><br>
                                        <?php echo e($tp->banner_image); ?>

                                    </td>

                                     <td>

                                      <img src="/uploads/<?php echo e($sp->product_image); ?>" width="120" height="120"><br>
                                        <?php echo e($sp->product_image); ?>

                                    </td>
                                

                                    <td>
                                         <?php echo e($sp->name); ?>

                                    </td>
                                    <td>
                   <button class="btn3 btn0"><a href="<?php echo e(url('admin/chemical_product_detail_view')); ?>/<?php echo e($sp->id); ?>" >View</a></button>

                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/update_chemical_product')); ?>/<?php echo e($sp->id); ?>" >Update</a></button></td>
                                    <td><button class="btn3 btn0"><a  onclick="delete_chemical_product(<?php echo e($sp->id); ?>)">Delete</a></button></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 


              <div class="page mt-4 category-page title1">
                  <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Texttile category list</h4>
                        <button class="btn1"><a href="" style="color:white">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                              <tbody>
                            
                                 
                                <tr>
                                    <td>
                                       
                                    </td>
                                

                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    <td>
                                       
                                   </td>
                                    <td><button class="btn3 btn0"><a href="">Delete</a></button></td>
                                </tr>
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 

  <!-- <div class=" page page1 my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">ADD NEW TEXTTILE PRODUCT</h4>
            <div class="detail">
                <div class="form">

                      <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 
                 <form  action="<?php echo e(url('admin/storetexttiledata')); ?>" enctype="multipart/form-data" method="POST" >
                         <?php echo csrf_field(); ?>
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Image</label>
                            </div>
                            <div class="col-md-12">
                                 <input type='file' name='image' onchange="readURL(this);" /required>
                                 <img id="blah" src="#" alt="" />
                               
                             </div>   
                        </div>
                        

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Name</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Product Name" name="name" value=""required>
                            </div>   
                        </div> 

                         <div class="part">
                            <div class="col-md-12 label">
                                <label>Price</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Product Price" name="price" value="">
                            </div>   
                        </div>  
                        <div class="main-button">
                            <button class="btn">Add</button> 
                       
                      <a href="<?php echo e(url('admin/home')); ?>"> Back to Home ?</a>
                            
                        </div>

                         
              
            
                    </form> 
                    
                        
                </div>
                
            </div>
        </div>
    </div>
 -->

   <!--  <div class="page page2 my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">ADD NEW SAFFROIND PRODUCT</h4>
            <div class="detail">
                <div class="form">

                      <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 
                 <form  action="<?php echo e(url('admin/storesaffroindproduct')); ?>" enctype="multipart/form-data" method="POST" >
                         <?php echo csrf_field(); ?>
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Image</label>
                            </div>
                            <div class="col-md-12">
                                 <input type='file' name='image' onchange="readURL(this);" /required>
                                 <img id="blah" src="#" alt="" />
                               
                             </div>   
                        </div>
                        

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Name</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Product Name" name="name" value=""required>
                            </div>   
                        </div> 

                         <div class="part">
                            <div class="col-md-12 label">
                                <label>Price</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Product Price ex. 100/kg" name="price" value="">
                            </div>   
                        </div>  
                        <div class="main-button">
                            <button class="btn">Add</button> 
                       
                      <a href="<?php echo e(url('admin/home')); ?>"> Back to Home ?</a>
                            
                        </div>

                         
              
            
                    </form> 
                    
                        
                </div>
                
            </div>
        </div>
    </div> -->
      

        </div>
    </div> 
    <style type="text/css">
        
        div#hideDiv {
  
    width: 50%;
    margin: 20px 0 0 auto;
    margin-right: 37px;
}

@media  only screen and (max-width: 767px){


        div#hideDiv {
  
    width: 100%;
    margin: 20px 0 0 auto;
    margin-right: 37px;
}




}
    </style>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

         $(function() {
setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

});

       function delete_texttile_product($id){

         if(confirm("do you want delete this Product ?")){
             $.ajax({

                url:'deletetexttileproduct/'+$id,
                type:'GET',
                dataType: "json",

             success: function(response){
        
                      $('.texttile_'+$id).hide();
          
                        },

              error: function(response) {


                        alert('error');
          
                 
                     },        
          
                  });

               }
            }  


             function delete_chemical_product($id){

         if(confirm("do you want delete this Product ?")){
             $.ajax({

                url:'delete_chemical_product/'+$id,
                type:'GET',
                dataType: "json",

             success: function(response){
        
                      $('.texttile_'+$id).hide();
          
                        },

              error: function(response) {


                        alert('error');
          
                 
                     },        
          
                  });

               }
            }
            
          
             
          
          
            function deletecontactus($id){

          if(confirm("do you want delete this contactus inquiry ?")){
                $.ajax({

                   url:'deletecontactus/'+$id,
                   type:'GET',
                   dataType: "json",

             success: function(response){
        
                      $('.conatct_'+$id).hide();
          
                        },

              error: function(response) {


                        alert('error');
          
                 
                     },        
          
                  });

               }
            }
        
        
 
 
   function deleteapplication($id){

          if(confirm("do you want delete this application ?")){
                $.ajax({

                   url:'deleteapplication/'+$id,
                   type:'GET',
                   dataType: "json",

             success: function(response){
        
                      $('.application_'+$id).hide();
          
                        },

              error: function(response) {


                        alert('error');
          
                 
                     },        
          
                  });

               }
            }
            
            
             function deleteenquiry($id){

          if(confirm("do you want delete this application ?")){
                $.ajax({

                   url:'deleteenquiry/'+$id,
                   type:'GET',
                   dataType: "json",

             success: function(response){
        
                      $('.inquiry_'+$id).hide();
          
                        },

              error: function(response) {


                        alert('error');
          
                 
                     },        
          
                  });

               }
            }







    $(document).ready(function(){
       
        $(".user-details").click(function(){
            $(".main-menu-content").slideToggle("slow");
        })

        $(".btn1").click(function(){
            $(".page1").show();
            $(".hosting-page").hide();
        })

       $("button.btn1.btn2").click(function(){
             $(".page2").show();
             $(".page1").hide();
            $(".dryfruit-page").hide();
         })
    });


     $(document).ready(function(){
        $("#submit").click(function(){


              $.ajax({

                     url:'getcity/'+id,
                     type:'GET',
                   dataType:'json',
                   

                }); 
        });
          

      
    });

    var tl = new TimelineMax();

//Logos
TweenMax.set('.wp-logo', { scale: 1 })
TweenMax.set('.weebly-logo', { scale: 1 })  

// Pages 
TweenMax.set('.dashboard-page', { display: 'none' })
TweenMax.set('.hosting-page', { display: 'block' })
TweenMax.set('.marketplace-page', { display: 'none' })
TweenMax.set('.domain-page', { display: 'none' })
TweenMax.set('.message-page', { display: 'none' })
TweenMax.set('.manage-account-page', { display: 'none' })
TweenMax.set('.dryfruit-page', { display: 'none' })
TweenMax.set('.category-page', { display: 'none' })

TweenMax.to('.mobile-nav', 0, { x: -300 })

/* Message Btn Starts */
$('.message-btn').on('click', function(){  
    $(this).addClass('active').removeClass('nav-btn');
    $('.marketplace-btn').removeClass('active').addClass('nav-btn');
    $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.hosting-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.dashboard-btn').removeClass('active').addClass('nav-btn');
    $('.manage-account-btn').removeClass('active').addClass('nav-btn');


   
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.manage-account-page').css({ display: 'none' })
   $('.message-page').css({ display: 'block' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
  
});
$('.manage-account-btn').on('click', function(){
    $(this).addClass('active').removeClass('nav-btn');
    $('.marketplace-btn').removeClass('active').addClass('nav-btn');
    $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.hosting-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.dashboard-btn').removeClass('active').addClass('nav-btn');
    $('.message-btn').removeClass('active').addClass('nav-btn');

   
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.message-page').css({ display: 'none' })
  $('.manage-account-page').css({ display: 'block' })
  $('.account-info-drop-down').css({ display: 'none' })
  $('.dryfruit-page').css({ display: 'none' })
  $('.category-page').css({ display: 'none' })
});


$('.dashboard-btn').on('click', function(){
   $(this).addClass('active').removeClass('nav-btn');
   $('.marketplace-btn').removeClass('active').addClass('nav-btn');
   $('.domain-btn').removeClass('active').addClass('nav-btn');
   $('.hosting-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
  
   $('.dashboard-page').css({ display: 'block' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.message-page').css({ display: 'none' })
    $('.manage-account-page').css({ display: 'none' }) 
    $('.dryfruit-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
});

$('.hosting-btn').on('click', function() {
    $(this).addClass('active').removeClass('nav-btn');
    $('.dashboard-btn').removeClass('active').addClass('nav-btn');
    $('.marketplace-btn').removeClass('active').addClass('nav-btn');
    $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.message-btn').removeClass('active').addClass('nav-btn');
    $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
   

    $('.dashboard-page').css({ display: 'none' })
    $('.hosting-page').css({ display: 'block' })
    $('.marketplace-page').css({ display: 'none' })
    $('.domain-page').css({ display: 'none' })
    $('.message-page').css({ display: 'none' })
    $('.manage-account-page').css({ display: 'none' })
    $('.dryfruit-page').css({ display: 'none' })
    $('.category-page').css({ display: 'none' })
  
});

$('.marketplace-btn').on('click', function(){
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.message-btn').removeClass('active').addClass('nav-btn'); 
    $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 

  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'block' })
     $('.domain-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.category-page').css({ display: 'none' })

});

$('.domain-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
    $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 

  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.domain-page').css({        display: 'block' })
     $('.message-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
       $('.category-page').css({ display: 'none' })

});

$('.dryfruit-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn');
      $('.manage-account-btn').removeClass('active').addClass('nav-btn');  
  
    $(".page1").hide();
    $(".page2").hide();
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })

});

$('.category-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
      $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
    $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 

  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })

});
</script>
</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/rajSynthetics1.ditests.com/resources/views/admin/home.blade.php ENDPATH**/ ?>