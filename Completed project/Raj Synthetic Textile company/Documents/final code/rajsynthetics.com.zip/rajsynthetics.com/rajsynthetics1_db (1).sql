-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 06, 2022 at 04:17 AM
-- Server version: 5.7.37-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rajsynthetics1_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admincontact`
--

CREATE TABLE `admincontact` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fb_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `india_mart_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admincontact`
--

INSERT INTO `admincontact` (`id`, `name`, `email`, `address`, `fb_url`, `india_mart_url`, `created_at`, `updated_at`) VALUES
(1, 'Raj Synthetics', 'rajsynthetic.surat@gmail.com', '409, 410 - SNS Arista, Behind Prime Shoppers, Vesu, Surat, Gujarat - 395007', 'https://www.facebook.com/Raj-Synthetics-1550407148517279/', 'https://www.indiamart.com/raj-synthetics-ltd/profile.html', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `token`, `created_at`, `updated_at`) VALUES
(1, 'apptest', 'rajsynthetics111@gmail.com', '$2y$10$fka3xBujaU2qnTlHDAUmdOg6n3MfCTpDFPOa9OhAgqJhee6DKMNXO', '9415', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `applicationform`
--

CREATE TABLE `applicationform` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `experience` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resume` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chemicaldproduct`
--

CREATE TABLE `chemicaldproduct` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chemicaldproduct`
--

INSERT INTO `chemicaldproduct` (`id`, `name`, `banner_image`, `product_image`, `description`, `created_at`, `updated_at`) VALUES
(10, 'Phthalic Anhydride', '1647692041_chemical_products-purification-banner.jpg', '1647498372_pthalic-pnhydride.png', '<div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><div class=\"kaylonabout textjustifiy\" style=\"margin: 0px 0px 15px; color: rgb(6, 6, 17);\"><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">Phthalic Anhydride (PA) is produced from the oxidation of O-xylene. At room temperature, it forms white crystal-like flakes. When contacted with water, phthalic acid is produced.</p></div><div class=\"kaylonabout textjustifiy\" style=\"margin: 0px 0px 15px; color: rgb(6, 6, 17);\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase; text-align: left;\">APPLICATION</h2><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">phthalic anhydride (PA) is used to manufacture plasticizers, pigments, dyes, and resins. One major consumer of PA is the phthalate plasticizer industry such as DINP, DOP, DBP, etc.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">PA is used in the manufacture of unsaturated polyester resins (UPR) that are usually blended with glass fibers to produce fiberglass-reinforced plastics. PA-based alkyd resins are used in paints and lacquers that go into architectural, machinery, furniture, and fixture applications.</p></div><div class=\"col-md-9 col-sm-9 col-xs-12 p0\" style=\"min-height: 1px; padding: 0px; float: left; width: 982.5px; color: rgb(6, 6, 17); text-align: start;\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase;\">DESCRIPTION</h2><ul style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; list-style: none; padding: 0px;\"><li><strong style=\"font-weight: bold;\">Name of a product:</strong> Phthalic Anhydride (A technical grade).</li><li><strong style=\"font-weight: bold;\">Chemical name (on IUPAC):</strong> 1,3-Dihydro-2-benzofuran-1,3-dione.</li><li><strong style=\"font-weight: bold;\">Chemical formula:</strong> C8H4O3.</li><li><strong style=\"font-weight: bold;\">CAS-number:</strong> 85-44-9</li></ul></div></div>', NULL, NULL),
(11, 'Maleic Anhydride', '1647690750_chemicals-inners.jpg', '1647690750_maleic-anhydride.png', '<h1 class=\"titlepagediv\" style=\"margin: 20px 0px 10px; font-size: 55px; font-family: Roboto, sans-serif; line-height: 1.1; color: rgb(102, 102, 102); padding: 10px 0px;\"><div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-size: 14px;\"><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">Maleic Anhydride (Maleic Anhydride) is an intermediate chemical, produced from the oxidation of benzene using a special catalyst.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">Maleic Anhydride is a versatile chemical that is needed in almost all fields of the chemical industry.&nbsp;The use of Maleic Anhydride varies due to the structure of the dicarboxylic acid group, double bond reactivity between alpha and beta positions.&nbsp;This chemical structure and the high reactivity of the Maleic Anhydride derivative make it possible to make various types of resins and also organic reagents for various chemical transformations.</p></div></h1><h2 class=\"bottle-grade-title\" style=\"font-family: Roboto, sans-serif; line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase;\">APPLICATION</h2><h1 class=\"titlepagediv\" style=\"margin: 20px 0px 10px; font-size: 55px; font-family: Roboto, sans-serif; line-height: 1.1; color: rgb(102, 102, 102); padding: 10px 0px;\"><div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-size: 14px;\"><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">Maleic Anhydride is an important Organic Acid Anhydride. It is used in the manufacture of a wide range of products like Un-saturated Polyester Resins, Alkyd Resins, Lube Oil Additives, Paper Sizing Chemicals, Insecticides and Fine Chemicals.</p></div></h1><h2 class=\"bottle-grade-title\" style=\"font-family: Roboto, sans-serif; line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase;\">DESCRIPTION</h2><h1 class=\"titlepagediv\" style=\"margin: 20px 0px 10px; font-size: 55px; font-family: Roboto, sans-serif; line-height: 1.1; color: rgb(102, 102, 102); padding: 10px 0px;\"><div class=\"col-md-9 col-sm-9 col-xs-12 p0\" style=\"min-height: 1px; padding: 0px; float: left; width: 982.5px; color: rgb(6, 6, 17); font-size: 14px;\"><ul style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; list-style: none; padding: 0px;\"><li><strong style=\"font-weight: bold;\">Chemical formula:</strong>&nbsp;C4H2O3</li><li><strong style=\"font-weight: bold;\">Molecular Weight:</strong>&nbsp;98.06</li><li><strong style=\"font-weight: bold;\">CAS-number:</strong>&nbsp;108-31-6</li></ul></div><br></h1>', NULL, NULL),
(12, 'Citric Acid', '1647690970_chemicals-inners.jpg', '1647690970_citric-acid.png', '<div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">Citric acid is a weak organic acid having the chemical formula&nbsp;C6H8O7.&nbsp;Citric acid is found naturally in citrus fruits. In biochemistry, citric acid acts as an intermediate in the citric acid cycle.</p></div><div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase; text-align: left;\">APPLICATION</h2><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">Citric Acid is mainly used as acidulant, flavoring agent, preservative and antistaling agent in food and beverage industry, it is also used as antioxidant, plasticizer and detergent in chemical, cosmetics and cleaning industries.</p></div><div class=\"col-md-9 col-sm-9 col-xs-12 p0\" style=\"min-height: 1px; padding: 0px; float: left; width: 982.5px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase;\">DESCRIPTION</h2><ul style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; list-style: none; padding: 0px;\"><li><strong style=\"font-weight: bold;\">Product Characters：</strong>&nbsp;White Crystalline Powders, Colorless Crystals or Granules</li><li><strong style=\"font-weight: bold;\">Executive Standards：</strong>&nbsp;BP/USP/FCC/E330/GB1886.235-2016</li><li><strong style=\"font-weight: bold;\">Formula:</strong>&nbsp;C6H8O7</li><li><strong style=\"font-weight: bold;\">CAS No:</strong>&nbsp;77-92-9</li></ul></div>', NULL, NULL),
(13, 'Di Octyl Phthalate', '1647691046_chemicals-inners.jpg', '1647691046_di-octyl-phthalate.jpg', '<div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">It has comprehensive properties, such as high plasticizing efficiency, low volatility, UV resisting property, water-extracting proof, Colds resisting property, and also good softness and electric Property.</p></div><div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase; text-align: left;\">APPLICATION</h2><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">Major Uses Film, Sheet, Leather, Wire, Paste , Tarpaulin, Applicable Plastics PVC, PS, Cellulose-based resin.</p></div><div class=\"col-md-9 col-sm-9 col-xs-12 p0\" style=\"min-height: 1px; padding: 0px; float: left; width: 982.5px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase;\">DESCRIPTION</h2><ul style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; list-style: none; padding: 0px;\"><li><strong style=\"font-weight: bold;\">Product:</strong>&nbsp;DOP</li><li><strong style=\"font-weight: bold;\">Chemical Name:&nbsp;</strong>Di(2-ethylhexyl) phthalate</li><li><strong style=\"font-weight: bold;\">Molecular Formula:&nbsp;</strong>C24H38O4</li><li><strong style=\"font-weight: bold;\">CAS No:</strong>&nbsp;117-81-7</li></ul></div>', NULL, NULL),
(14, 'Urea', '1647691135_chemicals-inners.jpg', '1647691135_urea01.png', '<div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">Technical Grade Urea&nbsp;is an&nbsp;organic compound. Urea serves an important role in the&nbsp;metabolism&nbsp;of nitrogen-containing compounds. It is a colorless, odorless solid, highly soluble in water, urea is basically non-toxic. It gets Dissolved in water easily, urea is not&nbsp;acidic. Urea is also not alkaline. The human body uses urea in many processes, most notably nitrogen excretion. The&nbsp;liver&nbsp;forms it by combining two ammonia&nbsp;molecules with a&nbsp;carbon dioxide molecule in the&nbsp;urea cycle. Urea is widely used in&nbsp;fertilizers&nbsp;as a source of nitrogen and is an important&nbsp;raw material&nbsp;for the&nbsp;chemical industry, animal feed, laminated boards.</p></div><div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase; text-align: left;\">APPLICATION</h2><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\">T.G.Urea is a non-corroding alternative to&nbsp;rock salt used for manufacturing of C.P.C blue Crude, Urea-formaldehyde, an ingredient in hair removers, browning agent, Raw material in&nbsp;skin cream,&nbsp;moisturizers,&nbsp;hair conditioners, Raw material for a flame-proofing agent, Raw material for tooth whitening&nbsp;products, Raw material in&nbsp;dish soap, Raw material for fermentation of&nbsp;sugars&nbsp;into&nbsp;ethanol, A nutrient used by&nbsp;plankton&nbsp;in&nbsp;ocean nourishment&nbsp;experiments for&nbsp;geoengineering&nbsp;purposes, Additive for extending the working temperature, As a solubility-enhancing and moisture-retaining additive to&nbsp;dye&nbsp;baths for textile dyeing or printing.</p></div><div class=\"col-md-9 col-sm-9 col-xs-12 p0\" style=\"min-height: 1px; padding: 0px; float: left; width: 982.5px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase;\">DESCRIPTION</h2><ul style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; list-style: none; padding: 0px;\"><li><strong style=\"font-weight: bold;\">Chemical Formula:&nbsp;</strong>CH4N2O</li><li><strong style=\"font-weight: bold;\">Molecular Weight:</strong>&nbsp;60.06</li></ul></div>', NULL, NULL),
(15, 'Sodium Hydro Sulfite', '1647691215_chemicals-inners.jpg', '1647691215_sodium-hydro-sulfite.png', '<div class=\"kaylonabout textjustifiy\" style=\"text-align: center; margin: 0px 0px 15px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase; text-align: left;\">APPLICATION</h2><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\"><strong style=\"font-weight: bold;\">TEXTILES</strong><br>Reduction agent for vat-dyeing cotton fibers and blends. Reduces and eliminates colors not absorbed in polyester fibers. Reduction agent for stripping colorants from textile fibers and in cleaning dyeing equipment.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\"><strong style=\"font-weight: bold;\">PULP AND PAPER</strong><br>Bleaching agent for mechanical and thermo-mechanical pulp and for deinking recycled paper.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px;\"><strong style=\"font-weight: bold;\">OTHERS</strong><br>Bleaching agent for sugarcane, glues, gelatins, soaps, oils and clay. Reducing or bleaching agent in production of dyestuffs and pharmaceuticals. Reduction of hexavalent chromium to trivalent state for effluent treatment.</p></div><div class=\"col-md-9 col-sm-9 col-xs-12 p0\" style=\"min-height: 1px; padding: 0px; float: left; width: 982.5px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><h2 class=\"bottle-grade-title\" style=\"line-height: 27px; color: rgb(53, 70, 188); margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 18px; text-transform: uppercase;\">DESCRIPTION</h2><ul style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; list-style: none; padding: 0px;\"><li><strong style=\"font-weight: bold;\">Chemical Formula:</strong>&nbsp;Na2S2O4</li><li><strong style=\"font-weight: bold;\">Molecular Weight:</strong>&nbsp;174.10</li><li><strong style=\"font-weight: bold;\">CAS Number:</strong>&nbsp;7775-14-6</li></ul></div>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `subject`, `description`, `created_at`, `updated_at`) VALUES
(2, 'jinal patel', 'apptest2303@gmail.com', 'Enquiry about product delivery', 'can you provide a home delivery of product', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Afghanistan', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Algeria', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Albania', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Argentina', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'Australia', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Bahamas', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'Bahrain', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'Banglades', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'Belgium', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'Bhutan', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'Brazil', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'Burma', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'Cambodia', NULL, NULL),
(14, 'Canada', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 'China', NULL, NULL),
(16, 'Colombia', NULL, NULL),
(17, 'Cuba', NULL, NULL),
(18, 'Denmark', NULL, NULL),
(19, 'Egypt', NULL, NULL),
(20, 'Fiji', NULL, NULL),
(21, 'Finland', NULL, NULL),
(22, 'France', NULL, NULL),
(23, 'Germany', NULL, NULL),
(24, 'Greece', NULL, NULL),
(25, 'Iceland', NULL, NULL),
(26, 'India', NULL, NULL),
(27, 'Indonesia', NULL, NULL),
(28, 'Iran', NULL, NULL),
(29, 'Iraq', NULL, NULL),
(30, 'Israel', NULL, NULL),
(31, 'Italy', NULL, NULL),
(32, 'Jamaica', NULL, NULL),
(33, 'Japan', NULL, NULL),
(34, 'Jordan', NULL, NULL),
(35, 'Kuwait', NULL, NULL),
(36, 'Malawi', NULL, NULL),
(37, 'Malaysia', NULL, NULL),
(38, 'Maldives', NULL, NULL),
(39, 'Mexico', NULL, NULL),
(40, 'Nepal', NULL, NULL),
(41, 'Netherlands', NULL, NULL),
(42, 'New Zealand', NULL, NULL),
(43, 'Nigeria', NULL, NULL),
(44, 'Norway', NULL, NULL),
(45, 'Oman', NULL, NULL),
(46, 'Pakistan', NULL, NULL),
(47, 'Saudi Arabia', NULL, NULL),
(48, 'Russian Federation', NULL, NULL),
(49, 'South Sudan', NULL, NULL),
(50, 'Spain', NULL, NULL),
(51, 'Sri Lanka', NULL, NULL),
(52, 'Turkey', NULL, NULL),
(53, 'United Arab Emirates', NULL, NULL),
(54, 'United States of America', NULL, NULL),
(55, 'Vietnam', NULL, NULL),
(56, 'Zimbabwe', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_06_25_095606_create_countries_table', 1),
(5, '2021_06_25_114921_create_', 2),
(6, '2021_06_25_115026_create_enquiry_table', 2),
(7, '2021_06_25_134250_create_applicationform_table', 3),
(8, '2021_06_27_074415_create_contact_us_table', 4),
(9, '2021_06_27_084601_create_admincontact_table', 5),
(10, '2021_06_28_052452_create_admins_table', 6),
(11, '2021_06_28_134848_create_texttilecatagory_table', 7),
(12, '2021_06_29_115447_create_subcategory_table', 8),
(13, '2021_06_30_065630_create_texttileproduct_table', 9),
(14, '2021_06_30_102903_create_saffroindproduct_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phone_no`
--

CREATE TABLE `phone_no` (
  `id` int(11) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phone_no`
--

INSERT INTO `phone_no` (`id`, `phone`, `admin_id`) VALUES
(1, '+91 63551 97413', 1),
(2, '+91 73837 34964', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `c_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `texttilecatagory`
--

CREATE TABLE `texttilecatagory` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `texttilecatagory`
--

INSERT INTO `texttilecatagory` (`id`, `cname`, `image`, `description`, `created_at`, `updated_at`) VALUES
(14, 'Yarns Product', '1625030293_product-2.jpg', 'Hand loom, Machine made', NULL, NULL),
(15, 'PET Chips Product', '1625030361_vision1.jpg', 'Hand loom, Machine made', NULL, NULL),
(16, 'Fabrics Product', '1625030405_product-3.jpg', 'Hand loom, Machine made', NULL, NULL),
(17, 'Garments Product', '1625030459_vision1.jpg', 'Hand loom, Machine made', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `texttileproduct`
--

CREATE TABLE `texttileproduct` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `texttileproduct`
--

INSERT INTO `texttileproduct` (`id`, `name`, `banner_image`, `product_image`, `description`, `created_at`, `updated_at`) VALUES
(12, 'Polyester Partially Oriented Yarn (Polyester POY)', '1647431951_product-bg.jpg', '1647430213_air-covered-yarn.jpg', '<p style=\"margin-bottom: 30px; font-size: 16px; line-height: 26px; letter-spacing: 0.5px; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, \"Noto Sans\", \"Liberation Sans\", sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\";\">Polyester Partially Oriented Yarn, commonly known as Polyester POY is the primary form of Polyester yarn. It is also known as Polyester Pre-Oriented Yarn. It is the first form of yarn made directly by spinning Polyester Chips. Polyester POY is mainly used for manufacturing textured yarn. Polyester POY can be available in two luster: Semi Dull & Bright. Dope Dyed technology is used for making of colored POY. Polyester POY is mainly available in packed in cone as per customer requirement.</p><p style=\"margin-bottom: 30px; font-size: 16px; line-height: 26px; letter-spacing: 0.5px; color: rgb(33, 37, 41); font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, \"Noto Sans\", \"Liberation Sans\", sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\";\">We have strong network in China, Taiwan, South Korea, Malaysia, Thailand, Indonesia, Mexico, Spain, Italy & various other countries for Polyester Yarns & Its Sub products. We have consistent monitoring of markets & providing valuable feedback to our valuable customers.</p>', NULL, NULL),
(18, 'Polyester Drawn Textured Yarn (Polyester DTY)', '1647511873_polyester-dty.jpg', '1647511873_polyester-dty.jpeg', '<p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">Drawn Textured Yarn (DTY) yarn is obtained when Polyester POY is simultaneously twisted and drawn. DTY yarn is mainly used as a part of weaving and knitting of fabrics for making garments, home decorations, seat covers, bags and numerous different things. DTY yarn can be in Semi Dull or Bright or Triloble Bright depending upon the kind of areas of filaments.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">Technical Properties of DTY yarn can be moulded in a few ways to make the yarn reasonable for its vast uses. Different heating techniques can be used to make the yarn set for particular use – 1 Heater DTY is normally woolly and more stretchable when contrasted with DTY with 2 Heater. Also the DTY yarn can be made with a several combination of Intermingle points – it can be Non-Intermingle (NIM) having 0 – 10 knots/meter or Semi-Intermingle (SIM) having 40 – 50 knots/meter or High-Intermingle (HIM) having 100 – 120 knots/meter. These knots are not actually the knots tied when two threads are broken yet they are the tangle knots created by heating pressure. These Intermingle yarns, also known as Interlaced yarn, are the replacement for lightly twisted yarns. Polyester DTY yarn can likewise be wound to high winds like 1500 TPM or 4000 TPM (twist per meter). Such twisted yarn can also be heat-set set to make the yarn for all time thermo-set the twist. Catonic DTY is another variation of Polyester DTY that is mainly used as a part of blankets. Catonic DTY is produced using Catonic PET Chips.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">Polyester DTY yarn can also be obtained in different colors by the dope dyed technology or by traditional dyeing. Dope dyed DTY is generally packed on paper bobbins though Raw White DTY that will be used for dyeing is loosely packed on perforated plastic tube so that all the yarn can be effectively dyed when the bobbin is dipped in color. DTY is mainly produced in huge quantity in China, India, Taiwan, Indonesia and Malaysia and export around the world.</p>', NULL, NULL),
(19, 'Polyester Fully Drawn Yarn (Polyester FDY)', '1647512028_polyester-fdy.jpg', '1647512028_download.jpg', '<p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">Polyester FDY is the abbreviation for Polyester Fully Drawn Yarn. It is also know as Polyester Filament Yarn (PFY) or Spin Draw Yarn (SDY). FDY is mainly used as weft or weaves in making fabrics. FDY can be knitted or woven with any other filament yarn to get fabric of various different varieties. It is mainly used in Home Furnishing Fabrics, Fashion Fabrics, Denim, Terry Towel and others.FDY yarn is mainly available in 3 lustre – Semi-dull (SD), Bright (BR) having circular section &amp; Triloble Bright (TBR) having triangular cross-sections</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">Filament yarn having trilobal bright lustre is widely used in making curtains, bed-sheets and carpets. FDY is available in Raw-white as well dope dyed. Dope Dyed FDY yarn can be used to make the colored fabric directly instead of making the fabric with FDY Raw-white first &amp; then dyeing it. Catonic FDY is another variation of Filament yarn. Catonic FDY yarn is made from Catonic PET Chips.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">Polyester FDY yarn can also be twisted to make Polyester Embroidery Thread that is widely used in sewing. India &amp; China are the leading manufacturers of Polyester FDY yarn. Currently we are exporting FDY yarns from China, India, Malaysia, Thailand &amp; Indonesiato various countries in the world. We have exclusive contacts with almost all suppliers &amp; manufacturers from China &amp; can get the best prices &amp; quality. Polyester FDY yarn is available in below specifications.</p>', NULL, NULL),
(22, 'Polyester Staple Fibre', '1647511757_staple-fibre.jpg', '1647511757_mono-yarn.jpg', '<p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">Polyester Staple Fiber (PSF) is somewhat Polyester Fiber made directly from PTA and MEG or PET Chips or from Recycled PET Bottle Flakes. PSF produced using PTA and MEG or PET Chips is known as Virgin PSF and PSF produced using Recycled PET Flakes is called Recycled PSF. 100% virgin PSF is typically unreasonable than recycled PSF and is also more hygienic. Polyester Staple Fiber is generally used in spinning, weaving non-woven.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">PSF is mainly used for fiber fillings in cushions and sofa. It is also used generally in spinning to make Polyester Spun Yarn which is then knitted or weaved into fabrics. PSF is mainly classified Solid and Hollow Polyester staple fiber. Hollow PSF can also have a few properties like Conjugated, Siliconized, Slick and Dry PSF. These properties are normally represented to as HSC (Hollow Conjugated Siliconized), HCNS (Hollow Conjugate Non-Siliconized) or Slick PSF that has a smooth finish. Depending upon the lustre, PSF can be classified as Semi Dull and Bright. By mixing color master-batch, dope dyed PSF can also be obtained in Optical White, Black and a several colors.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">Polyester Staple Fiber is available in various Deniers with various cut-lengths. It is mainly available in 1.4D, 1.5D, 3D, 6D, 7D, 15D and cut lengths like 32mm, 38mm, 44mm, 64mm. PSF is mainly produced in India, China, Taiwna, Indonesia, Vietnam, Malaysia, and Korea. We can supply you best quality Polyester Staple Fiber from manufacturers and suppliers in India, China, Taiwan, Indonesia, Vietnam, Malaysia and Korea.</p>', NULL, NULL),
(24, 'Polyester High Tenacity Yarn', '1647512188_high-tenacity-yarn.jpg', '1647512188_download (1).jpg', '<p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">kayavlon Impex Pvt Ltd. is a main exporter of High Tenacity Yarns in India and has been exporting world class quality high tenacity yarn to different nations over the globe creating its demand for quality products in Europe, Asia, Africa and America. A yarn containing filaments produced using synthetic polymers has a cross-section having no less than 5 vertices, a titer of 1 to 7 dtex and a tenacity of at least 60cN/tex.</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">The filaments of the high tenacity yarn ideally have a cross-section having 5 to 8 vertices, possibly with indentation between the vertices. The cross-section of the filaments is ideally star-shaped. The high tenacity yarn ideally has a tenacity of 60 to 85 cN/tex, a lengthening at break of 15% to 35%, hot-air shrinkage of 4% to 10% and a stretch recovery of 250 to 400 cN/tex. High Tenacity yarn is also available in various variations like typical shrinkage, low shrinkage and super low shrinkage depending on the suitable end-use. The high tenacity yarn is excellently suited for use in the manufacture of industrial fabrics, especially airbag fabrics</p><p style=\"color: rgb(51, 51, 51); line-height: 25px; font-size: 16px; text-align: justify; padding: 5px 0px 15px; font-family: Roboto, sans-serif;\">High tenacity yarns have been used in the manufacture of textiles, carpet and tarpaulin. In the manufacture of textile fabrics, for example, wovens, knitted and crocheted fabrics and nonwovens from yarns containing synthetic polymer filaments, the most vital thought in the manufacture of these fabrics is the use of yarns with filaments having high tenacity and ensuring great foldability. The high tenacity yarn has high strength, durability and chemical resistance, and withstands extremely hot environment that can stress conventional multi-filaments to their performance limits. We can supply you best quality Polyester High Tenacity yarns from manufacturers and suppliers in India, China, Taiwan, Indonesia, Vietnam, Malaysia and Korea.</p>', NULL, NULL),
(27, 'AIR CORVERD YARN', '1650891761_air-covered-yarn_banner.jpg', '1650890359_air-covered-yarn_banner.jpg', '<table border=\"1\" class=\"producttable\" style=\"border-spacing: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-color: rgb(214, 211, 211); width: 812px; color: rgb(6, 6, 17); font-family: Roboto, sans-serif; font-size: 14px;\"><tbody><tr><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\"><strong style=\"font-weight: bold;\">DTY</strong></td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\"><strong style=\"font-weight: bold;\">Spandex</strong></td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\"><strong style=\"font-weight: bold;\">Intermingle</strong></td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\"><strong style=\"font-weight: bold;\">Color</strong></td></tr><tr><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">150D/48F</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">20D, 30D, 40D, 70D</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">SIM/HIM</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">RW / BDD</td></tr><tr><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">200D/96F</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">20D, 30D, 40D, 70D</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">SIM/HIM</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">RW / BDD</td></tr><tr><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">300D/96F</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">20D, 30D, 40D, 70D</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">SIM/HIM</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">RW / BDD</td></tr><tr><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">150D/48F/2 PLY</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">20D, 30D, 40D, 70D</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">SIM/HIM</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">RW / BDD</td></tr><tr><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">300D/96F/2 PLY</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">20D, 30D, 40D, 70D</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">SIM/HIM</td><td style=\"padding: 6px 5px; font-size: 15px; border-color: rgb(208, 208, 208);\">RW / BD</td></tr></tbody></table>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admincontact`
--
ALTER TABLE `admincontact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `applicationform`
--
ALTER TABLE `applicationform`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chemicaldproduct`
--
ALTER TABLE `chemicaldproduct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `phone_no`
--
ALTER TABLE `phone_no`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `texttilecatagory`
--
ALTER TABLE `texttilecatagory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `texttileproduct`
--
ALTER TABLE `texttileproduct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admincontact`
--
ALTER TABLE `admincontact`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `applicationform`
--
ALTER TABLE `applicationform`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chemicaldproduct`
--
ALTER TABLE `chemicaldproduct`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `phone_no`
--
ALTER TABLE `phone_no`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `texttilecatagory`
--
ALTER TABLE `texttilecatagory`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `texttileproduct`
--
ALTER TABLE `texttileproduct`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
