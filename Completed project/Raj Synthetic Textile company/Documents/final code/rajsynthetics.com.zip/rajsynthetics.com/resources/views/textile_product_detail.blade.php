@extends('layouts.app')

@section('content')

<div class="co_inner-banner">
		<img src="/uploads/{{$banner_image}}">
	</div>
	<div class="co_product-detail">
		<div class="container">
			<div class="inner_pdetail">
				<h2>{{$name}}</h2>
				<div class="row">
					<div class="col-lg-7 col-md-7 order_01">
						<div class="product-prg">
							{!! $description !!}
                            <div class="button"><a href="{{url('/ContactUs')}}"><span>Send Enquiry Now</span></a></div>
						</div>
					</div>
					<div class="col-lg-5 col-md-5 order_02">
						<div class="product-detail-img">
							<img src="/uploads/{{$product_image}}">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
 <style type="text/css">
.co_footer:before {
    top: 10px;
}

@media only screen and (min-width: 768px) and (max-width: 1023px){
.co_footer:before {
    top: -12px;
}
}
@media only screen and (max-width: 767px){
   .co_footer:before {
    top: -7px;
}
}
</style>
	@endsection
	
	