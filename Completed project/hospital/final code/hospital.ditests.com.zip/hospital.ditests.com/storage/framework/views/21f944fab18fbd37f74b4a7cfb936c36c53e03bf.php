

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">

  	  <div class="mt-5">
                       <div class="list1">
                        <h4 class="mb-4">What We Do</h4>
                        
                       </div>

                     <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                  <!--   <th>Image</th>
                                    <th>Mission</th>
                                    <th>Value</th>
                                    <th>Promise</th> -->
                                    <th>Images</th>
                                </tr>
                            </thead>
                         
                             <tbody>
                              <?php $__currentLoopData = $about_work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                	 <?php $__currentLoopData = $about_workimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                	   <?php if($aw->id == $ai->work_id): ?>

                                        <td>
                                           <img src="/uploads/<?php echo e($ai->image); ?>" width="200" height="200"><br>

                                           <?php echo e($ai->image); ?>  
                                        </td>
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 </tr> <br>
                                       
                                  <div class="data">
                                      <b>Title</b>
                                  </div>

                                   
                                   <div class="data">
                              
                                    <?php echo e($aw->title); ?>


                                  </div> <br>
                                  <div  class="data">
                                      <b>Main Title</b> 
                                  	</div>
                                   
                                   <div  class="data">
                      
                                   
                                       <?php echo e($aw->main_title); ?>

                                   

                                   </div><br>

                                   
                                  
                                  
                                   <tr>
                                   
                                    <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateaboutwork')); ?>/<?php echo e($aw->id); ?>" >Update</a></button></td>
                                  </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </table>
                    </div>

                  </div>

              </div>


               <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">WORK BENIFITS </h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addworkbenifits')); ?>">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Icon</th>
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $work_benifits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="workbenifits_<?php echo e($wb->id); ?>">
                                    <td>

                                       <i class="<?php echo e($wb->icon); ?>"></i> 
                                        
                                         
                                    </td>

                                     <td>
                                      <?php echo e($wb->title); ?>

                                    </td>
                                   
                                    <td>
                                    <?php echo e($wb->description); ?>

                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateworkbenifits')); ?>/<?php echo e($wb->id); ?>">Update</a></button></td>
                                    <td><button class="btn3 btn0" onclick=" deleteworkbenifits(<?php echo e($wb->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>

                 <script type="text/javascript">

            function  deleteworkbenifits($id){
 
     if(confirm("do you want delete this Inquiry ?")){
             $.ajax({

                url:' deleteworkbenifits/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.workbenifits_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 
       
                   

                 </script>
                   

  <style type="text/css">
  	.data{

  		margin-left: 25px;
  	}

  </style>
  <?php $__env->stopSection(); ?>

 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/hospital.ditests.com/resources/views/admin/aboutwork.blade.php ENDPATH**/ ?>