

<?php $__env->startSection('content'); ?> 

<style type="text/css">
    .bor:last-child {
        border: none;
     }
</style>

    <div class="co-banner1">
          <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'About Us'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"><i class="far fa-home"></i> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
          <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="in_about">
          <div class="container">
             <?php $__currentLoopData = $about_description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="inner-about">
                        <?php $__currentLoopData = $about_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$ai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($keys<3): ?>
                        <?php if($keys==0): ?>
                        <figure class="image-1 "><img src="uploads/<?php echo e($ai->image); ?>" alt=""></figure>
                        <?php elseif($keys==1): ?>
                        <figure class="image-2 zoom"><img src="uploads/<?php echo e($ai->image); ?>" alt=""></figure>
                        <?php elseif($keys==3): ?>
                        <figure class="image-3 zoom"><img src="uploads/<?php echo e($ai->image); ?>" alt=""></figure>
                        <?php else: ?>
                      
                        <?php endif; ?>
                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                      <div class="about_disc">
                                    <h4><?php echo e($ad->title); ?></h4>
                                    <h3><?php echo e($ad->main_title); ?></h3>
                                   <?php echo $ad->description; ?>

                      </div>
                </div>
                </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
    </div>
    <div class="our">
          <div class="try_circle_first hidden-xs hidden-sm">
                 <img src="image/right_cycle1.png" alt="circle">
            </div>
            <div class="try_circle_second hidden-xs hidden-sm">
                   <img src="image/right_cycle2.png" alt="circle">
            </div>
          <div class="container">
                <div class="row">

                    <?php $__currentLoopData = $mission_vision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-lg-6 col-md-6 bor">
                            <div class="our_mission">
                                  <div class="round_img1">
                                     <a href="#"><i class="<?php echo e($m->icon); ?>"></i></a>
                                  </div>           
                                     <h3><?php echo e($m->title); ?></h3>
                                     <p><?php echo e($m->description); ?></p>
                             </div>
                       </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                </div>
          </div>
    </div>
    <div class="what">
          <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">

                          <div class="what_img">
                                 <img src="uploads/<?php echo e($about_workimage); ?>">
                          </div>
                    </div>
                    <div class="col-lg-6 col-md-6">

                     <?php $__currentLoopData = $about_work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="what_inner">
                            <h4><?php echo e($aw->title); ?></h4>
                            <h3><?php echo e($aw->main_title); ?></h3>
                            <div class="what_sub">
                                <div class="row">
                                    <?php $__currentLoopData = $work_benifits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="cl-intro">
                                        <div class="round_img2">
                                            <a href="#"><i class="<?php echo e($wb->icon); ?>"></i></a>
                                        </div>
                                        <h3><?php echo e($wb->title); ?></h3>
                                        <p><?php echo e($wb->description); ?></p>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="box-button">
                                <a href="#" class="banner-btn theme-btn" data-animation-in="bounceInLeft" data-animation-out="animate-out bounceOutRight">
                                    <span class="btn-title">Contact Now</span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
          </div>
    </div>
    <div class="choose">
        <?php $__currentLoopData = $whychooseus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="row row1">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="choose_disc">
                        <h4><?php echo e($wc->title); ?></h4>
                        <h3><?php echo e($wc->main_title); ?></h3>
                        <p><?php echo e($wc->description); ?></p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="choose_inner">
                        <div class="choose_img">
                            <img src="uploads/<?php echo e($wc->image); ?>" alt="image">
                        </div>
                        <div class="choose-inner">
                           <img src="image/image-5.png" alt="image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="ch_disc">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="ch_disc_main">

                        <?php $__currentLoopData = $benifits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="col-box">
                             <div class="round_img2">
                                 <a href="#"><i class="<?php echo e($b->icon); ?>"></i></a>
                             </div>
                            <div class="ch_disc_inner">
                                  <h2 ><?php echo e($b->name); ?></h2>
                                  <p><?php echo e($b->description); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                       
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="certi">
        <div class="container">
            <h3>Our Achivement</h3>
            <div class="row__1 cer_slider">

                 <?php $__currentLoopData = $achivement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-lg">
                        <div class="ce_inner">
                              <img src="uploads/<?php echo e($a->file); ?>">
                        </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
            </div>
        </div>
    </div>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script type="text/javascript" src="https://cldup.com/S6Ptkwu_qA.js"></script>
    <script type="text/javascript">

         $('.cer_slider').slick({
              dots: false,
              infinite: true,
              autoplay: true,
              autoplaySpeed: 1000,
              speed: 800,
              slidesToShow:3,
              adaptiveHeight: true,
              prevArrow: '<div class="slide-arrow2 prev-arrow2"><i class="fa fa-angle-left"></i></div>',
              nextArrow: '<div class="slide-arrow2 next-arrow2"><i class="fa fa-angle-right"></i></div>',
              responsive: [
                    {
                      breakpoint: 1024,
                      settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        adaptiveHeight: true,
                      },
                    },
                    {
                      breakpoint: 600,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                      },
                    },
                  ],
            });
        

    </script>
   
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical_app\resources\views/about.blade.php ENDPATH**/ ?>