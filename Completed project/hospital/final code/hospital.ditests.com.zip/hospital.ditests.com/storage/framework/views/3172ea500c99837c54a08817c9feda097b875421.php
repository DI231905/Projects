

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">



 <div class="mt-5">
                   
                   <h4 class="mb-4">Diagnostic Services page Banner</h4>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th> 
                                    <th>Page Name</th>   
                                    <th>Image</th> 
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                           <?php if($a->name=="Diagnostic Services"): ?>
                             <tbody>
                             
                               <tr>
                                    <td>
                                      <?php echo e($a->name); ?>

                                    </td>

                                      <td>
                                      <?php echo e($a->page_name); ?>

                                    </td>
                                   
                                    <td>

                                       <img src="/uploads/<?php echo e($a->image); ?>" width="120" height="100"><br>
                                       <?php echo e($a->image); ?>  
                                         
                                    </td>
    
                                 <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updatebannerimg')); ?>/<?php echo e($a->id); ?>">Update</a></button></td>
                                   
                                </tr>
                                
                            </tbody>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>





          <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Diagnostic Services</h4>
                        <button class="btn1"><a  style="color: black"  href="<?php echo e(url('admin/addnewservices1')); ?>">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th> 
                                    <th>Hover Image</th> 
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="services1_<?php echo e($hs->id); ?>">
                                    <td>

                                     <img src="/uploads/<?php echo e($hs->image1); ?>" width="120" height="100"><br>
                                       <?php echo e($hs->image1); ?>  
                                                     
                                    </td>
                                    <td>

                                     <img src="/uploads/<?php echo e($hs->image2); ?>" width="120" height="100"><br>
                                       <?php echo e($hs->image2); ?>  
                                                     
                                    </td>
                                   
                                     <td>
                                      <?php echo e($hs->title); ?>

                                    </td>
                                   
                                    <td>
                                    <?php echo e($hs->description); ?>

                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateservice1')); ?>/<?php echo e($hs->id); ?>">Update</a></button></td>
                                    <td><button class="btn3 btn0" onclick="deleteservice1(<?php echo e($hs->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>
                 <script type="text/javascript">
                   

  function deleteservice1($id){
    // alert('i am here');

     if(confirm("do you want delete this Inquiry ?")){
             $.ajax({

                url:'deleteservice1/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.services1_'+$id).hide();
          
                        },

      error: function(response){


               alert('error');
          
                 
                  },        
          
                });

          }
      } 
       

                 </script>
                 

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical_app\resources\views/admin/diagnostic_service.blade.php ENDPATH**/ ?>