             

 

   <?php $__env->startSection('content'); ?>

         <div class="page mt-4 hosting-page title1" style="display: block;">

               <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Mission-vision</h4>
                       
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Icon</th>
                                  
                                    <th>Title</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $mission_vision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr>
                                    <td>
                                      
                                       <i class="<?php echo e($m->icon); ?>"></i>                                        
                                         
                                    </td>

                                     <td>
                                      <?php echo e($m->title); ?>

                                    </td>
                                   
                                    <td>
                                    <?php echo e($m->description); ?>

                                    </td>
                                    
                                   <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updatemissionvision')); ?>/<?php echo e($m->id); ?>">Update</a></button></td>
                                    
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>
            <?php $__env->stopSection(); ?>
                 
                 
                 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical_app\resources\views/admin/missionvisionview.blade.php ENDPATH**/ ?>