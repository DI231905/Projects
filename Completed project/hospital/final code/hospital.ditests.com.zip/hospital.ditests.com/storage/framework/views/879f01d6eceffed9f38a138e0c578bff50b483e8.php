

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">

                 <div class="mt-5">

                   <div class="list1">   
                  <h4 class="mb-4">ADMIN DETAIL LIST</h4>
                    
                    </div>
                    
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>   
                                    <th>Name</th>
                                    <th>Email</th> 
                                    <th>Mobile NO</th> 
                                    <th>Address</th> 
                                    <th>Facebook URL</th> 
                                    <th>Instagram URL</th>
                                    <th>Twitter URL</th>  
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $admindetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr>
                                    <td>

                                       <img src="/uploads/<?php echo e($a->image); ?>" width="120" height="100"><br>
                                       <?php echo e($a->image); ?>  
                                         
                                    </td>

                                     <td>
                                      <?php echo e($a->name); ?>

                                    </td>

                                     <td>
                                      
                                      <?php $__currentLoopData = $email; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($a->id == $e->admin_id): ?>
                                        <li><?php echo e($e->email); ?></li>
                                        <?php endif; ?>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>

                                     <td>

                                      <?php $__currentLoopData = $mobile_number; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($a->id == $m->admin_id): ?>
                                        <li><?php echo e($m->mobileno); ?></li>
                                        <?php endif; ?>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>

                                     <td>
                                      <?php echo e($a->address); ?>

                                    </td>
                                     <td>
                                      <?php echo e($a->fb_link); ?>

                                    </td>
                                     <td>
                                      <?php echo e($a->insta_link); ?>

                                    </td>
                                     <td>
                                      <?php echo e($a->twitter_link); ?>

                                    </td>
                                    
                           <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateadmindetail')); ?>/<?php echo e($a->id); ?>">Update</a></button></td>

                                                
                            
                            
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>  
           </div>

           <?php $__env->stopSection(); ?>
                 
                  
                 
             
                 


               
                
                
                
                

              
               
        
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/hospital.ditests.com/resources/views/admin/admindetailview.blade.php ENDPATH**/ ?>