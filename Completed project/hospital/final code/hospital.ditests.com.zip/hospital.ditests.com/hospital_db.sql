-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 26, 2022 at 06:03 AM
-- Server version: 5.7.36-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_description`
--

CREATE TABLE `about_description` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `main_title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `about_description`
--

INSERT INTO `about_description` (`id`, `title`, `main_title`, `description`) VALUES
(1, 'About Us', 'Welcome to the Mangala Diagnostic Centre', '<p class=\"style1\" style=\"font-family: Georgia, \" times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 13px;\"=\"\">MANGALA DIAGNOSTIC CENTRE is an ISO 9001:2008 CERTIFIED diagnostic center with the latest and most modern equipment available today. We are dedicated to comprehensive, high-quality, rapid-response laboratory testing at affordable prices.</p><p class=\"style1\" style=\"font-family: Georgia, \" times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 13px;\"=\"\">Mangala Diagnostic Centre is fully owned and managed by Dr. Rajanish Mishra MBBS MD Path, who specializes in Laboratory medicines and Occupational Health. He has vast experience of more than 15 years of working in various reputed hospitals in Mumbai and has credentials few other doctors can match.</p><p class=\"style1\" style=\"font-family: Georgia, \" times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 13px;\"=\"\">Mangala diagnostic centre situated in the heart of Andheri( E )a busy business suburb of Mumbai is a fully-fledged medical diagnostic centre set up with a view to addressing the corporate health care requirements of the shipping industry and its personnel. We are approved by the Director-General shipping of India and a host of other regulatory medical and municipal bodies.</p><p class=\"style1\" style=\"font-family: Georgia, \" times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 13px;\"=\"\">The belief that quality healthcare services have no boundaries in a global world drives MDC to deliver the best healthcare products in its markets. A \'People-First Policy\' ensures that MDC meets and surpasses the evolving expectations of its customers, at all times.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `about_images`
--

CREATE TABLE `about_images` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `about_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `about_images`
--

INSERT INTO `about_images` (`id`, `image`, `about_id`) VALUES
(8, '1638517199_image-1.png', 1),
(9, '1638517199_image-2.png', 1),
(11, '1638517326_image-3.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `about_work`
--

CREATE TABLE `about_work` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `main_title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `about_work`
--

INSERT INTO `about_work` (`id`, `title`, `main_title`) VALUES
(1, 'What We Do', 'True Healthcare For Your Family');

-- --------------------------------------------------------

--
-- Table structure for table `about_workimage`
--

CREATE TABLE `about_workimage` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `work_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `about_workimage`
--

INSERT INTO `about_workimage` (`id`, `image`, `work_id`) VALUES
(4, '1638528697_image-4.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `achivement`
--

CREATE TABLE `achivement` (
  `id` int(11) NOT NULL,
  `file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `achivement`
--

INSERT INTO `achivement` (`id`, `file`) VALUES
(6, '1638621880_img_1.jpg'),
(7, '1638621880_img_2.jpg'),
(8, '1638621880_img_3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admindetail`
--

CREATE TABLE `admindetail` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `address` text,
  `fb_link` varchar(255) DEFAULT NULL,
  `insta_link` varchar(255) DEFAULT NULL,
  `twitter_link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admindetail`
--

INSERT INTO `admindetail` (`id`, `name`, `image`, `address`, `fb_link`, `insta_link`, `twitter_link`) VALUES
(1, 'apptest', '1638710710_doctor7.jpg', 'Symphony Apartments, Azad Road Near to BMC K-East Ward Office, Gundavalli Andheri (East), Mumbai - 400059', 'www.facebook.com', 'www.instagram.com', 'www.twitter.com');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `token`, `created_at`, `updated_at`) VALUES
(1, 'apptest', 'rajanishmishra2007@gmail.com', '$2y$10$ESIDNbwLoKGIdhoAq1kmbezoNsbBM37UM0MMt5DqDAQW9BJgF911S', '8784', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `main_heading` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `image`, `title`, `main_heading`) VALUES
(9, '1640881425_Waiting Room _new.jpg', 'Mangala Diagnostic Centre', NULL),
(10, '1638256670_banner-2.jpg', 'Mangala Hospital', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `banner_image`
--

CREATE TABLE `banner_image` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `page_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner_image`
--

INSERT INTO `banner_image` (`id`, `name`, `image`, `page_name`) VALUES
(2, 'Hospital Service', '1638691243_banner-2.jpg', 'HOSPITAL SERVICE'),
(3, 'Doctors', '1638689591_service-bg1.jpg', 'DOCTORS'),
(4, 'About Us', '1638510288_banner_1.jpg', 'About Us'),
(5, 'Contact Us', '1638790163_banner_1.jpg', 'CONTACT US'),
(6, 'Gallery', '1638689940_service-bg1.jpg', 'GALLERY'),
(7, 'Diagnostic Services', '1638699217_banner-1.jpg', 'DIAGNOSTIC SERVICES');

-- --------------------------------------------------------

--
-- Table structure for table `benifits`
--

CREATE TABLE `benifits` (
  `id` int(11) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `benifits`
--

INSERT INTO `benifits` (`id`, `icon`, `name`, `description`) VALUES
(2, 'fas fa-phone-volume', 'Health Information', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at est id leo'),
(3, 'fas fa-microscope', 'Medical Education', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at est id leo'),
(4, 'fas fa-briefcase-medical', 'Symptom Check', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at est id leo'),
(5, 'fas fa-user-md', 'Qualified Doctors', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at est id leo');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `mobileno`, `subject`, `description`, `created_at`, `updated_at`) VALUES
(11, 'jinal', 'jinalpatel23697@gmail.com', '123456789', 'test', 'test', NULL, NULL),
(12, 'jinal', 'jinalpatel23697@gmail.com', '123456789', 'test', 'test', NULL, NULL),
(13, 'test', 'jinalpatel23697@gmail.com', '123456789', 'test', 'test', NULL, NULL),
(14, 'jinal', 'jinalpatel23697@gmail.com', '123456789', 'test', 'test', NULL, NULL),
(15, 'jinal', 'jinalpatel23697@gmail.com', '123456789', 'test', 'test', NULL, NULL),
(16, 'test', 'jinalpatel23697@gmail.com', '123456789', 'test', 'tetdtwfdsytfds', NULL, NULL),
(17, 'test', 'jinalpatel23697@gmail.com', '123456789', 'test', 'tedfsfdsfcsd', NULL, NULL),
(18, 'test', 'jinalpatel23697@gmail.com', '123456789', 'test', 'test', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE `email` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`id`, `email`, `admin_id`) VALUES
(9, 'rajanishmishra2007@gmail.com', 1),
(10, 'drmishra@mangaladc.com', 1),
(11, 'admin@mangaladc.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `id` int(11) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `icon1` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`id`, `icon`, `icon1`, `name`, `description`) VALUES
(8, '1638770195_volunteer.png', '1638770203_volunteer_1.png', 'Quality & Safety', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type'),
(9, '1638425159_lifeline.png', '1638770242_lifeline_1.png', 'Leading Technology', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type'),
(10, '1638425201_doctor.png', '1638770257_doctor_1.png', 'Experts by Experience', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type');

-- --------------------------------------------------------

--
-- Table structure for table `footer_about`
--

CREATE TABLE `footer_about` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `footer_about`
--

INSERT INTO `footer_about` (`id`, `description`) VALUES
(1, '<p style=\"\" times=\"\" new=\"\" roman\",=\"\" times,=\"\" serif;=\"\" font-size:=\"\" 12px;=\"\" background-color:=\"\" rgb(51,=\"\" 51,=\"\" 51);\"=\"\"><span style=\"color: rgb(143, 141, 160);\">MANGALA DIAGNOSTIC CENTRE is a fully digital imaging center and automated and computerized pathology laboratory with the latest and most modern equipment available today. We are dedicated to comprehensive, high-quality, rapid-response laboratory testing at affordable prices.</span></p><div><br></div>');

-- --------------------------------------------------------

--
-- Table structure for table `gallary`
--

CREATE TABLE `gallary` (
  `id` int(11) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `extension` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gallary`
--

INSERT INTO `gallary` (`id`, `file`, `extension`) VALUES
(7, '1638640252_gallery-1.jpg', '.jpg'),
(8, '1638640252_gallery-2.jpg', '.jpg'),
(9, '1638640252_gallery-3.jpg', '.jpg'),
(10, '1638640252_gallery-4.jpg', '.jpg'),
(11, '1638640252_gallery-5.jpg', '.jpg'),
(12, '1638640252_gallery-6.jpg', '.jpg'),
(13, '1638640252_gallery-7.jpg', '.jpg'),
(14, '1638640252_gallery-8.jpg', '.jpg'),
(15, '1638640252_gallery-9.jpg', '.jpg'),
(16, '1638640253_gallery-10.jpg', '.jpg'),
(17, '1638640253_gallery-11.jpg', '.jpg'),
(18, '1638640253_gallery-12.jpg', '.jpg'),
(19, '1638640253_gallery-13.jpg', '.jpg'),
(20, '1638640253_gallery-14.jpg', '.jpg'),
(21, '1638640253_gallery-17.jpg', '.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `homeaboutus`
--

CREATE TABLE `homeaboutus` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `imagetitle` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sign_image` varchar(255) DEFAULT NULL,
  `Designation` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `homeaboutus`
--

INSERT INTO `homeaboutus` (`id`, `image`, `imagetitle`, `title`, `name`, `sign_image`, `Designation`, `description`) VALUES
(1, '1638430449_about-1.jpg', '28 years of</br> working \r\nexperience', 'The Best Medics, Doctors & Physicians', 'Dr. Mike William', '1638430449_signature.png', 'Chairman & Founder Earna', '<span style=\"color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; letter-spacing: 0.5px;\">orem ipsum dolor sit amet, consectetur adipisicing elit. At temporibus perspiciatis deserunt quam tempora molestias et dignissimos sunt animi ut cum, sint quos cumque enim laudantium dolore reiciendis est, obcaecati molestiae fugiat, inventore facere neque quo! Sit molestias ex voluptatem.Lorem ipsum dolor sit amet, consectetur adipisicing elit.At temporibus perspiciatis deserunt quam tempora molestias et dignissimos sunt animi ut cum,</span>');

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE `inquiry` (
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `description` text,
  `id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inquiry`
--

INSERT INTO `inquiry` (`fname`, `lname`, `email`, `mobileno`, `description`, `id`, `created_at`, `updated_at`) VALUES
('jinal', 'patel', 'apptest2303@gmail.com', '112323', 'test', 1, '2021-12-07 01:56:04', '2021-12-07 01:56:04'),
('jinal', 'patel', 'jinal@gail.com', '123456', 'test', 19, '2022-01-27 15:43:44', '2022-01-27 15:43:44'),
('vcbv', 'dv', 'sdfgv', '435345', 'vcv', 20, '2022-01-27 18:03:12', '2022-01-27 18:03:12'),
('ADXSAFCDS', 'SDFDSF', 'SFSDFD', '312324353', 'DFDGFD', 21, '2022-01-27 18:15:00', '2022-01-27 18:15:00'),
('SDFDG', 'EGDFGB', 'VDGRDFV', '2354354', 'FFBGFBGF', 22, '2022-01-27 18:19:49', '2022-01-27 18:19:49');

-- --------------------------------------------------------

--
-- Table structure for table `mission-vision`
--

CREATE TABLE `mission-vision` (
  `id` int(11) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mission-vision`
--

INSERT INTO `mission-vision` (`id`, `icon`, `title`, `description`) VALUES
(1, 'fas fa-users', 'Our Mission', '\"All under one roof\" Diagnostic centre which focuses high quality and excellent client service to reduce patient-cure time by providing  holistic, high quality, high standard diagnosis by using the most modern technology.'),
(2, 'fas fa-building', 'Our Vision', 'To provide the highest quality laboratory testing and expert pathology diagnosis to our patients by introducing state-of-art technology and best practices.');

-- --------------------------------------------------------

--
-- Table structure for table `mobile_number`
--

CREATE TABLE `mobile_number` (
  `id` int(11) NOT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mobile_number`
--

INSERT INTO `mobile_number` (`id`, `mobileno`, `admin_id`) VALUES
(9, '+91-9820064153', 1),
(10, '022-26827197', 1),
(11, '022-26845076', 1);

-- --------------------------------------------------------

--
-- Table structure for table `more_maintitle`
--

CREATE TABLE `more_maintitle` (
  `id` int(11) NOT NULL,
  `more_maintitle` text,
  `banner_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `more_maintitle`
--

INSERT INTO `more_maintitle` (`id`, `more_maintitle`, `banner_id`) VALUES
(52, 'Mangala Diagnostic Centre is an ISO 9001:2008 certified diagnostic center. With all the facilities under one roof, we are dedicated to comprehensive, high-quality, rapid-response laboratory testing at affordable prices.', 9),
(53, 'Mangala Hospital is a multi-specialty hospital managed by Dr. Rajanish Mishra MBBS, MD; where patients are given utmost care round the clock in a peaceful environment through trained nurses and a panel of eminent doctors and surgeons.', 10);

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `title_record` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `record`
--

INSERT INTO `record` (`id`, `title`, `title_record`) VALUES
(2, 'HAPPY PATIENTS', '5000'),
(3, 'SERVICE DONE', '1150'),
(4, 'DOCTORS', '15'),
(5, 'DEPARTMENTS', '10');

-- --------------------------------------------------------

--
-- Table structure for table `service1`
--

CREATE TABLE `service1` (
  `id` int(11) NOT NULL,
  `image1` varchar(255) DEFAULT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service1`
--

INSERT INTO `service1` (`id`, `image1`, `image2`, `title`, `description`) VALUES
(2, '1638774693_service-1.png', '1638774693_service-11.png', 'Cardiology', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
(3, '1638774763_service-2.png', '1638774763_service-22.png', 'Urology', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
(4, '1638774808_service-3.png', '1638774808_service-33.png', 'Neurology', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
(5, '1638774847_service-4.png', '1638774847_service-44.png', 'Orthopedic', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
(6, '1638774889_service-5.png', '1638774889_service-55.png', 'Dentist', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
(7, '1638774932_service-6.png', '1638774932_service-66.png', 'Gastrology', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `image`, `title`, `description`) VALUES
(3, '1638698141_hs-1.png', 'Health Check', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type'),
(4, '1638698183_hs-2.png', 'Operation Theater', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type'),
(5, '1638698215_hs-3.png', 'Pharmacy Support', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type'),
(6, '1638698256_hs-4.png', 'Ambulance Car', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type'),
(7, '1638698305_hs-5.png', 'Lab Tests', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type'),
(8, '1638698348_hs-6.png', 'Intensive Care', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type');

-- --------------------------------------------------------

--
-- Table structure for table `service_type`
--

CREATE TABLE `service_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_type`
--

INSERT INTO `service_type` (`id`, `name`) VALUES
(1, 'Hospital'),
(2, 'Diagnostic');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `qualification` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `image`, `name`, `qualification`, `title`, `description`) VALUES
(2, '1638636735_doctor1.jpg', 'Dr. Rajanish Mishra', '(M.D. Bom)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(3, '1638636784_doctor2.jpg', 'Dr. Rupali Dharwadkar', '(M.D. DGO.)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(4, '1638636826_doctor3.jpg', 'Dr Bhardesh Master', '(DNB Radiology)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(5, '1638636869_doctor4.jpg', 'Dr. Vanmala Hasny', '(M.A. Psychology)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(6, '1638636911_doctor5.jpg', 'Dr. Himali Bhogle', '(M.B.B.S. D.G.O)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(7, '1638636962_doctor6.jpg', 'Dr. Atish Laddad', '(M.D. Paediatrics)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(8, '1638637005_doctor7.jpg', 'Dr. Ambarish A. Saraf', '(M.B.B.S. DNB Ortho)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(9, '1638637059_doctor8.jpg', 'Dr. Chandan Pagdhane', '(M.S. Gen. Surg.)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(10, '1638637314_doctor9.jpg', 'Dr. Rahul Patil', '(M.S. (ENT.)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(11, '1638637185_doctor12.jpg', 'Dr. Smriti Choudhary', '(M.B.B.S. DOMS)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(12, '1638637300_doctor15.jpg', 'Dr. Mrs. Yamini Mehta', '(M.B. D. G.O.)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(13, '1638637372_doctor12.jpg', 'Dr. Kavita Rajdev', '( BDS, PGDHHM)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(14, '1638637427_doctor13.jpg', 'Dr. Nikhil B. Bhandari', '(M.B.B.S., DCH)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.'),
(15, '1638637483_doctor14.jpg', 'Dr. Mangesh A. Ghulghule', '(DPM, DNB)', 'About Doctor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.');

-- --------------------------------------------------------

--
-- Table structure for table `teamdescription`
--

CREATE TABLE `teamdescription` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `main_title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teamdescription`
--

INSERT INTO `teamdescription` (`id`, `title`, `main_title`, `description`) VALUES
(1, 'Helpful Doctors', 'Helpful Doctors Advanced Carefully Doctors', '<span style=\"color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 15px; letter-spacing: 0.5px; text-align: center;\">Why our services are best all-time since 1990. desires to obtain of itself, because it is pain, but because occasionally circles tanceprocure him some great deals.</span><br>');

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`id`, `name`, `image`, `occupation`, `description`, `created_at`, `updated_at`) VALUES
(12, 'Felicity Rains', '1638508127_client-1.jpg', 'Life coach', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', NULL, NULL),
(13, 'Sana Khan', '1638508174_client-1.jpg', 'student', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', NULL, NULL),
(14, 'Sana Khan', '1638508213_client-2.jpg', 'student', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `whychooseus`
--

CREATE TABLE `whychooseus` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `main_title` varchar(255) DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `whychooseus`
--

INSERT INTO `whychooseus` (`id`, `image`, `title`, `main_title`, `description`) VALUES
(1, '1638537956_image-5.webp', 'Why Choose Us', 'What You Can Do with Mangala Diagnostic Centre', 'The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps');

-- --------------------------------------------------------

--
-- Table structure for table `workstep`
--

CREATE TABLE `workstep` (
  `id` int(11) NOT NULL,
  `step_no` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `workstep`
--

INSERT INTO `workstep` (`id`, `step_no`, `image`, `title`, `description`) VALUES
(4, 1, '1638443440_work-1.jpg', 'Application', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit,'),
(5, 2, '1638443459_work-2.jpg', 'Check-ups', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit,'),
(6, 3, '1638443484_work-3.jpg', 'Consultation', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit,'),
(7, 4, '1638443503_work-4.jpg', 'Prescribe & Payment', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit,');

-- --------------------------------------------------------

--
-- Table structure for table `work_benifits`
--

CREATE TABLE `work_benifits` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `work_benifits`
--

INSERT INTO `work_benifits` (`id`, `title`, `icon`, `description`) VALUES
(1, 'Quality Control System', 'fas fa-file-medical', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy'),
(2, 'Highly Professional Staff', 'fas fa-hand-holding-heart', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_description`
--
ALTER TABLE `about_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `about_images`
--
ALTER TABLE `about_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `about_work`
--
ALTER TABLE `about_work`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `about_workimage`
--
ALTER TABLE `about_workimage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `achivement`
--
ALTER TABLE `achivement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admindetail`
--
ALTER TABLE `admindetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner_image`
--
ALTER TABLE `banner_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `benifits`
--
ALTER TABLE `benifits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email`
--
ALTER TABLE `email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer_about`
--
ALTER TABLE `footer_about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallary`
--
ALTER TABLE `gallary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `homeaboutus`
--
ALTER TABLE `homeaboutus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquiry`
--
ALTER TABLE `inquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mission-vision`
--
ALTER TABLE `mission-vision`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobile_number`
--
ALTER TABLE `mobile_number`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `more_maintitle`
--
ALTER TABLE `more_maintitle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `record`
--
ALTER TABLE `record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service1`
--
ALTER TABLE `service1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_type`
--
ALTER TABLE `service_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teamdescription`
--
ALTER TABLE `teamdescription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `whychooseus`
--
ALTER TABLE `whychooseus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workstep`
--
ALTER TABLE `workstep`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `work_benifits`
--
ALTER TABLE `work_benifits`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_description`
--
ALTER TABLE `about_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `about_images`
--
ALTER TABLE `about_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `about_work`
--
ALTER TABLE `about_work`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `about_workimage`
--
ALTER TABLE `about_workimage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `achivement`
--
ALTER TABLE `achivement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `admindetail`
--
ALTER TABLE `admindetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `banner_image`
--
ALTER TABLE `banner_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `benifits`
--
ALTER TABLE `benifits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `email`
--
ALTER TABLE `email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `footer_about`
--
ALTER TABLE `footer_about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gallary`
--
ALTER TABLE `gallary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `homeaboutus`
--
ALTER TABLE `homeaboutus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `inquiry`
--
ALTER TABLE `inquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `mission-vision`
--
ALTER TABLE `mission-vision`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mobile_number`
--
ALTER TABLE `mobile_number`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `more_maintitle`
--
ALTER TABLE `more_maintitle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `record`
--
ALTER TABLE `record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `service1`
--
ALTER TABLE `service1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `service_type`
--
ALTER TABLE `service_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `teamdescription`
--
ALTER TABLE `teamdescription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `whychooseus`
--
ALTER TABLE `whychooseus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `workstep`
--
ALTER TABLE `workstep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `work_benifits`
--
ALTER TABLE `work_benifits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
