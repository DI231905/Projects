  


<?php $__env->startSection('content'); ?>

    <div class="page mt-4 hosting-page title1" style="display: block;">

   <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4"> Doctors Team </h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addteam')); ?>"style="color:black">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Qualification</th>
                                    <th>Title</th>
                                    <th>description</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           
                             <tbody>
                              <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="team_<?php echo e($t->id); ?>">
                                    <td>
                                        <?php if($t->image !=" "): ?>
                                        <img src="/uploads/<?php echo e($t->image); ?>" width="60" height="60"><br>
                                         <?php echo e($t->image); ?> 
                                         <?php else: ?>
                                         <img src="/image/team.png" width="60" height="60">
                                         <?php endif; ?>
                                    </td>

                                    <td>
                                         <?php echo e($t->name); ?>

                                    </td>
                                    <td>
                                         <?php echo e($t->qualification); ?>

                                    </td>
                                    <td>
                                        <?php echo e($t->title); ?>

                                    </td>
                                   
                                     <td>
                                        <?php echo e($t->description); ?>

                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateteam')); ?>/<?php echo e($t->id); ?>">Update</a></button></td>
                          <td><button class="btn3 btn0" onclick="deleteteam(<?php echo e($t->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></button></td>
                                </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                            
                           
                        </table>
                    </div>
                 </div>
            </div>
        </div>
  <script type="text/javascript">
      
       function deleteteam($id){

     if(confirm("do you want delete this Team member ?")){
             $.ajax({

                url:'deleteteam/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.team_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
    
                  },        
          
                });

          }
      }

  </script>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/hospital.ditests.com/resources/views/admin/teamview.blade.php ENDPATH**/ ?>