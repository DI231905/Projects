

<?php $__env->startSection('content'); ?>

 <div class="page mt-4 hosting-page title1" style="display: block;">
                <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Testimonial </h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addtestimonial')); ?>">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Occupation</th>
                                    <th>Description</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                              <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="testimonial_<?php echo e($t->id); ?>">
                                    <td>
                                        <?php if($t->image !=""): ?>
                                        <img src="/uploads/<?php echo e($t->image); ?>" width="60" height="60"><br>
                                         <?php echo e($t->image); ?> 
                                         <?php else: ?>
                                         <img src="/image/team.png" width="60" height="60">
                                         <?php endif; ?>
                                    </td>

                                    <td>
                                       <?php echo e($t->name); ?> 
                                    </td>
                                    <td>
                                       <?php echo e($t->occupation); ?> 
                                    </td>
                                     <td>
                                      <?php echo e($t->description); ?> 

                                    </td>

                                  <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updatetestimonial')); ?>/<?php echo e($t->id); ?>">Update</a></button></td>

                                  <td><button class="btn3 btn0" onclick="deletetestimonial(<?php echo e($t->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></i></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </table>
                       </div>  
                     </div> 
                 </div>
                 <script type="text/javascript">
                 	

                 	  function deletetestimonial($id){

     if(confirm("do you want delete this testimonial ?")){
             $.ajax({

                url:'deletetestimonial/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.testimonial_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
 

                 
                  },        
          
                });

          }
      }

                 </script>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical_app\resources\views/admin/testimoniallist.blade.php ENDPATH**/ ?>