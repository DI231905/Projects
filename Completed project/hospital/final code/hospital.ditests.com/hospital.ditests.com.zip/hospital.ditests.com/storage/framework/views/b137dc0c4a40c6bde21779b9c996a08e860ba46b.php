

<?php $__env->startSection('content'); ?> 

  <div class="co-banner1">
          <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'Doctors'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"><i class="far fa-home"></i> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
          <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="doctor">
    	<div class="title2 mb-60 text-center">
            <h4><?php echo e($title); ?></h4>
            <h2><?php echo e($main_title); ?></h2>
            <p><?php echo $description; ?></p>
        </div>
        <div class="container">
			<div class="row">
				<?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-3 col-md-6 col-sm-12 col-12 mb-4">
					<div class="single-doctor">
						<img class="img-fluid" src="uploads/<?php echo e($t->image); ?>" alt="">
						<div class="single-doctor-info">
							<h4><?php echo e($t->name); ?></h4>
							<span><?php echo e($t->qualification); ?></span> 
						</div>
						<div class="single-doctor-mask">
							<div class="single-doctor-inner">
								<h5><?php echo e($t->title); ?></h5>
								<p><?php echo e($t->description); ?></p>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical_app\resources\views/doctors.blade.php ENDPATH**/ ?>