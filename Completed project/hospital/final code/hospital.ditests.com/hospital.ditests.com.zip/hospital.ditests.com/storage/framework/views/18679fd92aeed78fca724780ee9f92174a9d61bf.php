

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
             
                <div class="mt-5">
                    <h4 class="mb-4">GET IN TOUCH </h4>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                     <th>Mobile NO</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                              <?php $__currentLoopData = $contact_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                             
                                <tr class="contact_<?php echo e($cu->id); ?>">
                                    <td>
                                      <?php echo e($cu->name); ?>

                                    </td>
                                

                                    <td>
                                        <?php echo e($cu->email); ?>

                                    </td>
                                     <td>
                                        <?php echo e($cu->mobileno); ?>

                                    </td>
                                    <td>
                                       <?php echo e($cu->subject); ?>

                                    </td>
                                    <td>
                                       <?php echo e($cu->description); ?>

                                   </td>
                        
                                    <td><button class="btn3 btn0" onclick="deletecontact(<?php echo e($cu->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </table>
                    </div>
                </div> 
         
           </div>

           <script type="text/javascript">

function deletecontact($id){

     if(confirm("do you want delete this message ?")){
             $.ajax({

                url:'deletecontact/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.contact_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
    
                  },        
          
                });

          }
      }


          

      
           </script>

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical_app\resources\views/admin/contactlist.blade.php ENDPATH**/ ?>