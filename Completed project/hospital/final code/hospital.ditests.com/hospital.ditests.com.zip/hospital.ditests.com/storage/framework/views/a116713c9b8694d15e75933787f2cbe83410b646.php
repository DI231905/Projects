            


<?php $__env->startSection('content'); ?>

    <div class="page mt-4 hosting-page title1" style="display: block;">

            <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4"> ACHIVEMENT IMAGE  </h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addachivement')); ?>" style="color:black">ADD</a></button>
                     </div>
                    
                    <div class="detail" style="display:flex; flex-wrap:wrap ;" > 
                        <?php $__currentLoopData = $achivement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                         <div class="image_<?php echo e($a->id); ?>">
 
                         <div class="gallery">
                          <a target="_blank" href="/uploads/<?php echo e($a->file); ?>">
                          <img src="/uploads/<?php echo e($a->file); ?>" alt="Cinque Terre" width="250" height="200">
                           </a>
                          <div class="desc"><button  class="btnsubmit" onclick="deleteimage(<?php echo e($a->id); ?>)">Delete Image</button>
                               </div>
                             </div>  
                           
                           
                      </div>  
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    </div>
                   

                </div>
           </div>

           <script type="text/javascript">
             
              function deleteimage($id){

     if(confirm("do you want delete this Inquiry ?")){
             $.ajax({

                url:'deleteachivments/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.image_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  

   </script>
   <style type="text/css">
     .gallery{

          margin-top: 15px;
          margin-right: 15px;
     }

   </style>

           <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/hospital.ditests.com/resources/views/admin/achivementlist.blade.php ENDPATH**/ ?>