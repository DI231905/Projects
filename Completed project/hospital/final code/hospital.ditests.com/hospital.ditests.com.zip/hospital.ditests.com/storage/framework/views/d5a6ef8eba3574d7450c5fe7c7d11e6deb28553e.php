

<?php $__env->startSection('content'); ?>

<div class="co-banner1">
          <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'Gallery'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"><i class="far fa-home"></i> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
          <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="co_gallery">
        <div class="container">
            <div class="gallery">

               <?php $__currentLoopData = $gallary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <?php if('.mp4'===$g->extension): ?>

              <a href="uploads/<?php echo e($g->file); ?>" data-lightbox="homePortfolio">
                <iframe width="560" height="315" src="uploads/<?php echo e($g->file); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen autoplay="false"></iframe>
            </a>


               <?php else: ?>
                   <?php if($g->id % 2!=0 ): ?>
                   <a href="uploads/<?php echo e($g->file); ?>" data-lightbox="homePortfolio">
                   <img src="uploads/<?php echo e($g->file); ?>"/></a>
                   <?php else: ?>
                    <a href="uploads/<?php echo e($g->file); ?>" data-lightbox="homePortfolio" class="big">
                   <img src="uploads/<?php echo e($g->file); ?>"/></a>
                    <?php endif; ?> 

             <?php endif; ?>  

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                         

         
           </div>
        </div>
    </div>
<style>
    
    .lightbox, .lightboxOverlay {
    z-index: 9999999 !important;
}
</style>
    
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox-plus-jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

    	$(window).scroll(function(){
            if ($(this).scrollTop() > 150) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show-Z');  
            }
            else {
                btn.removeClass('show-Z');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });
        
    </script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical_app\resources\views/gallary.blade.php ENDPATH**/ ?>