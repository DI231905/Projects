

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
             <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4">Inquiry </h4>
                        
                    </div>
                       <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                        
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Mobile no</th>      
                                    <th>Description</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <?php $__currentLoopData = $enquires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>

                                <tr class="enquires_<?php echo e($e->id); ?>">
                                    <td>
                                        
                                      <?php echo e($e->fname); ?>  
                                         
                                    </td>
                                     <td>
                                        
                                      <?php echo e($e->lname); ?>  
                                         
                                    </td>
                                    <td>
                                        <?php echo e($e->email); ?>

                                    </td>
                                   
                                    <td>
                                        <?php echo e($e->mobileno); ?>

                                   </td>
                                  
                                  <td><?php echo e($e->description); ?></td>


                         
                                    <td><button class="btn3 btn0" onclick="deleteinquiry(<?php echo e($e->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></a></button></td>
                                </tr>
                          
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                        </table>
                    </div>
                </div>
           </div>

           <script type="text/javascript">


            function deleteinquiry($id){

     if(confirm("do you want delete this record ?")){
             $.ajax({

                url:'deleteenquiry/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.enquires_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }

      
           </script>

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical_app\resources\views/admin/home.blade.php ENDPATH**/ ?>