

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
             <div class="mt-5">
                    <h4 class="mb-4"> Footer About Us  </h4>
                     <div class="detail">
                       <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                   
                                </tr>
                            </thead>
                               <?php $__currentLoopData = $footer_about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                                
                                <tr>
                                    <td>
                                        <?php echo $fa->description; ?>

                                    </td>
                                
                    
                                  
                               <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/footer_about')); ?>/<?php echo e($fa->id); ?>" >Update</a></button></td>
                                   
                               
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                 </div>
           
              </div> 
           </div>
           <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical_app\resources\views/admin/footeraboutlist.blade.php ENDPATH**/ ?>