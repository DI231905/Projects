

<?php $__env->startSection('content'); ?> 

  <div class="co-banner1">
         <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'Diagnostic Services'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"><i class="far fa-home"></i> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
          <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="co_service service_1">
        <div class="container">
            <div class="row">
            	
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 d-flex">
                    <div class="Service-details">
                        <div class="inner-service">
                            <div class="service-img">
                                <img class="s_1" src="uploads/<?php echo e($s->image2); ?>">
                                <img class="s_2" src="uploads/<?php echo e($s->image1); ?>">
                            </div>
                            <h4><?php echo e($s->title); ?></h4>
                            <p><?php echo e($s->description); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/hospital.ditests.com/resources/views/diagnosticservices.blade.php ENDPATH**/ ?>