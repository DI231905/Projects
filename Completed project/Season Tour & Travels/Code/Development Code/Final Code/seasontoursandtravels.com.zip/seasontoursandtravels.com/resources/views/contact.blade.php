<!DOCTYPE html>
<html>
<head>
    <title>SEASON TRAVEL AGENCY</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <meta name="csrf-token" content="{{ csrf_token() }}" />
   <link rel="icon" href="image/logo.png">
 
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">

</style>
</head>
<body class="body">
    <div class="co_header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-9 col-md-9 col-5">
                    <ul class="map">
                        <li>
                            <a href="mailto:{{$email}}"><i class="fas fa-envelope"></i>
                            <span>{{$email}}</span></a>
                        </li>
                        <li>
                            <a href="tel:{{$mobileno}}"><i class="fab fa-whatsapp"></i>
                            <span>{{$mobileno}}</span></a>
                        </li>
                    </ul>                   
                </div>
                <div class="col-lg-3 col-md-3 col-7">
                    <ul class="social-link"> 
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_menu1" id="dynamic">
        <div class="co_menu">
            <div class="container">
                <div class="row row1">
                    <div class="col-lg-4 col-md-4 col-6">
                        <div class="logo">
                            <a href="{{url('/')}}"><img src="image/logo.png"></a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-6">
                        <nav id="mainnav" class="mainnav mainnav1">
                            <ul class="menu"> 
                                <li><a href="{{url('/')}}">Home</a></li>
                                 <li><a href="{{url('/about')}}">About us</a></li>
                                <li><a href="{{url('/services')}}">Services</a>
                                <li><a href="#">Packages</a>
                                    <ul class="submenu">
                                        <li><a href="{{url('/domesticpackage')}}">Domestic</a></li>
                                        <li><a href="{{url('/internationalpackage')}}">International</a></li>
                                    </ul>
                                </li>
                                 <li><a href="{{url('/gallary')}}">Gallery</a></li>
                                <li><a href="{{url('/contact')}}">Contact Us</a></li>
                            </ul>
                        </nav>
                        <div class="mobile-menu">
                            <div id="mySidepanel" class="sidepanel">
                                <div class="m_menu">
                                    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a> 
                                    <nav id="mainnav" class="mainnav">
                                        <ul class="menu"> 
                                            <li><a class="link" href="{{url('/')}}">Home</a></li>
                                             <li><a class="link" href="{{url('/about')}}">About us</a></li>
                                            <li><a class="link" href="{{url('/services')}}">Services</a>
                                            <li><a class="link" href="#">Packages</a>
                                                <ul class="submenu">
                                                    <li><a href="{{url('/domesticpackage')}}">Domestic</a></li>
                                                    <li><a href="{{url('/internationalpackage')}}">International</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="{{url('/gallary')}}">Gallery</a></li>
                                           <li><a href="{{url('/contact')}}">Contact Us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <div class="co_part-2">
        <div class="fix-part-2">
            <div class="img1">
                <img src="image/contact-bg.jpg">
            </div>
            <div class="about1">
                <div class="container">
                    <h2>Contact</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Contact Us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_contact">
        <div class="container">
            <div class="row fix-contact">
                <div class="col-lg-6 col-md-6 col-12 set-contact">
                       <p id="message"></p>
                        <div class="">
                        @if ($errors->any())
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li  style="color:red;">{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif 
                    <h2>Get in touch</h2>
                    <form  method="post" action="" class="form1 row"  >
                         @csrf
                        <div class="col-lg-6">
                            <div class="part-1">
                                <input type="text" placeholder="Name" name="name" id="name" value="" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="part-1">
                                <input type="email" placeholder="Email" name="email" id="email" value=""required>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="part-1">
                                <input type="text" placeholder="Subject" name="subject" id="subject" value=""required="email">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="part-1">
                                <textarea placeholder="Your Message" name="description" id="description" rows="7" 
                                cols="30" value="" required></textarea>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="sub1">
                                <input type="submit" id="submit" value="Send Message">
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
                <div class="col-lg-6 col-md-6 col-12 set-contact1">
                    <h2>Contact us</h2>
                    <div class="co_info row">
                        <div class="info-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="info-text">
                            <p><strong>Address:</strong>{{$address}}</p>
                        </div>
                    </div>
                    <div class="co_info row row1">
                        <div class="info-icon">
                           <i class="fas fa-phone-alt"></i>
                        </div>
                        <div class="info-text">
                            <p class="c_email"><strong>Contact Number:</strong> <span>{{$mobileno}}<br>(02634) 270797</span></p>
                            
                            <p>
                                <a href="tel:02634270797"></a>
                                </p>
                        </div>
                    </div>
                    <div class="co_info row row1">
                        <div class="info-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="info-text info-text1">
                            <p class="c_email"><strong>Email Us:</strong> <span>Holidays@seasontoursandtravels.com<br>
                              Contact@seasontoursandtravels.com</p>  </span>
                        </div>
                    </div>
                </div>
            </div>
       

            <div class="map1">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d119343.71146913151!2d72.88193415820314!3d20.81187100000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be0f1ce81fe5c33%3A0x52208769fd0cb33c!2sSeason%20Travel%20and%20Investment!5e0!3m2!1sen!2sin!4v1628065241542!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>

          </div>
        </div>
   

     <div class="co_footer">
        <div class="container">
            <div class="footer-loop">
                <div class="row">
                    <div class="col-lg-3 col-md-12 col-12 footer-logo fm-1">
                        <div class="main-footer">
                            <h2 class="title1"><a href="{{url('/')}}"><img src="image/logo.png"></a></h2>
                            <p>Book with confidence. We offer a unique travelling experience you can’t miss.</p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 col-12 fm-1">
                        <h2 class="title1">Company</h2>
                        <div class="footer-widget">
                            <ul>
                                <li><i class="far fa-angle-left"></i><a href="{{url('/services')}}">Services</a></li>
                                <li><i class="far fa-angle-left"></i><a href="{{url('/domesticpackage')}}">packages</a></li>
                                <li><i class="far fa-angle-left"></i><a href="{{url('/gallary')}}">Gallery</a></li>
                                <li><i class="far fa-angle-left"></i><a href="{{url('/contact')}}">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12 fm-1">
                        <h2 class="title1">Contact Us</h2>
                        <ul class="con-home">
                            <li><i class="fa fa-home" aria-hidden="true"></i>
                                <p>{{$address}}</p>
                            </li>
                            <li><i class="fa fa-envelope" aria-hidden="true"></i>
                               <p><a href="mailto:Holidays@seasontoursandtravels.com">Holidays@seasontoursandtravels.com</a>
                               <a href="mailto:Contact@seasontoursandtravels.com">Contact@seasontoursandtravels.com</a></p>      
                            </li>
                            <li><i class="fa fa-phone" aria-hidden="true"></i>
                                <p><a href="tel:{{$mobileno}}">{{$mobileno}}</a><br>
                                <a href="tel:02634270797">(02634) 270797</a>
                                </p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-3 col-12 fm-1">
                        <h2 class="title1">Newsletter</h2>
                        <p>Get latest updates and offers.</p>
                        <form class="form">
                            <input type="text" placeholder="Enter your email here" name="email" value="">
                            <!-- <div class="button sub">submit</div> -->
                            <div class="button sub">
                                <input type="Submit" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Season Tour and Investment © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </div>
    
 <a class="up-btn show1" href="#"></a>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  
 <script type="text/javascript">
     
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $("#submit").click(function(e){

      var name = $('#name').val();
      var email = $('#email').val();

      var subject = $('#subject').val();
      var description = $('#description').val();
  if(name!="" && email!="" && subject!="" && description!=""){

    var pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i

    if(!pattern.test(email))
   {
 
    }else{


      e.preventDefault();

        $.ajax({
           url:'/contactusfrom',
           method:'POST',
           data:{
                 name,
                 email,
                 subject,
                 description
                },


   success: function(dataResult){
                  console.log(dataResult);
                  var dataResult = JSON.parse(dataResult);
                  if(dataResult.statusCode==200){
                  $("#message").append("<b>your message submit sucessfully!!!</b>");
                   $('#message').delay(3000).fadeOut(3000);            
                  }
                  else {
                     alert("Error occured !");
                  }


                    $( '.form1' ).each(function(){
                          this.reset();
                        });    
                  
              }
          



         /*  success:function(response){
              if(response.success){
                  alert(response.message) //Message come from controller
              }else{
                  alert("Error")
              }
           },
           error:function(error){
              console.log(error)
           }*/
        });

    }
      }else{

      

      }
    });
      var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
        $('html, body').animate({scrollTop:0}, '300');
    }); 


function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

        $(window).scroll(function(){
            if ($(this).scrollTop() > 50) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        }); function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

        $(window).scroll(function(){
            if ($(this).scrollTop() > 50) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });



 </script>

</body>
</html>



