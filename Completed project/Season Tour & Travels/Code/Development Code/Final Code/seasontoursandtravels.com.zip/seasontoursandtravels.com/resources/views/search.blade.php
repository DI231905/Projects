@extends('layouts.app')

@section('content') 

 <div class="co_part-2">
        <div class="fix-part-2">
            <div class="img1">
                <img src="image/banner-3.jpg">
            </div>
            <div class="about1">
                <div class="container">
                    <h2>Search Packages</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Search Packages</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_package1">
        <div class="container">
            <div class="row justify-content-center">

          @forelse ($searchpackage as $p)
              <div class="col-lg-6 col-md-6 col-12">
                     <div class="package1">
                        <div class="recom-item-body">
                            <h4>{{$p->tittle}}</h4>
                            <h6>{{$p->tour_type}}</h6>
                            <div class="day">
                                <h5>Duration: <strong> {{$p->days}} DAYS</strong></h5>
                            </div>
                            <p class="block-ellipsis">{{$p->short_desc}}</p>
                            <a href="{{url('/packagedetail')}}/{{$p->id}}" class="cws-button">Read more</a>
                            <div class="price">Rs.{{$p->price}}</div>
                        </div>
                        <div class="recom-media">
                            <a href="{{url('/packagedetail')}}/{{$p->id}}">
                                <div class="package1-img">
                                    <img src="uploads/{{$p->image}}">
                                </div>
                            </a>
                            <div class="location">
                                <i class="far fa-map-marker-alt"></i> {{$p->country}}, {{$p->city}}
                            </div>
                        </div>
                    </div>
                  
                </div>
           @empty
            <div class="co_service">
        <div class="container">
            <div class="inner-head">
                <h1 class="title">NO TOUR AVAILABLE</h1>
                <img src="image/icon_title.png">
                <p class="prg">No tour available on this destination. please check some other...</p>
            </div>
        </div>
    </div>
           @endforelse
                      
             
            </div>
        </div>
    </div> 
   
 @endsection