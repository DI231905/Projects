<!DOCTYPE html>
<html>
<head>
    <title>SEASON TRAVEL AGENCY</title>
    <link rel="stylesheet" type="text/css" href="../css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div class="co_header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-9 col-md-9 col-5">
                    <ul class="map">
                        <li>
                            <a href="mailto:<?php echo e($email); ?>"><i class="fas fa-envelope"></i>
                            <span><?php echo e($email); ?></span></a>
                        </li>
                        <li>
                            <a href="tel:<?php echo e($mobileno); ?>"><i class="far fa-phone-alt"></i>
                            <span><?php echo e($mobileno); ?></span></a>
                        </li>
                    </ul>                   
                </div>
                <div class="col-lg-3 col-md-3 col-7">
                    <ul class="social-link"> 
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_menu1" id="dynamic">
        <div class="co_menu">
            <div class="container">
                <div class="row row1">
                    <div class="col-lg-4 col-md-4 col-6">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>"><img src="/image/logo.png"></a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-6">
                        <nav id="mainnav" class="mainnav mainnav1">
                            <ul class="menu"> 
                                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li><a href="<?php echo e(url('/services')); ?>">Services</a>
                                <li><a href="#">Packages</a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                        <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                    </ul>
                                </li>
                                 <li><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </nav>
                        <div class="mobile-menu">
                            <div id="mySidepanel" class="sidepanel">
                                <div class="m_menu">
                                    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a> 
                                    <nav id="mainnav" class="mainnav">
                                        <ul class="menu"> 
                                            <li><a class="link" href="<?php echo e(url('/')); ?>">Home</a></li>
                                            <li><a class="link" href="<?php echo e(url('/services')); ?>">Services</a>
                                            <li><a class="link" href="#">Packages</a>
                                                <ul class="submenu">
                                                    <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                                    <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                                </ul>
                                            </li>
                                             <li><a class="link" href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                            <li><a class="link" href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_part-2">
        <div class="fix-part-2">
            <div class="img1">
                <img src="/image/details-bg.jpg">
            </div>
            <div class="about1">
                <div class="container">
                    <h2>Destination</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Tour Details</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_tour">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-7 col-12 tour1">
                    <div class="tour">
                        <h1><?php echo e($tittle); ?> - <?php echo e($night); ?> Days in <?php echo e($country); ?>, <?php echo e($city); ?></h1>
                        <h4><?php echo e($days); ?> Days - <?php echo e($night); ?> Nights</h4>
                        <div class="tour-img">
                            <img src="/uploads/<?php echo e($image); ?>">
                            <div class="time-zone">
                                <span class="time1">Rs.<?php echo e($price); ?></span>
                                <p class="year">per person</p>
                            </div>
                        <p><?php echo nl2br(e($long_desc)); ?></p>
                    </div>
                    <div class="co_tab">
                        <div class="apple-tabs">
                            <ul>
                                <li>
                                    <a href="#Beyonce"><span>Itinerary</span></a>
                                </li>
                                <li>
                                    <a href="#Fergie"><span>Information</span></a>
                                </li>
                                <li>
                                    <a href="#Rihanna"><span>General Information</span></a>
                                </li>
                            </ul>
                            <div class="contents">
                                <div id="Beyonce">
                                    <div class="main-box">
                                        <ul class="timeline">

                                            <?php $__currentLoopData = $day_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="timeline-item">
                                                <h3 class="timeline-title">Day <?php echo e($key+1); ?></h3>
                                                <p class="timeline-text"><?php echo e($day->days_info); ?></p>
                                            </li> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                               
                                          
                                        </ul>
                                        <a href="" class="load-more"><button class="btn2">Load More <i class="far fa-angle-down"></i></button></a>
                                    </div>
                                </div>
                                <div id="Fergie">
                                    <div class="main-box">
                                        <div class="box-1">
                                            <h2>Inclusion :</h2>
                                            <ul class="box-prg">
                                             <!--   <?php echo nl2br(e($inclusion)); ?> -->
                                             <?php echo e($inclusion); ?>

                                            </ul>
                                        </div>
                                        <div class="box-1">
                                            <h2>Exclusion:</h2>
                                            <ul class="box-prg">
                                                  <!--   <?php echo nl2br(e($exclusion)); ?> -->
                                             <?php echo e($exclusion); ?>

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div id="Rihanna">
                                    <div class="main-box">
                                        <div class="box-1">
                                            <h2>General Terms & Conditions:</h2>
                                            <ul class="box-prg">
                                                 <?php echo nl2br(e($general_info)); ?> 
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                <div class="col-lg-4 col-md-5 col-12">


                    <div class="co_form" id="sidebar">
                        <div class="visa-form">
                             
                            
                            <h2>GET QUICK QUOTE</h2>

                              <p id="message"></p>
                              <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 

                      
                            <form method="post" class="form1">
                                 

                                 <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                                <div class="visa-text">
                                    <input type="text" placeholder="Name" name="name" id="name" value="" required autofocus/>
                                </div>
                                <div class="visa-text">
                                    <input type="number" placeholder="Number" name="mobileno" id="mobileno" value="" required autofocus/> 
                                </div>
                                <div class="visa-text">
                                    <input type="email" placeholder="Email" name="email" id="email" value="" required autofocus/> 
                                </div>
                                <div class="visa-text">
                                    <textarea placeholder="Messages" name="description" id="description" value="" required autofocus ></textarea>
                                </div>
                                <!-- <div class="sub1 ">
                                    <input type="submit" value="SUBMIT">
                                </div> -->
                                <div class="button sub sub2">
                                    <input type="Submit" id="submit" value="Submit">
                                </div> 
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_footer">
        <div class="container">
            <div class="footer-loop">
                <div class="row">
                    <div class="col-lg-3 col-md-12 col-12 footer-logo fm-1">
                        <div class="main-footer">
                            <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="/image/logo.png"></a></h2>
                            <p>We assure to provide hassle-free services and aim for long-term business relationships.</p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 col-12 fm-1">
                        <h2 class="title1">Company</h2>
                        <div class="footer-widget">
                            <ul>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/domesticpackage')); ?>">packages</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12 fm-1">
                        <h2 class="title1">Contact Us</h2>
                        <ul class="con-home">
                            <li><i class="fa fa-home" aria-hidden="true"></i>
                                <p><?php echo e($address); ?></p>
                            </li>
                            <li><i class="fa fa-envelope" aria-hidden="true"></i>
                                <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                            </li>
                            <li><i class="fa fa-phone" aria-hidden="true"></i>
                                <p><a href="tel:<?php echo e($mobileno); ?>"><?php echo e($mobileno); ?></a></p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-3 col-12 fm-1">
                        <h2 class="title1">Newsletter</h2>
                        <p>Get latest updates and offers.</p>
                        <form class="form">
                            <input type="text" placeholder="Enter your email here" name="email" value="">
                            <!-- <div class="button sub">submit</div> -->
                            <div class="button sub">
                                <input type="Submit" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Season Tour and Investment © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </div>
 <a class="up-btn show1" href="#"></a>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <!--   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script> -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>

   <!--   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
    
  <!--   <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> -->
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

        $(".apple-tabs").tabs({ 
            show: { effect: "slide", direction: "left", duration: 200, easing: "easeOutBack" } ,
            hide: { effect: "slide", direction: "right", duration: 200, easing: "easeInQuad" } 
        });

        $(window).scroll(function(){
            if ($(this).scrollTop() > 50) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

        $(function () {
            $(".main-box .timeline .timeline-item").slice(0, 3).show();
            $("body").on('click touchstart', '.load-more', function (e) {
                e.preventDefault();
                $(".timeline-item:hidden").slice(0, 3).slideDown();
                if ($(".timeline-item:hidden").length == 0) {
                    $(".load-more").css('visibility', 'hidden');
                }
                $('html,body').animate({
                    scrollTop: $(this).offset().top
                }, 1000);
            });
        });

           $.ajaxSetup({
        headers: {

               'X-CSRF-TOKEN': jQuery('#token').val()
           /* 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')*/
        }
    });

    $("#submit").click(function(e){

      var name = $('#name').val();
      var email = $('#email').val();
      var mobileno = $('#mobileno').val();
      var description = $('#description').val();

  if(name!="" && email!="" && mobileno!="" && description!=""){

     var pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i

    if(!pattern.test(email))
   {
 
    }else{


      e.preventDefault();

        $.ajax({
           url:'/enquiriesfrom',
           method:'POST',
           data:{
                 name,
                 email,
                 mobileno,
                 description
                },


   success: function(dataResult){
                  console.log(dataResult);
                  var dataResult = JSON.parse(dataResult);
                  if(dataResult.statusCode==200){

                  $("#message").append("<b>your message submit sucessfully!!!</b>");

                   $('#message').delay(3000).fadeOut(3000);         
                  }
                  else {
                     alert("Error occured !");
                  }


                    $( '.form1' ).each(function(){
                          this.reset();
                        });    
                  
              }
          



         /*  success:function(response){
              if(response.success){
                  alert(response.message) //Message come from controller
              }else{
                  alert("Error")
              }
           },
           error:function(error){
              console.log(error)
           }*/
        });

       }
      }else{

      

      }
    });

   /* $(document).ready(function(){
  $('#message').delay(5000).fadeOut(5000);
  });
*/

 var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
        $('html, body').animate({scrollTop:0}, '300');
    }); 



    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\seasontravels\resources\views/packagedetail.blade.php ENDPATH**/ ?>