<!DOCTYPE html>
<html>
<head>
    <title>SEASON TRAVEL AGENCY</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div class="co_header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-9 col-md-9 col-5">
                    <ul class="map">
                        <li>
                            <a href="mailto:<?php echo e($email); ?>"><i class="fas fa-envelope"></i>
                            <span><?php echo e($email); ?></span></a>
                        </li>
                        <li>
                            <a href="tel:<?php echo e($mobileno); ?>"><i class="fab fa-whatsapp"></i>
                            <span><?php echo e($mobileno); ?></span></a>
                        </li>
                    </ul>                   
                </div>
                <div class="col-lg-3 col-md-3 col-7">
                    <ul class="social-link"> 
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
  <div class="co_menu1" id="dynamic">
        <div class="co_menu">
            <div class="container">
                <div class="row row1">
                    <div class="col-lg-4 col-md-4 col-6">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>"><img src="image/logo.png"></a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-6">
                        <nav id="mainnav" class="mainnav mainnav1">
                            <ul class="menu"> 
                                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                 <li><a  href="<?php echo e(url('/about')); ?>">About us</a></li>
                                <li><a href="<?php echo e(url('/services')); ?>">Services</a>
                                <li><a href="#">Packages</a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                        <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                    </ul>
                                </li>
                                 <li><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </nav>
                        <div class="mobile-menu">
                            <div id="mySidepanel" class="sidepanel">
                                <div class="m_menu">
                                    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a> 
                                    <nav id="mainnav" class="mainnav">
                                        <ul class="menu"> 
                                            <li><a class="link" href="<?php echo e(url('/')); ?>">Home</a></li>
                                             <li><a class="link" href="<?php echo e(url('/about')); ?>">About us</a></li>
                                            <li><a class="link" href="<?php echo e(url('/services')); ?>">Services</a>
                                            <li><a class="link" href="#">Packages</a>
                                                <ul class="submenu">
                                                    <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                                    <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                                </ul>
                                            </li>
                                             <li><a class="link" href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                            <li><a class="link" href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_part-2">
        <div class="fix-part-2">
            <div class="img1">
                <img src="image/gallery-bg.jpg">
            </div>
            <div class="about1">
                <div class="container">
                    <h2>Gallery</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Gallery</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_gallery">
        <div class="container">
            <div class="gallery">

               <?php $__currentLoopData = $gallary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <?php if('.mp4'===$g->extension): ?>

              <a href="uploads/<?php echo e($g->file); ?>" data-lightbox="homePortfolio">
                <iframe width="560" height="315" src="uploads/<?php echo e($g->file); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen autoplay="false"></iframe>
            </a>


               <?php else: ?>
                   <?php if($g->id % 2==0 ): ?>
                   <a href="uploads/<?php echo e($g->file); ?>" data-lightbox="homePortfolio">
                   <img src="uploads/<?php echo e($g->file); ?>"/></a>
                   <?php else: ?>
                    <a href="uploads/<?php echo e($g->file); ?>" data-lightbox="homePortfolio" class="big">
                   <img src="uploads/<?php echo e($g->file); ?>"/></a>
                    <?php endif; ?> 

             <?php endif; ?>  

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                         

         
           </div>
        </div>
    </div>

      <div class="co_footer">
        <div class="container">
            <div class="footer-loop">
                <div class="row">
                    <div class="col-lg-3 col-md-12 col-12 footer-logo fm-1">
                        <div class="main-footer">
                            <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="image/logo.png"></a></h2>
                            <p>Book with confidence. We offer a unique travelling experience you can’t miss.</p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 col-12 fm-1">
                        <h2 class="title1">Company</h2>
                        <div class="footer-widget">
                            <ul>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/domesticpackage')); ?>">packages</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12 fm-1">
                        <h2 class="title1">Contact Us</h2>
                        <ul class="con-home">
                            <li><i class="fa fa-home" aria-hidden="true"></i>
                                <p><?php echo e($address); ?></p>
                            </li>
                            <li><i class="fa fa-envelope" aria-hidden="true"></i>
                               <p><a href="mailto:Holidays@seasontoursandtravels.com">Holidays@seasontoursandtravels.com</a>
                               <a href="mailto:Contact@seasontoursandtravels.com">Contact@seasontoursandtravels.com</a></p>   
                            </li>
                            <li><i class="fa fa-phone" aria-hidden="true"></i>
                                <p><a href="tel:<?php echo e($mobileno); ?>"><?php echo e($mobileno); ?></a><br>
                                <a href="tel:02634270797">(02634) 270797</a>
                                </p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-3 col-12 fm-1">
                        <h2 class="title1">Newsletter</h2>
                        <p>Get latest updates and offers.</p>
                        <form class="form">
                            <input type="text" placeholder="Enter your email here" name="email" value="">
                            <!-- <div class="button sub">submit</div> -->
                            <div class="button sub">
                                <input type="Submit" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Season Tour and Investment © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </div>
    
 <a class="up-btn show1" href="#"></a>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox-plus-jquery.min.js"></script>
    <script type="text/javascript">
        $(window).scroll(function(){
            if ($(this).scrollTop() > 50) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

          var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
        $('html, body').animate({scrollTop:0}, '300');
    }); 


    </script>

</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/seasontoursandtravels.com/resources/views/gallary.blade.php ENDPATH**/ ?>