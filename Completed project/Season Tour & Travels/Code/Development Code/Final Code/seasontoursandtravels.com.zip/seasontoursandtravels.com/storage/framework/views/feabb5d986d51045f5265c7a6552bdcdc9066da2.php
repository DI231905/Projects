<!DOCTYPE html>
<html>
<head>
    <title>NM Balaji Interior</title>
      <link rel="stylesheet" type="text/css" href="/css/main-dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body"> 
                      
            

    <div class="page my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">UPDATE PACKAGE</h4>
            <div class="detail">
                <div class="form">

                      <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 
                 <form  action="<?php echo e(url('admin/storeupdatepackage')); ?>/<?php echo e($id); ?>" enctype="multipart/form-data" method="POST" >
                         <?php echo csrf_field(); ?>
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Image</label>
                            </div>
                            <div class="col-md-12">
                                  <input type="file" value="<?php echo e($image); ?>" name="image" accept="image/*"  onchange="readURL(this);" />
                                  <img id="blah" src="/uploads/<?php echo e($image); ?>" width="120" height="120" />

                                <input type="hidden" name="oldimage" value="<?php echo e($image); ?> "/>
                             </div>   
                        </div>


                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Packages</label>
                            </div>
                            <div class="col-md-12 data">
                               <select name="packages" value= "" >
                                 <option>Select package Type</option>
                                <?php $__currentLoopData = $package_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($p->id); ?>"<?php echo e($p->id== $ptype_id ? 'selected' : ''); ?>><?php echo e($p->type_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </div>
                        </div>                      

                           <div class="part">
                            <div class="col-md-12 label">
                                <label>Tittle</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Tour Tittle" name="tittle" value="<?php echo e($tittle); ?>" >
                            </div>   
                        </div>

                         <div class="part">
                            <div class="col-md-12 label">
                                <label>Type of Tour</label>
                            </div>
                            <div class="col-md-12 data">
                            <select name="tour_type" value="" >
                             <option>Select Tour Type</option>

                               <?php $__currentLoopData = $tour_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($t->id); ?>"<?php echo e($t->id== $t_id ? 'selected' : ''); ?>><?php echo e($t->tour_type); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                           </select>
                            </div>
                        </div>      

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Country</label>
                            </div>
                            <div class="col-md-12 data">
                              <select name="country" id="country" >
                                         <option value="" >Select Country</option>

                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($c->id); ?>"<?php echo e($c->id== $country_id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  </select>
                            </div>
                             <?php echo csrf_field(); ?>
                        </div> 

                        <div class="part">
                            <div class="col-md-12 label">
                                <label>City</label>
                            </div>
                            <div class="col-md-12 data">
                                <select name="city" id="city" >

                                   <option value="<?php echo e($city_id); ?>"><?php echo e($city); ?></option>
                                           
                               </select> 
                            </div>
                        </div> 

                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Days</label>
                            </div>
                          <div class="col-md-12 data">
                                <input type="number" placeholder="Enter Days" name="numberofday" value="<?php echo e($numberofday); ?>" >
                          </div>
                       </div>
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Price</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="number" placeholder="Enter Price Number" name="price" value="<?php echo e($price); ?>" >
                            </div>   
                        </div>
                          <div class="part part1">
                            <div class="col-md-12 label">
                                <label>short Description</label>
                            </div>
                            <div class="col-md-12 data">
                                <textarea placeholder="Enter text.." name="short_desc" value="<?php echo e($short_desc); ?>"><?php echo e($short_desc); ?></textarea>
                            </div>   
                        </div>

                         <div class="part part1">
                            <div class="col-md-12 label">
                                <label>Days Information</label>
                            </div>
                              <?php $__currentLoopData = $days_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div class="col-md-12 data" style="display:flex; margin-top: 10px; ">
                                <button style="color:white; background-color: rgb(255 155 2 / 100%);">Day <?php echo e($key+1); ?></button>
                                <input type="text" placeholder="" name="daydata" value="<?php echo e($d->days_info); ?>" readonly>
                                <button style="background-color: rgb(255 155 2 / 100%); color: white!imortant;"><a href="<?php echo e(url('admin/deletedayinfo')); ?>/<?php echo e($d->id); ?>">Delete</a></button>
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

                            <div class="col-md-12 data data1" style="margin-top:10px" >
                            <div class="days data1">
                            
                             <textarea name="day" placeholder="please enter full day information" autocomplete="off" >
                            </textarea>
                            </div>
                            <button  id="removeRow" type="button" class="btn-remove">Remove</button>
                             <div id="newRow"></div>
                            <button id="addRow" type="button" class="btn-remove btn-add1">Add days</button>
                       </div>
                    </div> 

                      <div class="part part1">
                            <div class="col-md-12 label">
                                <label>Inclusion</label>
                            </div>
                            <div class="col-md-12 data">
                                <textarea placeholder="Enter text.." name="inclusion" value="<?php echo e($inclusion); ?>"><?php echo e($inclusion); ?></textarea >
                            </div>   
                        </div>
                         <div class="part part1">
                            <div class="col-md-12 label">
                                <label>Exclusion</label>
                            </div>
                            <div class="col-md-12 data">
                                <textarea placeholder="Enter text.." name="exclusion" value="<?php echo e($exclusion); ?>"><?php echo e($exclusion); ?></textarea >
                            </div>   
                        </div>
                          <div class="part part1">
                            <div class="col-md-12 label">
                                <label>General Information</label>
                            </div>
                            <div class="col-md-12 data">
                                <textarea placeholder="Enter text.." name="general_info" value="<?php echo e($general_info); ?>"><?php echo e($general_info); ?></textarea >
                            </div>   
                        </div>
                          <div class="part part1">
                            <div class="col-md-12 label">
                                <label>Large Description</label>
                            </div>
                            <div class="col-md-12 data">
                                <textarea placeholder="Enter text.." name="long_desc" value="<?php echo e($long_desc); ?>"><?php echo e($long_desc); ?></textarea >
                            </div> 

                        </div>

                     <div class="upload">
                        <button class="btn21">Update</button> 
                        <a href="<?php echo e(url('admin/home')); ?>">Back to Home?</a>       
                      </div>  
                        </div>

                    </form>     
                </div>
            </div>
        </div>
    </div>
  
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    
 <script type="text/javascript">
         function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result)
                        .width(130)
                        .height(130);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

          $("#addRow").click(function () {
            var html = '';
           
            html += '<div class="days">';
            html += ' <textarea name="days[]"  placeholder="please enter full day information" autocomplete="off"></textarea>';
            html += '<button id="removeRow" type="button" class="btn-remove">Remove</button>';
            html += '</div>';
           

            $('#newRow').append(html);
        });

        // remove row
        $(document).on('click', '#removeRow', function () {
            $(this).closest('.days').remove();
        });

          $(document).ready(function(){

            $('select[name="country"]').on('change',function(){
                var id=$(this).val();
                console.log(id);
 
           if(id){

                $.ajax({

                    url:'getcity/'+id,
                     type:'GET',
                     dataType:'json',
              success:function(data){

                    console.log(data);


                     
                  /*  var json = JSON.stringify(data);
                      console.log(json);

                    */

                      $('select[name="city"]').empty(); 

                       $('select[name="city"]').append('<option>Select City</option>');


                       $.each(data,function(key,value){

                       $('select[name="city"]')
                    
                       .append('<option value="'+value.id+'">'+value.name+'</option>');
                     });

                   }

                }); 
              }else{

                   $('select[name="city"]').empty();
              }
               
            });
       
        });   


</script>
</body>
</html><?php /**PATH D:\xampp\htdocs\seasontravels\resources\views/admin/updatepackage.blade.php ENDPATH**/ ?>