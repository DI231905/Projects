

<?php $__env->startSection('content'); ?> 
 <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/banner2.jpg">
    	    </div>
    	    <div class="about1">
    	    	<div class="container">
    		        <h2>Packages</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">Packages</li>
    		        </ul>
    		    </div>
    	    </div>
    	</div>
    </div>
    <div class="co_package1">
    	<div class="container">
    		<div class="row">
                <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<div class="col-lg-6 col-md-6 col-12">
    				<div class="package1">
    					<div class="recom-item-body">
                            <h4><?php echo e($p->tittle); ?></h4>
                            <h6><?php echo e($p->tour_type); ?></h6>
                            <div class="day">
                                <h5>Duration: <strong> <?php echo e($p->days); ?> DAYS</strong></h5>
                            </div>
                            <p class="block-ellipsis"><?php echo e($p->short_desc); ?></p>
                            <a href="<?php echo e(url('/packagedetail')); ?>/<?php echo e($p->id); ?>" class="cws-button">Read more</a>
                            <div class="price">Rs.<?php echo e($p->price); ?></div>
                        </div>
                        <div class="recom-media">
                        	<a href="<?php echo e(url('/packagedetail')); ?>/<?php echo e($p->id); ?>">
                                <div class="package1-img">
                                	<img src="uploads/<?php echo e($p->image); ?>">
                                </div>
                            </a>
                            <div class="location">
                            	<i class="far fa-map-marker-alt"></i> <?php echo e($p->country); ?>, <?php echo e($p->city); ?>

                            </div>
                        </div>
    				</div>
    			</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			
    		</div>
    	</div>
    </div>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/seasontoursandtravels.com/resources/views/domestic.blade.php ENDPATH**/ ?>