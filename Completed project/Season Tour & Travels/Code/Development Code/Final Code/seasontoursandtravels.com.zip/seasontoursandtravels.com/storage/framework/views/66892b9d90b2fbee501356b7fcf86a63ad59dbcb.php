<!DOCTYPE html>
<html>
<head>
	<title>SEASON TRAVEL AGENCY</title>
	<link rel="stylesheet" type="text/css" href="css/home.css">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" href="image/logo.png">
	<meta name="viewport" content="width=device-width, initial-scale=1">


</head>
<body class="body">
	 <div class="co_header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-9 col-md-9 col-5">
                    <ul class="map">
                        <li>
                            <a href="mailto:<?php echo e($email); ?>"><i class="fas fa-envelope"></i>
                            <span><?php echo e($email); ?></span></a>
                        </li>
                        <li>
                            <a href="tel:<?php echo e($mobileno); ?>"><i class="far fa-phone-alt"></i>
                            <span><?php echo e($mobileno); ?></span></a>
                        </li>
                    </ul>                   
                </div>
                <div class="col-lg-3 col-md-3 col-7">
                    <ul class="social-link"> 
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_menu1" id="dynamic">
        <div class="co_menu">
            <div class="container">
                <div class="row row1">
                    <div class="col-lg-4 col-md-4 col-6">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>"><img src="image/logo.png"></a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-6">
                        <nav id="mainnav" class="mainnav mainnav1">
                            <ul class="menu"> 
                                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li><a href="<?php echo e(url('/services')); ?>">Services</a>
                                <li><a href="#">Packages</a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                        <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                    </ul>
                                </li>
                                 <li><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </nav>
                        <div class="mobile-menu">
                            <div id="mySidepanel" class="sidepanel">
                                <div class="m_menu">
                                    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a> 
                                    <nav id="mainnav" class="mainnav">
                                        <ul class="menu"> 
                                            <li><a class="link" href="<?php echo e(url('/')); ?>">Home</a></li>
                                            <li><a class="link" href="<?php echo e(url('/services')); ?>">Services</a>
                                            <li><a class="link" href="#">Packages</a>
                                                <ul class="submenu">
                                                    <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                                    <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                                </ul>
                                            </li>
                                             <li><a class="link" href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                            <li><a class="link" href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/about-1.jpg">
    	    </div>
    	    <div class="about1">
    	    	<div class="container">
    		        <h2>About</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">About Us</li>
    		        </ul>
    		    </div>
    	    </div>
    	</div>
    </div>
    <div class="co_about1">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-7 col-md-12 col-12">
                    <div class="about-info1">
                        <h6>INTRODUCTION</h6>
                        <h2>WE ARE A TRAVEL AGENCY</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing</p>
                        <p> It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-5 col-md-12 col-12">
                    <div class="co_globe">
                        <div class="globe">
                            <div class="go"></div>
                            <div class="hand"></div>
                            <div class="hand1"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_mission">
        <div class="container">
            <div class="set-mission1">
                <div class="row">
                    <div class="main-mission">
                        <div class="mission">
                            <img src="image/mission.jpg">
                        </div>
                    </div>
                    <div class="main-mission">
                        <div class="mission-detail">
                            <div class="set-mission-detail">
                                <img src="image/writing.png">
                                <h2>Mission</h2>
                            </div>
                            <div class="icon-box-content effect-box">
                                <div class="effect-btn">
                                   <i class="cross-arrow fal fa-arrows-v"></i>
                                </div>
                                <p class="icon-box-desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy</p>
                            </div>
                        </div>
                    </div>
                    <div class="main-mission mission-y">
                        <div class="mission-detail m-detail1">
                            <div class="set-mission-detail">
                                <img src="image/writing.png">
                                <h2>Vision</h2>
                            </div>
                            <div class="icon-box-content1 effect-box e-box1">
                                <div class="effect-btn">
                                   <i class="c-arrow1 fal fa-arrows-v"></i>
                                </div>
                                <p class="icon-box-desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy</p>
                            </div>
                        </div>
                    </div>
                    <div class="main-mission mission-x">
                        <div class="mission">
                            <img src="image/vision.jpg">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_faq">
        <div class="container">
            <div class="inner-head">
                <h1 class="title">Frequently Asked Questions</h1>
                <img src="image/icon_title.png">
                <p class="prg">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident possimus quae adipisci quisquam distinctio</p>
            </div>
            <div class="row2">
                <div class="port1">
                    <div class="accordion-container">
                        <div class="row">
                             <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-lg-6 col-md-12">
                                <div class="set">
                                    <a><span><?php echo e($q->question); ?></span><i class="fa fa-plus"></i></a>
                                    <div class="content">
                                        <p><?php echo $q->answer; ?></p>
                                    </div>
                                </div>   
                            </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   <div class="co_footer">
        <div class="container">
            <div class="footer-loop">
                <div class="row">
                    <div class="col-lg-3 col-md-12 col-12 footer-logo fm-1">
                        <div class="main-footer">
                            <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="image/logo.png"></a></h2>
                            <p>Book with confidence. We offer a unique travelling experience you can’t miss.</p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 col-12 fm-1">
                        <h2 class="title1">Company</h2>
                        <div class="footer-widget">
                            <ul>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/domesticpackage')); ?>">packages</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12 fm-1">
                        <h2 class="title1">Contact Us</h2>
                        <ul class="con-home">
                            <li><i class="fa fa-home" aria-hidden="true"></i>
                                <p><?php echo e($address); ?></p>
                            </li>
                            <li><i class="fa fa-envelope" aria-hidden="true"></i>
                                <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                            </li>
                            <li><i class="fa fa-phone" aria-hidden="true"></i>
                                <p><a href="tel:<?php echo e($mobileno); ?>"><?php echo e($mobileno); ?></a></p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-3 col-12 fm-1">
                        <h2 class="title1">Newsletter</h2>
                        <p>Get latest updates and offers.</p>
                        <form class="form">
                            <input type="text" placeholder="Enter your email here" name="email" value="">
                            <!-- <div class="button sub">submit</div> -->
                            <div class="button sub">
                                <input type="Submit" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Season Tour and Investment © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </div>
    <a class="up-btn show1" href="#"></a>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

        
        $(window).scroll(function(){
            if ($(this).scrollTop() > 50) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

        $(document).ready(function(){
            $(".cross-arrow").click(function(){
                $(".icon-box-content").toggleClass("main");
            });
            
            $(".c-arrow1").click(function(){
                $(".icon-box-content1").toggleClass("main");
            });
        });

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
        $('html, body').animate({scrollTop:0}, '300');
    }); 


        $(document).ready(function() {
  $(".set").on("click", function() {
    if ($(this).hasClass("active")) {
      $(this).removeClass("active");
      $(this)
        .children(".content")
        .slideUp(200);
      $(".set > a i")
        .removeClass("fal fa-times")
        .addClass("fa-plus");
    } else {
      $(".set > a i")
        .removeClass("fal fa-times")
        .addClass("fa-plus");
      $(this)
        .find("i")
        .removeClass("fa-plus")
        .addClass("fal fa-times");
      $(".set").removeClass("active");
      $(this).addClass("active");
      $(".content").slideUp(200);
      $(this)
        .children(".content")
        .slideDown(200);
    }
  });
});

    </script><?php /**PATH D:\xampp\htdocs\seasontravels\resources\views/about.blade.php ENDPATH**/ ?>