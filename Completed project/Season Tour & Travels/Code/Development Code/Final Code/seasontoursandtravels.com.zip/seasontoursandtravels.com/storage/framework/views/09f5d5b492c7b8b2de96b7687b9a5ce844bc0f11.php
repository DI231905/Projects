<!DOCTYPE html>
<html>
<head>
    <title>SEASON TRAVEL AGENCY</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="https://kenwheeler.github.io/slick/slick/slick-theme.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div class="co_header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-9 col-md-9 col-5">
                    <ul class="map">
                        <li>
                            <a href="mailto:<?php echo e($email); ?>"><i class="fas fa-envelope"></i>
                            <span><?php echo e($email); ?></span></a>
                        </li>
                        <li>
                            <a href="tel:<?php echo e($mobileno); ?>"><i class="far fa-phone-alt"></i>
                            <span><?php echo e($mobileno); ?></span></a>
                        </li>
                    </ul>                   
                </div>
                <div class="col-lg-3 col-md-3 col-7">
                    <ul class="social-link"> 
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_menu1" id="dynamic">
        <div class="co_menu">
            <div class="container">
                <div class="row row1">
                    <div class="col-lg-4 col-md-4 col-6">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>"><img src="image/logo.png"></a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-6">
                        <nav id="mainnav" class="mainnav mainnav1">
                            <ul class="menu"> 
                                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li><a href="<?php echo e(url('/services')); ?>">Services</a>
                                <li><a href="#">Packages</a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                        <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                    </ul>
                                </li>
                                 <li><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </nav>
                        <div class="mobile-menu">
                            <div id="mySidepanel" class="sidepanel">
                                <div class="m_menu">
                                    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a> 
                                    <nav id="mainnav" class="mainnav">
                                        <ul class="menu"> 
                                            <li><a class="link" href="<?php echo e(url('/')); ?>">Home</a></li>
                                            <li><a class="link" href="<?php echo e(url('/services')); ?>">Services</a>
                                            <li><a class="link" href="#">Packages</a>
                                                <ul class="submenu">
                                                    <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                                    <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                                </ul>
                                            </li>
                                             <li><a class="link" href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                            <li><a class="link" href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<div >
  <?php echo $__env->yieldContent('content'); ?>
</div>
  <div class="co_footer">
        <div class="container">
            <div class="footer-loop">
                <div class="row">
                    <div class="col-lg-3 col-md-12 col-12 footer-logo fm-1">
                        <div class="main-footer">
                            <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="image/logo.png"></a></h2>
                            <p>We assure to provide hassle-free services and aim for long-term business relationships.</p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 col-12 fm-1">
                        <h2 class="title1">Company</h2>
                        <div class="footer-widget">
                            <ul>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/domesticpackage')); ?>">packages</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12 fm-1">
                        <h2 class="title1">Contact Us</h2>
                        <ul class="con-home">
                            <li><i class="fa fa-home" aria-hidden="true"></i>
                                <p><?php echo e($address); ?></p>
                            </li>
                            <li><i class="fa fa-envelope" aria-hidden="true"></i>
                                <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                            </li>
                            <li><i class="fa fa-phone" aria-hidden="true"></i>
                                <p><a href="tel:<?php echo e($mobileno); ?>"><?php echo e($mobileno); ?></a></p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-3 col-12 fm-1">
                        <h2 class="title1">Newsletter</h2>
                        <p>Get latest updates and offers.</p>
                        <form class="form">
                            <input type="text" placeholder="Enter your email here" name="email" value="">
                            <!-- <div class="button sub">submit</div> -->
                            <div class="button sub">
                                <input type="Submit" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Season Tour and Investment © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </div>
    <a class="up-btn show1" href="#"></a>
    
    
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/popper.min.js"></script> 
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

        $(window).scroll(function(){
            if ($(this).scrollTop() > 50) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

        $('.slider-nav').slick({
            autoplay: false,
            autoSpeed: 1500,
            arrows: true,
            slidesToShow: 2,
            slidesToScroll: 1,
            dots: false,
            focusOnSelect: true,
            prevArrow: '<div class="slide-arrow prev-arrow"><i class="far fa-angle-left"></i></div>',
            nextArrow: '<div class="slide-arrow next-arrow"><i class="far fa-angle-right"></i></div>',
            responsive: [{
                breakpoint: 1024,
                settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        // centerMode: true,
                    }
                }, {
                    breakpoint: 800,
                    settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                  }
                },  {
                    breakpoint: 480,
                    settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }]
        });

        $(document).ready(function(){
            $('.your-class').slick({
                infinite: true,
                arrows: true,
                dots: false,
                slidesToShow: 2,
                slidesToScroll: 1,
                prevArrow: '<div class="slide-arrow prev-arrow prev-arrow1"><i class="far fa-angle-left"></i></div>',
                nextArrow: '<div class="slide-arrow next-arrow next-arrow1"><i class="far fa-angle-right"></i></div>',
                responsive: [{
                breakpoint: 1024,
                settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        // centerMode: true,
                    }
                }, {
                    breakpoint: 800,
                    settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                  }
                },  {
                    breakpoint: 480,
                    settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }]
            });
        });

        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            $('.your-class').slick('setPosition');
        })

           var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
        $('html, body').animate({scrollTop:0}, '300');
    }); 


    </script>

</body>
</html><?php /**PATH D:\xampp\htdocs\seasontravels\resources\views/layouts/app.blade.php ENDPATH**/ ?>