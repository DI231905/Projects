 <!DOCTYPE html>
<html>
<head>
    <title>SEASON TRAVEL AGENCY</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="https://kenwheeler.github.io/slick/slick/slick-theme.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="image/logo.png">

</head>
<body class="body">
    <div class="co_header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-9 col-md-9 col-5">
                    <ul class="map">
                        <li>
                            <a href="mailto:<?php echo e($email); ?>"><i class="fas fa-envelope"></i>
                            <span><?php echo e($email); ?></span></a>
                        </li>
                        <li>
                            <a href="tel:<?php echo e($mobileno); ?>"><i class="far fa-phone-alt"></i>
                            <span><?php echo e($mobileno); ?></span></a>
                        </li>
                    </ul>                   
                </div>
                <div class="col-lg-3 col-md-3 col-7">
                    <ul class="social-link"> 
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_menu1" id="dynamic">
        <div class="co_menu">
            <div class="container">
                <div class="row row1">
                    <div class="col-lg-4 col-md-4 col-6">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>"><img src="image/logo.png"></a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-6">
                        <nav id="mainnav" class="mainnav mainnav1">
                            <ul class="menu"> 
                                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li><a href="<?php echo e(url('/services')); ?>">Services</a>
                                <li><a href="#">Packages</a>
                                    <ul class="submenu">
                                        <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                        <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                    </ul>
                                </li>
                                 <li><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </nav>
                        <div class="mobile-menu">
                            <div id="mySidepanel" class="sidepanel">
                                <div class="m_menu">
                                    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a> 
                                    <nav id="mainnav" class="mainnav">
                                        <ul class="menu"> 
                                            <li><a class="link" href="<?php echo e(url('/')); ?>">Home</a></li>
                                            <li><a class="link" href="<?php echo e(url('/services')); ?>">Services</a>
                                            <li><a class="link" href="#">Packages</a>
                                                <ul class="submenu">
                                                    <li><a href="<?php echo e(url('/domesticpackage')); ?>">Domestic</a></li>
                                                    <li><a href="<?php echo e(url('/internationalpackage')); ?>">International</a></li>
                                                </ul>
                                            </li>
                                             <li><a class="link" href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                            <li><a class="link" href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 

 
    <div class="co_banner">


        <div id="demo" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="banner-img">
                        <img src="image/banner-1.jpg" alt="banner1.jpg">
                    </div>

                    
                    <div class="banner-info">


                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div id="hideDiv" class="alert alert-info" role="alert">
                          <b> <?php echo e($error); ?></b>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          

                        <!--  <div class="Messages" style="height: 40px ; width: 500px; margin-left: 200px; background-color: white ; color: black; text-align: center;" >
                              
                          <p style="font-size:20px ;"><b>tfytgfvtgtv</b></p> 
                          
                          
                     </div> -->

                        <div class="banner-content">
                          <h4>Welcome To Season Travel Agency</h4>
                            <h1>Creating Your<br> Kind of Holiday</h1>
                            <button class="my-btn btn1"><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></button>
                            <!-- <button class="my-btn btn1"><a href="#">Our Portfolio</a></button> -->
                        </div>
                    </div>
                </div>
                 <div class="carousel-item">
                    <div class="banner-img">
                        <img src="image/banner-2.jpg" alt="banner2.jpg">
                    </div>
                    <div class="banner-info">
                        <div class="banner-content">

                           <h4>Welcome To Season Travel Agency</h4>
                            <h1>Let Us Be Your<br>Passport To The World.</h1>
                            <button class="my-btn btn1"><a href="SS_contact.html">Contact Us</a></button>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="banner-img">
                        <img src="image/banner-3.jpg" alt="banner3.jpg">
                    </div>
                    <div class="banner-info">
                        <div class="banner-content">
                         <h4>Welcome To Season Travel Agency</h4>
                            <h1>Explore<br>All Seasons</h1>
                            <button class="my-btn btn1"><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></button>
                        </div>
                    </div>
                </div> 
            </div>
            <a class="arrow carousel-control-prev" href="#demo" data-slide="prev">
                <i class="far fa-angle-left"></i>
            </a>
            <a class="arrow carousel-control-next" href="#demo" data-slide="next">
                <i class="far fa-angle-right"></i>
            </a>
        </div>
   </div>
    <div class="co_search">

   
        <div class="container">
          <form method="GET" action="<?php echo e(url('/travel_search')); ?>">
             <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-12">
                
                            <div class="test">
                                <input type="text" placeholder="Where to?" name="service" id="service">
                            </div>
                     
                </div>
                <div class="col-lg-3 col-md-3 col-12">
                  
                            <div class="test">
                                <input type="number" placeholder="Price" name="price" id="price">
                            </div>
                     
                </div>
                <div class="col-lg-3 col-md-3 col-12">
                  
                            <div class="test test-search">
                                <select name="type" id="type">
                                    <option value="">Travel Type</option>
                                     <option value="Family Tours">Family Tours</option>
                                     <option value="Honeymoon Tours">Honeymoon Tours</option>
                                     <option value="Summer Tours">Summer Tours</option>
                                     <option value="Winter Tours">Winter Tours</option>
                                     <option value="Adventure Tours">Adventure Tours</option>
                                </select>
                                <span class="test-icon"><i class="far fa-chevron-down"></i></span>
                            </div>
                      
                </div>
                <div class="col-lg-3 col-md-3 col-12">
                    
                            <div class="test">
                                <button  class="btn2" id="search"  onclick="search_value()"><i class="far fa-search"></i> Find Now</button>
                                <!-- <i class="far fa-search"></i>
                                <input type="Submit" value="Find Now"> -->
                            </div> 
                </div>
            </div>
        </form>
        </div>
    </div>
    <div class="co_about">
        <div class="container">
            <div class="row row1">
                <div class="col-lg-6 col-md-5 col-12 part-1">
                    <div class="about-img">
                        <img src="image/about.jpg">
                    </div>
                </div>
                <div class="col-lg-6 col-md-7 col-12 part-1">
                    <div class="about-info">
                       <h1>Leading Tours & Travels Agency</h1>
                        <p>Season Tours & Travels is a prominent travel business that specialises in creating unique travel experiences. Our commitment to quality guarantees that every trip is easy and worry-free, allowing the visitor to experience, be inspired by and learn about a destination's culture. Each day is personalised to your specific interests, timetable, level of energy, and travel choices, with your professional guide and driver at each place. We only book the best of the best, and we know how to make your travel experience hassle-free, inspiring and enlightening.</p>
                        <span class="author">VoyageTime Team <i class="far fa-smile"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_service">
        <div class="container">
            <div class="inner-head">
                <h1 class="title">Our Services</h1>
                <img src="image/icon_title1.png">
                <p class="prg">We offer tours around the world that we believe are perfect for your vacation time. Each location has a rich cultural heritage, luxury hotels and resorts, and a strong tourism infrastructure.

</p>
            </div>
            <div class="row row2">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-4 col-md-6 col-12">
                    <div class="service">
                        <div class="service-img">
                            <img src="uploads/<?php echo e($s->image); ?>">
                        </div>
                        <div class="info-title">
                            <h4>Passport <i class="<?php echo e($s->icon_url); ?>"></i></h4>
                        </div>
                        <div class="overlay">
                            <div class="box">
                                <div class="content1">
                                    <div class="overlay-content">
                                        <h4><?php echo e($s->name); ?></h4>   
                                        <p><?php echo e($s->description); ?></p>   
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            </div>
            <div class="button sub btn-1"><a href="<?php echo e(url('/services')); ?>">See all Services</a></div>
        </div>
    </div>
    <div class="co_package">
        <div class="container">
            <div class="inner-head">
                <h1 class="title">Packages</h1>
                <img src="image/icon_title1.png">
                <p class="prg">Book your perfect holiday packages for any international destination of your choice.

</p>
            </div>
            <div class="row row2">
                <div class="col-lg-3 col-md-12">
                    <ul class="nav nav-tabs nav1" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Family Tours</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Honeymoon Tours</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Summer Tours</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="service-tab" data-toggle="tab" href="#service" role="tab" aria-controls="service" aria-selected="false">Winter Tours</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="about-tab" data-toggle="tab" href="#about" role="tab" aria-controls="about" aria-selected="false">Adventure Tours</a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-9 col-md-12">
                    <div class="tab-content" id="myTabContent">
                         
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                           
                            <div class="your-class">
                                 <?php $__currentLoopData = $f_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <div class="package1 package11">
                                        <div class="recom-item-body recom-item-body1">
                                            <h4><?php echo e($fp->tittle); ?></h4>
                                            <h6><?php echo e($fp->country); ?>, <?php echo e($fp->city); ?></h6>
                                            <div class="day">
                                            <h5>Duration: <strong><?php echo e($fp->days); ?> DAYS</strong></h5>
                                            </div>
                                            <?php if($fp->country != 'India'): ?>

                                                <a href="<?php echo e(url('/internationalpackage')); ?>" class="cws-button">Read more</a>

                                            <?php else: ?>

                                                 <a href="<?php echo e(url('/domesticpackage')); ?>" class="cws-button">Read more</a>

                                             <?php endif; ?>
                                           
                                            <div class="price">Rs.<?php echo e($fp->price); ?></div>
                                        </div>
                                        <div class="recom-media recom-media1">
                                            <div class="package1-img">
                                                <img src="uploads/<?php echo e($fp->image); ?>">
                                            </div>
                                        </div>
                                      
                                    </div>
                                      
                                </div>
                               
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>      
                        </div>


                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="your-class">
                                <?php $__currentLoopData = $h_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <div class="package1 package11">
                                        <div class="recom-item-body recom-item-body1">
                                            <h4><?php echo e($hp->tittle); ?></h4>
                                            <h6><?php echo e($hp->country); ?>, <?php echo e($hp->city); ?></h6>
                                            <div class="day">
                                            <h5>Duration: <strong> <?php echo e($hp->days); ?> DAYS</strong></h5>
                                            </div>
                                            <?php if($hp->country != 'India'): ?>

                                                <a href="<?php echo e(url('/internationalpackage')); ?>" class="cws-button">Read more</a>

                                            <?php else: ?>

                                                 <a href="<?php echo e(url('/domesticpackage')); ?>" class="cws-button">Read more</a>

                                             <?php endif; ?>
                                           
                                            <div class="price">Rs.<?php echo e($hp->price); ?></div>
                                        </div>
                                        <div class="recom-media recom-media1">
                                            <div class="package1-img">
                                                <img src="uploads/<?php echo e($hp->image); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                            </div>
                        </div>

                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="your-class">
                               <?php $__currentLoopData = $s_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <div class="package1 package11">
                                        <div class="recom-item-body recom-item-body1">
                                            <h4><?php echo e($sp->tittle); ?></h4>
                                            <h6><?php echo e($sp->country); ?>, <?php echo e($sp->city); ?></h6>
                                            <div class="day">
                                                <h5>Duration: <strong><?php echo e($sp->days); ?> DAYS</strong></h5>
                                            </div>
                                            <?php if($sp->country != 'India'): ?>

                                                <a href="<?php echo e(url('/internationalpackage')); ?>" class="cws-button">Read more</a>

                                            <?php else: ?>

                                                 <a href="<?php echo e(url('/domesticpackage')); ?>" class="cws-button">Read more</a>

                                             <?php endif; ?>
                                            <div class="price">Rs.<?php echo e($sp->price); ?></div>
                                        </div>
                                        <div class="recom-media recom-media1">
                                            <div class="package1-img">
                                                <img src="uploads/<?php echo e($sp->image); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="service" role="tabpanel" aria-labelledby="service-tab">
                            <div class="your-class">
                             <?php $__currentLoopData = $w_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <div class="package1 package11">
                                        <div class="recom-item-body recom-item-body1">
                                            <h4><?php echo e($wp->tittle); ?></h4>
                                            <h6><?php echo e($wp->country); ?>, <?php echo e($wp->city); ?></h6>
                                            <div class="day">
                                            <h5>Duration: <strong><?php echo e($wp->days); ?> DAYS</strong></h5>
                                            </div> 
                                            <?php if($wp->country != 'India'): ?>

                                                <a href="<?php echo e(url('/internationalpackage')); ?>" class="cws-button">Read more</a>

                                            <?php else: ?>

                                                 <a href="<?php echo e(url('/domesticpackage')); ?>" class="cws-button">Read more</a>

                                             <?php endif; ?>
                                            <div class="price">Rs.<?php echo e($wp->price); ?></div>
                                        </div>
                                        <div class="recom-media recom-media1">
                                            <div class="package1-img">
                                                <img src="uploads/<?php echo e($wp->image); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                        </div>

                        <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="about-tab">
                            <div class="your-class">
                                 <?php $__currentLoopData = $a_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <div class="package1 package11">
                                        <div class="recom-item-body recom-item-body1">
                                            <h4><?php echo e($ap->tittle); ?></h4>
                                            <h6><?php echo e($ap->country); ?>, <?php echo e($ap->city); ?></h6>
                                            <div class="day">
                                            <h5>Duration: <strong><?php echo e($ap->days); ?> DAYS</strong></h5>
                                            </div>
                                            <?php if($ap->country != 'India'): ?>

                                                <a href="<?php echo e(url('/internationalpackage')); ?>" class="cws-button">Read more</a>

                                            <?php else: ?>

                                                 <a href="<?php echo e(url('/domesticpackage')); ?>" class="cws-button">Read more</a>

                                             <?php endif; ?>
                                            <div class="price">Rs.<?php echo e($ap->price); ?></div>
                                        </div>
                                        <div class="recom-media recom-media1">
                                            <div class="package1-img">
                                                <img src="uploads/<?php echo e($ap->image); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_why1">
        <div class="inner-head">
            <h1 class="title">Why choose Us</h1>
            <img src="image/icon_title1.png">
            <p class="prg">We are one of the most reliable tour operators in India for a reason. When you choose Season Tours & Travels, you get well-planned holidays at affordable prices featuring experienced and friendly guides.

</p>
        </div>
        <div class="co_why row2">
            <div class="row">
                <div class="col-lg-6 col-md-5 col-4"></div>
                <div class="col-lg-6 col-md-7 col-8 inner-why">
                    <div class="why">
                        <div class="icon">
                            <img src="image/world.png">
                        </div>
                        <div class="why-dec">
                            <h4>World Class Service</h4>
                            <p>We are dedicated to keeping our trips of the highest quality. As a result, we are always convinced that, given the excellent quality of all our services, we will always do our best to make your trip a success.</p>
                        </div>
                    </div>
                    <div class="why">
                        <div class="icon">
                            <img src="image/hot-air-balloon.png">
                        </div>
                        <div class="why-dec">
                            <h4>Best Price Guarantee</h4>
                            <p>Travelling is an investment, and we make sure you get the best value for your money. We pride ourselves on offering the best quality travel for your money. You can save up to 20% on tour costs when booking directly with Season tours and travels.</p>
                        </div>
                    </div>
                    <div class="why">
                        <div class="icon">
                            <img src="image/trolley-bag.png">
                        </div>
                        <div class="why-dec">
                            <h4>Stay Safe</h4>
                            <p>We're used to coping with unexpected, and sometimes disruptive, events. So, if something unexpected happens during your tour, don't be concerned. We will handle any changes to your schedule while keeping you safe and informed.</p>
                        </div>
                    </div>
                    <div class="why">
                        <div class="icon">
                           <img src="image/clock.png">
                        </div>
                        <div class="why-dec">
                            <h4>24 Hours Services</h4>
                            <p>Our 24/7 helpline means we are just a call away. Relax and let us handle your vacation planning. We handle everything for you, from route planning to arranging reservations. Enjoy your journey knowing that everything is in good hands.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_testimonial">
        <div class="container">
            <div class="inner-head">
                <h1 class="title">Testimonials</h1>
                <img src="image/icon_title1.png">
                <p class="prg">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text </p>
            </div>
            <div class="main">
                <div class="slider slider-nav">
                    <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="client-main">
                            <div class="client">
                                <i class="fas fa-quote-left"></i>
                                <p><?php echo e($t->description); ?></p>
                            </div>
                            <div class="client-info">
                                <div class="client-img">
                                    <img src="uploads/<?php echo e($t->image); ?>">
                                </div>
                                <div class="client-name">
                                    <h3><?php echo e($t->name); ?></h3>
                                    <p><?php echo e($t->occupation); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>



   <div class="co_footer">
        <div class="container">
            <div class="footer-loop">
                <div class="row">
                    <div class="col-lg-3 col-md-12 col-12 footer-logo fm-1">
                        <div class="main-footer">
                            <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="image/logo.png"></a></h2>
                            <p>Book with confidence. We offer a unique travelling experience you can’t miss.</p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 col-12 fm-1">
                        <h2 class="title1">Company</h2>
                        <div class="footer-widget">
                            <ul>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/domesticpackage')); ?>">packages</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/gallary')); ?>">Gallery</a></li>
                                <li><i class="far fa-angle-left"></i><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12 fm-1">
                        <h2 class="title1">Contact Us</h2>
                        <ul class="con-home">
                            <li><i class="fa fa-home" aria-hidden="true"></i>
                                <p><?php echo e($address); ?></p>
                            </li>
                            <li><i class="fa fa-envelope" aria-hidden="true"></i>
                                <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                            </li>
                            <li><i class="fa fa-phone" aria-hidden="true"></i>
                                <p><a href="tel:<?php echo e($mobileno); ?>"><?php echo e($mobileno); ?></a></p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-3 col-12 fm-1">
                        <h2 class="title1">Newsletter</h2>
                        <p>Get latest updates and offers.</p>
                        <form class="form">
                            <input type="text" placeholder="Enter your email here" name="email" value="">
                           
                            <div class="button sub">
                                <input type="Submit" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div> 
  <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Season Tour and Investment © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </div> 
<a class="up-btn show1" href="#"></a>
    
     <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!--  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/popper.min.js"></script> -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

          $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });


        $(window).scroll(function(){
            if ($(this).scrollTop() > 50) {
                $('#dynamic').addClass('newClass');
            } else {
                $('#dynamic').removeClass('newClass');
            }
        });

        $('.slider-nav').slick({
            autoplay: false,
            autoSpeed: 1500,
            arrows: true,
            slidesToShow: 2,
            slidesToScroll: 1,
            dots: false,
            focusOnSelect: true,
            prevArrow: '<div class="slide-arrow prev-arrow"><i class="far fa-angle-left"></i></div>',
            nextArrow: '<div class="slide-arrow next-arrow"><i class="far fa-angle-right"></i></div>',
            responsive: [{
                breakpoint: 1024,
                settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        // centerMode: true,
                    }
                }, {
                    breakpoint: 800,
                    settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                  }
                },  {
                    breakpoint: 480,
                    settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }]
        });

        $(document).ready(function(){
            $('.your-class').slick({
                infinite: true,
                arrows: true,
                dots: false,
                slidesToShow: 2,
                slidesToScroll: 1,
                prevArrow: '<div class="slide-arrow prev-arrow prev-arrow1"><i class="far fa-angle-left"></i></div>',
                nextArrow: '<div class="slide-arrow next-arrow next-arrow1"><i class="far fa-angle-right"></i></div>',
                responsive: [{
                breakpoint: 1024,
                settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        // centerMode: true,
                    }
                }, {
                    breakpoint: 800,
                    settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                  }
                },  {
                    breakpoint: 480,
                    settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }]
            });
        });

        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            $('.your-class').slick('setPosition');
        });


    function search_value(){
          var service = $('#service').val();
      var price = $('#price').val();
      var type = $('#type').val();

      if(service == "")
         {
            // alert('Search is empty');
         }else{
         
         }
              var search_keywords = $('#search_keywords').val();
         
         if(search_keywords == "")
         {
           //  alert('Search is empty');
         }else{
                 $('#databaseActionForm').submit();
         }

     }

      var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
        $('html, body').animate({scrollTop:0}, '300');
    }); 







    /*      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $("#search").click(function(e){

      var service = $('#service').val();
      var price = $('#price').val();
      var type = $('#type').val();

     
    
  if(service !="" || price !="" || type !=""){

  
      e.preventDefault();

        $.ajax({
           url:'/travel_search',
           method:'GET',
           data:{
                 service,
                 price,
                 type,
               
                },


   success: function(dataResult){
                  console.log(dataResult);
                  var dataResult =JSON.parse(dataResult);
                  if(dataResult.statusCode==200){

                      alert("success !"); */
                      
                /*  $("#message").append("<b>your message submit sucessfully!!!</b>");
                   $('#message').delay(3000).fadeOut(3000);*/

             /*     }else {
                     alert("Error occured !");
                      }*/
 

                      /* $( '.form1' ).each(function(){
                          this.reset();
                        });    */
       /*           
                }
          


              });

   
      }else{

      

      }
    });
*/
    </script>

</body>
</html> <?php /**PATH D:\xampp\htdocs\seasontravels\resources\views/welcome.blade.php ENDPATH**/ ?>