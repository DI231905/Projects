

<?php $__env->startSection('content'); ?>

  <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/service-bg.jpg">
    	    </div>
    	    <div class="about1">
    	    	<div class="container">
    		        <h2>Services</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">Services</li>
    		        </ul>
    		    </div>
    	    </div>
    	</div>
    </div>
    <div class="co_service">
		<div class="container">
			<div class="row">
				<?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="service service1">
						<div class="service-img">
							<img src="uploads/<?php echo e($s->image); ?>">
						</div>
						<div class="info-title">
                            <h4><?php echo e($s->name); ?> <i class="<?php echo e($s->icon_url); ?>"></i></h4>
                        </div>
                        <div class="overlay">
                            <div class="box">
                                <div class="content1">
                                    <div class="overlay-content">
                                        <h4><?php echo e($s->name); ?></h4>   
                                        <p><?php echo e($s->description); ?></p>   
                                    </div>
                                </div>
                            </div>
                        </div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>
		</div>
	</div>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\seasontravels\resources\views/services.blade.php ENDPATH**/ ?>