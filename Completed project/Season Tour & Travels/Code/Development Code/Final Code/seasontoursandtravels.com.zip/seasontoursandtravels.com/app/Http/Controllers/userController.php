<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use DB;
use App\Models\contact_us;
use App\Models\enquiries;


class userController extends Controller
{
     
  public function index(){

       $admindetail=DB::table('admindetail')->take(1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

         $services=DB::table('service')->take(3)->get();
         $data['services']=$services;

          $tour_type=DB::table('tour_type')->get();
         $data['tour_type']=$tour_type;


         $f_package=DB::table('package')->where('tour_type',"Family Tours")->get();
         $data['f_package']=$f_package;

         $h_package=DB::table('package')->where('tour_type',"Honeymoon Tours")->get();
         $data['h_package']=$h_package;

          $s_package=DB::table('package')->where('tour_type',"Summer Tours")->get();
          $data['s_package']=$s_package;

          $w_package=DB::table('package')->where('tour_type',"Winter Tours")->get();
          $data['w_package']=$w_package;

          $a_package=DB::table('package')->where('tour_type',"Adventure Tours")->get();
          $data['a_package']=$a_package;

          $testimonial=DB::table('testimonial')->get();
          $data['testimonial']=$testimonial;

          return view('welcome',$data);
        }

         public function about(){

        $faq=DB::table('faq')->get();
         $data['faq']=$faq;

        $admindetail=DB::table('admindetail')->take(1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

        return view('about',$data);
    }
    




   
    public function Service(){

        $service=DB::table('service')->get();
         $data['service']=$service;

        $admindetail=DB::table('admindetail')->take(1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

        return view('services',$data);
    }
    
   
    
     public function contact(){

        $admindetail=DB::table('admindetail')->take(1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

        return view('contact',$data);
    }

     public function domestic(){

      $admindetail=DB::table('admindetail')->take(1)->get();
        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
  
       $package=DB::table('package')->where('package_type',"Domestic Packages")->orderBy('id', 'desc')->get();
        $data['package']=$package;

       
        return view('domestic',$data);
    }
   
    public function international(){

       $admindetail=DB::table('admindetail')->take(1)->get();
        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

       $package=DB::table('package')->where('package_type',"International packages")->orderBy('id', 'desc')->get();
        $data['package']=$package;

        return view('international',$data);
    }
      public function gallary(){

       $admindetail=DB::table('admindetail')->where('id',1)->get();
        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;


         $gallary=DB::table('gallary')->get();
         $data['gallary']=$gallary;

        
        return view('gallary',$data);
    }
    public function search(){

      $admindetail=DB::table('admindetail')->where('id',1)->get();
        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

        /* $portfolio=DB::table('portfolio')->get();
         $data['portfolio']=$portfolio;*/

        return view('search',$data);
    }
      public function packagedetail($id){

      $admindetail=DB::table('admindetail')->take(1)->get();
        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

       $package=DB::table('package')->where('id',$id)->get();
      
        $data['id']=$package[0]->id;
        $data['image']=$package[0]->image;
        $data['tittle']=$package[0]->tittle;
        $data['days']=$package[0]->days;
        $data['night']=(int)$package[0]->days-1;
        $data['country']=$package[0]->country;
        $data['city']=$package[0]->city;
        $data['price']=$package[0]->price;
        $data['long_desc']=$package[0]->long_desc;
        $data['inclusion']=$package[0]->inclusion;
        $data['exclusion']=$package[0]->exclusion;
        $data['general_info']=$package[0]->general_info;

        $day_info=DB::table('days_info')->where('p_id',$id)->get();
        $data['day_info']=$day_info;

        return view('packagedetail',$data);
    }
   
 
     public function contactusfrom(Request $request){

        $request->validate([

            'name' => 'required',
            'email' => 'required|email', 
            'subject' => 'required',  
            'description' => 'required',  


        ]);


        contact_us::create($request->all());
        return json_encode(array(
            "statusCode"=>200
         ));

         
    }

    public function enquiriesfrom(Request $request){

         $request->validate([

            'name' => 'required',
            'mobileno' => 'required', 
            'email' => 'required|email', 
            'description' => 'required',  

         ]);

           enquiries::create($request->all());
         return json_encode(array(
            "statusCode"=>200
         ));

    }
    public function travel_search(Request $request){


       $admindetail=DB::table('admindetail')->take(1)->get();
        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
    

       $service=$request->service;
      $price=$request->price;
       $type=$request->type;

        


   if($service!="" && $price!="" && $type!="" ){

    $packagedetail = DB::table('package')
            ->where('tour_type', "like", "%" .$request->type . "%")
            ->where('price', '<', $request->price)
            ->where('tittle', "like", "%" .$request->service . "%")
            ->orWhere(function($query) use ($request) {
                $query->orWhere('country', "like", "%" .$request->service . "%")
                      ->orWhere('city', "like", "%" .$request->service . "%")
                      ->Where('tour_type', "like", "%" .$request->type . "%")
                      ->where('price', '<=', $request->price);
             })->get();


                $data['searchpackage']=$packagedetail;

                  return view('search',$data);
              
      
    }else{

    
        
          if ( $service !="" && $price !="" ){

          
            $packagedetail=DB::table('package')->orWhere('tittle', 'like', '%'.$service.'%')->orWhere('country', 'like', '%'.$service.'%')->orWhere('city', 'like', '%'.$service.'%')->Where('price', '<=', $request->price)->get();
         
                 $data['searchpackage']=$packagedetail;

                  return view('search',$data);
           
          }else if($service !="" && $type !="" ){

           
            $packagedetail=DB::table('package')->orWhere(function($query) use ($request) {
                $query->orWhere('country', "like", "%" .$request->service . "%")
                      ->orWhere('city', "like", "%" .$request->service . "%")
                      ->orwhere('tittle', "like", "%" .$request->service . "%")
                       ->Where('tour_type', "like", "%" .$request->type . "%");
                    
             })->get();
         
                 $data['searchpackage']=$packagedetail;

                  return view('search',$data);

              
          }else if($price !="" && $type !="" ){

            
            $packagedetail=DB::table('package')->orWhere(function($query) use ($request) {
                $query->Where('price', '<=', $request->price) 
                      ->Where('tour_type', "like", "%" .$request->type . "%");
                    
             })->get();
         
               $data['searchpackage']=$packagedetail;

                  return view('search',$data);
              
          }else if($service!=""){

           
            $packagedetail=DB::table('package')->orWhere(function($query) use ($request) {
                $query->orWhere('country', "like", "%" .$request->service . "%")
                      ->orWhere('city', "like", "%" .$request->service . "%")
                      ->orwhere('tittle', "like", "%" .$request->service . "%");
                    
             })->get();
         
                 $data['searchpackage']=$packagedetail;

                  return view('search',$data);

              
          }else if($price!=""){

          
            $packagedetail=DB::table('package')->orWhere(function($query) use ($request) {
                  $query->Where('price', '<=', $request->price);
                    
             })->get();
         
                 $data['searchpackage']=$packagedetail;

                  return view('search',$data);

              
          }else if($type!=""){

          
            $packagedetail=DB::table('package')->orWhere(function($query) use ($request) {
                  $query->Where('tour_type', "like", "%" .$request->type . "%");
                    
             })->get();
         
               $data['searchpackage']=$packagedetail;

                  return view('search',$data);

              
          }else{

              return Redirect::back()->withErrors([' please enter search value!!!!!  ']);         
          }  

     }
  }


}
