<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
//use App\Models\User;
use Carbon\carbon;
use DB;
use Hash;
use \Crypt;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\validator;

class Admincontroller extends Controller{


   public function __construct(){

                $this->middleware('auth:admin');
        }

   public function home(){
 
         $admin=Auth::guard('admin')->user();
         $data['admin']=$admin;
         $data['site_url']= env('APP_URl');
         $data['metatitle']='home page';


         $admindetail=DB::table('admindetail')->get();
         $data['admindetail']=$admindetail;

         $testimonial=DB::table('testimonial')->get();
         $data['testimonial']=$testimonial;

         $service=DB::table('service')->get();
         $data['service']=$service;

          $gallary=DB::table('gallary')->get();
         $data['gallary']=$gallary;

           $package=DB::table('package')->get();
           $data['package']=$package;

           $contact_us=DB::table('contact_us')->get();
           $data['contact_us']=$contact_us;
           
           $enquiries=DB::table('enquiries')->get();
           $data['enquiries']=$enquiries;

           $faq=DB::table('faq')->get();
           $data['faq']=$faq;


         return view('admin.home',$data);
      
     } 

     /*----------- change password ---------------*/

      public function changepassword(){
       
         return view('admin.changepassword');
     }

      public function updatepassword(Request $request,$id){

          $request->validate([
              'oldpassword' => 'required|string',
              'newpassword' => 'required|string|min:8',
           
              ]);

             $oldpassword=$request->input('oldpassword');
             $newpassword=$request->input('newpassword');

             $password=DB::table('admins')->where('id', $id)->get();

             $password1=$password[0]->password;

           if(Hash::check($oldpassword,$password1)){

               DB::table('admins')->where('id', $id)->update(['password'=>Hash::make($newpassword)]);

               return redirect('admin/home')->with('error','your password has been update sucessfully' );

               }else{

                return Redirect::back()->with('error','Your Old password is not correct!!!!');

            }
         }

    /*----------- admin data ---------------*/

      public function updateadmindetail($id){

       $admindetail=DB::table('admindetail')->where('id', $id)->get();

        $data['id']=$admindetail[0]->id;
         $data['email']=$admindetail[0]->email;
        $data['name']=$admindetail[0]->name;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      
         return view('admin.updateadmindetailview',$data);

        }

       public function storeadmindetail(Request $request,$id){


         $request->validate([

            'name' => 'required|string',
            'email' => 'required|email',
            'mobileno' => 'required',
            'address' => 'required',  

             ]);
       
             $name=$request->input('name');
             $email = $request->input('email');
             $mobileNo=$request->input('mobileno');
             $address=$request->input('address');
     
            DB::table('admindetail')->where('id',$id)->update(['name'=>$name ,'email'=>$email,'mobileno'=>$mobileNo,'address'=>$address]);

           return redirect('admin/home')->with('error',' update admin detail sucessfully!!!!');
    
          }


    /*----------- Contactus data ---------------*/

      public function deletecontactus($id){
  
       DB::table('contact_us')->where('id', $id)->delete();

       return redirect('admin/home');

       }


         public function deleteenquiry($id){
  
       DB::table('enquiries')->where('id', $id)->delete();

       return redirect('admin/home')->with('error','delete Enquiry succcesfully!!!!');;

       }
  
  

    /*----------- testimonial data ---------------*/

      public function addtestimonial(){
  
       return view('admin.addtestimonial');
          }
  
      public function storetestimonial(Request $request){
         
          $request->validate([

            'name' => 'required|string',
            'image' => 'required',
            'occupation' => 'required',
            'description' => 'required',
         ]);
       


           $name=$request->input('name');
           $occupation = $request->input('occupation');
           $description=$request->input('description');
           $file=$request->file('image');
           
         if ($file){
          
           $destinationPath='uploads';
           $imagename=time().'_'.$file->getClientOriginalName();
           $file->move($destinationPath,$imagename);
      
           }
         
         DB::table('testimonial')->insert(['name'=>$name ,'occupation'=>$occupation,'image'=>$imagename,'description'=>$description]);
    
           return redirect('admin/home')->with('error',' testimonial insterted succcesfully!!!!');
            }
  
      public function deletetestimonial($id){

          $testimonial=DB::table('testimonial')->where('id', $id)->get();
          echo $testimonial[0]->image;


          if ($testimonial[0]->image!=''){

            unlink("/home/mzldwoswysm5/public_html/seasontoursandtravels.com/uploads/".$testimonial[0]->image);
          }

           DB::table('testimonial')->where('id', $id)->delete();

         return redirect('admin/home')->with('error',' testimonial delete succcesfully!!!!');

       }
  
      public function updatetestimonial($id){

        $testimonial= DB::table('testimonial')->where('id', $id)->get();

        $data['id']=$testimonial[0]->id;
        $data['name']=$testimonial[0]->name;
        $data['image']=$testimonial[0]->image;
        $data['occupation']=$testimonial[0]->occupation;
        $data['description']=$testimonial[0]->description;
    
        return view('admin.updatetestimonial',$data);
        }
  
      public function storeupdatetestimonial(Request $request ,$id){

         $request->validate([

            'name' => 'required|string',
            'occupation' => 'required',
            'description' => 'required',
           
           ]);
       
           $name=$request->input('name');
           $occupation = $request->input('occupation');
           $description=$request->input('description');
           $file=$request->file('image');
        
           $imagename=' ';

            if ($file){
         
           $destinationPath='uploads';
           $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('testimonial')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink("/home/mzldwoswysm5/public_html/seasontoursandtravels.com/uploads/".$request->input('oldimage'));

             }

           }

          DB::table('testimonial')->where('id', $id)->update(['name'=>$name ,'occupation'=>$occupation,'description'=>$description]);

           return redirect('admin/home')->with('error',' update Team member data succcesfully!!!!');
 
          }


          public function addgallary(){
         
              return view('admin.gallary');
          }
          public function storegallary(Request $request){
   
               $request->validate([

                  'file' => 'required',
              
                  'file.*' =>'mimes:mp4,jpeg,jpg,png','max:40000'
  
                  ]);

                 $file=$request->file('file');
           $filename=' ';
       
         foreach($file as $key =>$f) {

             $destinationPath='uploads';
             $filename=time().'_'.$f->getClientOriginalName();


             $extenstion ='.'.$f->getClientOriginalExtension();
        


              echo $filename; echo '<br>';
              echo $extenstion;

    
             $f->move($destinationPath,$filename);

             DB::table('gallary')->insert(['file'=>$filename,'extension'=>$extenstion]);
             
             
             }
 
              return redirect('admin/home')->with('error','your file insert sucessfully!!');
          } 

    /*------------gallary data----------------*/

      public function deleteimage($id){

          $gallary=DB::table('gallary')->where('id', $id)->get();

          echo $gallary[0]->file;

          if ($gallary[0]->file!=''){

            echo "12345";

             unlink("/home/mzldwoswysm5/public_html/seasontoursandtravels.com/uploads/".$gallary[0]->file);
            }

           DB::table('gallary')->where('id', $id)->delete();

           return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);


          }

          public function deletecontact($id){

             DB::table('contact_us')->where('id', $id)->delete();

            return redirect('admin/home')->with('error','contact_us message delete successfully!!');


          }

            /*--------------- FAQ data--------------------*/


    public function addfaqview(){
  
        return view('admin.addfaq');

       }

    public function storefaq(Request $request){


           $request->validate([

            'question' => 'required',
            'answer'=>'required',
            
        ]);
       
        $question=$request->input('question');
        $answer=$request->input('answer');
       
    
    
         DB::table('faq')->insert(['question'=>$question,'answer'=>$answer]);
       
       return redirect('admin/home')->with('error','FREQUENTLY ASK QUESTIONS Added sucessfully!!' );
          
     }

    public function deletefaq($id){

      
        DB::table('faq')->where('id', $id)->delete();

        return redirect('admin/home')->with('error','FREQUENTLY ASK QUESTIONS deleted sucessfully!!' );


        }

      public function updatefaq($id){ 

        $faq= DB::table('faq')->where('id', $id)->get();
       
        //$work=DB::table('work')->where('id',$id)->get();
        $data['id']=$faq[0]->id;
        $data['question']=$faq[0]->question;
        $data['answer']=$faq[0]->answer;
       
       
        return view('admin.updatefaq',$data);

       
       }

    public function storeupdatefaq(Request $request,$id){


         $request->validate([

            'question' => 'required',
            'answer'=>'required',
           
        ]);
       
        $question=$request->input('question');
        $answer=$request->input('answer');
     
       

          DB::table('faq')->where('id', $id)->update(['question'=>$question,'answer'=>$answer]);

           return redirect('admin/home')->with('error','FREQUENTLY ASK QUESTIONS updated sucessfully!!');

    }



 
 }



     
 


   

  




