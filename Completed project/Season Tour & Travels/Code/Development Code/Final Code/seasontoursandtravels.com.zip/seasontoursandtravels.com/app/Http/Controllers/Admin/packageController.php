<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
//use App\Models\User;
use Carbon\carbon;
use DB;
use Hash;
use \Crypt;
use Illuminate\support\facades\Auth;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class packageController extends Controller{


   public function __construct(){

                $this->middleware('auth:admin');
        }



     public function adddestination(){

            return view('admin.addcountryview');
             }

     public function storedestination(Request $request){
    
          $request->validate([
            'country' => 'required|string',
            'city' => 'required|string',
           
            ]);

             $countryname=$request->input('country');
             $cityname=$request->input('city');
    
              $countryname;
              $cityname;


             $country=DB::table('countries')->where('name',$countryname)->count();
             $country;

          if($country){

               $countrydata=DB::table('countries')->where('name',$countryname)->get();

                 $country_id=$countrydata[0]->id;

                   $citydata=DB::table('cities')->where('name',$cityname)->count();

                        if($citydata){

                          return redirect()->route('adddestination')->with('error','This country and city are already inserted.');

        
                         }else{

                           DB::table('cities')->insert(['name'=>$cityname,'c_id'=>$country_id]);

                            return redirect()->route('adddestination')->with('error','This city are inserted in list.');

                     }

            }else{
         
               DB::table('countries')->insert(['name'=>$countryname]);

                $countrydata=DB::table('countries')->where('name',$countryname)->get();

                 $country_id=$countrydata[0]->id;


               $citydata=DB::table('cities')->where('name',$cityname)->count();

                        if($citydata){

                          return redirect()->route('adddestination')->with('error','This city is already inserted.');

        
                         }else{

                           DB::table('cities')->insert(['name'=>$cityname,'c_id'=>$country_id]);

                            return redirect()->route('adddestination')->with('error','This country and city are inserted in list.');

                         }



               /* DB::table('cities')->insert(['name'=>$cityname,'c_id'=>$country_id]);

                return redirect()->route('adddestination')->with('error','This country and city are inserted in list.');*/


              }
       
           }

     public function getcity($id){

          return json_encode( DB::table('cities')->where('c_id',$id)->get()->toArray());
        }

     public function getcity1($id){

          return json_encode( DB::table('cities')->where('c_id',$id)->get()->toArray());
           }
       
     public function addpackage(){


           $country = DB::table('countries')->get();
           $data['country']=$country;
 
           $package_type=DB::table('package_type')->get();
           $data['package_type']=$package_type; 

           $tour_type=DB::table('tour_type')->get();
           $data['tour_type']=$tour_type;     

          return view('admin.addpackage',$data);

          }

     public function storepackage1(Request $request){

          $request->validate([
      
            'image' => 'required',
            'packages' =>'required',
            'tittle' => 'required|string',
            'tour_type' => 'required',
            'country' => 'required',
            'city' => 'required',
            'numberofday' => 'required',
            'price' => 'required',
            'short_desc' => 'required',
            'day' => 'required',
            'inclusion' => 'required',
            'exclusion' => 'required',
            'long_desc' => 'required',
            'general_info' => 'required'           
         ]);
 
           $packages=$request->input('packages');
           $tittle=$request->input('tittle');
           $tour_type=$request->input('tour_type');
           $country=$request->input('country');
           $city=$request->input('city');
           $numberofday=$request->input('numberofday');
           $price=$request->input('price');
           $short_desc=$request->input('short_desc'); 
           $inclusion=$request->input('inclusion');
           $exclusion=$request->input('exclusion');
           $long_desc=$request->input('long_desc');
           $general_info=$request->input('general_info');
           $image=$request->file('image');

           $packages=DB::table('package_type')->where('id',$packages)->get();
           $package1=$packages[0]->type_name;
  
           $tour_type=DB::table('tour_type')->where('id',$tour_type)->get();
           $tour_type1=$tour_type[0]->tour_type;
  
           $country=DB::table('countries')->where('id',$country)->get();
           $country1=$country[0]->name;
  
           $city=DB::table('cities')->where('id',$city)->get();
           $city1=$city[0]->name;



          $imagename=' ';

           if ($image) {
          
                $destinationPath='uploads';
                $imagename=time().'_'.$image->getClientOriginalName();

                $image->move($destinationPath,$imagename);
      
           }

           DB::table('package')->insert(['package_type'=>$package1,'image'=>$imagename,'tittle'=>$tittle,'tour_type'=>$tour_type1,'country'=>$country1,'city'=> $city1,'days'=>$numberofday,'price'=>$price,'short_desc'=> $short_desc,'inclusion'=>$inclusion,'exclusion'=>$exclusion,'long_desc'=>$long_desc,'general_info'=> $general_info]);


               $last_id = DB::table('package')->max('id'); 
   
              $day=$request->input('day');
   
             DB::table('days_info')->insert(['days_info'=>$day,'p_id'=>$last_id]);


             echo $day;
      
              $days=$request->input('days');

               if($days!=null){
            

              for($i=0; $i<count($days); $i++){

                $day_info=$days[$i];

                   DB::table('days_info')->insert(['days_info'=>$day_info,'p_id'=>$last_id]);
 
                 
                }
            }

           return redirect('admin/home')->with('error',' insert package succcesfully!!!!');

         }

     public function updatepackage($id){

         $country = DB::table('countries')->get();
         $data['country']=$country;

         $package_type=DB::table('package_type')->get();
         $data['package_type']=$package_type; 

          $tour_type=DB::table('tour_type')->get();
         $data['tour_type']=$tour_type;   

         $days_info=DB::table('days_info')->where('p_id', $id)->get();
         $data['days_info']=$days_info; 

          $package= DB::table('package')->where('id', $id)->get();
      
              $data['id']=$package[0]->id;
       
              $data['image']=$package[0]->image;
              $data['tittle']=$package[0]->tittle;
              $data['numberofday']=$package[0]->days;
              $data['price']=$package[0]->price;
              $data['short_desc']=$package[0]->short_desc;
              $data['inclusion']=$package[0]->inclusion;
              $data['exclusion']=$package[0]->exclusion;
              $data['general_info']=$package[0]->general_info;
              $data['long_desc']=$package[0]->long_desc;
              $data['city']=$package[0]->city;
            //  $data['tour_type']=$package[0]->tour_type;
   
            $packagename=$package[0]->package_type;
            $tour_type=$package[0]->tour_type;
            $country=$package[0]->country;
             $city=$package[0]->city;
       
              $ptype=DB::table('package_type')->where('type_name',$packagename)->get();
              $data['ptype_id']=$ptype[0]->id;
   
               $tour_type=DB::table('tour_type')->where('tour_type',$tour_type)->get();
               $data['t_id']=$tour_type[0]->id;
   
                $country=DB::table('countries')->where('name',$country)->get();
              $data['country_id']=$country[0]->id;

            $city=DB::table('cities')->where('name',$city)->get();
            $data['city_id']=$city[0]->id;
         
          return view('admin.updatepackage',$data);
          }

     public function deletedayinfo($id){

      $day=DB::table('days_info')->where('id',$id)->get();

      $p_id=$day[0]->p_id;

      DB::table('days_info')->where('id',$id)->delete();

        return redirect('admin/updatepackage/'.$p_id);

      }    

     public function storeupdatepackage(Request $request, $id){


         $request->validate([
      
          
            'packages' =>'required',
            'tittle' => 'required|string',
            'tour_type' => 'required',
            'country' => 'required',
            'city' => 'required',
            'numberofday' => 'required',
            'price' => 'required',
            'short_desc' => 'required',
            'inclusion' => 'required',
            'exclusion' => 'required',
            'long_desc' => 'required',
            'general_info' => 'required'           
         ]);


           $packages=$request->input('packages');
           $tittle=$request->input('tittle');
           $tour_type=$request->input('tour_type');
           $country=$request->input('country');
           $city=$request->input('city');
           $numberofday=$request->input('numberofday');
           $price=$request->input('price');  
           $short_desc=$request->input('short_desc'); 
           $inclusion=$request->input('inclusion');
           $exclusion=$request->input('exclusion');
           $long_desc=$request->input('long_desc');
           $general_info=$request->input('general_info');
          

           $packages=DB::table('package_type')->where('id',$packages)->get();
           $package1=$packages[0]->type_name;
  
           $tour_type=DB::table('tour_type')->where('id',$tour_type)->get();
           $tour_type1=$tour_type[0]->tour_type;
  
           $country=DB::table('countries')->where('id',$country)->get();
           $country1=$country[0]->name;
  
           $city=DB::table('cities')->where('id',$city)->get();
           $city1=$city[0]->name;

         DB::table('package')->where('id', $id)->update(['package_type'=>$package1,'tittle'=>$tittle,'tour_type'=>$tour_type1,'country'=>$country1,'city'=> $city1,'days'=>$numberofday,'price'=>$price,'short_desc'=> $short_desc,'inclusion'=>$inclusion,'exclusion'=>$exclusion,'long_desc'=>$long_desc,'general_info'=> $general_info]);
         

          $file=$request->file('image');
           $imagename=' ';

          if($file){
         
            $destinationPath='uploads';
            $imagename=time().'_'.$file->getClientOriginalName();
    
            $file->move($destinationPath,$imagename);

            DB::table('package')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink("/home/mzldwoswysm5/public_html/seasontoursandtravels.com/uploads/".$request->input('oldimage'));

          }

           }
        
         $day=$request->input('day');
          if($day !=null){

              DB::table('days_info')->insert(['days_info'=>$day,'p_id'=>$id]);


          }
           $days=$request->input('days');

            if($days!=null){
            

            for($i=0; $i<count($days); $i++){

              $day_info=$days[$i];

             DB::table('days_info')->insert(['days_info'=>$day_info,'p_id'=>$id]);

            }
            }
   
            return redirect('admin/home')->with('error',' update package detail sucessfully!!!!');
         
    
          }

     public function deletepackage($id){


      $package= DB::table('package')->where('id', $id)->get();

          if ($package[0]->image!='') {

          
           unlink("/home/mzldwoswysm5/public_html/seasontoursandtravels.com/uploads/".$package[0]->image);

            }

            DB::table('days_info')->where('p_id',$id)->delete();

           DB::table('package')->where('id', $id)->delete();


         return redirect('admin/home')->with('error',' delete package  data succcesfully!!!!');

          }



        }



     
 


   

  




