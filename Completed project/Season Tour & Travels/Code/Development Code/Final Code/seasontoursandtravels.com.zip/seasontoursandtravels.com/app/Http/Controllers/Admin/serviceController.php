<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class serviceController extends Controller
{
      public function __construct(){

                $this->middleware('auth:admin');
        }


          public function addserviceview(){
  
        return view('admin.addservices');

       }

        public function storeservice(Request $request){


        $request->validate([

             'name' => 'required',
             'image'=>'required',
             'icon_url'=>'required',
             'description' => 'required', 

        ]);
       
        $name=$request->input('name');
        $icon_url=$request->input('icon_url');
        $description=$request->input('description');
        $file=$request->file('image');
        $imagename=' ';

        if ($file){
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();

         $file->move($destinationPath,$imagename);
      
        }


         DB::table('service')->insert(['name'=>$name,'image'=>$imagename, 'icon_url'=>$icon_url,'description'=>$description]);
       
          return redirect('admin/home')->with('error','your service has been inserted sucessfully' );
          
    }


     public function deleteservice($id){


          $services= DB::table('service')->where('id', $id)->get();

         if ($services[0]->image!='') {

            unlink("/home/mzldwoswysm5/public_html/seasontoursandtravels.com/uploads/".$services[0]->image);

            }

      
        DB::table('service')->where('id', $id)->delete();

        return redirect('admin/home')->with('error','your service has been deleted sucessfully' );


    }

      public function updateservice($id){

    

      $service= DB::table('service')->where('id', $id)->get();
       
        //$work=DB::table('work')->where('id',$id)->get();
        $data['id']=$service[0]->id;
        $data['name']=$service[0]->name;
        $data['image']=$service[0]->image;
        $data['icon_url']=$service[0]->icon_url;
        $data['description']=$service[0]->description;
       
        return view('admin.updateservice',$data);

       
       }

  public function storeupdateservice(Request $request,$id){


        $request->validate([

            'name' => 'required',
            'icon_url' => 'required',
            'description' =>'required',
           
        ]);
       
       echo $name=$request->input('name');
       echo $description =$request->input('description');
            $icon_url=$request->input('icon_url');
            $file=$request->file('image');

    
        $imagename=' ';

        if($file){
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('service')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink("/home/mzldwoswysm5/public_html/seasontoursandtravels.com/uploads/".$request->input('oldimage'));

             }

           }

          DB::table('service')->where('id', $id)->update(['name'=>$name ,'icon_url'=>$icon_url,'description'=>$description]);

           return redirect('admin/home')->with('error','your service has been updated sucessfully' );

    }





}
