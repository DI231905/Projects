<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class package_days_infoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
