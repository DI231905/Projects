<!-- Msg Field -->
<div class="form-group col-sm-12 col-lg-12">
    {!! Form::label('msg', 'Msg:') !!}
    {!! Form::textarea('msg', null, ['class' => 'form-control']) !!}
</div>