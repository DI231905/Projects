<!-- <button data-toggle="modal" data-target="#myModal">enquiry</button> -->

<div id="pageMessages"></div>
<div class="table-responsive">
    
    <table class="table" id="messages-table">
        <thead>
            <tr>
                <th>Msg</th>
                <th>send message</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($messages as $message)
            <tr>
                <td>{{ $message->msg }}</td>

                <td><button  id="{{$message->id}}" class="alert-info send_message" style="background-color:#007bff!important">send</button></td>


                <td width="120">
                    {!! Form::open(['route' => ['messages.destroy', $message->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{{ route('messages.show', [$message->id]) }}" class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="{{ route('messages.edit', [$message->id]) }}" class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        {!! Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>


<div class="modal modal-address" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content" id="append_table">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">User List</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <input type="hidden" name="message" class="message"id="message_id" >
                </div>
                <!-- Modal body -->
                <div class="modal-body table-responsive scroll-inner">
                    <table class="table table-bordered csv_table">
                        <thead>
                            <tr>
                                <th><input type="checkbox" name="" id="chkcheckAll"/></th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile NO.</th>
                                <th>Gender</th>
                            </tr>
                        </thead>
                        <tbody id="myTable">
                           
                        </tbody>
                    </table>

                </div>
                 <button class="table-button1" id="SendselectedRecord">Send Message</button>
            </div>
        </div>
    </div>

<style type="text/css">
/*----------- view-csv-modal -----------*/
.table-responsive {
    display: block;
    width: 100%;
    overflow-y: auto;
    height: 492px;
}
.modal-address.modal {
   /* z-index: 9999999!IMPORTANT;*/
    background: rgb(0 0 0 / 50%);
}
.modal-address .modal-dialog {
    top: 17%;
    width: 1200px!important;
    max-width: 1200px!important;
}
.modal-address .b-detail {
    padding: 10px;
    border: unset;
}
.modal-address .modal-title {
    font-size: 22px;
    font-weight: 700;
    margin: 0;
    line-height: unset;
    text-transform: uppercase;
    color: black;
}
.modal-address .btn-z {
    display: block;
    width: 100%;
    margin-top: 10px;
}
.csv_table.table thead th {
    vertical-align: middle !important;
    padding: 10px 28px !important;
    font-size: 17px !important;
    text-transform: capitalize !important;
}
.csv_table td {
    font-size: 15px !important;
}
.scroll-inner::-webkit-scrollbar {
     width: 5px;
}
.scroll-inner::-webkit-scrollbar:horizontal {
     height: 8px;
}
.scroll-inner::-webkit-scrollbar-track {
     background-color: transparent;
}
.scroll-inner::-webkit-scrollbar-thumb {
     border-radius: 10px;
     background: linear-gradient(231deg, rgb(0 98 204 / 40%), #0062cc);
}
.table .send_message{
    background-color: #007bff!important;
    padding: 4px 15px;
    border-radius: 2px;
    text-transform: capitalize;
    font-size: 15px;
    font-weight: 500;
}
button.close:focus {
    outline: none;
}
.table-button1{
    display: inline-block;
    background: #0062cc;
    color: white;
    width: 125px;
    border: unset;
    height: 42px;
    font-size: 15px;
    text-transform: uppercase;
    font-weight: 700;
    margin: 20px 20px 20px auto;
    border-radius: 5px;
}
button:focus{
    outline: none;
}
button{
    border: unset;
}



  
#pageMessages {
   display: inline-block;
    position: absolute;
    top: -120px;
    right: 25px;
    width: 23%;
    z-index: 9999999999999999999!important;
   
}

.alert-dismissible{

border-left: 10px solid green;

}
.suceess_mes{
    color: #449556;
    text-align: center;
    width: 72%;
    font-size: 18px;
    top: 46px;
    font-weight: 400;
    background-color: white !important;
    border: none!important;
}

.error_mes {
    color: #dc3545;
    font-weight: 600;
    font-size: 18px;
    background: none;
    border: none;
    top: 45px;
    margin-left: 79px;
  
}

@media only screen and (min-width: 1024) and (max-width: 1260)  { 
#pageMessages {


      top: 45px;
      right: 21px;
      width: 41%;

  }
}

@media only screen and (min-width: 768px) and (max-width: 1023px){

#pageMessages {
    top: 20px;
    right: 16px;
    width: 50%;
   }

}

@media only screen and (max-width: 767px){

#pageMessages {

    top: 23px;
    right: 3px;
    width: 100%
  }
}


@media only screen and (max-width: 320px){

#pageMessages {
    top: 23px;
    right: -55px;
    width: 112%;
 }
}

</style>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script type="text/javascript">

   // $(document).ready(function() {


     //  $('.send_message').click(function(event) {

     //   alert(event.target.id);





          /* var new_id =event.target.id; 




        $("#message_id").attr("id", new_id);

         $('#myModal').modal('show');

*/


//    });




//});







$('.send_message').click(function(){

      var id = $(this).attr('id');


     $("#message_id").attr("id", id);


        $.ajax({

                url:'open_user_model/'+ id,
                type:'GET',
              /*  dataType: "json",*/

        success:function(response){



                  console.log(response);

            $('#myModal').modal('show');
            $('#myTable').html("");
            $('#myTable').html(response);
   
                     
           },

      error: function(response){

         
                  alert('somethig went wrong!!!')
         
                  },        
          
                });

   });

     
         $(function(e) {

               $('#chkcheckAll').click(function(){


                     $(".checkBoxClass").prop('checked', $(this).prop('checked'));

               });

               $('#SendselectedRecord').click(function(e){

                      e.preventDefault();

                      var message_id = $('.message').attr("id");

                      var allids=[];



                      $("input:checkbox[name=ids]:checked").each(function(){


                        allids.push($(this).val());


                      });

                      $.ajax({

                        url:'/send_message',
                        type:'post',
                        data:{

                          message_id,
                          ids:allids,
                          _token:$("input[name=_token]").val()

                        },

                        success:function(response){
                            if(response.status==200){

                              $.each(allids,function(key,val){
    
    
                                $('.letter_'+val).hide();
    
    
    
                              });
                              
                                 createAlert('','Success!', 'message sent successfully!!.','success',true,true,'pageMessages');
                           
                            }
                            else{
                                alert(response.message)
                            }



                        }




                      });



               });
                

             });
             
             
               function createAlert(title, summary, details, severity, dismissible, autoDismiss, appendToId) {
                  var iconMap = {
                    info: "fa fa-info-circle",
                    success: "fa fa-thumbs-up",
                    warning: "fa fa-exclamation-triangle",
                    danger: "fa ffa fa-exclamation-circle"
                  };
                
                        var iconAdded = false;
             
                         var alertClasses = ["alert", "animated", "flipInX"];
                         alertClasses.push("alert-" + severity.toLowerCase());
             
                          if (dismissible) {
                              alertClasses.push("alert-dismissible");
                              }

                            var msgIcon = $("<i />", {
                              "class": iconMap[severity] // you need to quote "class" since it's a reserved keyword
                            });

                            var msg = $("<div />", {
                              "class": alertClasses.join(" ") // you need to quote "class" since it's a reserved keyword
                            });

                           if (title) {
                             var msgTitle = $("<h4 />", {
                               html: title
                             }).appendTo(msg);
                             
                             if(!iconAdded){
                               msgTitle.prepend(msgIcon);
                               iconAdded = true;
                             }
                           }

                          if (summary) {
                            var msgSummary = $("<strong />", {
                              html: summary
                            }).appendTo(msg);
                            
                            if(!iconAdded){
                              msgSummary.prepend(msgIcon);
                              iconAdded = true;
                                  }
                            }
            
                   if (details) {
                     var msgDetails = $("<p />", {
                       html: details
                     }).appendTo(msg);
                     
                     if(!iconAdded){
                       msgDetails.prepend(msgIcon);
                       iconAdded = true;
                     }
                   }
  

                      /*  if (dismissible) {
                          var msgClose = $("<span />", {
                            "class": "close", // you need to quote "class" since it's a reserved keyword
                            "data-dismiss": "alert",
                            html: "<i class='fa fa-times-circle'></i>"
                          }).appendTo(msg);
                        }
                        */
                    $('#' + appendToId).prepend(msg);
                    
                    if(autoDismiss){
                      setTimeout(function(){
                        msg.addClass("flipOutX");
                        setTimeout(function(){
                          msg.remove();
                        },1000);
                      }, 5000);
                    }
             }

  
     $(function() {
         setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

        });


     $(function() {
         setTimeout(function() { $("#hideDiv1").fadeOut(1500); }, 3000)

        });


    


</script>