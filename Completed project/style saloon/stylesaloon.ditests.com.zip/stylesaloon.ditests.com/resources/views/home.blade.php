@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

        Dashboard will appear here !!!!
    </div>
</div>
@endsection
