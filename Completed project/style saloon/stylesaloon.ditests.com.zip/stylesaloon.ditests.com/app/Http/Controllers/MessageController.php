<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateMessageRequest;
use App\Http\Requests\UpdateMessageRequest;
use App\Repositories\MessageRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Response;
use App\Models\Customer;
use App\Models\Message;

class MessageController extends AppBaseController
{
    /** @var  MessageRepository */
    private $messageRepository;

    public function __construct(MessageRepository $messageRepo)
    {
        $this->messageRepository = $messageRepo;
    }

    /**
     * Display a listing of the Message.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $messages = $this->messageRepository->all();

        return view('messages.index')
            ->with('messages', $messages);
    }

    /**
     * Show the form for creating a new Message.
     *
     * @return Response
     */
    public function create()
    {
        return view('messages.create');
    }

    /**
     * Store a newly created Message in storage.
     *
     * @param CreateMessageRequest $request
     *
     * @return Response
     */
    public function store(CreateMessageRequest $request)
    {
        $input = $request->all();

        $message = $this->messageRepository->create($input);

        Flash::success('Message saved successfully.');

        return redirect(route('messages.index'));
    }

    /**
     * Display the specified Message.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $message = $this->messageRepository->find($id);

        if (empty($message)) {
            Flash::error('Message not found');

            return redirect(route('messages.index'));
        }

        return view('messages.show')->with('message', $message);
    }

    /**
     * Show the form for editing the specified Message.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $message = $this->messageRepository->find($id);

        if (empty($message)) {
            Flash::error('Message not found');

            return redirect(route('messages.index'));
        }

        return view('messages.edit')->with('message', $message);
    }

    /**
     * Update the specified Message in storage.
     *
     * @param int $id
     * @param UpdateMessageRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateMessageRequest $request)
    {
        $message = $this->messageRepository->find($id);

        if (empty($message)) {
            Flash::error('Message not found');

            return redirect(route('messages.index'));
        }

        $message = $this->messageRepository->update($request->all(), $id);

        Flash::success('Message updated successfully.');

        return redirect(route('messages.index'));
    }

    /**
     * Remove the specified Message from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $message = $this->messageRepository->find($id);

        if (empty($message)) {
            Flash::error('Message not found');

            return redirect(route('messages.index'));
        }

        $this->messageRepository->delete($id);

        Flash::success('Message deleted successfully.');

        return redirect(route('messages.index'));
    }

      public function open_user_model($id){

        $message_id=$id;

        $Customer=Customer::all();

        $total_row =  $Customer->count();

          $output='';


      if($total_row > 0)
      {
        foreach($Customer as $row)
      {

        $output .='<tr>
                     <td><input type="checkbox" name="ids" class="checkBoxClass" value="'.$row->id.'"/></td>
                     <td>'.$row->name.'</td>
                     <td>'.$row->email.'</td>
                     <td>'.$row->mobile.'</td>';

           if($row->gender==0){

                   $output .='<td>Female</td>            
                               </tr>';      
                }else{

                 $output .='<td>Male</td>            
                            </tr>';   

                 }
            }
      }
      else
      {
          $output .='<tr><h2> Users data is not available...<h2></tr>';
      } 

     return response($output);

    }



    public function send_message(Request $request){
        $ids=[];
        if($request->ids){
            $ids=$request->ids;
        }

        $customers=Customer::wherein('id',$ids)->get();
        $mobile=[];
        foreach($customers as $cust){
            $mobile[]=$cust->mobile;
        }
        $mobile=implode(',',$mobile);

        $message_id=$request->message_id;

        $messages=Message::where('id',$message_id)->get();

        $messages=$messages[0]->msg;
        $data=[
            'status'=>200,
            'message'=>""
            ];
        if($mobile && $messages){
            // $messagestatus=$this->sendsms('8128348036',$messages);
            $messagestatus=$this->sendsms($mobile,$messages);
            if($messagestatus){
                $data['message']="Successfully sent";
                return response()->json($data,200);
            }
        }
        $data['status']=500;
        $data['message']="Something Went Wrong";
        return response()->json($data,200);
    }
    
    function sendsms($mobile,$message){
        
        $profileid 	= "20101359";
        $password 	= "Gk@sLQ2";
        $smstype=0;
        $sender="ROZNAL";
        $countrycode=91;
        $url= "http://mshastra.com/sendurlcomma.aspx?user=".$profileid."&pwd=".$password."&senderid=".$sender."&CountryCode=".$countrycode."&mobileno=".$mobile."&msgtext=".urlencode($message)."&smstype=".$smstype;
        
        $cSession = curl_init();  
        curl_setopt($cSession,CURLOPT_URL, $url);
        curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($cSession,CURLOPT_HEADER, false);  
        $curl_scraped_page = curl_exec($cSession); 
        curl_close($cSession);
        
        //echo $curl_scraped_page;
        // dd(trim($curl_scraped_page));
        
        /*
        $url = "http://mshastra.com/sendurlcomma.aspx?user=".$profileid."&pwd=".$password."&senderid=".$sender."&CountryCode=91&mobileno=".$mobile."&msgtext=".$message;
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $curl_scraped_page = curl_exec($ch);
        curl_close($ch);
        echo $curl_scraped_page;
        dd($curl_scraped_page);*/
        
        if(trim($curl_scraped_page) == 'Send Successful')
		{
			return 1;
		}
		else
		{
			return 0;
		}
    }
}
