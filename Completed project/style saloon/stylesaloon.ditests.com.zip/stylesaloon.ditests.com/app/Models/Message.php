<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Message.
 *
 * @version October 9, 2021, 5:45 am UTC
 *
 * @property string $msg
 */
class Message extends Model
{
    use SoftDeletes;
    use HasFactory;

    public $table = 'messages';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'msg',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'msg' => 'string',
    ];

    /**
     * Validation rules.
     *
     * @var array
     */
    public static $rules = [
        'msg' => 'required',
    ];
}
