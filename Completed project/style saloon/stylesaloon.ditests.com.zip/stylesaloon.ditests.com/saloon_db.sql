-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 06, 2022 at 04:16 AM
-- Server version: 5.7.37-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saloon_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `mobile`, `gender`, `created_at`, `updated_at`, `deleted_at`) VALUES
(14, 'customer', 'cust1@gmail.com', '9912399123', 0, '2021-11-25 04:05:23', '2022-02-08 07:22:38', NULL),
(15, 'customer2', 'customer2@gmail.com', '123456987', NULL, '2021-11-25 05:52:50', '2021-11-25 05:52:50', NULL),
(16, 'cutomer2', 'cutomer2@gmail.com', '9912399123', NULL, '2021-11-25 05:58:51', '2022-02-08 07:22:49', '2022-02-08 07:22:49'),
(17, 'customer3', 'customer3@gmail.com', '9912399123', NULL, '2021-11-25 05:59:26', '2021-11-25 05:59:26', NULL),
(18, 'customer4', 'customer4@gmail.com', '9912399123', NULL, '2021-11-25 05:59:52', '2021-11-25 05:59:52', NULL),
(19, 'customer6', 'customer6@gmail.com', '9912399123', NULL, '2021-11-25 06:00:12', '2021-11-25 06:00:12', NULL),
(20, 'customer7', 'customer7@gmail.com', '9912399123', NULL, '2021-11-25 06:00:32', '2021-11-25 06:00:32', NULL),
(21, 'customer7', 'customer7@gmail.com', '9912399123', NULL, '2021-11-25 06:00:55', '2021-11-25 06:00:55', NULL),
(22, 'customer8', 'customer8@gmail.com', '9912399123', NULL, '2021-11-25 06:01:11', '2021-11-25 06:01:11', NULL),
(23, 'customer9', 'customer9@gmail.com', '9912399123', NULL, '2021-11-25 06:01:29', '2021-11-25 06:01:29', NULL),
(24, 'customer10', 'customer10@gmail.com', '991239913', NULL, '2021-11-25 06:01:50', '2021-11-25 06:01:50', NULL),
(25, 'jinal', 'jinal.digitalinovation2021@gmail.com', '7698877904', 0, '2022-02-09 04:43:14', '2022-02-09 04:43:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `msg` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `msg`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2021-10-09 00:16:19', '2021-11-25 04:42:53', NULL),
(3, 'This is the test msg with these data', '2021-10-09 00:17:20', '2021-10-09 00:17:20', NULL),
(5, 'tesr', '2021-10-09 00:17:54', '2021-10-09 00:17:54', NULL),
(6, 'test', '2021-10-09 00:17:59', '2021-10-09 00:17:59', NULL),
(7, 'test', '2021-10-09 00:18:04', '2021-10-09 00:18:04', NULL),
(8, 'asdasd', '2021-10-09 00:18:10', '2022-02-08 23:35:44', '2022-02-08 23:35:44'),
(9, 'asdasdas', '2021-10-09 00:18:13', '2022-02-08 23:35:41', '2022-02-08 23:35:41'),
(10, 'asdasdasd', '2021-10-09 00:18:18', '2022-02-08 23:35:39', '2022-02-08 23:35:39'),
(11, 'asdasda', '2021-10-09 00:18:25', '2022-02-08 23:35:29', '2022-02-08 23:35:29'),
(12, 'asdasd', '2021-10-09 00:18:30', '2022-02-08 23:35:21', '2022-02-08 23:35:21'),
(13, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum', '2021-11-25 04:36:23', '2022-02-08 23:35:36', '2022-02-08 23:35:36'),
(14, 'messages messagesmessagesmessagesmessagesmessagesmessages', '2021-11-25 04:36:51', '2022-02-08 23:35:50', '2022-02-08 23:35:50');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_10_08_074454_create_posts_table', 2),
(5, '2021_10_08_102507_create_customers_table', 3),
(6, '2021_10_08_111532_create_customers_table', 4),
(7, '2021_10_08_122452_create_customers_table', 5),
(8, '2021_10_09_054536_create_messages_table', 6),
(9, '2021_10_09_063525_create_tests_table', 7);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('akshay.digitalinovation@gmail.com', '$2y$10$wBVZq5ShNYnNxMBc4xWrR.768uKRP5iZcqkPIvUoEqFsMIOUcI2vW', '2022-01-24 23:52:17');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `publish` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `description`, `publish`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'test sdf', 'testsdf', '2021-10-29', '2021-10-08 04:18:43', '2021-10-08 04:19:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `msg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`id`, `name`, `msg`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'test update', 'test update', '2021-10-09 01:05:42', '2021-10-09 01:06:00', '2021-10-09 01:06:00'),
(2, 'test', 'test', '2021-10-09 01:06:48', '2021-10-09 01:06:48', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Akshay', 'akshay.digitalinovation@gmail.com', NULL, '$2y$10$6JeQ/v8qcWwGW61ZNpJtDO4iRBg/CSCCQauFJuOxdl26MpY/6zLu.', 'br3nXKsOKoaLjKqVhDaa3J8DiuW5B9QEjJtKhjF3Wuhi7KhZsooAucnkbaQf', '2021-10-08 01:14:21', '2021-10-11 01:14:09'),
(2, 'Akshay', 'akshay.digitalinovation1@gmail.com', NULL, '$2y$10$uTb5LXmfjnA3ZtnblfzSvOifP.eB1CUmQrBiRUXKIgwWbgkasCj9e', NULL, '2021-10-26 00:01:46', '2021-10-26 00:01:46'),
(3, 'test', 'test@gmail.com', NULL, '$2y$10$tUVpR0pKLNtUMT1Y9/gaFuKyZvvurnf7QB7Iq89pVckSBEE.m.sQa', NULL, '2021-11-18 06:29:40', '2021-11-18 06:29:40'),
(4, 'Akshay', 'aksahy@gmail.com', NULL, NULL, NULL, '2021-11-19 23:48:40', '2021-11-19 23:48:40'),
(5, 'Akshay', 'akshay@gmail.com', NULL, NULL, NULL, '2021-11-20 00:13:29', '2021-11-20 00:13:29'),
(7, 'Akshay', 'aksahy123@gmail.com', NULL, NULL, NULL, '2021-11-20 00:15:33', '2021-11-20 00:15:33'),
(8, 'Akshay', 'testtest@gmail.com', NULL, NULL, NULL, '2021-11-20 00:16:34', '2021-11-20 00:16:34'),
(9, 'Akshay', 'akshaytest!@gmail.com', NULL, NULL, NULL, '2021-11-20 00:27:13', '2021-11-20 00:27:13'),
(10, 'test', 'testtesttest@gmail.com', NULL, NULL, NULL, '2021-11-20 00:28:26', '2021-11-20 00:28:26'),
(11, 'Emily Dare', 'torphy.raleigh@example.com', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'c6QUsw4Mfi', '2021-11-20 01:40:54', '2021-11-20 01:40:54'),
(12, 'Andreane Murray', 'zane13@example.org', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Gk8fKuH2lX', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(13, 'Dr. Aletha Bashirian', 'margarett.dibbert@example.com', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'WpupyKNPyV', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(14, 'Mr. Brook Welch II', 'ajast@example.net', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'gsgUPkR8rV', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(15, 'Mrs. Kaela Morissette MD', 'rex08@example.com', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'mj7cYutufe', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(16, 'Shakira Champlin MD', 'bruen.mauricio@example.com', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'fZfaF2jFaY', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(17, 'Kylee Gibson', 'smith.osborne@example.net', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '482ALrRxJw', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(18, 'Mrs. Alessandra Hyatt', 'qcarroll@example.org', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'nachZUneNi', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(19, 'Keenan Heaney', 'jwaters@example.net', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'v97NDm0iVg', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(20, 'Aletha Grimes', 'uprosacco@example.org', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'rCraiNnCBq', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(21, 'Murray Smith', 'bhalvorson@example.org', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'HDCRJB8vd7', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(22, 'Mrs. Amalia Stehr', 'michale.monahan@example.org', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '5okKCMl5Uz', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(23, 'Mr. Brennon Runolfsson III', 'addie.bruen@example.net', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'VU1RkO7AQO', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(24, 'Tristian Williamson', 'brennan.cormier@example.com', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'r4g9Cjndxs', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(25, 'Heaven Bayer PhD', 'sbechtelar@example.net', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '1nQtTGM2Go', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(26, 'Concepcion Casper', 'sveum@example.net', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6oghL0oBAG', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(27, 'Prof. Buford Hermann', 'mandy07@example.net', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'IH9fhzHFhn', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(28, 'Gail Ferry', 'jakubowski.danyka@example.com', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'qJ57XdfIpd', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(29, 'Rhoda Spencer', 'jfriesen@example.net', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'xHuISPBgjU', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(30, 'Mr. Lucius Mertz III', 'judson.grant@example.org', '2021-11-20 01:40:54', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'KPZitkbR3Q', '2021-11-20 01:40:55', '2021-11-20 01:40:55'),
(31, 'jinal patel', 'apptest2303@gmail.com', NULL, '$2y$10$R5Fn2GsuYqzyag7Jf/zN0u81oNjIN/jUbbTW22nwfQRgjIoHViP0S', NULL, '2022-01-24 23:53:06', '2022-01-24 23:53:06'),
(32, 'jinal', 'jinal.digitalinovation2021@gmail.com', NULL, '$2y$10$4EGmkBHhlmj0KchJtMRYPuo63LwVYWGMCVgQ33xxAXBrfe4uq2jDK', NULL, '2022-02-08 07:13:21', '2022-02-08 07:13:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
