<!-- Msg Field -->
<div class="col-sm-12">
    <?php echo Form::label('msg', 'Msg:'); ?>

    <p><?php echo e($message->msg); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($message->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($message->updated_at); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\Saloon\resources\views/messages/show_fields.blade.php ENDPATH**/ ?>