<!-- Name Field -->
<div class="col-sm-12">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($test->name); ?></p>
</div>

<!-- Msg Field -->
<div class="col-sm-12">
    <?php echo Form::label('msg', 'Msg:'); ?>

    <p><?php echo e($test->msg); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($test->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($test->updated_at); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\Saloon\resources\views/tests/show_fields.blade.php ENDPATH**/ ?>