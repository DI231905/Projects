<!-- Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('title', 'Title:'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

</div>

<!-- Description Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('description', 'Description:'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

</div>

<!-- Publish Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('publish', 'Publish:'); ?>

    <?php echo Form::text('publish', null, ['class' => 'form-control','id'=>'publish']); ?>

</div>

<?php $__env->startPush('page_scripts'); ?>
    <script type="text/javascript">
        $('#publish').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\Saloon\resources\views/posts/fields.blade.php ENDPATH**/ ?>