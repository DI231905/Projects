<!-- Name Field -->
<div class="col-sm-12">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($customer->name); ?></p>
</div>

<!-- Email Field -->
<div class="col-sm-12">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo e($customer->email); ?></p>
</div>

<!-- Mobile Field -->
<div class="col-sm-12">
    <?php echo Form::label('mobile', 'Mobile:'); ?>

    <p><?php echo e($customer->mobile); ?></p>
</div>

<!-- Gender Field -->
<div class="col-sm-12">
    <?php echo Form::label('gender', 'Gender:'); ?>

    <p><?php echo e($customer->gender); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($customer->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($customer->updated_at); ?></p>
</div>

<?php /**PATH D:\xampp\htdocs\Saloon\resources\views/customers/show_fields.blade.php ENDPATH**/ ?>