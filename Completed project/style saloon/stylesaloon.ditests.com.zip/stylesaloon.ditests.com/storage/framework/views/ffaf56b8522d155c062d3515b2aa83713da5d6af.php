

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

        Dashboard will appear here !!!!
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Saloon\resources\views/home.blade.php ENDPATH**/ ?>