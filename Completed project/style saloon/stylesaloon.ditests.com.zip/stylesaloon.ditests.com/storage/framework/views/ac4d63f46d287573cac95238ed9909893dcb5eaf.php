<!-- Title Field -->
<div class="col-sm-12">
    <?php echo Form::label('title', 'Title:'); ?>

    <p><?php echo e($post->title); ?></p>
</div>

<!-- Description Field -->
<div class="col-sm-12">
    <?php echo Form::label('description', 'Description:'); ?>

    <p><?php echo e($post->description); ?></p>
</div>

<!-- Publish Field -->
<div class="col-sm-12">
    <?php echo Form::label('publish', 'Publish:'); ?>

    <p><?php echo e($post->publish); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($post->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($post->updated_at); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\Saloon\resources\views/posts/show_fields.blade.php ENDPATH**/ ?>