<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Msg Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('msg', 'Msg:'); ?>

    <?php echo Form::text('msg', null, ['class' => 'form-control']); ?>

</div><?php /**PATH C:\xampp\htdocs\Saloon\resources\views/tests/fields.blade.php ENDPATH**/ ?>