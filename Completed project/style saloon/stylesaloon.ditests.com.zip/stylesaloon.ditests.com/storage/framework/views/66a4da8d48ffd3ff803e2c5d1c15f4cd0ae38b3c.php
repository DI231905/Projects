
<li class="nav-item">
    <a href="<?php echo e(route('customers.index')); ?>"
       class="nav-link <?php echo e(Request::is('customers*') ? 'active' : ''); ?>">
        <p>Customers</p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('messages.index')); ?>"
       class="nav-link <?php echo e(Request::is('messages*') ? 'active' : ''); ?>">
        <p>Messages</p>
    </a>
</li>
<?php /**PATH /home/mzldwoswysm5/public_html/stylesaloon.ditests.com/resources/views/layouts/menu.blade.php ENDPATH**/ ?>