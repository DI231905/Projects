<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::text('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Mobile Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mobile', 'Mobile:'); ?>

    <?php echo Form::text('mobile', null, ['class' => 'form-control']); ?>

</div>

<!-- Gender Field -->
<div class="form-group col-sm-6">
<label>Gender : </label><br>
<input type="radio" value="1" id="male" name="gender" checked>
<label for="male">Male</label>
<input type="radio" value="0" id="female" name="gender">
<label for="female">Female</label>
</div><?php /**PATH D:\xampp\htdocs\Saloon\resources\views/customers/fields.blade.php ENDPATH**/ ?>