<!-- Msg Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('msg', 'Msg:'); ?>

    <?php echo Form::textarea('msg', null, ['class' => 'form-control']); ?>

</div><?php /**PATH /home/mzldwoswysm5/public_html/stylesaloon.ditests.com/resources/views/messages/fields.blade.php ENDPATH**/ ?>