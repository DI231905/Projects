<!-- Msg Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('msg', 'Msg:'); ?>

    <?php echo Form::textarea('msg', null, ['class' => 'form-control']); ?>

</div><?php /**PATH D:\xampp\htdocs\Saloon\resources\views/messages/fields.blade.php ENDPATH**/ ?>