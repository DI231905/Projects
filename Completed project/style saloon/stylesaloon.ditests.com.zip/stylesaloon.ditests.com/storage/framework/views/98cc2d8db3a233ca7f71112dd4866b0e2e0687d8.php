<?php echo e($slot); ?>

<?php /**PATH /home/mzldwoswysm5/public_html/stylesaloon.ditests.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>