<!DOCTYPE html>
<html>
<head>
	<title>form</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <link rel="icon" type="image/png" href="/image/logo.jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1">

  	<style type="text/css">

  		.form{
  			width: 40%;
  			margin: 10px auto;
  			border : 2px solid black;
  			padding: 20px;
  			box-sizing: border-box;
  		}
  		.form h3{
  			font-size: 18px;
  		}

  		.form ul{
  			padding-left: 0;
  			margin: 0;
  		}
  		.form li{
  			font-size: 14px;
  			list-style-type: none;
  			padding-left: 0;
  			margin: 0;
  		}
  		.form textarea{
  			width: 100%;
  			height: auto;
  		}
          .btn{

        background-color:#f17ac1 ;
        color: white;
        margin-left: 630px;
      }

      .btn a{

        color: white;
      }

  		@media  only screen and (min-width: 1024px) and (max-width: 1260px){

  		
  			.form{
  				width: 80%;
  			}

  			.btn{

  			
  			margin-left: 400px!important;
  		}
  		}

  		@media  only screen and (min-width: 768px) and (max-width: 1023px){
               
  			.form{
  				width: 80%;
  			}
  			.btn{

  			
  			margin-left: 300px!important;
  		}

         }

  		@media  only screen and (max-width :767px)
  		{
  			.form{
  				width: 100%;
  			}
  			.btn{

  			
  			margin-left: 100px!important;
  		}

  		}
  	</style>
</head>
<body>
	<div class="form">
		    <h3 class="text-center">Personal Detail</h3>
		   <ul>
		   	<li><b>Name     :</b> <?php echo e($name); ?> </li>
		   	<li><b>Phone No :</b> <?php echo e($mobileno); ?> </li>
		   	<li><b>Email    :</b> <?php echo e($email); ?> </li>
		   </ul>
	</div>

	<div class="form">
		    <h3 class="text-center">Trailer Type</h3>
		   <ul>
		   	<?php if($Trailer_type==1): ?>
		   	<li><b>Tailer type             :</b>  Dry Van </li>
		   	<?php elseif($Trailer_type==2): ?>
		   	<li><b>Tailer type             :</b>  Refrigerated </li>
		   	<?php elseif($Trailer_type==3): ?>
		   	<li><b>Tailer type             :</b>  Flatbed </li>
		   	<?php elseif($Trailer_type==4): ?>
		   	<li><b>Tailer type             :</b>  Specialized (RGN, Lowboy, Etc) </li>
		   	<?php elseif($Trailer_type==5): ?>
		   	<li><b>Tailer type             :</b>  Power Only </li>
		   	<?php else: ?>
		   	<li><b>Tailer type             :</b>         </li>
             <?php endif; ?>

             <?php if($Amount_of_Trailer==1): ?>
		   	<li><b>Amount of trailer needed:</b> Full Trailer </li>
		   	 <?php elseif($Amount_of_Trailer==2): ?>
		   	<li><b>Amount of trailer needed:</b> Partial Trailer </li>
		   	<?php else: ?>
		    <li><b>Amount of trailer needed:</b>         </li>
            <?php endif; ?>

		   	<li><b>Feet occupied           :</b> <?php echo e($feet); ?> </li>
		   </ul>
	</div>

	<div class="form">
		    <h3 class="text-center">Shipping origin</h3>
		   <ul>
		   	<li><b>Zip code             :</b>  <?php echo e($from_zip); ?> </li>
		   	<li><b>Date                 :</b>  <?php echo e($date); ?> </li>

           <?php if($from_location==1): ?>
		   	<li><b>location             :</b>  Residence </li>
		   	 <?php elseif($from_location==2): ?>
		   	<li><b>location             :</b>Business with loading dock or forklift </li>

		   	 <?php elseif($from_location==3): ?>
		   	<li><b>location             :</b>Business without loading dock or forklift </li>
		   	<?php else: ?>
		    <li><b>location             :</b>         </li>
             <?php endif; ?>
		   </ul>
	</div>

		<div class="form">
		    <h3 class="text-center">Shipping destination</h3>
		   <ul>
		   	<li><b>Zip code             :</b>  <?php echo e($to_zip); ?> </li>
		   	 <?php if($from_location==1): ?>
		   	<li><b>location             :</b>  Residence </li>
		   	 <?php elseif($from_location==2): ?>
		   	<li><b>location             :</b>Business with loading dock or forklift </li>

		   	 <?php elseif($from_location==3): ?>
		   	<li><b>location             :</b>Business without loading dock or forklift </li>
		   	<?php else: ?>
		    <li><b>location             :</b>         </li>
             <?php endif; ?>
		   </ul>
	</div>

	<div class="form">
		    <h3 class="text-center">Weight and Quantity</h3>
		   <ul>
		   	<?php if($shipping_unit==1): ?>
		   	   <li><b>Shipping units             :</b> Full Truckload </li>
            <?php elseif($shipping_unit==2): ?>
            <li><b>Shipping units             :</b> Pallets (48"x40") </li>
            <?php elseif($shipping_unit==3): ?>
            <li><b>Shipping units             :</b>Pallets (48"x48")</li>
            <?php elseif($shipping_unit==4): ?>
            <li><b>Shipping units             :</b> Pallets (60"x48")</li>
            <?php elseif($shipping_unit==5): ?>
            <li><b>Shipping units             :</b> Pallets (enter dimensions) </li>
            <?php elseif($shipping_unit==6): ?>
            <li><b>Shipping units             :</b> Bags </li>
            <?php elseif($shipping_unit==7): ?>
            <li><b>Shipping units             :</b> Bales</li>
            <?php elseif($shipping_unit==8): ?>
            <li><b>Shipping units             :</b> Boxes </li>
            <?php elseif($shipping_unit==9): ?>k
            <li><b>Shipping units             :</b> Bundles </li>
            <?php elseif($shipping_unit==10): ?>
            <li><b>Shipping units             :</b> Carpets </li>
            <?php elseif($shipping_unit==11): ?>
            <li><b>Shipping units             :</b> Coils </li>
            <?php elseif($shipping_unit==12): ?>
            <li><b>Shipping units             :</b> Crates </li>
            <?php elseif($shipping_unit==13): ?>
            <li><b>Shipping units             :</b> Cylinders </li>
            <?php elseif($shipping_unit==14): ?>
            <li><b>Shipping units             :</b> Drums </li>
            <?php elseif($shipping_unit==15): ?>
            <li><b>Shipping units             :</b> Pails </li>
            <?php elseif($shipping_unit==16): ?>
            <li><b>Shipping units             :</b> Reels </li>
            <?php elseif($shipping_unit==17): ?>
            <li><b>Shipping units             :</b> Rolls </li>
            <?php elseif($shipping_unit==18): ?>
            <li><b>Shipping units             :</b> Tubes/Pipes </li>
            <?php else: ?>
            <li><b>Shipping units             :</b>  </li>
            <?php endif; ?>

		   	<li><b>Total weight                :</b> <?php echo e($total_weight); ?> </li>
		   	<li><b>Weight unit            :</b> <?php echo e($Weight_unit); ?> </li>
		   	<?php if($good_type==1): ?>
		   	<li><b>Good type               :</b> New Goods </li>
		   	<?php elseif($good_type==2): ?>
            <li><b>Good type               :</b> Used Goods </li>
            <?php else: ?>
             <li><b>Good type               :</b>  </li>
           <?php endif; ?>
		   	<li><b>Number of Pieces         :</b> <?php echo e($number_of_piece); ?> </li>
		   </ul>
	</div>

	<div class="form">
		    <h3 class="text-center">Weight and Quantity</h3>
		   <ul>
		   	<li><b>Length(in)*           :</b> <?php echo e($lenght); ?> </li>
		   	<li><b>Width(in)*                 :</b><?php echo e($width); ?> </li>
		   	<li><b>Height(in)*           :</b> <?php echo e($height); ?>

		   	<li><b>Approx value              :</b><?php echo e($approx_value); ?></li>
		   	<li><b>Shipment destination         :</b> <?php echo e($ship_decs); ?> </li>
		   </ul>
	</div>

	<div class="form">
		<h3 class="text-center">Special Delivery Instruction:</h3>
		<?php if($instructions==1): ?>
		<p>No additional instructions needed</p>
		<?php elseif($instructions==2): ?>
		<p>Schedule appointment</p>
		<?php elseif($instructions==3): ?>
		<p>Notify by phone on arrival</p>
		<?php else: ?>
		<p></p>
		<?php endif; ?>

	</div>

	<button class="btn"><a href="<?php echo e(url('admin/home')); ?>">Back to home ?</a></button>

</body>
</html> <?php /**PATH D:\xampp\htdocs\RRTransport\resources\views/admin/viewinquirydetail.blade.php ENDPATH**/ ?>