-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 06, 2022 at 04:15 AM
-- Server version: 5.7.37-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rrtransport`
--

-- --------------------------------------------------------

--
-- Table structure for table `admindetail`
--

CREATE TABLE `admindetail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` text COLLATE utf8mb4_unicode_ci,
  `fblink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitterlink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admindetail`
--

INSERT INTO `admindetail` (`id`, `name`, `email`, `mobileno`, `fax_no`, `website`, `address`, `area`, `fblink`, `instalink`, `twitterlink`, `created_at`, `updated_at`) VALUES
(1, 'R&R Transportation, Inc.', 'info@rrtransportationinc', '(336) 292-4630', '(336) 547-8488', 'www.rrtransportationinc.com', '4415 Abner Place Greensboro,\r\nNC 27407', 'North Carolina, USA', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `token`, `created_at`, `updated_at`) VALUES
(1, 'apptest', 'info@rrtransportationinc.com', '$2y$10$vM3HX8fYpuYcFq1xhxogh.Z12u.tidJcQOa.PiEYTIOxU/27Olbjy', '1342', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `affiliation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `app_accidentrecord`
--

CREATE TABLE `app_accidentrecord` (
  `id` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `nature` varchar(255) DEFAULT NULL,
  `fatalities` varchar(255) DEFAULT NULL,
  `injuries` varchar(255) DEFAULT NULL,
  `chemicalspill` varchar(255) DEFAULT NULL,
  `personal_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_education`
--

CREATE TABLE `app_education` (
  `id` int(11) NOT NULL,
  `school` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `graduate` varchar(255) DEFAULT NULL,
  `detail` text,
  `personal_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_experience`
--

CREATE TABLE `app_experience` (
  `id` int(11) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `approx_mile` varchar(255) DEFAULT NULL,
  `personal_id` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_history`
--

CREATE TABLE `app_history` (
  `id` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` text,
  `position` text,
  `job_from` varchar(255) DEFAULT NULL,
  `job_to` varchar(255) DEFAULT NULL,
  `reason` text,
  `salary` varchar(255) DEFAULT NULL,
  `gape` text,
  `regulation` varchar(255) DEFAULT NULL,
  `cfr` varchar(255) DEFAULT NULL,
  `personal_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_license`
--

CREATE TABLE `app_license` (
  `id` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `licenseno` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `endorsement` varchar(255) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `personal_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_othereduction`
--

CREATE TABLE `app_othereduction` (
  `id` int(11) NOT NULL,
  `detail` text,
  `personal_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_personalinfo`
--

CREATE TABLE `app_personalinfo` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `application_date` date DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `work_date` date DEFAULT NULL,
  `workpermit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_residency`
--

CREATE TABLE `app_residency` (
  `id` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `personal_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_restriction`
--

CREATE TABLE `app_restriction` (
  `id` int(11) NOT NULL,
  `restriction` varchar(255) DEFAULT NULL,
  `restriction_description` text,
  `suspended` varchar(255) DEFAULT NULL,
  `suspended_description` text,
  `personal_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `app_traffic`
--

CREATE TABLE `app_traffic` (
  `id` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `violation` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `penlty` varchar(255) DEFAULT NULL,
  `personal_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `main_heading` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `image`, `title`, `main_heading`) VALUES
(3, '1634898541_banner-1.jpg', 'Welcome To R&R Transportation, Inc.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `banner_image`
--

CREATE TABLE `banner_image` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `page_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner_image`
--

INSERT INTO `banner_image` (`id`, `name`, `image`, `page_name`) VALUES
(1, 'Services', '1634477617_banner-2.jpg', 'our services'),
(2, 'Career', '1634479079_banner-2.jpg', 'career'),
(3, 'Our Team', '1634478780_banner-2.jpg', 'team'),
(4, 'About Us', '1638204873_Screenshot-15 (2).png', 'About Us'),
(5, 'Contact Us', '1634479133_banner-2.jpg', 'Contact Us'),
(6, 'Gallery', '1634479336_banner-2.jpg', 'gallery'),
(7, 'Inquiry Form', '1634479281_banner-2.jpg', 'INQUIRY');

-- --------------------------------------------------------

--
-- Table structure for table `benifits`
--

CREATE TABLE `benifits` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `benifits`
--

INSERT INTO `benifits` (`id`, `title`, `description`) VALUES
(1, 'Make a Difference in a Truck Driving Career', '<p><span style=\"font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px; text-align: center;\">Every time you pick up and deliver a truckload or LLTL, you are serving our customers. Without them, we wouldnâ€™t have a business. So we work hard to honor every request. R&amp;R Transportation, Inc has built a thriving business on treating our customers like family and providing top-notch customer service at every turn.</span><br></p>'),
(2, 'We Put Our Drivers First!', '<p>At R&R Transportation, Inc we work together as a family to serve our customers. We also realize that families contain different people. So we promise to always treat you like an individual, not just a number or a work hand. And when it comes to driver safety and job satisfaction, we place our drivers in high priority.</p>'),
(3, 'Weâ€™re into Giving Second Chances', '<span style=\"font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px; text-align: center;\">Over the past five years, R&amp;R Transportation, Inc. has made a determined effort to give others a second chance. We believe that a few wrong turns in your life shouldnâ€™t determine your future path. And a criminal record shouldnâ€™t be a life sentence that keeps you from success.</span><div><span style=\"color: rgb(255, 255, 255); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px; text-align: center;\"><br></span></div>');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emp_type`
--

CREATE TABLE `emp_type` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_type`
--

INSERT INTO `emp_type` (`id`, `type`) VALUES
(1, 'Owner'),
(2, 'Employee');

-- --------------------------------------------------------

--
-- Table structure for table `enquires`
--

CREATE TABLE `enquires` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `affiliation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `enquires`
--

INSERT INTO `enquires` (`id`, `name`, `email`, `mobileno`, `date`, `from`, `to`, `created_at`, `updated_at`, `affiliation`, `type`, `description`) VALUES
(1, 'jinal', 'jinal.digitalinovation2021@gmail.com', '123456789', '2021-12-15', 'rerw', 'wdew', '2021-12-14 00:00:37', '2021-12-14 00:00:37', 'test', 'test', 'wdsdf'),
(2, '123456', 'apptest2303@gmail.com', '1234567890', '2022-01-13', 'efedf', 'efedfd', '2022-01-08 20:07:31', '2022-01-08 20:07:31', 'sygcdsugc', 'scfsd', 'dvfdvfdvfd'),
(3, 'jinal', 'jinal.digitalinovation2021@gmail.com', '1213243454', '2022-01-28', 'dsfsfd', 'dsfdgfd', '2022-01-27 12:13:24', '2022-01-27 12:13:24', 'dsfdsf', 'dsfdsfdsg', 'asdsafcdf');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(12, 'What Is LTL Transport?', '<p><span style=\"color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\">LTL Transport shipments service smaller businesses and smaller shipment needs.</span><br style=\"color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\"><span style=\"color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\">Throughout the United States, products and merchandise are moved from point to point anywhere in the country by several different modes of transportation: land, air, rail, and water. Truck shipments offer shippers immense flexibility due to a comparatively low land transportation cost. In addition, land truck transportation can move large items faster than by rail because the shipment itself is not dependent on the railroadâ€™sâ€”or any other industryâ€™sâ€”schedule.</span><br></p>', NULL, NULL),
(13, 'Carolina Trucking Company Jobs', '<span style=\"color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\">If youâ€™re looking for a professional work opportunity in North Carolina, youâ€™ve come to the right place! R&amp;R Transportation Inc. is always looking for good truck drivers who want to work hard and take pride in the work that they do</span>', NULL, NULL),
(14, 'Reliable LLTL Trucking Shipments', '<p><span style=\"color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\">Our LLTL trucking services are both reliable and backed by our guaranteed trucking services. Weâ€™ll transport your cargo to its destination on time and intact. We invite you to ship your LLTL freight with the fastest, friendliest, and most affordable carrier. We are proud to serve all of North Carolina and southern Virginia.</span><br></p>', NULL, NULL),
(15, 'Need Training?', '<p><span style=\"color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\">Weâ€™re happy to offer on-the-job training. So you can be paid to work while you train. We pair each new truck driver with a dedicated, experienced driver manager to show you the ropes until youâ€™re able to drive solo. Youâ€™ll have the chance to develop a one-on-one relationship with your trainer, our owner, other drivers, and office staff. Soon, youâ€™ll have the confidence to head out on the highway with the backing and support of your trusted co-workers.</span><br></p>', NULL, NULL),
(16, 'How Do LTL and LLTL Shipping Rates Work?', '<p><span style=\"color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\">LTL and LLTL Shipping rates are determined by weight, class, fuel surcharges, pick-up location, and delivery destination zip codes, as well as any additional services required. Fuel surcharges are updated weekly and are based on the national average cost of diesel fuel. The fuel cost and surcharges are divided among the customers who fill a truck.</span><br style=\"color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\"><span style=\"color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\">With the rising cost of shipping and fuel, many customers have been surprised by a higher rate. When the economy is doing well, trucks are filled more frequently and fuel costs and surcharges can be shared among more shippers. However, if the economy dips, not as many businesses are shipping. Thus trucks may not be filled and fuel fees and surcharges are shared among fewer shippers.</span><br></p>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `id` int(11) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`id`, `icon`, `name`, `description`) VALUES
(2, 'fad fa-truck', 'Secure Transportation', 'Finding secure transportation services can be a challenge. R&R Transportation, Inc. makes it easy to receive safe and timely transport. With over 30 years of experience, we deliver the flexibility, service, and security that you can always expect from R&R Transportation, Inc.'),
(3, 'fas fa-money-bill-alt', 'Best Price Guarantee!', 'R&R Transportation provides you best Price Guarantee means that you can be sure of getting excellent service at the best rate.'),
(4, 'fas fa-history', '24/7 Business Support', 'R&R transportation provides all customers access to our 24x7 Help Desk Services managed by a team of trained experts on hand 24 hours a day, 7 days a week.\r\n24 hour, 7 days a week dispatch operation at R&R Transportation, Inc. won\'t let you down after hours. Get up-to-the-minute information on the status of your shipment 24 hours a day, 7 days a week. We are always here to serve you.\r\nOur investment in technology provides customized technology that will improve your experience. Seamless In-cab/smartphone connectivity to keep drivers connected while maintaining regulatory compliance.');

-- --------------------------------------------------------

--
-- Table structure for table `footer_about`
--

CREATE TABLE `footer_about` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `footer_about`
--

INSERT INTO `footer_about` (`id`, `description`) VALUES
(1, '<span style=\"font-family: Poppins, sans-serif; font-size: 14px; letter-spacing: 0.5px;\">When you ship your freight with R&amp;R Transportation Inc., you get more than just a professional trucking carrier.</span>');

-- --------------------------------------------------------

--
-- Table structure for table `gallary`
--

CREATE TABLE `gallary` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gallary`
--

INSERT INTO `gallary` (`id`, `file`, `extension`, `created_at`, `updated_at`) VALUES
(24, '1630306456_gallery-29.jpg', '.jpg', NULL, NULL),
(25, '1630306456_gallery-30.jpg', '.jpg', NULL, NULL),
(26, '1630306456_about-1.jpg', '.jpg', NULL, NULL),
(27, '1630306456_banner-1.jpg', '.jpg', NULL, NULL),
(28, '1630306456_banner-2.jpg', '.jpg', NULL, NULL),
(29, '1630306456_banner-3.jpg', '.jpg', NULL, NULL),
(30, '1630306456_career-1.jpg', '.jpg', NULL, NULL),
(31, '1630306456_gallery-21.jpg', '.jpg', NULL, NULL),
(32, '1630306456_gallery-22.jpg', '.jpg', NULL, NULL),
(33, '1630306456_gallery-23.jpg', '.jpg', NULL, NULL),
(34, '1630306457_gallery-24.jpg', '.jpg', NULL, NULL),
(35, '1630306457_gallery-25.jpg', '.jpg', NULL, NULL),
(36, '1630306457_gallery-26.jpg', '.jpg', NULL, NULL),
(37, '1630306457_gallery-27.jpg', '.jpg', NULL, NULL),
(40, '1638203863_Screenshot-14.png', '.png', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `get_queto`
--

CREATE TABLE `get_queto` (
  `id` int(11) NOT NULL,
  `fromtype` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `Trailer_type` int(11) DEFAULT NULL,
  `Amount_of_Trailer` int(11) DEFAULT NULL,
  `feet` varchar(11) DEFAULT NULL,
  `from_zip` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `from_location` int(11) DEFAULT NULL,
  `to_zip` varchar(255) DEFAULT NULL,
  `to_location` int(11) DEFAULT NULL,
  `shipping_unit` int(11) DEFAULT NULL,
  `good_type` varchar(255) DEFAULT NULL,
  `total_weight` varchar(255) DEFAULT NULL,
  `Weight_unit` varchar(255) DEFAULT NULL,
  `number_of_piece` int(11) DEFAULT NULL,
  `lenght` varchar(255) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `approx_value` varchar(255) DEFAULT NULL,
  `ship_decs` text,
  `instructions` int(11) DEFAULT NULL,
  `Freight` varchar(255) DEFAULT NULL,
  `Commodities` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `get_queto`
--

INSERT INTO `get_queto` (`id`, `fromtype`, `name`, `mobileno`, `email`, `Trailer_type`, `Amount_of_Trailer`, `feet`, `from_zip`, `date`, `from_location`, `to_zip`, `to_location`, `shipping_unit`, `good_type`, `total_weight`, `Weight_unit`, `number_of_piece`, `lenght`, `width`, `height`, `approx_value`, `ship_decs`, `instructions`, `Freight`, `Commodities`, `created_at`, `updated_at`) VALUES
(2, 1, 'test', '123456789', 'jinal.digitalinovation2021@gmail.com', 1, 2, '1234', '123456', '2021-11-19', 3, '123456', 2, 4, 'Used Goods', '12354', 'Kilos', 124, '123', '1545', '54', '5', 'test', 2, NULL, NULL, '2021-11-18 18:51:58', '2021-11-18 18:51:58'),
(4, 1, 'BiggB Distribution', '336-555-1234', 'krobin1030@gmail.com', 1, 1, '48', '27408', '2021-11-22', 2, '27265', 2, 1, '1', '12062', 'Lbs', 30, '48', '50', '62', '200000', 'none', 1, NULL, NULL, '2021-11-22 23:12:12', '2021-11-22 23:12:12'),
(5, 1, 'jinal', '123456', 'apptest2303@gmail.com', 1, 2, '1213242', '123212', '2021-12-17', 2, '213242', 2, 15, '1', '243', 'Kilos', 4224, '24', '24', '2424', '243243', '2423424qwewrewr', 2, NULL, NULL, '2021-12-14 12:03:38', '2021-12-14 12:03:38'),
(6, 1, 'jinal', '123456', 'apptest2303@gmail.com', 1, 2, '1213242', '123212', '2021-12-17', 2, '213242', 2, 15, '1', '243', 'Kilos', 4224, '24', '24', '2424', '243243', '2423424qwewrewr', 2, NULL, NULL, '2021-12-14 12:03:53', '2021-12-14 12:03:53'),
(7, 1, 'jinal', '12312312', 'apptest2303@gmail.com', 1, 2, '123123', '13213', '2021-12-24', 2, '21321', 2, 17, '1', '124', 'Kilos', 24242, '124', '24', '224', '2424', 'test', 2, NULL, NULL, '2021-12-14 12:06:05', '2021-12-14 12:06:05'),
(8, 1, 'test', '121321', 'apptest2303@gmail.com', 1, 2, '121', '132213', '2021-12-17', 2, '231321', 2, 15, '1', '321', 'Kilos', 321, '321', '32', '32', '23', '232wdewrwe', 2, NULL, NULL, '2021-12-14 12:11:53', '2021-12-14 12:11:53');

-- --------------------------------------------------------

--
-- Table structure for table `get_queto1`
--

CREATE TABLE `get_queto1` (
  `id` int(11) NOT NULL,
  `fromtype` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `from_zip` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `from_location` varchar(255) DEFAULT NULL,
  `to_zip` varchar(255) DEFAULT NULL,
  `to_location` varchar(255) DEFAULT NULL,
  `shipping_unit` varchar(255) DEFAULT NULL,
  `good_type` varchar(255) DEFAULT NULL,
  `total_weight` varchar(255) DEFAULT NULL,
  `Weight_unit` varchar(255) DEFAULT NULL,
  `number_of_piece` int(11) DEFAULT NULL,
  `lenght` varchar(255) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `approx_value` varchar(255) DEFAULT NULL,
  `ship_decs` text,
  `instructions` varchar(255) DEFAULT NULL,
  `Freight` varchar(255) DEFAULT NULL,
  `Commodities` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `Trailer_type` varchar(255) DEFAULT NULL,
  `Amount_of_Trailer` varchar(255) DEFAULT NULL,
  `feet` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `get_queto1`
--

INSERT INTO `get_queto1` (`id`, `fromtype`, `name`, `mobileno`, `email`, `from_zip`, `date`, `from_location`, `to_zip`, `to_location`, `shipping_unit`, `good_type`, `total_weight`, `Weight_unit`, `number_of_piece`, `lenght`, `width`, `height`, `approx_value`, `ship_decs`, `instructions`, `Freight`, `Commodities`, `created_at`, `updated_at`, `Trailer_type`, `Amount_of_Trailer`, `feet`) VALUES
(1, 2, 'test', '123456789', 'apptest2303@gmail.com', '123456', '2021-11-13', '1', '123456', '1', '1', '1', '11111', 'Kilos', 12, '11', '11', '11', '11', 'test', '2', 'Select a Freight Class', 'Chairs Upholstered', '2021-11-24 20:26:46', '2021-11-24 20:26:46', NULL, NULL, NULL),
(2, 2, 'tets', '123213', 'apptest2303@gmail.com', '213214', '2021-12-24', '3', '243234', '3', '16', '1', '43', 'Kilos', 432, '432', '43', '432', '43', '342342', '2', '300', 'Select a Commodity', '2021-12-14 12:14:41', '2021-12-14 12:14:41', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `image`, `title`, `description`) VALUES
(1, '1634192473_about-1.jpg', 'Professional Trucking Carrier Since 1990:', 'Owner and President, Karl Robinson of R&amp;R Transportation Inc., operates an asset-based, family-owned trucking company within a geographical area of approximately 300 miles based in Greensboro, NC. The company has earned and maintains the position as a front-runner in specialized services and a niche of LLTL \"Local Less Than Truck Load\" that it uses to service a wide variety of industries. Awards received by R &amp; R Transportation, Inc., are The Small Minority Business-Person Award, 3-M Companies Quality Carrier of the Year award 1997, Jostens Graphics Quality Carrier Award 1997, 1998, 1999, 2000, 2002, 2004, 2006, AT &amp; T Federal Procurement Citation 1992, 2012 Piedmont Business Ethics Award, and the before the word Triad Family Business Award 2019.&nbsp;');

-- --------------------------------------------------------

--
-- Table structure for table `inquirycontent`
--

CREATE TABLE `inquirycontent` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inquirycontent`
--

INSERT INTO `inquirycontent` (`id`, `title`, `subtitle`, `description`) VALUES
(1, 'We are R&R Transportation, Inc.', 'Get in Touch With Us And We\'ll Move Your Business In the Right Direction.', '<span style=\"color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 15px; letter-spacing: 0.5px; background-color: rgb(245, 247, 248);\">R&R Transportation, Inc. offers all our customers â€“ businesses, individuals, and organizations â€“ competitively priced trucking rates and logistics management. We will keep your trucking rates low and your shipments on schedule.</span><br>');

-- --------------------------------------------------------

--
-- Table structure for table `job_application`
--

CREATE TABLE `job_application` (
  `id` int(11) NOT NULL,
  `name` varchar(110) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `vacancy` varchar(110) DEFAULT NULL,
  `mobileno` varchar(50) DEFAULT NULL,
  `experience` varchar(50) DEFAULT NULL,
  `resume` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_08_28_090825_create_admins_table', 1),
(6, '2021_08_28_092855_create_admindetail_table', 2),
(7, '2021_08_28_112800_create_service_table', 3),
(8, '2021_08_29_081629_create_testimonial_table', 4),
(9, '2021_08_29_085131_create_position_table', 5),
(10, '2021_08_29_160605_create_team_table', 6),
(11, '2021_08_30_043310_create_faq_table', 7),
(12, '2021_08_30_063805_create_gallary_table', 8),
(13, '2021_08_30_142806_create_enquires_table', 9),
(14, '2021_08_30_171217_create_contact_us_table', 10),
(15, '2021_08_30_181042_create_appointment_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `mission`
--

CREATE TABLE `mission` (
  `id` int(11) NOT NULL,
  `mission_name` varchar(255) DEFAULT NULL,
  `image` varchar(250) NOT NULL,
  `mission` text NOT NULL,
  `value_name` varchar(255) DEFAULT NULL,
  `value` text NOT NULL,
  `promise_name` varchar(255) DEFAULT NULL,
  `promise` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mission`
--

INSERT INTO `mission` (`id`, `mission_name`, `image`, `mission`, `value_name`, `value`, `promise_name`, `promise`) VALUES
(1, 'OUR MISSION', '1634204077_service-3.jpg', '<span style=\"color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; letter-spacing: 0.5px;\">To provide the highest and safest level of transportation services on timely deliveries, based on fair and competitive pricing, while maintaining integrity, fairness, and honesty with our customers, employees, and business partners.</span><br>', 'OUR VALUES', '<p style=\"color: rgb(33, 37, 41); margin-bottom: 1rem; font-size: 16px; letter-spacing: 0.5px; line-height: 28px; font-family: Poppins, sans-serif;\"><span style=\"font-weight: bolder;\">Integrity -&nbsp;</span>We honor our commitment to customers, employees, and community.</p><p style=\"color: rgb(33, 37, 41); margin-bottom: 1rem; font-size: 16px; letter-spacing: 0.5px; line-height: 28px; font-family: Poppins, sans-serif;\"><span style=\"font-weight: bolder;\">Excellence -&nbsp;</span>We ensure quality service delivery at 100%, every time!</p><p style=\"color: rgb(33, 37, 41); margin-bottom: 1rem; font-size: 16px; letter-spacing: 0.5px; line-height: 28px; font-family: Poppins, sans-serif;\"><span style=\"font-weight: bolder;\">Safety -&nbsp;</span>We strive to maintain an environment with zero accidents.</p><p style=\"color: rgb(33, 37, 41); margin-bottom: 1rem; font-size: 16px; letter-spacing: 0.5px; line-height: 28px; font-family: Poppins, sans-serif;\"><span style=\"font-weight: bolder;\">Dependability -&nbsp;</span>We say what we mean so you can trust what we say.</p><p style=\"color: rgb(33, 37, 41); margin-bottom: 1rem; font-size: 16px; letter-spacing: 0.5px; line-height: 28px; font-family: Poppins, sans-serif;\"><span style=\"font-weight: bolder;\">Teamwork -&nbsp;</span>We work together to make everyoneâ€™s job easier.</p>', 'OUR PROMISE', '<p style=\"margin-bottom: 1rem; font-size: 16px; letter-spacing: 0.5px; line-height: 28px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif;\">Our customers come first at R&R Transportation, Inc. <i><b>Always!</b></i></p><p style=\"margin-bottom: 1rem; font-size: 16px; letter-spacing: 0.5px; line-height: 28px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif;\">When you ship your freight with R&R Transportation Inc., you get more than just a professional trucking carrier. You get a full-service transportation and logistics provider with a staff of experienced transportation specialists. When you need a full truckload or less than a truckload shipment delivered in North Carolina or out of state, weâ€™ll help you get it thereâ€”on time, every time. Thatâ€™s our sincere promise to you.</p><p style=\"margin-bottom: 1rem; font-size: 16px; letter-spacing: 0.5px; line-height: 28px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif;\"><span style=\"color: rgb(33, 37, 41); letter-spacing: normal;\">R&R Transportation, Inc specializes in the following trucking carrier and transportation services in North Carolina:</span><span style=\"color: rgb(33, 37, 41); letter-spacing: normal;\"></span></p><ul class=\"box-1\" style=\"padding: 0px 0px 0px 41px; position: relative; z-index: 1; color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px;\"><li style=\"padding: 0px; position: relative; width: 579px; margin-right: 30px; list-style-type: disc;\"><span style=\"letter-spacing: 0.5px; line-height: 26px;\">Same-day deliveries</span></li><li style=\"padding: 0px; position: relative; width: 579px; margin-right: 30px; list-style-type: disc;\"><span style=\"letter-spacing: 0.5px; line-height: 26px;\">Next-day transfers</span></li><li style=\"padding: 0px; position: relative; width: 579px; margin-right: 30px; list-style-type: disc;\"><span style=\"letter-spacing: 0.5px; line-height: 26px;\">Full truckload transports</span></li><li style=\"padding: 0px; position: relative; width: 579px; margin-right: 30px; list-style-type: disc;\"><span style=\"letter-spacing: 0.5px; line-height: 26px;\">Local less than truckload consignments (LLTL)</span></li><li style=\"padding: 0px; position: relative; width: 579px; margin-right: 30px; list-style-type: disc;\"><span style=\"letter-spacing: 0.5px; line-height: 26px;\">Regional shipments</span></li></ul>');

-- --------------------------------------------------------

--
-- Table structure for table `more_maintitle`
--

CREATE TABLE `more_maintitle` (
  `id` int(11) NOT NULL,
  `more_maintitle` text,
  `banner_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `more_maintitle`
--

INSERT INTO `more_maintitle` (`id`, `more_maintitle`, `banner_id`) VALUES
(15, 'Simple Logistics', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_of_vacancy` int(11) DEFAULT NULL,
  `vacancy_type` int(11) DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Responsibilities` text COLLATE utf8mb4_unicode_ci,
  `Requirements` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`id`, `name`, `no_of_vacancy`, `vacancy_type`, `country`, `Responsibilities`, `Requirements`, `created_at`, `updated_at`) VALUES
(22, 'Driver', 5, 2, 'United States', 'This position is primarily responsible for safely driving a commercial vehicle and requires compliance with safety & DOT Regulations, continuous training, and customer service.', '<ul class=\"post-tab_0\" style=\"margin-bottom: 0px; padding: 0px 20px; font-size: 14px; line-height: 23px; letter-spacing: 0.5px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif;\"><li style=\"margin-bottom: 10px;\">High School Degree or equivalent.</li><li style=\"margin-bottom: 10px;\">Must have the ability to read, write, speak English, and perform simple mathematical calculations with general mental abilities to handle receipts, read maps, road signs, maintain logs, etc.</li><li style=\"margin-bottom: 10px;\">A driver must be a minimum of 21 years of age, pass the DOT physical and eye examination and provide copies to us, as well as submit a current MVR on an annual basis</li><li style=\"margin-bottom: 10px;\">Must pass a background check and motor vehicle check</li><li style=\"margin-bottom: 10px;\">Must pass a drug and alcohol screen before the hire date and by random selection</li><li style=\"margin-bottom: 10px;\">Pass a screening skills road test</li><li style=\"margin-bottom: 10px;\">Must provide appropriate CDL and endorsements for the position</li><li style=\"margin-bottom: 10px;\">Minimum of 2 years experience within the last 3 years</li><li style=\"margin-bottom: 10px;\">Ability to follow written and/or oral instructions and operate electronic data telecommunications</li><li style=\"margin-bottom: 10px;\">Ability to read, interpret and abide by DOT laws, rules, regulations policies, and/or procedures</li><li style=\"margin-bottom: 10px;\">Detecting, eliminating, or minimizing safety hazards by maintaining accurate records and logs</li><li style=\"margin-bottom: 10px;\">Loading/Unloading freight or assisting in the loading/unloading of freight if required by the customer</li><li style=\"margin-bottom: 10px;\">Operate equipment, such as truck cab computers, phones, or global positioning systems (GPS)</li><li style=\"margin-bottom: 10px;\">Report vehicle defects, accidents, traffic violations, or damage to the vehicles.</li><li style=\"margin-bottom: 10px;\">Obtain receipts, signatures, and bills of lading for delivered goods and assignment details.</li></ul>', NULL, NULL),
(25, 'Driver', 5, 4, 'United States', 'This position is primarily responsible for safely driving a commercial vehicle and requires compliance with safety & DOT Regulations, continuous training, and customer service.', '<ul class=\"post-tab_0\" style=\"margin-bottom: 0px; padding: 0px 20px; font-size: 14px; line-height: 23px; letter-spacing: 0.5px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif;\"><li style=\"margin-bottom: 10px;\">High School Degree or equivalent.</li><li style=\"margin-bottom: 10px;\">Must have the ability to read, write, speak English, and perform simple mathematical calculations with general mental abilities to handle receipts, read maps, road signs, maintain logs, etc.</li><li style=\"margin-bottom: 10px;\">A driver must be a minimum of 21 years of age, pass the DOT physical and eye examination and provide copies to us, as well as submit a current MVR on an annual basis</li><li style=\"margin-bottom: 10px;\">Must pass a background check and motor vehicle check</li><li style=\"margin-bottom: 10px;\">Must pass a drug and alcohol screen before the hire date and by random selection</li><li style=\"margin-bottom: 10px;\">Pass a screening skills road test</li><li style=\"margin-bottom: 10px;\">Must provide appropriate CDL and endorsements for the position</li><li style=\"margin-bottom: 10px;\">Minimum of 2 years experience within the last 3 years</li><li style=\"margin-bottom: 10px;\">Ability to follow written and/or oral instructions and operate electronic data telecommunications</li><li style=\"margin-bottom: 10px;\">Ability to read, interpret and abide by DOT laws, rules, regulations policies, and/or procedures</li><li style=\"margin-bottom: 10px;\">Detecting, eliminating, or minimizing safety hazards by maintaining accurate records and logs</li><li style=\"margin-bottom: 10px;\">Loading/Unloading freight or assisting in the loading/unloading of freight if required by the customer</li><li style=\"margin-bottom: 10px;\">Operate equipment, such as truck cab computers, phones, or global positioning systems (GPS)</li><li style=\"margin-bottom: 10px;\">Report vehicle defects, accidents, traffic violations, or damage to the vehicles.</li><li style=\"margin-bottom: 10px;\">Obtain receipts, signatures, and bills of lading for delivered goods and assignment details.</li></ul>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `position_type`
--

CREATE TABLE `position_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `position_type`
--

INSERT INTO `position_type` (`id`, `name`) VALUES
(1, 'CONTRACT'),
(2, 'FULL TIME'),
(3, 'INTERNSHIP'),
(4, 'PART-TIME');

-- --------------------------------------------------------

--
-- Table structure for table `qutoe_service`
--

CREATE TABLE `qutoe_service` (
  `id` int(11) NOT NULL,
  `qutoe_service` varchar(255) DEFAULT NULL,
  `form_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `qutoe_service`
--

INSERT INTO `qutoe_service` (`id`, `qutoe_service`, `form_id`) VALUES
(1, '1', 1),
(2, '2', 1),
(3, '1', 2),
(4, '2', 2);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `image`, `name`, `title`, `short_desc`, `long_desc`, `created_at`, `updated_at`) VALUES
(7, '1632729343_service-1.jpg', 'R&R Transportation, Incâ€”Your LLTLÂ® Trucking Carrier', 'LOCAL LLTL', 'LLTLÂ® trucking â€”â€œLOCAL LESS THAN TRUCKLOADâ€Â® â€”is our unique shipping service, providing direct shipping within a 100-mile radius of our central office located in Greensboro, North Carolina (27407).', '<div class=\"service-info1\" style=\"margin-bottom: 35px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; background-color: rgb(242, 243, 250);\"><p style=\"margin-bottom: 1rem; letter-spacing: 0.5px; line-height: 27px;\">At R&amp;R Transportation, Inc. weâ€™ve created a NEW category of trucking to serve the growing needs of our shippers. LLTLÂ® trucking â€”â€œLOCAL LESS THAN TRUCKLOADâ€Â® â€”is our unique shipping service, providing direct shipping within a 100-mile radius of our central office located in Greensboro, North Carolina (27407). Our LLTL trucking shipments service North Carolina zip codes ranging from 270â€“274 with same-day, next-day, and expedited freight shipping. Our dependable, LLTL direct service shifts your delivery cycle into high speed. Through LTL trucking, we can assist you in leveraging the strength of the just-in-time distribution. In addition, you can use our trucking service to build a strong advantage over your competition. Our exclusive LLTL trucking carrier service is available within a 100-mile radius of Greensboro, North Carolina.</p></div><div class=\"set-dec\" style=\"margin-bottom: 20px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; background-color: rgb(242, 243, 250);\"><h6 style=\"font-weight: 600; line-height: 25px; font-size: 17px;\">LLTL trucking throughout North Carolina allows us to serve our customers in new ways:</h6><ul style=\"padding-left: 40px;\"><li style=\"margin-bottom: 10px;\">Reduced Costs: 20â€“25% more economical than other carriers Increased Service: 24/7 same-day, next-day, or expedited service</li><li style=\"margin-bottom: 10px;\">Increased Efficiency: Internet-based, real-time data</li></ul></div><div class=\"set-dec\" style=\"margin-bottom: 20px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; background-color: rgb(242, 243, 250);\"><h6 style=\"font-weight: 600; line-height: 25px; font-size: 17px;\">Discover how LLTL Trucking can help your business. Here are the steps:</h6><ul style=\"padding-left: 40px;\"><li style=\"margin-bottom: 10px;\">Get a Quote Create a Shipment</li><li style=\"margin-bottom: 10px;\">Schedule a Pickup</li></ul></div><div class=\"set-dec\" style=\"margin-bottom: 20px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; background-color: rgb(242, 243, 250);\"><h6 style=\"font-weight: 600; line-height: 25px; font-size: 17px;\">R&amp;R Transportation, Inc. Provides Regional LLTL Trucking Service</h6><ul style=\"padding-left: 40px;\"><li style=\"margin-bottom: 10px;\">Our direct LLTL trucking service takes you where you need to be. Through our custom rates, you can take advantage of consistent, reliable regional trucking service. LLTL shipping allows us to have more control and flexibility over the shipment process, and decrease our costsâ€”and yours.</li></ul></div><div class=\"set-dec\" style=\"margin-bottom: 20px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; background-color: rgb(242, 243, 250);\"><h6 style=\"font-weight: 600; line-height: 25px; font-size: 17px;\">Several main factors help determine your LLTL shipping rates:</h6><ul style=\"padding-left: 40px;\"><li style=\"margin-bottom: 10px;\">Shipping Distance Shipping Weight</li><li style=\"margin-bottom: 10px;\">Freight Classification</li></ul></div>', NULL, NULL),
(8, '1632729600_service-2.jpg', 'Your Dependable Full Truckload Transportation Company.', 'FULL TRUCKLOADS', 'Your Dependable Full Truckload Transportation Company! Weâ€™re your reliable full truckload transportation company in North Carolina.', '<p style=\"margin-bottom: 1rem; font-size: 16px; letter-spacing: 0.5px; line-height: 27px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif; background-color: rgb(242, 243, 250);\">Weâ€™re your reliable full truckload transportation company in North Carolina. No matter how large or small your product isâ€”and no matter the size of your total shipmentâ€”R&amp;R Transportation, Inc. has both the truck drivers and equipment to get it there on time. Our family-run business values hard work, honesty, respect, attention to detail, commitment, teamwork, and personal service with a smile. Youâ€™ll find that our work environment is built on courtesy, friendliness, top-notch service, dedication, and enthusiasm. We are committed to providing our customers with exceptional service.</p><div class=\"set-dec\" style=\"margin-bottom: 20px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; background-color: rgb(242, 243, 250);\"><h6 style=\"font-weight: 600; line-height: 25px; font-size: 17px;\">Our full truckload and next-day trucking services provide the following trailer sizes with air-ride options for optimal cargo protection:</h6><ul style=\"padding-left: 40px;\"><li style=\"margin-bottom: 10px;\">48-foot trailers 53-foot trailers</li></ul></div><div class=\"set-dec\" style=\"margin-bottom: 20px; color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; background-color: rgb(242, 243, 250);\"><h6 style=\"font-weight: 600; line-height: 25px; font-size: 17px;\">Refrigerated trailers R&amp;R Transportation Inc. specializes in the following truckload transportation services in North Carolina:</h6><ul style=\"padding-left: 40px;\"><li style=\"margin-bottom: 10px;\">Same-day local deliveries Next-day transfers<ul style=\"padding-left: 40px;\"><li style=\"margin-bottom: 10px;\">Full truckload transports</li><li style=\"margin-bottom: 10px;\">24/7 trucking services</li><li style=\"margin-bottom: 10px;\">Freight Shipping Services</li></ul></li><li style=\"margin-bottom: 10px;\">Business Shipments</li></ul></div>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fblink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitterlink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ineedlink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `name`, `image`, `type`, `fblink`, `instalink`, `twitterlink`, `ineedlink`, `description`, `created_at`, `updated_at`) VALUES
(8, 'Karl Robinson', '1634533314_team-1.png', 'Owner', NULL, NULL, NULL, NULL, 'Karl Robinson, Owner and President of R&R Transportation, Inc., an asset-based trucking company that operates 24/7 within a geographical area of approximately 300 miles. The company has specialized services and a niche of LLTL \"Local Less Than Truck Load\" that it uses to service a wide variety of industries. Robinsonâ€™s business accolades include the Family Business Award 2019, Triad Business Journal; 2012 Piedmont Business Ethics Award, Society of Financial Service Professionals; and Minority Small Business â€œPerson of The Yearâ€ 1998, Greensboro Chamber of Commerce. Robinson is active on several local and state boards: Board Chair, Guilford County Workforce Development Board; Board member, Greensboro Chamber of Commerce; Board member, Guilford County Economic Development Alliance; Board of Trustees, Guilford Technical Community College; Business Advisory Board, First National Bank; Board Chair, Piedmont Business Capital; and Regional Board Member, North Carolina Small Business and Technology Development Center. In 2017, he was one of eight gubernatorial public appointees to the North Carolina State Banking Commission. Robinson is a native of High Point and studied business administration at GTCC. Karl is married to Cassie W. Robinson\r\nand has 3 daughters and 6 grandchildren.', NULL, NULL),
(9, 'James Cockrell', '1634533244_team-1.png', 'Employee', NULL, NULL, NULL, NULL, 'James has been with our company for more than 25 years. He is a loyal and dependable member of our family. James fills R&R Transportation with laughter and joy, and he always keeps a smile on our customersâ€™ faces. In his free time, James loves to ride his motorcycle and enjoy relaxation.', NULL, NULL),
(10, 'Ferris Evans', '1634533282_team-1.png', 'Employee', NULL, NULL, NULL, NULL, 'Ferris started as a part-time employee and transitioned to a full-time schedule. He has now been with our company for more than 15 years, and we are happy that he decided to be a larger part of the R&R Transportation family. Ferris is a wonderful asset, and he has built great relationships with our customers. On his days off, Ferris loves spending time with his son.', NULL, NULL),
(11, 'LaShelle Robinson', '1634533268_team-1.png', 'Employee', NULL, NULL, NULL, NULL, 'LaShelle has been with R&R Transportation for more than 20 years, working in both accounts receivable and payable. She brings great value to our company with her background in finance. She has a warm and inviting smile, and she ensures that our invoices are sent on time. In her spare time, LaShelle likes to spend time with her family and watch HGTV for new DIY ideas.', NULL, NULL),
(14, 'Kai Robinson', '1635238388_team-1.png', 'Employee', NULL, NULL, NULL, NULL, 'Kai joined the R&R Transportation family 5 years ago as part of our office team. She keeps track of the daily logs, completes the monthly mileage reports and handles all Human Resource functions. Kai also makes customer courtesy calls and brings a smile and a positive attitude to our family. In her spare time, Kai enjoys spending time with family, cooking, and basketry.', NULL, NULL),
(15, 'Jerry Parker', ' ', 'Employee', NULL, NULL, NULL, NULL, 'Jerry, a Navy veteran, came to work for R & R Transportation, Inc. about 4 years ago but has been a professional driver for over 20 years.  It was the family owned business practice that really attracted him to the company and he appreciated that Karl Robinson prioritized hiring veterans.  When Jerry came to R & R and met several experienced drivers like himself, he also took note that they gave new CDL drivers a chance to gain experience but also gave 2nd chances to those that needed to get a fresh start. R & R Transportation has given him an opportunity to do what he loves and make a good living.  Jerry is proud to be part of the R & R Transportation family and  looks forward to this being his last employer until retirement.', NULL, NULL),
(16, 'German Bustillo Diaz', ' ', 'Employee', NULL, NULL, NULL, NULL, 'German has been a team member since March, 2020. He enjoys driving tractor trailers runs that are particularly long hauls. When he is not listening to music and playing fantasy football, he enjoys spending time with his family.', NULL, NULL),
(17, 'Leon Vance', ' ', 'Employee', NULL, NULL, NULL, NULL, 'Leon, better known as \"Sam\" has enjoyed driving for R&R Transportation for over 13 years. He especially likes the customer routes that he makes on a routine basis, especially the Honda Jet transports. In his spare time, Sam likes keeping in shape and working out, watching television, going to the horse race tracks around the country, and traveling when he is not working.', NULL, NULL),
(18, 'James Hairston', ' ', 'Employee', NULL, NULL, NULL, NULL, 'Having been with R&R Transportation, Inc. for close to 30 years, James, also known as \"Mickey\", has been a strong part of the business\'s foundation.  He is a total company asset, a valued driver, and an individual who is a highly trained mechanic that enjoys working on all types of vehicles. Mickey loves visiting racetracks, especially NASCAR and spending time with and caring for his family.', NULL, NULL),
(19, 'Odell Rush', ' ', 'Employee', NULL, NULL, NULL, NULL, 'Odell , a military veteran has been employed for over 13 years with R&R Transportation, Inc.', NULL, NULL),
(20, 'Garland Jackson', ' ', 'Employee', NULL, NULL, NULL, NULL, 'Garland has been driving with R&R Transportation, Inc. for over 10 years. He lives in High Point with his wife of 37 years and has 2 children. Garland is also a decorated Army veteran. His hobbies are radio controlled race cars and trucks, building radio controlled construction toys, and going to NASCAR races.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`id`, `name`, `image`, `occupation`, `description`, `created_at`, `updated_at`) VALUES
(6, 'McMichael Mills', '1637301837_1635238388_team-1.png', 'Sandy Adkins, Customer Service Manager', 'You have consistently given us great service with a smile.  McMichael Mills considers R&R Transportation, Inc. a direct extension of our company. Thank you again and we look forward to doing continued daily business with you.', NULL, NULL),
(7, 'Brian Braswell', '', 'Corporate Services Analyst at Frontier Yarns, Inc.', 'R&R Transportation, Inc. treats its customers with respect and professionalism. They are a quick and responsive team that does their best every day to fulfill our shipping needs.  Working with them is easy, relaxed, and always a pleasure.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `we_are_hiring`
--

CREATE TABLE `we_are_hiring` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `heading` varchar(255) NOT NULL,
  `topdescription` varchar(900) NOT NULL,
  `title1` varchar(255) NOT NULL,
  `title2` varchar(255) NOT NULL,
  `description` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `we_are_hiring`
--

INSERT INTO `we_are_hiring` (`id`, `image`, `heading`, `topdescription`, `title1`, `title2`, `description`) VALUES
(1, '1634646057_career-1.jpg', 'WE\'RE HIRING!', '<span style=\"color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 16px; letter-spacing: 0.5px; text-align: center;\">If youâ€™re looking for a professional work opportunity in North Carolina, youâ€™ve come to the right place! R&R Transportation, Inc. is always looking for good truck drivers who want to work hard and take pride in the work that they do.</span><br>', 'Working At', 'R&R TRANSPORTATION, INC.', '<span style=\"color: rgb(33, 37, 41); font-family: Poppins, sans-serif; font-size: 15px; letter-spacing: 0.5px;\">R&R Transportation, Inc is a local leader in reliable trucking transport throughout North Carolina and the Southeast region. We are your Carolina trucking company jobs resource. Join our team where you can earn a stable income and be respected as an individual.</span>');

-- --------------------------------------------------------

--
-- Table structure for table `why_choose_us`
--

CREATE TABLE `why_choose_us` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `why_choose_us`
--

INSERT INTO `why_choose_us` (`id`, `image`, `title`, `description`) VALUES
(1, '1634206931_gallery-21.jpg', 'Hot Shot Shipping| R&R Transportation', '<div class=\"need\" style=\"margin-bottom: 20px; font-family: Poppins, sans-serif; font-size: 16px;\"><h6 style=\"margin-bottom: 5px; font-weight: 600; font-size: 18px; font-style: italic;\">Need your shipment to arrive on a holiday?</h6><h6 style=\"margin-bottom: 5px; font-weight: 600; font-size: 18px; font-style: italic;\">Do you require a Sunday pickup?</h6><h6 style=\"margin-bottom: 5px; font-weight: 600; font-size: 18px; font-style: italic;\">Is an after-hours delivery a must?</h6><h6 style=\"margin-bottom: 5px; font-weight: 600; font-size: 18px; font-style: italic;\"><div class=\"need\" style=\"margin-bottom: 20px; font-size: 16px; font-style: normal; font-weight: 400;\"></div><p style=\"margin-bottom: 1rem; font-size: 16px; line-height: 27px; letter-spacing: 0.5px; font-style: normal; font-weight: 400;\">We can get a truck to your facility on short notice, enabling you to meet your critical shipment deadlines. R&R Transportation Inc. has the resources and truck drivers [Link to Careers pg] available to meet your hot shot shipping needsâ€”all sized shipments, all day, every day. Whether you need it across the county, across the state, or across the region, we have the know-how to get it there for you quickly, safely, and when you need it.</p></h6></div>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admindetail`
--
ALTER TABLE `admindetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_accidentrecord`
--
ALTER TABLE `app_accidentrecord`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_education`
--
ALTER TABLE `app_education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_experience`
--
ALTER TABLE `app_experience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_history`
--
ALTER TABLE `app_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_license`
--
ALTER TABLE `app_license`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_othereduction`
--
ALTER TABLE `app_othereduction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_personalinfo`
--
ALTER TABLE `app_personalinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_residency`
--
ALTER TABLE `app_residency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_restriction`
--
ALTER TABLE `app_restriction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_traffic`
--
ALTER TABLE `app_traffic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner_image`
--
ALTER TABLE `banner_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `benifits`
--
ALTER TABLE `benifits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_type`
--
ALTER TABLE `emp_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquires`
--
ALTER TABLE `enquires`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer_about`
--
ALTER TABLE `footer_about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallary`
--
ALTER TABLE `gallary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `get_queto`
--
ALTER TABLE `get_queto`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `get_queto1`
--
ALTER TABLE `get_queto1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquirycontent`
--
ALTER TABLE `inquirycontent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_application`
--
ALTER TABLE `job_application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mission`
--
ALTER TABLE `mission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `more_maintitle`
--
ALTER TABLE `more_maintitle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `position_type`
--
ALTER TABLE `position_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qutoe_service`
--
ALTER TABLE `qutoe_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `we_are_hiring`
--
ALTER TABLE `we_are_hiring`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admindetail`
--
ALTER TABLE `admindetail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_accidentrecord`
--
ALTER TABLE `app_accidentrecord`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_education`
--
ALTER TABLE `app_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_experience`
--
ALTER TABLE `app_experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_history`
--
ALTER TABLE `app_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_license`
--
ALTER TABLE `app_license`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_othereduction`
--
ALTER TABLE `app_othereduction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_personalinfo`
--
ALTER TABLE `app_personalinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_residency`
--
ALTER TABLE `app_residency`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_restriction`
--
ALTER TABLE `app_restriction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_traffic`
--
ALTER TABLE `app_traffic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `banner_image`
--
ALTER TABLE `banner_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `benifits`
--
ALTER TABLE `benifits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emp_type`
--
ALTER TABLE `emp_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `enquires`
--
ALTER TABLE `enquires`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `footer_about`
--
ALTER TABLE `footer_about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gallary`
--
ALTER TABLE `gallary`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `get_queto`
--
ALTER TABLE `get_queto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `get_queto1`
--
ALTER TABLE `get_queto1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inquirycontent`
--
ALTER TABLE `inquirycontent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `job_application`
--
ALTER TABLE `job_application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `mission`
--
ALTER TABLE `mission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `more_maintitle`
--
ALTER TABLE `more_maintitle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `position`
--
ALTER TABLE `position`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `position_type`
--
ALTER TABLE `position_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `qutoe_service`
--
ALTER TABLE `qutoe_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `we_are_hiring`
--
ALTER TABLE `we_are_hiring`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
