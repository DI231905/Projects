<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Imports\JobImport;
use Excel;
use Session;
use Carbon\Carbon;

class JobController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function activeJob()
    {
        $endpoint = 'job/listing/customer/activeJobs';
        $query = [
            'page' => 0,
            'pageSize' => 6,
            'type' => null,
        ];
        $response = $this->api($endpoint, 'GET', $query);
        $response = $response['body'];

        return view('jobs.job-active');
    }

    public function jobHostory(Request $request)
    {
        if($request->download) {
            $endpoint = 'api/users/customer/monthlyStatement';
            $query = [
                'month' => $request->month,
                'year' => $request->year,
            ];
            $response = $this->api($endpoint, 'GET', $query);
            $response = $response['body'];
        }
        else {
            $endpoint = 'job/listing/customer/jobsHistory';
            $query = [
                'page' => 0,
                'pageSize' => 6,
                'type' => null,
            ];
            $response = $this->api($endpoint, 'GET', $query);
            $response = $response['body'];
        }
        return view('jobs.job-history');
    }

    public function create()
    {
        $endpoint = 'ref-data/insurance-levels';
        $response = $this->api($endpoint, 'GET');
        $insurances = $response['body'];
        
        $endpoint = 'address';
        $query = ['filter'=>'TOP'];
        $response = $this->api($endpoint, 'GET', $query);
        $response = $response['body'];
        $addresses = [];
        $org_addresses = [];
        foreach($response->data as $address) {
            $addresses[$address->id] = $address->addressOne.', '.$address->postcode;
            $org_addresses[$address->id] = $address;
        }
        return view('jobs.job-booking')->with(['insurances'=>$insurances, 'addresses'=>$addresses, 'org_addresses'=>json_encode($org_addresses)]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'pickup_date' => 'required',
            'pickup_time' => 'required',
            'drop_time' => 'required',
            'contactName' => 'required',
            'contactNumber' => 'required',
            'addressOne' => 'required',
            'city' => 'required',
            'postcode' => 'required',
            'jobLabel' => 'required',
            'file' => 'required|mimes:xlsx,csv,xls',
            'insuranceCover' => 'required',
        ]);
        $file = $request->file('file');
        $sheets = Excel::toArray(new JobImport, $file);
        $drops = [];
        foreach($sheets[0] as $key=>$val) {
            $drops[$key] = [
                "addressOne" => $val['address_one'],
                "city" => $val['city'],
                "postcode" => $val['postcode'],
                "contactNumber" => $val['contact_number'],
                "contactName" => $val['contact_name'],
                "dropOffNotes" => $val['drop_off_notes'],
                "signatureRequired" => true,
                "clientTag" => $val['clienttag'],
                "deliveryWeight" => $val['delivery_weight_kilos'],
            ];
        }
        $pickup_time = explode('-', $request->pickup_time);
        $drop_time = explode('-', $request->drop_time);
        $endpoint = config('app.bulk_api_url').'planBulkDrops';
        $method = 'POST';
        $body = [
            'jobLabel' => $request->jobLabel,
            "insuranceCover" => $request->insuranceCover,
            'pickUp' => [
                'addressOne'=> $request->addressOne,
                'addressTwo' => $request->addressTwo,
                'city' => $request->city,
                'postcode' => $request->postcode,
                'contactNumber' => $request->contactNumber,
                'contactName' => $request->contactName,
                'pickUpNotes' => $request->pickUpNotes,
                'pickUpFrom' => Carbon::parse($request->pickup_date.' '. $pickup_time[0])->format('Y-m-d\TH:i:s.u\Z'),
                'pickUpTo' => Carbon::parse($request->pickup_date.' '. $pickup_time[1])->format('Y-m-d\TH:i:s.u\Z'),
            ],
            'drops' => $drops,
            'deliveryFrom' => Carbon::parse($request->delivery_date.' '. $drop_time[0])->format('Y-m-d\TH:i:s.u\Z'),
            'deliveryTo' => Carbon::parse($request->delivery_date . ' '.$drop_time[1])->format('Y-m-d\TH:i:s.u\Z'),
            'callbackUrl' => null,
            'customerEmail' => Session::get('registeredEmail'),
            'customerId' => Session::get('customerId'),
            'submittedOn' => Carbon::now()->format('Y-m-d\TH:i:s.u\Z'),
        ];
        $response = $this->api($endpoint, $method, $body);
        if($response['status']==200) {
            Session::flash('success', 'Job created successfully!'); 
            return response()->json([
                'message' => 'Job created successfully!'
            ]);
        }
        else {
            throw new \Exception("Something went wrong! Please try again.", 500);
        }
    }

    public function preview(Request $request)
    {
        $file = $request->file('file');
        $sheets = Excel::toArray(new JobImport, $file);
        return $sheets[0]?$sheets[0]:[];
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return view('jobs.job-detail');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
