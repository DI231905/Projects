<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;

class AuthController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if($request->session()->has('authenticated') && $request->route()->getName()!='auth.logout') {
                return redirect()->to(route('home'));
            }
            return $next($request);
        });
    }

    public function register()
    {
        return view('auth.register');
    }
    
    public function login()
    {
        return view('auth.login');
    }

    public function loginProcess(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $endpoint = "tokens";
        $body = [
            'authType' => 'CUSTOMER', 
            'email' => $request->email,
            'password' => $request->password,
        ];
        $response = $this->api($endpoint, 'POST', $body);
        if($response['status']===200) {
            $accessToken = $response['headers']['Authorization'][0];
            Session::put('accessToken', $accessToken);

            $endpoint = "users/customer/whoami";
            $response = $this->api($endpoint, 'GET');
            if($response['status']===200) {
                $content = $response['body'];

                Session::put('customerId', $content->customerId);
                Session::put('registeredEmail', $content->registeredEmail);
                Session::put('authenticated', time());
            
                return redirect()->to(route('job.booking'));
            }
        }
        $error = \Illuminate\Validation\ValidationException::withMessages([
            'email' => ["I'm afraid the details you entered were incorrect, please check and try again."],
        ]);
        throw $error;
    }
    
    public function forgotPassword()
    {
        return view('auth.forgot-password');
    }

    public function logout()
    {
        Session::forget('accessToken');
        Session::forget('customerId');
        Session::forget('registeredEmail');
        Session::forget('authenticated');

        return redirect()->to(route('auth.login'));
    }
}
