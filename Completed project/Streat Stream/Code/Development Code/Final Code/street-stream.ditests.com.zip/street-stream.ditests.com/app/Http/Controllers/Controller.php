<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Session;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function api($endpoint, $method='GET', $body=[], $headers=[]) {
        if(strpos($endpoint, "https://") === false) {
            $endpoint = config('app.api_url').$endpoint;
        }
        $headers['Authorization'] = Session::get('accessToken');
        $headers['Content-Type'] = 'application/json';

        $client = new \GuzzleHttp\Client(['http_errors'=>false, 'headers'=>$headers]);
        $response = $client->request($method, $endpoint, ['body'=>json_encode($body)]);
        
        $return['headers'] = $response->getHeaders();
        $return['status'] = $response->getStatusCode();
        $return['body'] = json_decode($response->getBody()->getContents());

        return $return;
    }
}
