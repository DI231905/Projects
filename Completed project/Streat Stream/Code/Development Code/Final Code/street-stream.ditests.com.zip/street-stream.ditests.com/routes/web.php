<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/','HomeController@index')->name('home');

Route::group(['prefix'=>'auth'], function(){
    Route::get('register', 'AuthController@register')->name('auth.register');
    Route::get('login', 'AuthController@login')->name('auth.login');
    Route::post('login', 'AuthController@loginProcess')->name('auth.login');
    Route::get('forgot-password', 'AuthController@forgotPassword')->name('auth.forgot-password');
    Route::get('logout', 'AuthController@logout')->name('auth.logout');
});

Route::group(['prefix'=>'jobs', 'middleware' => ['web', 'auth']], function(){
    Route::get('active', 'JobController@activeJob')->name('job.active');
    Route::get('history', 'JobController@jobHostory')->name('job.history');
    Route::post('preview', 'JobController@preview')->name('job.preview');
    Route::get('detail/{id}', 'JobController@show')->name('job.detail');
    Route::get('booking', 'JobController@create')->name('job.booking');
    Route::post('booking', 'JobController@store')->name('job.booking');
});
