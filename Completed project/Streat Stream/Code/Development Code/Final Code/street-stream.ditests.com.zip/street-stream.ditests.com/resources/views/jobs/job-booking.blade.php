@extends('layouts.app')
@section('title', 'Book Courier')
@section('content')
	{!! Form::open(['route'=>'job.booking', 'novalidate'=>true, 'files'=>true, 'id'=>'bookingForm']) !!}
	<!--	<div class="co_vehicle">
			<div class="container">
				<div class="all-button">
					<button type="button">
						<div class="d-flex justify-content-center wrapper align-items-center">
			  				{!! Form::file('file', ['class'=>'file', 'id'=>'file']) !!}
							<div class="d-flex flex-column">
								{!! Form::input('button', 'csv', 'upload excel', ['class'=>'btn1']) !!}
								{!! Form::text('file-name', null, ['class'=>'file-name', 'id'=>'file-name', 'readonly'=>'readonly']) !!}
							</div>
						</div>
					</button>
					<a href="{{ url('bulk-upload-format.xlsx') }}">{!! Form::button('download template', ['id'=>'']) !!}</a>
					{!! Form::button('view csv', ['data-toggle'=>'modal', 'data-target'=>'#myModal']) !!}
				</div>
			</div>
		</div>-->
		<div class="co_time">
			<div class="container">
				@if(session('success'))
					<div class="alert alert-success">
						{{ session('success') }}
					</div>
				@endif
				@if(session('error'))
					<div class="alert alert-danger">
						{{ session('error') }}
					</div>
				@elseif($errors->any())
					<div class="alert alert-danger">
						Please fill all mandatory fields
					</div>
				@endif
				<div class="row">
					<div class="col-lg-2">
						<div class="inner-vehicle">
				    		<i class="fal fa-clock"></i>
				    		<h2>Time</h2>
				    	</div>
					</div>
					<div class="col-lg-10">
						<div class="inner-time">
							<h6>When should we collect your packages?</h6>
							<div class="row">
								<div class="col-lg-3">
									<div class="select-day">
										<div class="set-name">
											<p>Pick up day</p>
											<h6 class="dayname">Today</h6>
										</div>
										{!! Form::text('pickup_date', date('d/m/Y'), ['id'=>'datepicker', 'class'=>'form-control', 'required'=>true]) !!}
										@error('pickup_date')
						                    <div class="error">{{ $message }}</div>
						                @enderror
									</div>
								</div>
								<div class="col-lg-9">
									<div class="time_range">
	                                        <div id="time-range">
	                                        	<div class="set-name">
											        <p>Pick up time</p>
											        <h6><p>between: <span class="slider-time_1_1">09:00</span> - <span class="slider-time_1_2">11:00</span></p></h6>
	                                            </div>
	                                            <div class="sliders_step1">
	                                                <div id="slider-range"></div>
	                                            </div>
	                                            <div class="set-name">
	                                            	<p class="same_day">09:00</p>
	                                            	<p class="future_day">09:00</p>
	                                            	<p class="end_time">15:00</p>
	                                            </div>
	                                        </div>
	                                    	  {!! Form::hidden('pickup_time', old('pickup_time', '09:00-11:00'), ['id'=>'formrange', 'required'=>true]) !!}
	                                    	  @error('pickup_time')
								                <div class="error">{{ $message }}</div>
								              @enderror
	                                    <div class="set-name">
	                                    	{!! Form::button('<i class="fal fa-chevron-circle-left"> </i><span>Earlier</span>', ['id'=>'slide_1_prev', 'disabled'=>true]) !!}
	                                    	{!! Form::button('<span>later</span> <i class="fal fa-chevron-circle-right"></i>', ['id'=>'slide_1_next']) !!}
	                                    	
	                                    </div>
									</div>
								</div>
							</div>
						</div>
						<div class="inner-time">
							<h6>When should we deliver your packages?</h6>
							<div class="row">
								<div class="col-lg-3">
									<div class="select-day">
										<div class="set-name">
											<p>Circuit start day</p>
											<h6 class="dayname dayname_2">Today</h6>
										</div>
										<p id="delivery_date">{{ date('d/m/Y') }}</p>
									</div>
								</div>
								<div class="col-lg-9">
									<div class="time_range">
	                                        <div id="time-range1">
	                                        	<div class="set-name">
											        <p>Circuit start time</p>
											        <h6><p>between: <span class="slider-time_2_1">09:30</span> - <span class="slider-time_2_2">11:30</span></p></h6>
	                                            </div>
	                                            <div class="sliders_step1">
	                                                <div id="slider-range_1"></div>
	                                            </div>
	                                            <div class="set-name">
	                                            	<p class="same_day_2">09:30</p>
													<!-- <p class="future_day_2">09:30</p> -->
	                                            	<p class="end_time_2">15:30</p>
	                                            </div>
	                                        </div>
	                                  		{!! Form::hidden('drop_time', old('drop_time', '9:30-11:30'), ['id'=>'formrange1', 'required'=>true]) !!}
	                                  		@error('drop_time')
								                <div class="error">{{ $message }}</div>
								            @enderror
	                                    <div class="set-name">
	                                    	{!! Form::button('<i class="fal fa-chevron-circle-left"> </i><span>Earlier</span>', ['id'=>'slide_2_prev', 'disabled'=>true]) !!}
	                                    	{!! Form::button('<span>later</span> <i class="fal fa-chevron-circle-right"></i>', ['id'=>'slide_2_next']) !!}
	                                    </div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="co_userform">
			<div class="container">
				<div class="row">
					<div class="col-lg-2">
						<div class="inner-vehicle">
				    		<i class="fas fa-map-marker-alt"></i>
				    		<h2>pick up</h2>
				    	</div>
					</div>
					<div class="col-lg-10">
						<div class="inner-time">
							<h6>Where should we collect the packages?</h6>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-item">
	                                    {!! Form::text('contactName', null, ['required'=>true, 'id'=>'contactName']) !!}
	                                    <label >Sender's Name</label>
	                                    @error('contactName')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    {!! Form::number('contactNumber', null, ['required'=>true, 'id'=>'contactNumber']) !!}
	                                    <label>Sender's Contact Number</label>
	                                    @error('contactNumber')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>
								<div class="col-lg-12">
									<div class="form-item">
	                                    {!! Form::text('addressOne', null, ['required'=>true, 'id'=>'addressOne']) !!}
	                                    <label>Address line 1</label>
	                                    @error('addressOne')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>
								<div class="col-lg-12">
									<div class="form-item">
	                                    {!! Form::text('addressTwo', null, ['id'=>'addressTwo']) !!}
	                                    <label>Address line 2</label>
	                                    @error('addressTwo')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    {!! Form::text('city', null, ['required'=>true, 'id'=>'city']) !!}
	                                    <label>City/Town</label>
	                                    @error('city')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    {!! Form::text('county', null, ['id'=>'county']) !!}
	                                    <label>County</label>
	                                	@error('county')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    {!! Form::text('postcode', null, ['required'=>true, 'id'=>'postcode']) !!}
	                                    <label>Post Code</label>
	                                    @error('postcode')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>
								<!--<div class="col-lg-12">
									<div class="custom-control custom-checkbox">
	                                    {!! Form::checkbox('save', true, false, ['class'=>'custom-control-input', 'id'=>'customCheckBox1']) !!}
	                                    <label class="custom-control-label" for="customCheckBox1">Save this address in my Address Book</label>
	                                    @error('save')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>-->
								<div class="col-lg-12">
									<div class="form-item">
	                                    {!! Form::textarea('pickUpNotes', null, ['required'=>true, 'rows'=>'3', 'id'=>'pickUpNotes']) !!}
	                                    <label>Collection Instructions</label>
	                                    @error('pickUpNotes')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>
								<div class="col-lg-12">
									<h4>Give your job a name</h4>
									<div class="form-item">
	                                    {!! Form::text('jobLabel', null, ['required'=>true, 'id'=>'jobLabel']) !!}
	                                    <label>Job Label (The title that couriers will see.)</label>
	                                    @error('jobLabel')
							                <div class="error">{{ $message }}</div>
							            @enderror
	                                </div>
								</div>
							</div>
					    </div>
				    </div>
				    <div class="col-lg-12">
				         <div class="co_bulk-button">
                        	<div class="bulk-button">
                        		<div class="row">
                        		    <div class="col-lg-6 col-md-8">
                        			<div class="inner-bulk-button">
                        				<h1>Bulk Upload of addresses</h1>
                        				<div class="all-button">
										<a href="{{ url('bulk-upload-format.xlsx') }}">{!! Form::button('Download Template', ['id'=>'']) !!}</a>
                        			<button type="button">
                        				<div class="d-flex justify-content-center wrapper align-items-center">
                        	  				{!! Form::file('file', ['class'=>'file', 'id'=>'file']) !!}
                        					<div class="d-flex flex-column">
                        						{!! Form::input('button', 'csv', 'Upload Sheet', ['class'=>'btn1']) !!}
                        						{!! Form::text('file-name', null, ['class'=>'file-name', 'id'=>'file-name', 'readonly'=>'readonly']) !!}
                        					</div>
                        				</div>
                        			</button>
                        			{!! Form::button('View Sheet', ['data-toggle'=>'modal', 'data-target'=>'#myModal']) !!}
                        		</div>
                        			</div>
                        		    </div>
                        		    <div class="col-lg-6 col-md-4">
                        			<div class="inner-bulk-img">
                        				<img src="{{ asset('image/bulk-img.png') }}">
                        			</div>
                        	        </div>
                        	    </div>
                        </div>
	                </div>
	                </div>
				</div>
			</div>
					<div class="co_select co_insurance">
						<div class="container">
							<div class="insurance">
								<h2>SELECT INSURANCE</h2>
							</div>
							<div class="row">
								@foreach($insurances as $insurance)
								<div class="col-lg-3 col-md-6 col-12 d-flex">
									<div class="select_disc" id="cover-{{ $insurance->defaultLabel }}" data-id="{{ $insurance->defaultLabel }}">
										<h3>{{ $insurance->defaultLabel }}</h3>
										<p>This option insures your package for up to <span>£</span>{{ $insurance->maxCover }}</p>
										@if($insurance->exVatCost==0)
										<h2 class="pa">FREE</h2>
										<div class="show">
											<i class="fas fa-check"></i>
										</div>
										@else
										<h2>£{{ number_format((float)$insurance->exVatCost, 2, '.', '') }}</h2>
										<h6>£{{ number_format((float)$insurance->totalPayableWithVat, 2, '.', '') }} inc VAT</h6>
										@if($insurance->code=='UKIC0002')
										<div class="new-box">
											<div class="pop">
												<span>POPULAR</span>
											</div>
										</div>
										@endif
										<div class="show">
											<i class="fas fa-check"></i>
										</div>
										@endif
									</div>
								</div>
								@endforeach
							</div>
						</div>
					</div>
					@if(session('success'))
					<div class="container pt-4">
    				    <div class="alert alert-success">
							{{ session('success') }}
    					</div>	
    			   </div>
				   	@endif
				   	<div class="container pt-4 errors hide">
						<div class="alert alert-danger"></div>
					</div>
    			  <div class="container"> 
					{!! Form::hidden('insuranceCover', old('insuranceCover', 'PERSONAL'), ['required'=>true, 'id'=>'insuranceCover']) !!}
					{!! Form::button('<span>Confirm &amp; Book</span>', ['type'=>'submit', 'class'=>'btn_acele btn_black btn_insu1 mt-5']) !!} 
				  </div>
			    </div>
		    </div>
		</div>
	{!! Form::close() !!}
	<input type="hidden" id="maxDate2" />
	<!---------- view-csv-modal -------------->
    <div class="modal modal-address" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">csv data</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body table-responsive scroll-inner">
                	<table class="table table-bordered csv_table">
                        <thead>
                            <tr>
                                <th>Address One</th>
                                <th>Address Two</th>
                                <th>City</th>
                                <th>County</th>
                                <th>Postcode</th>
                                <th>Contact Number</th>
                                <th>Contact Name</th>
                                <th>Drop-Off Notes</th>
                                <th>Client Tag</th>
                                <th>Delivery Weight (kilos)</th>
                            </tr>
                        </thead>
                        <tbody id="myTable"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('styles')
	<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/book-courier.css') }}">
@endsection
@section('js')
	<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.min.js"></script>
	<script type="text/javascript" src="{{ asset('js/book-courier.js') }}?v=1.5"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			var org_addresses = JSON.parse('{!! $org_addresses !!}');
			$('#addressBookId').change(function(){
				if(org_addresses[$(this).val()]) {
					org_addresse = org_addresses[$(this).val()];
					$('#contactName').val(org_addresse['contactName']);
					$('#contactNumber').val(org_addresse['contactNumber']);
					$('#addressOne').val(org_addresse['addressOne']);
					$('#addressTwo').val(org_addresse['addressTwo']);
					$('#city').val(org_addresse['city']);
					$('#county').val(org_addresse['county']);
					$('#postcode').val(org_addresse['postcode']);
				}
				else {
					$('#contactName, #contactNumber, #addressOne, #addressTwo, #city, #county, #postcode').val(null);
				}
			});
			$("#bookingForm").submit(function(e) {
				e.preventDefault();
				$('div.error').remove();
				$('.success').hide();
				$('.errors').hide();
				var actionurl = e.currentTarget.action;
				// $("#bookingForm").find('[type="submit"]').prop('disabled', true);
				var formData = new FormData(this);
				if($('#file')[0].files[0]) {
					formData.append("file", $('#file')[0].files[0], $('#file')[0].files[0].name);
					formData.append("upload_file", true);
				}
				formData.append('delivery_date', $('#delivery_date').html());

				$.ajax({
					url: actionurl,
					type: 'post',
					data: formData,
					cache: false,
					contentType: false,
					processData: false,
					success: function(data) {
						// console.log(data);
						window.location.href = location.href;
					},
					error: function (jqXHR, textStatus, errorThrown) {
						$("#bookingForm").find('[type="submit"]').prop('disabled', false);
						errors = JSON.parse(jqXHR.responseText);
						$('.errors').show().find('.alert').html(errors.message);
						if (jqXHR.status == 422) {
							var i = 0;
							$.each(errors.errors, function(key,val) {
								if(i==0) {
									$('[name="'+key+'"]').focus();
									i++;
								}
								if(key=='file') {
									$('<div class="error">'+val[0]+'</div>').insertAfter($('[name="'+key+'"]').closest('.all-button').find('button:last'));
								}
								else {
									$('<div class="error">'+val[0]+'</div>').insertAfter($('[name="'+key+'"]').closest('.form-item').find('label'));
								}
							});
						}
					}
				});
			});
		});
	</script>
@endsection
