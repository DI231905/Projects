<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>@yield('title')</title>
	<link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />
	<link rel="stylesheet" type="text/css" href="{{ asset('css/home.css') }}">
	<meta name="csrf-token" content="{{ csrf_token() }}" />
	<meta name="site-url" content="{{ url('') }}" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/styles.css') }}?v=1.4">
</head>
<body class="body">
	<div class="co_header">
		<div class="container">
			<div class="row row1">
				<div class="col-lg-3">
					<div class="logo">
						<a href="{{ url('') }}"><img src="{{ asset('image/logo.png') }}"></a>
					</div>
				</div>
				<div class="col-lg-9">
					<div class="menu">
						<a href="{{ config('app.site_url') }}jobs/active">Active Jobs</a>
						<a href="{{ config('app.site_url') }}jobs/history">Job History</a>
						@if(Session::has('authenticated'))
						<a href="{{ config('app.site_url') }}account">My Account</a>
						<a href="{{ route('auth.logout') }}">Log out</a>
						@else
						<a href="{{ route('auth.login') }}">Log in</a>
						@endif
						<a class="btn_1" href="{{ route('job.booking') }}">Book a Courier</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	@yield('content')
	<div class="co_footer">
		<div class="container">
			<div class="row">
			    <div class="footer">
			    	<div class="logo">
						<a href="{{ url('') }}"><img src="{{ asset('image/logo1.png') }}"></a>
				    </div>
				    <p>Copyright Street Stream® 2021 On Demand Deliveries London</p>
			    </div>
			    <div class="f_1">
			    	<div class="footer-link">
			    		<a href="{{ config('app.site_url') }}about">About us</a>
			    		<a href="{{ config('app.site_url') }}courier">For Couriers</a>
			    		<a href="{{ config('app.site_url') }}contact">Contact</a>
			    		<a href="{{ config('app.site_url') }}faqs">FAQs</a>
			    		<a href="https://github.com/Street-Stream">Developers</a>
			    		<a href="{{ config('app.site_url') }}franchises">Franchises</a>
			    	</div>
			    	<div class="footer-link">
			    		<a href="{{ config('app.site_url') }}/assets/files/customer-terms-conditions.pdf">Terms & Conditions</a>
			    		<a href="{{ config('app.site_url') }}privacy-policy/customers">Privacy Policy - Customers</a>
			    		<a href="{{ config('app.site_url') }}privacy-policy/couriers">Privacy Policy - Couriers</a>
			    		<a href="{{ config('app.site_url') }}assets/files/data-protection-retention-policies.pdf">Data Protection & Data <br>  Retention Policies</a>
			    		<a href="{{ config('app.site_url') }}cookies">Cookie Policy</a>
			    	</div>
			    </div>
			    <div class="footer-link_1">
			    	<p>Follow us</p>
			    	<ul>
			    		<li><a href="https://www.instagram.com/street_stream/"><i class="fab fa-instagram"></i></a></li>
			    		<li><a href="https://twitter.com/iStreetStream/"><i class="fab fa-twitter"></i></a></li>
			    		<li><a href="https://www.facebook.com/streetstream.co.uk/"><i class="fab fa-facebook-f"></i></a></li>
			    	</ul>
			    </div>
			</div>
		</div>
	</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.js"></script>
    @yield('styles')
    @yield('js')
</body>
</html>