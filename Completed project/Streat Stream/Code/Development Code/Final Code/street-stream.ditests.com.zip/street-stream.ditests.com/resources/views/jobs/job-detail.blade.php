@extends('layouts.app')
@section('title', 'Job Detail')
@section('content')
	<div class="co_details">
		<div class="container">
			<div class="heading_1">
	        	<h2>job overview</h2>
	        </div>
			<div class="row">
				<div class="col-lg-3">
					<div class="vehicle-confirm">
						<div class="vehicle-icon">
                        	<img src="{{ asset('image/pallete carrier.svg') }}">
                        </div>
						<p>xyz</p>
						<p><strong>max size:</strong> 120cm x 100cm x 220cm</p>
						<p><strong>max weight:</strong> 1000kg</p>
					</div>
				</div>
				<div class="col-lg-3">
					<div class="from">
						<div class="from-icon">
							<i class="far fa-map-marker-alt"></i>
						</div>
						<div class="from-name">
							<p class="p1">from</p>
							<p>Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</p>
							<p class="time">14:30 - 16:30</p>
						</div>
					</div>
				</div>
				<div class="col-lg-3">
					<div class="from">
						<div class="from-icon">
							<i class="far fa-map-marker-alt"></i>
						</div>
						<div class="from-name">
							<p class="p1">to</p>
							<p>H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</p>
							<p class="time">15:00 - 17:00</p>
						</div>
					</div>
				</div>
				<div class="col-lg-3" style="padding: 0;">
					<div class="job-price">
						<div class="price_1 pr_1">
							<p>DROP OFF</p>
							<h5>28/12/2021</h5>
						</div>
						<div class="price_1 pr_2">
							<p>COST</p>
							<h2>€51.99</h2>
							<h6>€1,914.96 inc VAT</h6>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="contact_bg"><img src="{{ asset('image/contact-bg4.png') }}"></div>
	</div>
	<div class="co_map">
        <div class="container">
        	<div class="inner_map">
        	    <h2 class="map-title"><i class="far fa-map-marker-alt"></i> delivery overview</h2>
                <ul class="nav" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab" aria-selected="true">map</a>
                    </li>
                    <!--<li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab" aria-selected="false">Satellite</a>
                    </li>-->
                </ul>
                <div class="tab-content map1">
                    <div class="tab-pane active" id="tabs-1" role="tabpanel">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2761.1511501758346!2d6.119222915785369!3d46.20744809156154!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478c64c868c128e5%3A0x860af76bc1416b3a!2sAll.%20Pic-Pic%202%2C%201203%20Gen%C3%A8ve%2C%20Switzerland!5e0!3m2!1sen!2sin!4v1640322951825!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                </div>
                <button class="btn_acele btn_black"><span>cancel job</span></button>
            </div>
        </div>
    </div>
    <div class="co_timeline">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-6">
    				<div class="timeline">
    					<h2 class="map-title"><i class="fal fa-clock"></i> job timeline</h2>
    					<div class="set-timeline">
    						<div class="inner-timeline">
    							<div class="d-flex align-items-center">
    								<div class="timeline-icon">
    									<i class="fal fa-clock"></i>
    								</div>
    								<div class="timeline-date">
    									<h6>11:29 - 28/12/2021</h6>
    									<p>Submitted for offers</p>
    								</div>
    							</div>
    						</div>
    						<div class="inner-timeline check-timeline">
    							<div class="d-flex">
    								<div class="timeline-icon">
    									<i class="fal fa-check"></i>
    								</div>
    								<div class="timeline-date">
    									<h6>11:29 - 28/12/2021</h6>
    									<p class="agreed">Job agreed</p>
    								</div>
    							</div>
    						</div>
    					</div>
    				</div>
    			</div>
    			<div class="col-lg-1"></div>
    			<div class="col-lg-5">
    				<div class="billing">
    					<h2 class="map-title">billing overview</h2>
    				    <table class="table">
                            <tbody>
                                <tr>
                                    <td>Quote</td>
                                    <td class="text-right">€51.99</td>
                                </tr>
                                <tr>
                                    <td>Insurance</td>
                                    <td class="text-right">FREE</td>
                                </tr>
                                <tr>
                                    <td>Ex Vat</td>
                                    <td class="text-right">€51.99</td>
                                </tr>
                                <tr>
                                    <td>Vat</td>
                                    <td class="text-right">€10.40</td>
                                </tr>
                                <tr>
                                    <td><strong>Total</strong></td>
                                    <td class="text-right"><strong>€62.39</strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
    			</div>
    		</div>
    	</div>
    </div>
@endsection
