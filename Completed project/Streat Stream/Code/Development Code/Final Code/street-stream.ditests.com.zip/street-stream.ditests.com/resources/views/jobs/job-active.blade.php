@extends('layouts.app')
@section('title', 'Active Jobs')
@section('content')
	<div class="co_jobsection">
		<div class="container">
			<div class="job_section1">
				<h2>ACTIVE JOBS</h2>
				<div class="month_statement">
					<div class="row">
						<div class="col-lg-4"></div>
						<div class="col-lg-4">
							<div class="address-field">
								<select>
									<option>All</option>
									<option>Assigned Jobs</option>
									<option>Unassigned Jobs</option>
								</select>
						    </div>
						</div>
						<div class="col-lg-4"></div>
					</div>
				</div>
				<div class="month_statement">
					<h3>jobs</h3>
					<div class="job-slider">
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/van.jpg') }}">
									<h2>canceled</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/pallet-carrier.jpg') }}">
									<h2>expired</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/van.jpg') }}">
									<h2>expired</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/van.jpg') }}">
									<h2>canceled</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/pallet-carrier.jpg') }}">
									<h2>canceled</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection
@section('js')
	<script type="text/javascript">
		$(document).ready(function(){
			$('.job-slider').slick({
	            slidesToShow: 3,
	            slidesToScroll: 1,
	            dots: true,
	            arrows: false,
	            focusOnSelect: true
	        });
		})
    </script>
@endsection
