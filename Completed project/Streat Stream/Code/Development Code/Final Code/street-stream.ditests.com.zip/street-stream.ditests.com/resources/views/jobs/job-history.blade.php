@extends('layouts.app')
@section('title', 'Job History')
@section('content')
	<div class="co_jobsection">
		<div class="container">
			<div class="job_section1">
				<h2>JOB HISTORY</h2>
				<div class="month_statement">
					<h3>Monthly Statement</h3>
					<div class="row">
						<div class="col-lg-4">
							<div class="address-field">
								<select>
									<option>Select Month...</option>
									<option>January</option>
									<option>February</option>
									<option>March</option>
									<option>April</option>
									<option>May</option>
									<option>June</option>
									<option>July</option>
									<option>August</option>
									<option>September</option>
									<option>October</option>
									<option>November</option>
									<option>December</option>
								</select>
						    </div>
						</div>
						<div class="col-lg-4">
							<div class="address-field">
								<select>
									<option>Select year...</option>
									<option>2015</option>
									<option>2016</option>
									<option>2017</option>
									<option>2018</option>
									<option>2019</option>
									<option>2020</option>
									<option>2021</option>
								</select>
						    </div>
						</div>
						<div class="col-lg-4">
							<button class="btn_acele btn_black"><span>download</span></button>
						</div>
					</div>
				</div>
				<div class="month_statement">
					<h3>jobs</h3>
					<div class="job-slider">
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/van.jpg') }}">
									<h2>canceled</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/pallet-carrier.jpg') }}">
									<h2>expired</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/van.jpg') }}">
									<h2>expired</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/van.jpg') }}">
									<h2>canceled</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
						<div>
							<div class="set-jobs">
								<div class="jobs-icon">
									<img src="{{ asset('image/pallet-carrier.jpg') }}">
									<h2>canceled</h2>
								</div>
								<div class="jobs-desc">
									<p class="p2">xyz</p>
									<div class="pick-up">
									    <p>pick up: 27/12/2021</p>
									    <p>QUOTES: 1</p>
									</div>
									<div class="job-location">
										<div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content">Eisenbahnstr. 10g Gaggenau Baden-Württemberg 76571</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">from</p>
										        		<p>RG30 2EZ</p>
										        	</div>
										        </div>
										    </div>
                                        </div>
                                        <div class="tooltipWrapper">
                                            <div class="tooltip">
                                                <span class="tooltip__content tooltip__content1">H, Tamar Court Amethyst Lane Reading Berkshire RG30 2EZ</span>
										        <div class="from">
										        	<div class="from-icon">
										        		<i class="far fa-map-marker-alt"></i>
										        	</div>
										        	<div class="from-name">
										        		<p class="p1">to</p>
										        		<p>RH4 1EW</p>
										        	</div>
										        </div>
										    </div>
										</div>
									</div>
									<a href="{{ route('job.detail', '1') }}">job details</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection
@section('js')
	<script type="text/javascript">
		$(document).ready(function(){
			$('.job-slider').slick({
	            slidesToShow: 3,
	            slidesToScroll: 1,
	            dots: true,
	            arrows: false,
	            focusOnSelect: true
	        });
		})
    </script>
@endsection
