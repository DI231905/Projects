@extends('layouts.auth')
@section('title', 'Register')
@section('content')
	<div class="login-inner">
		<div class="set-login">
			<div class="logo">
			    <h3><a href="{{ route('home') }}"><img src="{{ asset('image/logo.png') }}"></a></h3>
		    </div>
		    <h3>Create an account</h3>
		    <form>
		    	<div class="text_1">
		    		<input type="text" placeholder="Full Name" name="name">
		    	</div>
		    	<div class="text_1">
		    		<input type="email" placeholder="Email Address" name="email">
		    	</div>
		    	<div class="text_1">
		    		<input type="number" placeholder="Phone Number" name="number">
		    	</div>
		    	<div class="text_1">
		    		<input type="text" placeholder="Company Name" name="c-name">
		    	</div>
		    	<div class="text_1">
		    		<input type="text" placeholder="Enter Password" name="pwd">
		    	</div>
		    	<div class="text_1">
		    		<input type="text" placeholder="Enter confirm Password" name="pwd">
		    	</div>
		    	<ul class="validation_1">
	    	    <li>
              <div class="form-check">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="">I have read and agree to the street stream privacy policy and Terms & conditions
                </label>
              </div>
          	</li>
        	</ul>
          <div class="submit-btn">
          	<button class="btn_acele btn_black"><span>register</span></button>
          </div>
		    </form>
	      <p class="forgot">Already a member? <a href="{{ route('auth.login') }}">Login here</a></p>
	    </div>
	  </div>
@endsection
