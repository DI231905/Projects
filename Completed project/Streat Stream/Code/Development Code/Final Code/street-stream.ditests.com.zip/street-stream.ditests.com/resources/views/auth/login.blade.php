@extends('layouts.auth')
@section('title', 'Login')
@section('content')
<div class="login-inner">
	<div class="set-login">
		<div class="logo">
		    <a href="{{ route('home') }}"><img src="{{ asset('image/logo.png') }}"></a>
	    </div>
	    <h3>Sign into your account</h3>
        {!! Form::open(['route' => 'auth.login']) !!}
	    	<div class="text_1">
                {!! Form::email('email', null, ['placeholder'=>'Email Address']) !!}
                @error('email')
                    <div class="error">{{ $message }}</div>
                @enderror
	    	</div>
	    	<div class="text_1">
                {!! Form::password('password', ['placeholder' => 'Password']) !!}
                @error('password')
                <div class="error">{{ $message }}</div>
                @enderror
	    	</div>
            <div class="submit-btn">
            	<!-- <input type="submit" value="Login"> -->
                {!! Form::button('<span>submit</span>', ['type'=>'submit', 'class'=>'btn_acele btn_black']) !!}
            </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection