function slide_1(val1, val2) {
  var hours1 = Math.floor(val1 / 60);
  var minutes1 = val1 - (hours1 * 60);

  if (hours1.length == 1) hours1 = '0' + hours1;
  if (minutes1.length == 1) minutes1 = '0' + minutes1;
  if (minutes1 == 0) minutes1 = '00';
  if (hours1 >= 12) {
    if (hours1 == 12) {
      hours1 = hours1;
      minutes1 = minutes1 + " PM";
    } else {
      hours1 = hours1 - 12;
      minutes1 = minutes1 + " PM";
    }
  } else {
    hours1 = hours1;
    minutes1 = minutes1 + " AM";
  }
  if (hours1 == 0) {
    hours1 = 12;
    minutes1 = minutes1;
  }

  $('.slider-time_1_1').html(hours1 + ':' + minutes1);
  var hours2 = Math.floor(val2 / 60);
  var minutes2 = val2 - (hours2 * 60);

  if (hours2.length == 1) hours2 = '0' + hours2;
  if (minutes2.length == 1) minutes2 = '0' + minutes2;
  if (minutes2 == 0) minutes2 = '00';
  if (hours2 >= 12) {
    if (hours2 == 12) {
      hours2 = hours2;
      minutes2 = minutes2 + " PM";
    } else if (hours2 == 24) {
      hours2 = 11;
      minutes2 = "59 PM";
    } else {
      hours2 = hours2 - 12;
      minutes2 = minutes2 + " PM";
    }
  } else {
    hours2 = hours2;
    minutes2 = minutes2 + " AM";
  }
  $('.slider-time_1_2').html(hours2 + ':' + minutes2);
  document.getElementById("formrange").value = hours1 + ':' + minutes1 + '-' + hours2 + ':' + minutes2;

  var slider = $("#slider-range_1");
  var step = slider.slider("option", "step");
  slider.slider("values", [val1+parseInt(step), val2+parseInt(step)]);
  var values = slider.slider("values");
  slide_2(values[0], values[1]);
}
function slide_2(val1, val2) {
  var hours1 = Math.floor(val1 / 60);
        var minutes1 = val1 - (hours1 * 60);

        if (hours1.length == 1) hours1 = '0' + hours1;
        if (minutes1.length == 1) minutes1 = '0' + minutes1;
        if (minutes1 == 0) minutes1 = '00';
        if (hours1 >= 12) {
          if (hours1 == 12) {
            hours1 = hours1;
            minutes1 = minutes1 + " PM";
          } else {
            hours1 = hours1 - 12;
            minutes1 = minutes1 + " PM";
          }
        } else {
          hours1 = hours1;
          minutes1 = minutes1 + " AM";
        }
        if (hours1 == 0) {
          hours1 = 12;
          minutes1 = minutes1;
        }

        $('.slider-time_2_1').html(hours1 + ':' + minutes1);
        var hours2 = Math.floor(val2 / 60);
        var minutes2 = val2 - (hours2 * 60);

        if (hours2.length == 1) hours2 = '0' + hours2;
        if (minutes2.length == 1) minutes2 = '0' + minutes2;
        if (minutes2 == 0) minutes2 = '00';
        if (hours2 >= 12) {
          if (hours2 == 12) {
            hours2 = hours2;
            minutes2 = minutes2 + " PM";
          } else if (hours2 == 24) {
            hours2 = 11;
            minutes2 = "59 PM";
          } else {
            hours2 = hours2 - 12;
            minutes2 = minutes2 + " PM";
          }
        } else {
          hours2 = hours2;
          minutes2 = minutes2 + " AM";
        }
        $('.slider-time_2_2').html(hours2 + ':' + minutes2);
        document.getElementById("formrange1").value = hours1 + ':' + minutes1 + '-' + hours2 + ':' + minutes2;
}
$(document).ready(function(){
  $('#datepicker').datepicker({
    uiLibrary: 'bootstrap4',
    minDate: new Date(),
    maxDate: 7,
    onSelect: function(date) {
      $('#delivery_date').html(date);
      var date = new Date(date);
      $('.dayname').html(date.toLocaleString('en-us', {weekday:'long'}));
      var current_date = new Date();
      if(date.getTime() > current_date.getTime()) {
        var slider = $("#slider-range");
        var values = slider.slider("values");
        slider.slider("option", "min", 540);
        slider.slider("values", [540, 660]);
        var values = slider.slider("values");
        slide_1(values[0], values[1]);

        var slider = $("#slider-range_1");
        var values = slider.slider("values");
        slider.slider("option", "min", 570);
        slider.slider("values", [570, 690]);
        var values = slider.slider("values");
        slide_2(values[0], values[1]);
        $('.future_day').show();
        $('.same_day').hide();
      }
      else {
        var slider = $("#slider-range");
        var values = slider.slider("values");
        slider.slider("option", "min", 870);
        slider.slider("values", [870, 990]);
        var values = slider.slider("values");
        slide_1(values[0], values[1]);

        var slider = $("#slider-range_1");
        var values = slider.slider("values");
        slider.slider("option", "min", 900);
        slider.slider("values", [900, 1020]);
        var values = slider.slider("values");
        slide_2(values[0], values[1]);
        $('.same_day').show();
        $('.future_day').hide();
      }
    }
  });

  $("#slider-range").slider({
    range: true,
    min: 870,
    max: 1950,
    step: 30,
    values: [870, 990],
    slide: function(e, ui) {
      if(ui.values[1] - ui.values[0] < 30){
        return false;
      }
      else {
        slide_1(ui.values[0], ui.values[1]);
      }
    }
  });

  $("#slider-range_1").slider({
      range: true,
      min: 900,
      max: 1980,
      step: 30,
      values: [900, 1020],
      slide: function(e, ui) {
        if(ui.values[1] - ui.values[0] < 30){
          return false;
        }
        else {
          slide_2(ui.values[0], ui.values[1]);
        }
      }
  });

  $('#slide_1_prev').click(function(){
    var slider = $("#slider-range");
    var values = slider.slider("values");
    var step = slider.slider("option", "step");
    slider.slider("values", [(parseInt(values[0])-parseInt(step)), (parseInt(values[1])-parseInt(step))]);
    var values = slider.slider("values");
    slide_1(values[0], values[1]);
  });
  $('#slide_1_next').click(function(){
    var slider = $("#slider-range");
    var values = slider.slider("values");
    var step = slider.slider("option", "step");
    slider.slider("values", [(parseInt(values[0])+parseInt(step)), (parseInt(values[1])+parseInt(step))]);
    var values = slider.slider("values");
    slide_1(values[0], values[1]);
  });
  $('#slide_2_prev').click(function(){
    var slider = $("#slider-range_1");
    var values = slider.slider("values");
    var step = slider.slider("option", "step");
    slider.slider("values", [(parseInt(values[0])-parseInt(step)), (parseInt(values[1])-parseInt(step))]);
    var values = slider.slider("values");
    slide_2(values[0], values[1]);
  });
  $('#slide_2_next').click(function(){
    var slider = $("#slider-range_1");
    var values = slider.slider("values");
    var step = slider.slider("option", "step");
    slider.slider("values", [(parseInt(values[0])+parseInt(step)), (parseInt(values[1])+parseInt(step))]);
    var values = slider.slider("values");
    slide_2(values[0], values[1]);
  });

  function download(filename, text) {
    var createDl = document.createElement('a');
    createDl.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    createDl.setAttribute('download', filename);
    createDl.style.display = 'none';
    document.body.appendChild(createDl);
    createDl.click();
    document.body.removeChild(createDl);
  }

  $('.btn1').on('click', function() {
    $('.file').trigger('click');
  });

  $('.file').on('change', function() {
    var fileName = $(this)[0].files[0].name;
    $('#file-name').val(fileName);

    $('#myTable').html('');
    var formData = new FormData();
    formData.append("file", $(this)[0].files[0], $(this)[0].files[0].name);
    formData.append("upload_file", true);

    $.ajax({
        type: "POST",
        url: $('meta[name="site-url"]').attr('content')+"/jobs/preview",
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function (data) {
          $.each(data, function(i, item) {
            if(item.address_one) {
              var $tr = $('<tr>').append(
                  $('<td>').text(item.address_one),
                  $('<td>').text(item.address_two),
                  $('<td>').text(item.city),
                  $('<td>').text(item.county),
                  $('<td>').text(item.postcode),
                  $('<td>').text(item.contact_name),
                  $('<td>').text(item.contact_number),
                  $('<td>').text(item.drop_off_notes),
                  $('<td>').text(item.clienttag),
                  $('<td>').text(item.delivery_weight_kilos),
              ).appendTo('#myTable');
            }
        });
        },
        error: function (error) {
            // handle error
        },
        async: true,
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
    });
  });
  $('#cover-'+$('#insuranceCover').val()).addClass('active');
  $('.select_disc').click(function(){
    var $this = $(this);
    $siblings = $this.parent().children(),
    position = $siblings.index($this);
    $('.select_disc').removeClass('active').eq(position).addClass('active');
    $siblings.removeClass('active');
    $(".select_disc").removeClass("active");
    $this.addClass('active');
    $('#insuranceCover').val($(this).data('id'));
  });
})
