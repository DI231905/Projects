function slide_1(val1, val2) {
  while(val1>=1440) {
    val1 = val1 - 1440;
  }
  while(val2>1440) {
    val2 = val2 - 1440;
  }
  var hours1 = Math.floor(val1 / 60);
  var minutes1 = val1 - (hours1 * 60);

  if(hours1<10) {
    hours1 = '0' + hours1;
  }
  if(minutes1<10) {
    minutes1 = '0' + minutes1;
  }
  start = hours1 + ':' + minutes1;
  $('.slider-time_1_1').html(start);

  var hours2 = Math.floor(val2 / 60);
  var minutes2 = val2 - (hours2 * 60);

  if(hours2<10) {
    hours2 = '0' + hours2;
  }
  if(minutes2<10) {
    minutes2 = '0' + minutes2;
  }
  end = hours2 + ':' + minutes2;
  $('.slider-time_1_2').html(end);
  $('#formrange').val(start+'-'+end);
}
function slide_2(val1, val2) {
  while(val1>=1440) {
    val1 = val1 - 1440;
  }
  while(val2>1440) {
    val2 = val2 - 1440;
  }
  var hours1 = Math.floor(val1 / 60);
  var minutes1 = val1 - (hours1 * 60);

  if(hours1<10) {
    hours1 = '0' + hours1;
  }
  if(minutes1<10) {
    minutes1 = '0' + minutes1;
  }
  start = hours1 + ':' + minutes1;
  $('.slider-time_2_1').html(start);

  var hours2 = Math.floor(val2 / 60);
  var minutes2 = val2 - (hours2 * 60);

  if(hours2<10) {
    hours2 = '0' + hours2;
  }
  if(minutes2<10) {
    minutes2 = '0' + minutes2;
  }
  end = hours2 + ':' + minutes2;
  $('.slider-time_2_2').html(end);
  $('#formrange1').val(start+'-'+end);
}

function setRange1(min, max) {
  var hours1 = Math.floor(min / 60);
  var minutes1 = min - (hours1 * 60);

  if(hours1<10) {
    hours1 = '0' + hours1;
  }
  if(minutes1<10) {
    minutes1 = '0' + minutes1;
  }
  start = hours1 + ':' + minutes1;
  $('.same_day').html(start);

  if(max<0) {
    max = 1440;
  }
  max1 = max;

  
  var hours2 = Math.floor(max / 60);
  var minutes2 = max - (hours2 * 60);

  if(hours2<10) {
    hours2 = '0' + hours2;
  }
  if(minutes2<10) {
    minutes2 = '0' + minutes2;
  }
  end = hours2 + ':' + minutes2;
  $('.end_time').html(end);
}
function setRange2(min, max) {
  var hours1 = Math.floor(min / 60);
  var minutes1 = min - (hours1 * 60);

  if(hours1<10) {
    hours1 = '0' + hours1;
  }
  if(minutes1<10) {
    minutes1 = '0' + minutes1;
  }
  start = hours1 + ':' + minutes1;
  $('.same_day_2').html(start);

  if(max<0) {
    max = 1440;
  }
  max1 = max;

  
  var hours2 = Math.floor(max / 60);
  var minutes2 = max - (hours2 * 60);

  if(hours2<10) {
    hours2 = '0' + hours2;
  }
  if(minutes2<10) {
    minutes2 = '0' + minutes2;
  }
  end = hours2 + ':' + minutes2;
  $('.end_time_2').html(end);
}

function temp(date) {
  var slider = $("#slider-range");

  var today = new Date(samedayvalues['minDate']).getTime();
  var Christmas = new Date(date+' '+'09:00').getTime();
  var diffMs = Math.floor((Christmas - today))/60000;
  if(slider.slider('values')[0]<1440) {
    diffMs = 1440 + 630;
  }
  else {
    diffMs = diffMs + slider.slider('values')[0];
  }
  
  date = date.split('/');
  date = date[1] + '/' + date[0] + '/' + date[2];
  $('#delivery_date').html(date);

  flag = false;
  while(slider.slider('values')[0]<diffMs) {
    $('#slide_1_next').trigger('click');
  }
  var slider = $("#slider-range");
  flag = true;
}

function dateSelect(date) {
  // $('#delivery_date').html(date);
  var date = new Date(date);
  year  = date.getFullYear();
  month = (date.getMonth() + 1).toString().padStart(2, "0");
  day   = date.getDate().toString().padStart(2, "0");

  d = day + '/' + month + '/' + year;
  // $('#delivery_date').html(d);
  $('#datepicker').val(d);

  var current_date = new Date();
  diff  = new Date(date - current_date),
  days  = diff/1000/60/60/24;
  if(days<=0) {
    $('.dayname').html('Today');
  }
  else if(days<=1) {
    $('.dayname').html('Tomorrow');
  }
  else {
    $('.dayname').html(date.toLocaleString('en-us', {weekday:'long'}));
  }
  var now = new Date(month + '/' + day + '/' + year).getTime();
  $datepicker = $('#datepicker').datepicker();

  var maxDate2 = new Date(now + 1 * 86400000);
  maxDate2 = (maxDate2.getMonth()+1).toString().padStart(2, "0") + '/' + (maxDate2.getDate()).toString().padStart(2, "0") + '/' + maxDate2.getFullYear().toString();
  $('#maxDate2').val(maxDate2);
}
var samedayvalues = [];
var flag = true;
$(document).ready(function(){
  var $datepicker = $('#datepicker').datepicker({
    uiLibrary: 'bootstrap4',
    minDate: new Date(),
    maxDate: 7,
    onSelect: function(date) {
      var d = new Date();
      date = date.split('/');
      var date = date[1].toString().padStart(2, '0') + "/" + (date[0]).toString().padStart(2, '0') + "/" + date[2];
      var strDate = d.getDate().toString().padStart(2, '0') + "/" + ((d.getMonth()+1)).toString().padStart(2, '0') + "/" + d.getFullYear();
      if(strDate==date) {
        interval = samedayvalues['interval'][samedayvalues['min']];
      }
      else {
        starttime = '09:00';
        var result = $.grep(samedayvalues['interval'], function(v,i) {
          return v!=undefined && v['date'] === date && v['starttime']==starttime;
        });
        interval = result[0];
      }
      
      $('#slide_1_prev, #slide_2_next').prop('disabled', false);
      var slider = $("#slider-range");
      slider.slider("option", "min", interval['min']);
      slider.slider("option", "max", interval['max']);
      slider.slider("values", [interval['start'], interval['end']]);
      slide_1(interval['start'], interval['end']);

      $('.same_day').html(interval['starttime']);
      $('.end_time').html(interval['maxtime']);

      $('#datepicker').val(interval['date']);
      $('.dayname').html(interval['day']);

      $('#slide_2_prev, #slide_2_next').prop('disabled', false);
      var slider = $("#slider-range_1");
      slider.slider("option", "min", interval['min2']);
      slider.slider("option", "max", interval['max2']);
      slider.slider("values", [interval['start2'], interval['end2']]);
      slide_2(interval['start'], interval['end2']);

      $('.same_day_2').html(interval['starttime2']);
      $('.end_time_2').html(interval['maxtime2']);

      $('.dayname_2').html(interval['day']);
      $('#delivery_date').html(interval['date2']);
      $('#slide_2_prev').prop('disabled', true);
    }
  });

  // console.log($('#datepicker').datepicker('option', 'maxDate'));

  
  var n_p_step = 180;
  var s_e_gap = 120;
  var slider_max = 360;
  var maxDate = new Date(Date.now() + ($datepicker.datepicker('option', 'maxDate')) * 86400000);
  maxDate = (maxDate.getMonth()+1).toString().padStart(2, "0") + '/' + (maxDate.getDate()).toString().padStart(2, "0") + '/' + maxDate.getFullYear().toString();
  samedayvalues['maxDate'] = maxDate;

  var maxDate2 = new Date(Date.now() + 1 * 86400000);
  maxDate2 = (maxDate2.getMonth()+1).toString().padStart(2, "0") + '/' + (maxDate2.getDate()).toString().padStart(2, "0") + '/' + maxDate2.getFullYear().toString();
  $('#maxDate2').val(maxDate2);
  samedayvalues['maxDate2'] = maxDate2;

  var event = new Date();
  date =event.toLocaleString('en-GB', { timeZone: 'Europe/London' });
  var start = moment(date);
  var remainder = 30 - (start.minute() % 30);
  
  var dateTime = moment(start).add(remainder, "minutes").format("HH:mm");
  var a = dateTime.split(':');
  var sstart = (+a[0]) * 60 + (+a[1]);
  same_day = (+a[0]).toString().padStart(2, "0") + ':' + (+a[1]).toString().padStart(2, "0");
  $('.same_day, .slider-time_1_1').html(same_day);
  samedayvalues['same_day'] = same_day;

  var current_date = $('#datepicker').val();
  current_date = current_date.split('/');
  current_date = current_date[1]+'/'+current_date[0]+'/'+current_date[2];
  samedayvalues['minDate'] = current_date + ' ' + same_day;

  totalMinutes = sstart+s_e_gap;
  var hours = Math.floor(totalMinutes / 60);          
  var minutes = totalMinutes % 60;
  time_1_2 = hours.toString().padStart(2, "0") + ':' + minutes.toString().padStart(2, "0");
  $('.slider-time_1_2').html(time_1_2);
  samedayvalues['time_1_2'] = time_1_2;

  totalMinutes = sstart+slider_max;
  var hours = Math.floor(totalMinutes / 60);          
  var minutes = totalMinutes % 60;

  end_time = hours.toString().padStart(2, "0") + ':' + minutes.toString().padStart(2, "0");
  $('.end_time').html(end_time);
  samedayvalues['end_time'] = end_time;

  totalMinutes = sstart+30;
  var hours = Math.floor(totalMinutes / 60);          
  var minutes = totalMinutes % 60;

  same_day_2 = hours.toString().padStart(2, "0") + ':' + minutes.toString().padStart(2, "0");
  $('.same_day_2, .slider-time_2_1').html(same_day_2);
  samedayvalues['same_day_2'] = same_day_2;

  totalMinutes = totalMinutes+s_e_gap;
  var hours = Math.floor(totalMinutes / 60);          
  var minutes = totalMinutes % 60;

  time_2_2 = hours.toString().padStart(2, "0") + ':' + minutes.toString().padStart(2, "0");
  $('.slider-time_2_2').html(time_2_2);
  samedayvalues['time_2_2'] = time_2_2;

  totalMinutes = sstart+30+slider_max;
  var hours = Math.floor(totalMinutes / 60);          
  var minutes = totalMinutes % 60;

  end_time_2 = hours.toString().padStart(2, "0") + ':' + minutes.toString().padStart(2, "0");
  $('.end_time_2').html(end_time_2);
  samedayvalues['end_time_2'] = end_time_2;


  samedayvalues['min'] = sstart;
  samedayvalues['maxDateTime'] = samedayvalues['maxDate']+' 23:59';
  samedayvalues['max'] = 1440 * (1 + parseInt($('#datepicker').datepicker('option', 'maxDate')));

  var g = sstart;
  samedayvalues['interval'] = [];
  c = 1080;
  time = g;
  disableprev = true;
  dates = [];
  p = 0;
  while(g<=samedayvalues['max']) {
    gg = g;
    max = gg+360;
    max2 = gg+30+360;
    disablenext = disablenext2 = false;
    if(max>samedayvalues['max']) {
      max = samedayvalues['max'];
      disablenext = true;
    }

    t = new Date(Date.now() + (Math.floor(g/1440)) * 86400000);
    t = (t.getMonth()+1).toString().padStart(2, "0") + '/' + (t.getDate()).toString().padStart(2, "0") + '/' + t.getFullYear().toString();
    t1 = t.split('/');
    t1 = t1[1]+'/'+t1[0]+'/'+t1[2];

    var current_date = new Date();
    var cdate = new Date(t);
    diff  = new Date(cdate - current_date),
    days  = diff/1000/60/60/24;
    if(days<=0) {
      day = 'Today';
    }
    else if(days<=1) {
      day = 'Tomorrow';
    }
    else {
      day = cdate.toLocaleString('en-us', {weekday:'long'});
    }
    day2 = day;
    

    starttime = gg;
    while(starttime>=1440) {
      starttime = starttime - 1440;
    }
    var hours1 = (Math.floor(starttime / 60)).toString().padStart(2, "0");
    var minutes1 = (starttime - (hours1 * 60)).toString().padStart(2, "0");
    starttime = mintime = hours1 + ':' + minutes1;

    maxtime = max;
    while(maxtime>1440) {
      maxtime = maxtime - 1440;
    }
    var hours2 = (Math.floor(maxtime / 60)).toString().padStart(2, "0");
    var minutes2 = (maxtime - (hours2 * 60)).toString().padStart(2, "0");
    maxtime = hours2 + ':' + minutes2;

    endtime = gg+120;
    while(endtime>1440) {
      endtime = endtime - 1440;
    }
    var hours2 = (Math.floor(endtime / 60)).toString().padStart(2, "0");
    var minutes2 = (endtime - (hours2 * 60)).toString().padStart(2, "0");
    endtime = hours2 + ':' + minutes2;


    // 
    j = 1440 * (Math.floor(g/1440)==0?1:Math.floor(g/1440));
    if(max2>j) {
      // max2 = j;
      // disablenext2 = true;
    }
    if(max2%1440 === 0 ) {
      p++;
    }
    if(max2>=samedayvalues['max']) {
      max2 = samedayvalues['max'];
      disablenext2 = true;
    }

    starttime2 = gg+30;
    while(starttime2>=1440) {
      starttime2 = starttime2 - 1440;
    }
    var hours1 = (Math.floor(starttime2 / 60)).toString().padStart(2, "0");
    var minutes1 = (starttime2 - (hours1 * 60)).toString().padStart(2, "0");
    starttime2 = mintime2 = hours1 + ':' + minutes1;

    maxtime2 = max2;
    while(maxtime2>1440) {
      maxtime2 = maxtime2 - 1440;
    }
    var hours2 = (Math.floor(maxtime2 / 60)).toString().padStart(2, "0");
    var minutes2 = (maxtime2 - (hours2 * 60)).toString().padStart(2, "0");
    maxtime2 = hours2 + ':' + minutes2;

    endtime2 = gg+30+120;
    while(endtime2>1440) {
      endtime2 = endtime2 - 1440;
    }
    var hours2 = (Math.floor(endtime2 / 60)).toString().padStart(2, "0");
    var minutes2 = (endtime2 - (hours2 * 60)).toString().padStart(2, "0");
    endtime2 = hours2 + ':' + minutes2;

    t2 = new Date(Date.now() + (p) * 86400000);
    t3 = (t2.getMonth()+1).toString().padStart(2, "0") + '/' + (t2.getDate()).toString().padStart(2, "0") + '/' + t2.getFullYear().toString();
    t2 = (t2.getDate()).toString().padStart(2, "0") + '/' + (t2.getMonth()+1).toString().padStart(2, "0") + '/' + t2.getFullYear().toString();
    // if(gg % 1080 == 0) 
    {
      var current_date2 = new Date();
      var cdate2 = new Date(t3);
      diff2  = new Date(cdate2 - current_date2),
      days2  = diff2/1000/60/60/24;
      if(days2<=0) {
        day2 = 'Today';
      }
      else if(days2<=1) {
        day2 = 'Tomorrow';
      }
      else {
        day2 = cdate2.toLocaleString('en-us', {weekday:'long'});
      }
    }

    samedayvalues['interval'][g] = {
      'p': p,
      'd': Math.floor(g/1440),
      'd2': Math.floor(g/1440) + 1,
      'd2max': 1440 * (Math.floor(g/1440)==0?1:Math.floor(g/1440)),
      'day': day,
      'day2': day2,
      'date': t1,
      'date2': t2,
      'start': gg,
      'end': gg+120,
      'start2': gg+30,
      'end2': gg+30+120,
      'min': gg,
      'max': max,
      'min2': gg+30,
      'max2': max2,
      'starttime': starttime,
      'mintime': mintime,
      'endtime': endtime,
      'maxtime': maxtime,
      'starttime2': starttime2,
      'mintime2': mintime2,
      'endtime2': endtime2,
      'maxtime2': maxtime2,
      'disablenext': disablenext,
      'disableprev': disableprev,
      'disablenext2': disablenext2,
    };
    g = g+30;
    disableprev = false;
  }

  console.log(samedayvalues);

  $("#slider-range").slider({
    range: true,
    min: sstart,
    max: (sstart+slider_max),
    step: 30,
    values: [sstart, (sstart+s_e_gap)],
    slide: function(e, ui) {
      if(ui.values[1] - ui.values[0] < 30){
        return false;
      }
      else {
        slide_1(ui.values[0], ui.values[1]);
      }
    }
  });

  $("#slider-range_1").slider({
      range: true,
      min: (sstart+30),
      max: (sstart+slider_max+30),
      step: 30,
      values: [(sstart+30), (sstart+s_e_gap+30)],
      slide: function(e, ui) {
        if(ui.values[1] - ui.values[0] < 30){
          return false;
        }
        else {
          slide_2(ui.values[0], ui.values[1]);
        }
      }
  });
  $('#slide_1_prev').click(function(){
    $('#slide_1_next').prop('disabled', false);
    var slider = $("#slider-range");
    var min = slider.slider("option", "min");
    min = min - 180;
    if(samedayvalues['interval'][min]==undefined) {
      $(this).prop('disabled', true);
      return false;
    }
    interval = samedayvalues['interval'][min];
    slider.slider("option", "min", interval['min']);
    slider.slider("option", "max", interval['max']);
    slider.slider("values", [interval['start'], interval['end']]);
    slide_1(interval['start'], interval['end']);

    $('.same_day').html(interval['starttime']);
    $('.end_time').html(interval['maxtime']);

    $('#datepicker').val(interval['date']);
    $('.dayname').html(interval['day']);
    $('#slide_2_prev').trigger('click');

    $(this).prop('disabled', interval['disableprev']);
    if(samedayvalues['interval'][min-180]==undefined) {
      $(this).prop('disabled', true);
      return false;
    }
  });
  $('#slide_1_next').click(function(){
    $('#slide_1_prev, #slide_2_next').prop('disabled', false);
    var slider = $("#slider-range");
    var min = slider.slider("option", "min");
    min = min + 180;
    if(samedayvalues['interval'][min]==undefined) {
      $(this).prop('disabled', true);
      return false;
    }
    interval = samedayvalues['interval'][min];
    slider.slider("option", "min", interval['min']);
    slider.slider("option", "max", interval['max']);
    slider.slider("values", [interval['start'], interval['end']]);
    slide_1(interval['start'], interval['end']);

    $('.same_day').html(interval['starttime']);
    $('.end_time').html(interval['maxtime']);

    $('#datepicker').val(interval['date']);
    $('.dayname').html(interval['day']);
    $('#slide_2_next').trigger('click');

    $(this).prop('disabled', interval['disablenext']);
    $('#slide_2_next').prop('disabled', interval['disablenext']);

    slider1 = $('#slider-range_1');
    if(slider1.slider('option', 'min')==interval['min2']) {
      $('#slide_2_prev').prop('disabled', true);
    }
  });
  $('#slide_2_prev').click(function(){
    $('#slide_2_next').prop('disabled', false);
    var slider = $("#slider-range_1");
    var min = slider.slider("option", "min");
    min = min - 180 - 30;
    if(samedayvalues['interval'][min]==undefined) {
      $(this).prop('disabled', true);
      return false;
    }

    var slider = $("#slider-range_1");
    interval = samedayvalues['interval'][min];
    slider1 = $('#slider-range');
    if(slider1.slider('option', 'min')+30==interval['min2']) {
      $(this).prop('disabled', true);
    }
    slider.slider("option", "min", interval['min2']);
    slider.slider("option", "max", interval['max2']);
    slider.slider("values", [interval['start2'], interval['end2']]);
    slide_2(interval['start2'], interval['end2']);

    $('.same_day_2').html(interval['starttime2']);
    $('.end_time_2').html(interval['maxtime2']);

    $('.dayname_2').html(interval['day']);

    // $(this).prop('disabled', interval['disableprev']);
    if(samedayvalues['interval'][min-180]==undefined) {
      $(this).prop('disabled', true);
      return false;
    }
  });
  $('#slide_2_next').click(function(){
    $('#slide_2_prev').prop('disabled', false);
    var slider = $("#slider-range_1");
    var min = slider.slider("option", "min");
    min = min + 180 - 30;
    if(samedayvalues['interval'][min + 180]==undefined) {
      $(this).prop('disabled', true);
    }
    if(samedayvalues['interval'][min]==undefined) {
      $(this).prop('disabled', true);
      return false;
    }
    interval = samedayvalues['interval'][min];
    if(interval['max2']>=samedayvalues['max']) {
      interval['max2'] = samedayvalues['max'];
      $(this).prop('disabled', true);
      // return false;
    }
    else {
      $(this).prop('disabled', interval['disablenext2']);
    }

    slider.slider("option", "min", interval['min2']);
    slider.slider("option", "max", interval['max2']);
    slider.slider("values", [interval['start2'], interval['end2']]);
    slide_2(interval['start2'], interval['end2']);

    $('.same_day_2').html(interval['starttime2']);
    $('.end_time_2').html(interval['maxtime2']);

    $('.dayname_2').html(interval['day2']);
    $('#delivery_date').html(interval['date2']);
    if(interval['min']>=1080) {
      interval['disablenext2'] = false;
    }

  });

  function download(filename, text) {
    var createDl = document.createElement('a');
    createDl.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    createDl.setAttribute('download', filename);
    createDl.style.display = 'none';
    document.body.appendChild(createDl);
    createDl.click();
    document.body.removeChild(createDl);
  }

  $('.btn1').on('click', function() {
    $('.file').trigger('click');
  });

  $('.file').on('change', function() {
    var fileName = $(this)[0].files[0].name;
    $('#file-name').val(fileName);

    $('#myTable').html('');
    var formData = new FormData();
    formData.append("file", $(this)[0].files[0], $(this)[0].files[0].name);
    formData.append("upload_file", true);

    $.ajax({
        type: "POST",
        url: $('meta[name="site-url"]').attr('content')+"/jobs/preview",
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function (data) {
          $.each(data, function(i, item) {
            if(item.address_one) {
              var $tr = $('<tr>').append(
                  $('<td>').text(item.address_one),
                  $('<td>').text(item.address_two),
                  $('<td>').text(item.city),
                  $('<td>').text(item.county),
                  $('<td>').text(item.postcode),
                  $('<td>').text(item.contact_name),
                  $('<td>').text(item.contact_number),
                  $('<td>').text(item.drop_off_notes),
                  $('<td>').text(item.clienttag),
                  $('<td>').text(item.delivery_weight_kilos),
              ).appendTo('#myTable');
            }
        });
        },
        error: function (error) {
            // handle error
        },
        async: true,
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
    });
  });
  $('#cover-'+$('#insuranceCover').val()).addClass('active');
  $('.select_disc').click(function(){
    var $this = $(this);
    $siblings = $this.parent().children(),
    position = $siblings.index($this);
    $('.select_disc').removeClass('active').eq(position).addClass('active');
    $siblings.removeClass('active');
    $(".select_disc").removeClass("active");
    $this.addClass('active');
    $('#insuranceCover').val($(this).data('id'));
  });
})
