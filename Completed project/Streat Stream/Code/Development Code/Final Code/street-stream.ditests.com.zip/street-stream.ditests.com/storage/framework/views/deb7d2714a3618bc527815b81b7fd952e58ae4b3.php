<?php $__env->startSection('title', 'Book Courier'); ?>
<?php $__env->startSection('content'); ?>
	<?php echo Form::open(['route'=>'job.booking', 'novalidate'=>true, 'files'=>true]); ?>

		<div class="co_vehicle">
			<div class="container">
				<div class="all-button">
					<button type="button">
						<div class="d-flex justify-content-center wrapper align-items-center">
			  				<?php echo Form::file('file', ['class'=>'file', 'id'=>'file']); ?>

							<div class="d-flex flex-column">
								<?php echo Form::input('button', 'csv', 'upload excel', ['class'=>'btn1']); ?>

								<?php echo Form::text('file-name', null, ['class'=>'file-name', 'id'=>'file-name', 'readonly'=>'readonly']); ?>

							</div>
						</div>
					</button>
					<?php echo Form::button('download template', ['id'=>'downloadMe']); ?>

					<?php echo Form::button('view csv', ['data-toggle'=>'modal', 'data-target'=>'#myModal']); ?>

				</div>
			</div>
		</div>
		<div class="co_time">
			<div class="container">
				<?php if(session('success')): ?>
					<div class="alert alert-success">
						<?php echo e(session('success')); ?>

					</div>
				<?php endif; ?>
				<?php if(session('error')): ?>
					<div class="alert alert-danger">
						<?php echo e(session('error')); ?>

					</div>
				<?php endif; ?>
				<div class="row">
					<div class="col-lg-2">
						<div class="inner-vehicle">
				    		<i class="fal fa-clock"></i>
				    		<h2>Time</h2>
				    	</div>
					</div>
					<div class="col-lg-10">
						<div class="inner-time">
							<h6>When should the courier collect your package?</h6>
							<div class="row">
								<div class="col-lg-3">
									<div class="select-day">
										<div class="set-name">
											<p>Pick up day</p>
											<h6 class="dayname"><?php echo e(date('l')); ?></h6>
										</div>
										<?php echo Form::text('pickup_date', date('m/d/Y'), ['id'=>'datepicker', 'class'=>'form-control', 'required'=>true]); ?>

										<?php $__errorArgs = ['pickup_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						                    <div class="error"><?php echo e($message); ?></div>
						                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
								<div class="col-lg-9">
									<div class="time_range">
	                                        <div id="time-range">
	                                        	<div class="set-name">
											        <p>Pick up time</p>
											        <h6><p>between: <span class="slider-time_1_1">2:30 PM</span> - <span class="slider-time_1_2">4:30 PM</span></p></h6>
	                                            </div>
	                                            <div class="sliders_step1">
	                                                <div id="slider-range"></div>
	                                            </div>
	                                            <div class="set-name">
	                                            	<p>14:30</p>
	                                            	<p>20:30</p>
	                                            </div>
	                                        </div>
	                                    	  <?php echo Form::hidden('pickup_time', old('pickup_time', '2:30 PM-4:30 PM'), ['id'=>'formrange', 'required'=>true]); ?>

	                                    	  <?php $__errorArgs = ['pickup_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								                <div class="error"><?php echo e($message); ?></div>
								              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                    <div class="set-name">
	                                    	<?php echo Form::button('<i class="fal fa-chevron-circle-left"> </i><span>Earlier</span>', ['id'=>'slide_1_prev']); ?>

	                                    	<?php echo Form::button('<span>later</span> <i class="fal fa-chevron-circle-right"></i>', ['id'=>'slide_1_next']); ?>

	                                    	
	                                    </div>
									</div>
								</div>
							</div>
						</div>
						<div class="inner-time">
							<h6>Choose the delivery window</h6>
							<div class="row">
								<div class="col-lg-3">
									<div class="select-day">
										<div class="set-name">
											<p>Circuit start day</p>
											<h6 class="dayname"><?php echo e(date('l')); ?></h6>
										</div>
										<p id="delivery_date"><?php echo e(date('m/d/Y')); ?></p>
									</div>
								</div>
								<div class="col-lg-9">
									<div class="time_range">
	                                        <div id="time-range1">
	                                        	<div class="set-name">
											        <p>Circuit start time</p>
											        <h6><p>between: <span class="slider-time_2_1">3:00 PM</span> - <span class="slider-time_2_2">5:00 PM</span></p></h6>
	                                            </div>
	                                            <div class="sliders_step1">
	                                                <div id="slider-range_1"></div>
	                                            </div>
	                                            <div class="set-name">
	                                            	<p>15:00</p>
	                                            	<p>21:00</p>
	                                            </div>
	                                        </div>
	                                  		<?php echo Form::hidden('drop_time', old('drop_time', '3:00 PM-5:00 PM'), ['id'=>'formrange1', 'required'=>true]); ?>

	                                  		<?php $__errorArgs = ['drop_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								                <div class="error"><?php echo e($message); ?></div>
								            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                    <div class="set-name">
	                                    	<?php echo Form::button('<i class="fal fa-chevron-circle-left"> </i><span>Earlier</span>', ['id'=>'slide_2_prev']); ?>

	                                    	<?php echo Form::button('<span>later</span> <i class="fal fa-chevron-circle-right"></i>', ['id'=>'slide_2_next']); ?>

	                                    </div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="co_userform">
			<div class="container">
				<div class="row">
					<div class="col-lg-2">
						<div class="inner-vehicle">
				    		<i class="fas fa-map-marker-alt"></i>
				    		<h2>pick up</h2>
				    	</div>
					</div>
					<div class="col-lg-10">
						<div class="inner-time">
							<h6>When should the courier collect your package?</h6>
							<div class="row">
								<div class="col-lg-6">
									<div class="address-field">
										<label>Select a saved address</label>
										<?php echo Form::select('addressBookId', [''=>'']+$addresses, old('addressBookId'), ['id'=>'addressBookId']); ?>

										<?php $__errorArgs = ['addressBookId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
								<div class="col-lg-6">
									
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    <?php echo Form::text('contactName', null, ['required'=>true, 'id'=>'contactName']); ?>

	                                    <label >Sender's Name</label>
	                                    <?php $__errorArgs = ['contactName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    <?php echo Form::number('contactNumber', null, ['required'=>true, 'id'=>'contactNumber']); ?>

	                                    <label>Sender's Contact Number</label>
	                                    <?php $__errorArgs = ['contactNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-12">
									<div class="form-item">
	                                    <?php echo Form::text('addressOne', null, ['required'=>true, 'id'=>'addressOne']); ?>

	                                    <label>Address line 1</label>
	                                    <?php $__errorArgs = ['addressOne'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-12">
									<div class="form-item">
	                                    <?php echo Form::text('addressTwo', null, ['id'=>'addressTwo']); ?>

	                                    <label>Address line 2</label>
	                                    <?php $__errorArgs = ['addressTwo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    <?php echo Form::text('city', null, ['required'=>true, 'id'=>'city']); ?>

	                                    <label>City/Town</label>
	                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    <?php echo Form::text('county', null, ['id'=>'county']); ?>

	                                    <label>county</label>
	                                	<?php $__errorArgs = ['county'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    <?php echo Form::text('postcode', null, ['required'=>true, 'id'=>'postcode']); ?>

	                                    <label>Post Code</label>
	                                    <?php $__errorArgs = ['postcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-6">
									<div class="form-item">
	                                    <?php echo Form::text('country', null, ['required'=>true, 'id'=>'country']); ?>

	                                    <label>country</label>
	                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-12">
									<div class="custom-control custom-checkbox">
	                                    <?php echo Form::checkbox('save', true, false, ['class'=>'custom-control-input', 'id'=>'customCheckBox1']); ?>

	                                    <label class="custom-control-label" for="customCheckBox1">Save this address in my Address Book</label>
	                                    <?php $__errorArgs = ['save'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-12">
									<div class="form-item">
	                                    <?php echo Form::textarea('pickUpNotes', null, ['required'=>true, 'rows'=>'3', 'id'=>'pickUpNotes']); ?>

	                                    <label>Collection Instructions</label>
	                                    <?php $__errorArgs = ['pickUpNotes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
								<div class="col-lg-12">
									<h4>Give your job a name</h4>
									<div class="form-item">
	                                    <?php echo Form::text('jobLabel', null, ['required'=>true, 'id'=>'jobLabel']); ?>

	                                    <label>Job Label (The title that couriers will see.)</label>
	                                    <?php $__errorArgs = ['jobLabel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							                <div class="error"><?php echo e($message); ?></div>
							            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                                </div>
								</div>
							</div>
					    </div>
				    </div>
					<div class="co_select co_insurance">
						<div class="container">
							<div class="insurance">
								<h2>SELECT INSURANCE</h2>
							</div>
							<div class="row">
								<?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-lg-3 col-md-6 col-12 d-flex">
									<div class="select_disc" id="cover-<?php echo e($insurance->defaultLabel); ?>" data-id="<?php echo e($insurance->defaultLabel); ?>">
										<h3><?php echo e($insurance->defaultLabel); ?></h3>
										<p>This option insures your package for up to <span>€</span><?php echo e($insurance->maxCover); ?></p>
										<?php if($insurance->exVatCost==0): ?>
										<h2 class="pa">FREE</h2>
										<div class="show">
											<i class="fas fa-check"></i>
										</div>
										<?php else: ?>
										<h2>€<?php echo e(number_format((float)$insurance->exVatCost, 2, '.', '')); ?></h2>
										<h6>€<?php echo e(number_format((float)$insurance->totalPayableWithVat, 2, '.', '')); ?> inc VAT</h6>
										<?php if($insurance->code=='UKIC0002'): ?>
										<div class="new-box">
											<div class="pop">
												<span>POPULAR</span>
											</div>
										</div>
										<?php endif; ?>
										<div class="show">
											<i class="fas fa-check"></i>
										</div>
										<?php endif; ?>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
					<?php echo Form::hidden('insuranceCover', old('insuranceCover', 'PERSONAL'), ['required'=>true, 'id'=>'insuranceCover']); ?>

					<?php echo Form::button('<span>Confirm &amp; Book</span>', ['type'=>'submit', 'class'=>'btn_acele btn_black']); ?>

			    </div>
		    </div>
		</div>
	<?php echo Form::close(); ?>

	<!---------- view-csv-modal -------------->
    <div class="modal modal-address" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">csv data</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body table-responsive scroll-inner">
                	<table class="table table-bordered csv_table">
                        <thead>
                            <tr>
                            	<th>#</th>
                                <th>Address One</th>
                                <th>Address Two</th>
                                <th>City</th>
                                <th>Country</th>
                                <th>Postcode</th>
                                <th>Contact Number</th>
                                <th>Contact Name</th>
                                <th>Drop-Off Notes</th>
                                <th>Client Tag</th>
                                <th>Delivery Weight (kilos)</th>
                            </tr>
                        </thead>
                        <tbody id="myTable"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
	<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/book-courier.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/book-courier.js')); ?>"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#cover-'+$('#insuranceCover').val()).addClass('active');
			$('.select_disc').click(function(){
				var $this = $(this);
				$siblings = $this.parent().children(),
				position = $siblings.index($this);
				console.log (position);
				$('.select_disc').removeClass('active').eq(position).addClass('active');
				$siblings.removeClass('active');
				$(".select_disc").removeClass("active");
				$this.addClass('active');
				console.log($('#insuranceCover').val(), $(this).attr('id'));
				$('#insuranceCover').val($(this).data('id'));
			});
			var org_addresses = JSON.parse('<?php echo $org_addresses; ?>');
			$('#addressBookId').change(function(){
				if(org_addresses[$(this).val()]) {
					org_addresse = org_addresses[$(this).val()];
					$('#contactName').val(org_addresse['contactName']);
					$('#contactNumber').val(org_addresse['contactNumber']);
					$('#addressOne').val(org_addresse['addressOne']);
					$('#addressTwo').val(org_addresse['addressTwo']);
					$('#city').val(org_addresse['city']);
					$('#county').val(org_addresse['county']);
					$('#postcode').val(org_addresse['postcode']);
					$('#country').val(org_addresse['country']);
				}
				else {
					$('#contactName, #contactNumber, #addressOne, #addressTwo, #city, #county, #postcode, #country').val(null);
				}
			});
		});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/street-stream/resources/views/jobs/job-booking.blade.php ENDPATH**/ ?>