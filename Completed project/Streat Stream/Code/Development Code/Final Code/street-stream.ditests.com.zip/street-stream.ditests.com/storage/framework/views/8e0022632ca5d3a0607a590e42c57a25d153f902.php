<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $__env->yieldContent('title'); ?></title>
		<link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/home.css')); ?>">
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>?v=1.2">
	</head>
	<body class="body">
		<div class="co_login">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-12">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
				<div class="col-lg-6 col-md-6 col-12">
			    	<div class="login-inner login-bg">
			    	    <div class="login-info">
			    	    	<div class="title_11">
	                        	<h1 class="wave">street stream </h1>
	                        <h1 >Bulk Upload site</h1>
	                        </div>
			    	    	<p>
							Do you have a large number of same-day deliveries to go out at once?  Use this site to upload a file of orders and our machine learning technology will break it down into route-optimised circuits in an efficient manner.
							</p>
							<div class="main_site_buttons">
								<a class="btn_1" href="<?php echo e(config('app.site_url')); ?>">Return to the Main Site</a>
							<!--	<a class="btn_1" href="<?php echo e(config('app.site_url')); ?>booking">Book Couriers</a>-->
							</div>
			    	    </div>
			    	</div>
				</div>
			</div>
		</div>
	</body>
</html>

<?php /**PATH /home/mzldwoswysm5/public_html/street-stream.ditests.com/resources/views/layouts/auth.blade.php ENDPATH**/ ?>