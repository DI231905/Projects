<?php $__env->startSection('title', 'Insurance'); ?>
<?php $__env->startSection('content'); ?>
    <div class="co_select co_insurance">
    	<div class="container">
    		<div class="insurance">
    			<h2>SELECT INSURANCE</h2>
    		</div>
    		<div class="row">
                <?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<div class="col-lg-3 col-md-6 col-12 d-flex">
    				<div class="select_disc">
    					<h3><?php echo e($insurance->defaultLabel); ?></h3>
    					<p>This option insures your package for up to <span>€</span><?php echo e($insurance->maxCover); ?></p>
                        <?php if($insurance->exVatCost==0): ?>
    					<h2 class="pa">FREE</h2>
    					<div class="show">
    						<i class="fas fa-check"></i>
    					</div>
                        <?php else: ?>
                        <h2>€<?php echo e($insurance->exVatCost); ?></h2>
    					<h6>€<?php echo e($insurance->totalPayableWithVat); ?> inc VAT</h6>
                        <?php if($insurance->code=='UKIC0002'): ?>
                        <div class="new-box">
    						<div class="pop">
    						    <span>POPULAR</span>
    					    </div>
    					</div>
                        <?php endif; ?>
    					<div class="show">
    						<i class="fas fa-check"></i>
    					</div>
                        <?php endif; ?>
    				</div>
    			</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</div>
    	</div>
    </div>
    <div class="co_times">
    	<div class="co_timeline1">
	    	<div class="container">
	    		<div class="row">
	    			<div class="col-lg-5 col-md-7 col-12">
	                    <div class="check_btn">
	                    	<button class="btn_acele btn_black"><span>Confirm &amp; Book</span></button>
	                    </div>
	    			</div>
	    		</div>
	    	</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">	
    $('.select_disc').first().addClass('active');
    $('.select_disc').click(function(){
        var $this = $(this);
        $siblings = $this.parent().children(),
        position = $siblings.index($this);
        console.log (position);
        $('.select_disc').removeClass('active').eq(position).addClass('active');
        $siblings.removeClass('active');
        $(".select_disc").removeClass("active");
        $this.addClass('active');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/street-stream/resources/views/jobs/job-insurance.blade.php ENDPATH**/ ?>