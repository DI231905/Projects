<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/home.css')); ?>">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
	<meta name="site-url" content="<?php echo e(url('')); ?>" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body class="body">
	<div class="co_header">
		<div class="container">
			<div class="row row1">
				<div class="col-lg-3">
					<div class="logo">
						<a href="<?php echo e(url('')); ?>"><img src="<?php echo e(asset('image/logo.png')); ?>"></a>
					</div>
				</div>
				<div class="col-lg-9">
					<div class="menu">
						<a href="<?php echo e(config('app.site_url')); ?>jobs/active">Active Jobs</a>
						<a href="<?php echo e(config('app.site_url')); ?>jobs/history">Job History</a>
						<?php if(Session::has('authenticated')): ?>
						<a href="<?php echo e(config('app.site_url')); ?>account">My Account</a>
						<a href="<?php echo e(route('auth.logout')); ?>">Log out</a>
						<?php else: ?>
						<a href="<?php echo e(route('auth.login')); ?>">Log in</a>
						<?php endif; ?>
						<a class="btn_1" href="<?php echo e(route('job.booking')); ?>">Book a Courier</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php echo $__env->yieldContent('content'); ?>
	<div class="co_footer">
		<div class="container">
			<div class="row">
			    <div class="footer">
			    	<div class="logo">
						<a href="<?php echo e(url('')); ?>"><img src="<?php echo e(asset('image/logo1.png')); ?>"></a>
				    </div>
				    <p>Copyright Street Stream® 2021 On Demand Deliveries London</p>
			    </div>
			    <div class="f_1">
			    	<div class="footer-link">
			    		<a href="<?php echo e(config('app.site_url')); ?>about">About us</a>
			    		<a href="<?php echo e(config('app.site_url')); ?>courier">For Couriers</a>
			    		<a href="<?php echo e(config('app.site_url')); ?>contact">Contact</a>
			    		<a href="<?php echo e(config('app.site_url')); ?>faqs">FAQs</a>
			    		<a href="https://github.com/Street-Stream">Developers</a>
			    		<a href="<?php echo e(config('app.site_url')); ?>franchises">Franchises</a>
			    	</div>
			    	<div class="footer-link">
			    		<a href="<?php echo e(config('app.site_url')); ?>/assets/files/customer-terms-conditions.pdf">Terms & Conditions</a>
			    		<a href="<?php echo e(config('app.site_url')); ?>privacy-policy/customers">Privacy Policy - Customers</a>
			    		<a href="<?php echo e(config('app.site_url')); ?>privacy-policy/couriers">Privacy Policy - Couriers</a>
			    		<a href="<?php echo e(config('app.site_url')); ?>assets/files/data-protection-retention-policies.pdf">Data Protection & Data <br>  Retention Policies</a>
			    		<a href="<?php echo e(config('app.site_url')); ?>cookies">Cookie Policy</a>
			    	</div>
			    </div>
			    <div class="footer-link_1">
			    	<p>Follow us</p>
			    	<ul>
			    		<li><a href="https://www.instagram.com/street_stream/"><i class="fab fa-instagram"></i></a></li>
			    		<li><a href="https://twitter.com/iStreetStream/"><i class="fab fa-twitter"></i></a></li>
			    		<li><a href="https://www.facebook.com/streetstream.co.uk/"><i class="fab fa-facebook-f"></i></a></li>
			    	</ul>
			    </div>
			</div>
		</div>
	</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.js"></script>
    <?php echo $__env->yieldContent('styles'); ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/street-stream/resources/views/layouts/app.blade.php ENDPATH**/ ?>