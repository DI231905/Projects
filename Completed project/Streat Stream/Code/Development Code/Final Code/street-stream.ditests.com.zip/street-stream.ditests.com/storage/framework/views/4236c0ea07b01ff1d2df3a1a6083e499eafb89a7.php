<?php $__env->startSection('title', 'Forgot Password'); ?>
<?php $__env->startSection('content'); ?>
	<div class="login-inner">
		<div class="set-login">
			<div class="logo">
			    <h3><a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('image/logo.png')); ?>"></a></h3>
		    </div>
		    <h3>Recover your password</h3>
		    <form>
		    	<div class="text_1 mb-0">
		    		<input type="email" placeholder="Email Address" name="email">
		    	</div>
                <div class="submit-btn">
                	<button class="btn_acele btn_black"><span>send me email</span></button>
                </div>
		    </form>
		    <div class="extra-login clearfix">
                <span>Or Login With</span>
            </div>
            <div class="social-list">
                <a href="#" class="facebook-bg">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a href="#" class="twitter-bg">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="#" class="google-bg">
                    <i class="fab fa-google"></i>
                </a>
                <a href="#" class="linkedin-bg">
                    <i class="fab fa-linkedin-in"></i>
                </a>
            </div>
             <p class="forgot">Already a member? <a href="<?php echo e(route('auth.login')); ?>">Login here</a></p>
	    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/street-stream/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>