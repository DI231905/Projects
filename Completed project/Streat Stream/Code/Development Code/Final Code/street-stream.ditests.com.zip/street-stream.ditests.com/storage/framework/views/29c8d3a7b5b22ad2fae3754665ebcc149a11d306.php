<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<div class="login-inner">
	<div class="set-login">
		<div class="logo">
		    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('image/logo.png')); ?>"></a>
	    </div>
	    <h3>Sign into your account</h3>
        <?php echo Form::open(['route' => 'auth.login']); ?>

	    	<div class="text_1">
                <?php echo Form::email('email', null, ['placeholder'=>'Email Address']); ?>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	    	</div>
	    	<div class="text_1">
                <?php echo Form::password('password', ['placeholder' => 'Password']); ?>

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	    	</div>
            <div class="submit-btn">
            	<!-- <input type="submit" value="Login"> -->
                <?php echo Form::button('<span>submit</span>', ['type'=>'submit', 'class'=>'btn_acele btn_black']); ?>

            </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/street-stream/resources/views/auth/login.blade.php ENDPATH**/ ?>