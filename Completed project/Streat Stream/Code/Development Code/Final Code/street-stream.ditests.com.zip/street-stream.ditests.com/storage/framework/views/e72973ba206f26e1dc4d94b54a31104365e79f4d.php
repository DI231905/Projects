<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $__env->yieldContent('title'); ?></title>
		<link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/home.css')); ?>">
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>">
	</head>
	<body class="body">
		<div class="co_login">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-12">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
				<div class="col-lg-6 col-md-6 col-12">
			    	<div class="login-inner login-bg">
			    	    <div class="login-info">
			    	    	<div class="title_11">
	                        	<h1>welcome to </h1>
	                        	<h1 class="wave">street stream</h1>
	                        </div>
			    	    	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
			    	    </div>
			    	</div>
				</div>
			</div>
		</div>
	</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/street-stream/resources/views/layouts/auth.blade.php ENDPATH**/ ?>