<?php $__env->startSection('content'); ?>
<div class="co-banner1">
      <div class="container">
         <h1>About</h1>
         <ul class="breadcrumb1">
             <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
             <li>/</li>
             <li>About</li>
         </ul>
      </div>
    </div>
    <div class="about-area inc-shape default-padding">
      <div class="container">
         <div class="row">           
            <div class="col-lg-5 offset-lg-1 info" data-aos="fade-up" data-aos-duration="3000">
               <h2>About Us</h2>
               <p>
               Sevn3.ai is a full-services Software Development and Consulting company, transforming businesses through the power of 
               People, Innovative Technologies, and Automated Processes. By utilizing our expertise and years of experience in 
               strategic planning and innovative software technologies, our team of certified experts help clients gain efficiency and 
               productivity, reduce operational and labor costs, ensure compliance, and enable digital transformation.
               </p>
               <p>Thanks to our lean, agile methodology and extensive experience in leading-edge technologies, we can design and 
               develop smart, scalable solutions for any industry. We are committed to always learning and researching new ways to 
               solve old (and new) problems. Our team has experience in designing and developing products for a global marketplace. 
               We help organizations go digital and empower them to grow in an increasingly connected world.</p>
               <button class="button-8"><div class="eff-8"></div><a href="#">Read More</a></button>
            </div>
            <div class="col-lg-6 " data-aos="fade-up" data-aos-duration="3000">
               <div class="them box15">
                  <img src="image/img17.jpg" alt="Thumb">
                  <div class="box-content1"></div>
               </div>
            </div>       
         </div>
      </div>
   </div>
   <div class="about_offer">
      <div class="container">
         <div class="row">
            <div class="col-lg-6" data-aos="fade-up" data-aos-duration="3000">
               <div class="offer_img box14">
                  <img src="image/img8.jpg">
                  <div class="box-content"></div>
               </div>
            </div>
            <div class="col-lg-6" data-aos="fade-up" data-aos-duration="3000">
               <div class="offer_detail">
                  <span>About Us</span>
                  <h2>Without stopping for a moment we give you best technology experience discussing from our expertise to stop threats being theft or damaged.</h2>                  
                  <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" href="#profile" role="tab" data-toggle="tab">What we offer</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#buzz" role="tab" data-toggle="tab">Our Vision</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#references" role="tab" data-toggle="tab">Our Mission</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#profile1" role="tab" data-toggle="tab">Our values</a>
                    </li>
                  </ul>
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="profile">
                        <div class="detail_content">
                           <ul class="content_list">
                              <li>Accelerated product strategizing & road mapping</li>
                              <li>Global product development</li>
                              <li>End to End (Design, prototyping, build, release, maintain) of any application that you may fancy</li>
                              <li>Digital product innovation</li>
                           </ul>
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="buzz">
                        <div class="vision_para">
                           <div class="vi_main vi_mi">
                              <div class="vi-icon-box">
                                 <span class="vi-icon">
                                    <i class="fas fa-building"></i>        
                                 </span>
                              </div>
                              <div class="vi-content">
                                 <p class="vi-description">We believe that every tech product should have an alluring UX UI, no bugs, great speed, and be unique.Our far-sighted vision of looking beyond the clients’ immediate needs, has set a true testimony for us in developing sustainable and successful tech products.It is our brand DNA that has helped us to be consistent during all these years of service:</p>
                              </div>
                           </div>
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="references">
                        <div class="mission_para">
                           <div class="vi_main1">
                              <div class="vi-icon-box">
                                 <span class="vi-icon">
                                    <i class="fas fa-users"></i>        
                                 </span>
                              </div>
                              <div class="vi-content">
                                 <p class="vi-description">Our mission is to give our clients a competitive dvantage and altimate business efficiency through strategic planning, innovative technologies, and streamlined processes,we aspire to deliver competency and excellence to transform every aspect of our clients prganizations.</p>
                              </div>
                           </div>
                        </div>
                    </div>
                     <div role="tabpanel" class="tab-pane" id="profile1">
                        <div class="detail_content">
                           <ul class="content_list">
                              <li>Work with INTEGRITY and PASSION</li>
                              <li>Deliver INNOVATION and EXCELLENCE</li>
                              <li>Be a TRUSTED PARTNER to our clients</li>
                              <li>RESPECT and praise our people</li>
                              <li>GIVE  BACK to the local communities</li>
                              <li>COMMITTED to our clients, people, and partners</li>
                           </ul>
                        </div>
                     </div>
                  </div>
              </div>
            </div>
         </div>
      </div>
   </div>
   <div class="choose">
      <div class="container">
         <h3>Why choose us</h3>
         <div class="row">
            <div class="col-lg-4 or_2" data-aos="fade-up" data-aos-duration="3000">
            <?php $__currentLoopData = $why_choose_odd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$odd_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="bixol-service-item h4-service-column">
                  <div class="bixol-icon-wrapper">
                      <span><i class="<?php echo e($odd_val->icon); ?>"></i></span>
                  </div>
                  <div class="bixol-service-content">
                      <a href="service-details.html" tabindex="-1"><h5><?php echo e($odd_val->title); ?></h5></a>
                      <p><?php echo \Illuminate\Support\Str::limit($odd_val->description, 90, $end='...'); ?></p>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
            <div class="col-lg-4 or_1" data-aos="fade-up" data-aos-duration="3000">
               <div class="h4-service-img">
                  <img src="image/img15.png">
               </div>
            </div>
            <div class="col-lg-4 or_3" data-aos="fade-up" data-aos-duration="3000">
            <?php $__currentLoopData = $why_choose_even; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$ev_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bixol-service-item h4-service-column">
                  <div class="bixol-icon-wrapper">
                     <span><i class="<?php echo e($ev_val->icon); ?>" aria-hidden="true"></i></span> 
                  </div>
                  <div class="bixol-service-content">
                     <a href="service-details.html" tabindex="-1"><h5><?php echo e($ev_val->title); ?></h5></a>
                     <p><?php echo \Illuminate\Support\Str::limit($ev_val->description, 90, $end='...'); ?></p>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>            
         </div>
      </div>
   </div>
   <section class="artist_section">
        <div class="container">
            <div class="artist">
                <h3>Our Team</h3>
            </div>
            <div class="artist_main" data-aos="fade-up" data-aos-duration="1000">
                <div class="row slider_div">
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col column">
                        <div class="artist_image effect-3">
                           <div class="effect-img">
                               <img src="uploads/<?php echo e($team->image); ?>" height="250px" width="100%">
                           </div>
                           <div class="effect-text">
                              <div class="social so_1">
                                <ul>
                                   <li><a href="<?php echo e($team->fblink); ?>"><i class="fab fa-facebook-f"></i></a></li>
                                   <li><a href="<?php echo e($team->twitterlink); ?>"><i class="fab fa-twitter"></i></a></li>
                                   <li><a href="<?php echo e($team->instalink); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                                </ul>
                              </div>
                           </div>
                            <div class="artist_image1">
                                <h3><?php echo e($team->name); ?> </h3>
                                <h4><?php echo e($team->occupation); ?></h4>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
            </div> 
        </div>
    </section>
  
   
<?php $__env->stopSection(); ?>

     
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/sevn3.ai/resources/views/about.blade.php ENDPATH**/ ?>