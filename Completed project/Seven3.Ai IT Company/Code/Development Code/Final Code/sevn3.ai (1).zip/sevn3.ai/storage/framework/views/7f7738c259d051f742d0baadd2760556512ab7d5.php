<!DOCTYPE html>
<html>
<head>
    <title>R&R Transportation Inc.</title>
    <link rel="stylesheet" type="text/css" href="/css/main-dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   
      <link rel="icon" type="image/png" href="/image/logo1.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style type="text/css">
      .tittle12{

        font-size: 17px;
    font-weight: 600;
    position: relative;
    padding-top: 10px;
    text-transform: capitalize;
      }
      .service-update1{
    background: white;
    padding: 12px 20px 17px 35px;
    display: none;
}
.service-update1 a {
    color: #f17ac1;
    font-size: 15px;
    font-weight: 600;
    text-decoration: underline;
    display: block;
    position: relative;
}
.down1{
  float: right;
}
.service-update1 a:before {
    content: '';
    position: absolute;
    top: 8px;
    left: -17px;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #f17ac1;
    display: block;
}
/*.none1, .none2{
  display: none!important;
}*/

.active .service-update1 {
    display: block;
}

    </style>


</head>
<body class="body">
    <div class="mobile-view">
        <div class="row">
            <div class="col-md-6 col-6 logo1">
                <img src="/image/logo_1.png">
            </div>
            <div class="col-md-6 col-6">
                <div class="mobile-menu">
                    <div id="mySidepanel" class="sidepanel">
                        <div class="m_menu">
                            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a>  
                            <div class="top-nav-wrapper">
                                <div class="top-nav">                       
                                    <div class="co_profile">
                                        <div class="profile-img">
                                           
                                        </div>
                                        <div class="user-details">
                                            <span id="more-details">Sevn3.ai<i class="fa fa-caret-down"></i></span>
                                        </div>
                                    </div>
                                    <div class="main-menu-content">
                                        <ul>   
                                            <li class="more-details">
                                             <i class="" aria-hidden="true"></i><a href="<?php echo e(url('admin/changepassword')); ?>">change password</a>
                                           </li><br>

                                            <li class="more-details">
                                                <i class="fa fa-lock" aria-hidden="true"></i><a href="<?php echo e(route('adminlogout')); ?>">Logout</a>
                                            </li>
                                        </ul>

                                    </div>
                                    <div class="nav-slider"></div>


                                     <div class="hosting dash">
                                       <div class="hosting-btn nav-btn"> Home <i class="fas fa-chevron-right"></i> Truckload Inquiry</div>
                                     </div>

                                       <div class="quteo2 dash">
                                       <div class="quteo2-btn nav-btn">Home <i class="down1 fa fa-caret-down"></i>

                                      <div class="service-update1 none">
                                       <a href="<?php echo e(url('admin/addproduct')); ?>">ADD product OR Update product</a>
                                     </div>

                                     </div>
                                    </div>
                                    

                                     <div class="quteo1 dash">
                                       <div class="quteo1-btn nav-btn">About Us
                                       <div class="service-update1 none">
                                            <a href="<?php echo e(url('admin/addwhychooseus')); ?>">Why choose us</a>
                                        </div>
                                        <div class="service-update1 none">
                                            <a href="<?php echo e(url('admin/teamview')); ?>">Team</a>
                                        </div>
                                        </div>
                                     </div>

                                      <div class="career dash">
                                        <div class="career-btn nav-btn">Portfolio<i class="down1 fa fa-caret-down"></i>
                                            <div class="service-update1 none">
                                               <a href="<?php echo e(url('admin/addportfolio')); ?>">ADD Portfolio OR Update portfolio</a>
                                            </div>
                                            <div class="service-update1 none">
                                           <a href="<?php echo e(url('admin/add_category')); ?>">Add Portfolio Type</a>

                                          
                                            </div>


                                        </div>
                                   
                                    </div>

                                <div class="dryfruit dash">
                                    <div class="dryfruit-btn dryfruit-btn1 nav-btn">Service <i class="down1 fa fa-caret-down"></i>
                                     <div class="service-update1 none">
                                  <a href="<?php echo e(url('admin/addserviceview')); ?>">ADD Service OR Update Service</a>
                              </div>
                            </div>
                           
                         </div>
                                     <div class="domains dash">
                            <div class="domain-btn nav-btn"> Product detail <i class="down1 fa fa-caret-down"></i>
                               <div class="service-update1 none">
                                    <a href="<?php echo e(url('admin/add_productdetail')); ?>">Add product Detail</a> 
                              </div>
                             </div>
                        </div>
 <!-- 

                                     <div class="marketplace dash">
                                        <div class="marketplace-btn nav-btn">Admin Detail </div>
                                    </div>
                                     
                                     <div class="manage-account dash">
                                       <div class="manage-account-btn nav-btn">Gallary </div>
                                    </div>
                                     <div class="message dash">
                                       <div class="message-btn nav-btn">Open Position </div>
                                    </div>
                                    <div class="team dash">
                                        <div class="team-btn nav-btn">Team</div>
                                    </div> 
                                     <div class="category dash">
                                        <div class="category-btn nav-btn">Testimonial</div>
                                    </div>
                                    <div class="faq dash">
                                        <div class="faq-btn nav-btn">FAQ</div>
                                    </div> -->
                                    
                                   
                                    <div class="nav-slider"></div>
                                </div>
                            </div> 
                        </div>
                    </div>
                    <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                </div>
            </div>
        </div> 
    </div>
    <div class="row">
        <div class="col-xl-3 col-lg-3 col-md-6">
            <div class="two">
                <div class="top-nav-wrapper">
                    <div class="top-nav">
                        <div class="logo">
                            <img src="/image/logo_1.png">
                        </div>
                        <div class="co_profile">
                            <div class="profile-img">
                               
                            </div>
                            <div class="user-details">
                                <span id="more-details">Sevn3.ai<i class="fa fa-caret-down"></i></span>
                            </div>
                        </div>
                        <div class="main-menu-content">
                                  <ul>                                  
                                      <li class="more-details">
                                         <i class="" aria-hidden="true"></i><a href="<?php echo e(url('admin/changepassword')); ?>">change password</a>
                                      </li><br>  
                                       <li class="more-details">
                                          <i class="fa fa-lock" aria-hidden="true"></i><a href="<?php echo e(route('adminlogout')); ?>">Logout</a>
                                      </li>
                                  </ul>
                              </div>
                        <div class="nav-slider"></div>
                        <!-- <div class="dashboard dash">
                            <button class="active dashboard-btn nav-btn">Details List</button>
                        </div> -->
                        <div class="hosting dash">
                            <div class="hosting-btn nav-btn"> Contact us</div>
                        </div>

                         <div class="quteo2 dash">
                             <div class="quteo2-btn nav-btn">Home <i class="down1 fa fa-caret-down"></i>

                              <div class="service-update1 none">
                                 <a href="<?php echo e(url('admin/addproduct')); ?>">ADD product OR Update product</a>
                              </div>

                             </div>
                        </div>
                                   <div class="quteo1 dash">
                                       <div class="quteo1-btn nav-btn">About Us<i class="down1 fa fa-caret-down"></i>
                                       <div class="service-update1 none">
                                            <a href="<?php echo e(url('admin/addwhychooseus')); ?>">Why choose us</a>
                                        </div>
                                         <div class="service-update1 none">
                                            <a href="<?php echo e(url('admin/teamview')); ?>">Team</a>
                                        </div>
                                       <!--  <div class="service-update1 none">
                                            <a href="<?php echo e(url('admin/teamview')); ?>">Mission_Vision</a>
                                        </div> -->
                                      </div>
                                     </div>

                              <div class="career dash">
                                        <div class="career-btn nav-btn">Portfolio<i class="down1 fa fa-caret-down"></i>
                                            <div class="service-update1 none">
                                               <a href="<?php echo e(url('admin/addportfolio')); ?>">ADD Portfolio OR Update portfolio</a>
                                            </div>
                                            <div class="service-update1 none">
                                           <a href="<?php echo e(url('admin/add_category')); ?>">Add Portfolio Type</a>

                                          
                                            </div>


                                        </div>
                                    </div>
                        
                          <div class="dryfruit dash">
                            <div class="dryfruit-btn dryfruit-btn1 nav-btn"> Home & Services  <i class="fas fa-chevron-right"></i> Service <i class="down1 fa fa-caret-down"></i>
                              <div class="service-update1 none">
                                  <a href="<?php echo e(url('admin/addserviceview')); ?>">ADD Service OR Update Service</a>
                              </div>
                            </div>
                           
                         </div>

                        <div class="domains dash">
                            <div class="domain-btn nav-btn"> Product detail <i class="down1 fa fa-caret-down"></i>
                               <div class="service-update1 none">
                                    <a href="<?php echo e(url('admin/add_productdetail')); ?>">Add product Detail</a> 
                              </div>
                             </div>
                        </div>
                        <div class="marketplace dash">
                            <div class="marketplace-btn nav-btn"> Admin Detail </div>
                        </div>
                        <!--  <div class="manage-account dash">
                            <div class="manage-account-btn nav-btn">Gallary <i class="down1 fa fa-caret-down"></i> 

                          <div class="service-update1 none">
                                  <a href="#">ADD Service </a><a href="#">Update Service</a>
                              </div>
                            </div>
                        </div>
                         <div class="message dash">
                            <div class="message-btn nav-btn" >Career <i class="fas fa-chevron-right"></i> Open posts <i class="down1 fa fa-caret-down"></i>
                                <div class="service-update1 none">
                                  <a href="#">ADD Service </a><a href="#">Update Service</a>
                              </div>

                            </div>
                        </div> 
                        <div class="team dash">
                          <div class="team-btn nav-btn">Team <i class="down1 fa fa-caret-down"></i><div class="service-update1">
                                  <a href="#">ADD Team</a>
                              </div></div>
                          
                       </div>
                        <div class="category dash">
                            <div class="category-btn nav-btn"> Home <i class="fas fa-chevron-right"></i> Testimonial </div>
                        </div> 
                        <div class="faq dash">
                            <div class="faq-btn nav-btn"> About Us <i class="fas fa-chevron-right"></i> FAQ</div>
                        </div>
                         -->
                        
                        <div class="nav-slider"></div>
                    </div>
                </div>
            </div>
        </div>

     <div class="col-xl-9 col-lg-9 col-md-12 dash-11">
          <?php if($message = Session::get('error')): ?>
            <div  id="hideDiv" class="alert alert-success alert-block" >
                <!--     <input type="text" class="close" data-dismiss="alert"></input> -->
                <strong style="padding-top : 5px !important; display: inline-block;"><?php echo e($message); ?></strong>
             </div>
           <?php endif; ?>



           <div class="page mt-4 hosting-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">contact us<span class="tittle12"></span></h4>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile NO.</th>
                                    <th>Message</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             
                            <tbody>
                             
                                <tr class="queto_">
                                    <td>
                                      
                                    </td>
                                

                                    <td>
                                       
                                    </td>
                                    <td>
                                      
                                    </td>
                                     <td>
                                       
                                    </td>
                                    

                                   
                                    <td><button class="btn3 btn0" onclick="deletequeto()"><i class="fa fa-trash" aria-hidden="true"></button></td>
                                </tr>
                                
                            </tbody>
                           
                        
                        </table> 
                    </div>
                </div> 
            </div> 


                          <!-- admindetail list --> 
           <div class="page mt-4 marketplace-page title1">
                <div class="mt-5">
                    <h4 class="mb-4"> Admin Details List</h4>
                     <div class="detail">
                       <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile no</th>
                                    <th>Address</th>
                              
                                    <th>Facebook URL</th>
                                    <th>Instagram URL</th>
                                    <th>Twitter URL</th>
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                               <?php $__currentLoopData = $admindetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                                
                                <tr>
                                    <td>
                                        <?php echo e($a->name); ?>

                                    </td>
                                
                    
                                    <td>
                                          <?php echo e($a->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($a->mobileno); ?>

                                    </td>
                                    <td>
                                        <?php echo e($a->address); ?>

                                   </td>
                                  
                                   <td>
                                        <?php echo e($a->fblink); ?>

                                   </td>
                                   <td>
                                        <?php echo e($a->instalink); ?>

                                   </td>
                                   <td>
                                        <?php echo e($a->twitterlink); ?>

                                   </td>
                                  
                             <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateadmindetail')); ?>/<?php echo e($a->id); ?>">Update</a></button></td>
                                   
                               
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>

              <!-- service list --> 
         <div class="page mt-4 dryfruit-page title1">
                   <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Services</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addserviceview')); ?>"style="color:white">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Icon</th>
                                  
                                    <th>Name</th>
                                    <th>Description</th> 
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                           <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr class="service_<?php echo e($s->id); ?>">
                                    <td>

                                       <i class="<?php echo e($s->icon); ?>"></i>
                                        
                                         
                                    </td>

                                     <td>
                                      <?php echo e($s->name); ?>

                                    </td>
                                   
                                    <td>
                                    <?php echo $s->description; ?>

                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateservice')); ?>/<?php echo e($s->id); ?>" >Update</a></button></td>
                                    <td><button class="btn3 btn0" onclick="deleteservice(<?php echo e($s->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </table>
                    </div>
                 </div>
            </div> 

               <!--    Career Application---- -->
        <div class="page mt-4 career-page title1">
                <div class="mt-5">
                   <div class="list1">
                    <h4 class="mb-4">Portfolio List</h4>
                     <button class="btn1"><a href="<?php echo e(url('admin/addportfolio')); ?>"style="color:white">ADD</a></button>
                   </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Category Type</th>
                                     <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="portfolio_<?php echo e($p->id); ?>">
                                    <td>
                                         <img src="/uploads/<?php echo e($p->image); ?>" width="60" height="60"><br>
                                         <?php echo e($p->image); ?> 
                                    </td>
                                

                                    <td>
                                          <?php echo e($p->name); ?>

                                    </td>
                                   
                                   
                                    <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateportfolio')); ?>/<?php echo e($p->id); ?>">Update</a></button></td> 
    
                                   <td><button class="btn3 btn0" onclick="deleteportfolio(<?php echo e($p->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></button></td> 
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </table>
                    </div>
                </div> 
            </div> 

              <div class="page mt-4 quteo2-page title1">
                <div class="mt-5">
                     <div class="list1">
                    <h4 class="mb-4">PRODUCT LIST <span>[Home <i class="fa fa-angle-right"></i>product]</span></h4>
                       <button class="btn1"><a href="<?php echo e(url('admin/addproduct')); ?>"style="color:white">ADD</a></button>
                     </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>View</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                              <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                             
                                <tr class="product_<?php echo e($p->id); ?>">
                                    <td>
                                      <?php echo e($p->name); ?>

                                    </td>
                                

                                    <td>
                                        <?php echo $p->description; ?>

                                    </td>
                                   
                                  
                                    <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateproduct')); ?>/<?php echo e($p->id); ?>">update</a></button></td>

                                  
                                    <td><button class="btn3 btn0" onclick="deleteproduct(<?php echo e($p->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </table> 
                    </div>
                </div> 
            </div> 
            <div class="page mt-4 quteo1-page title1">
                <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4">WHY CHOOSE US</h4>
                         <button class="btn1"><a href="<?php echo e(url('admin/addwhychooseus')); ?>"style="color:white">ADD</a></button> 
                    </div>
                       <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr >
                        
                                    <th>icon</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <?php $__currentLoopData = $whychooseus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>

                                <tr class="whychooseus_<?php echo e($w->id); ?>">
                                    <td>
                                        
                                       <i class="<?php echo e($w->icon); ?>"></i>
                                    </td>
                                    <td>
                                        <?php echo e($w->title); ?>

                                     </td>
                                   

                                     <td><?php echo $w->description; ?></td>

                                <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updatewhychooseus')); ?>/<?php echo e($w->id); ?>">update</a></button></td>



                         
                                  <td><button class="btn3 btn0" onclick="deletewhychooseus(<?php echo e($w->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></a></button></td>
                                </tr>
                          
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                        </table>
                    </div>
                </div>


                 <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4">TEAM </h4>
                         <button class="btn1"><a href="<?php echo e(url('admin/addwhychooseus')); ?>"style="color:white">ADD</a></button> 
                    </div>
                       <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                        
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Occupation</th>
                                    <th>facebook URL</th>
                                    <th>Instagram URL</th>
                                    <th>Twitter URL</th>
                                    <th>update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>

                                <tr class="team_<?php echo e($t->id); ?>">
                                    <td>
                                         <img src="/uploads/<?php echo e($t->image); ?>" width="60" height="60"><br>
                                         <?php echo e($t->image); ?>  
                                      
                                    </td>
                                    <td>
                                       <?php echo e($t->name); ?>  
                                     </td>
                                   

                                     <td><?php echo e($t->occupation); ?></td>

                                     <td><?php echo e($t->fblink); ?></td>

                                     <td><?php echo e($t->instalink); ?></td>

                                     <td><?php echo e($t->twitterlink); ?></td>

                                <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/teamupdate')); ?>/<?php echo e($t->id); ?>">update</a></button></td>

                                  <td><button class="btn3 btn0" onclick="teamdelete(<?php echo e($t->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></a></button></td>
                                </tr>
                          
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                        </table>
                    </div>
                </div>
            </div>  


              <div class="page mt-4 domain-page title1">
                <div class="mt-5">
                   <div class="list1">
                    <h4 class="mb-4">Product Detail List</h4>
                      <button class="btn1"><a href="<?php echo e(url('admin/add_productdetail')); ?>"style="color:white">ADD</a></button> 
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>short description</th>
                                    <th>description</th>
                                    <th>update</th>
                                    <th>Delete</th>

                                </tr>
                            </thead>
                              <?php $__currentLoopData = $productdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                             
                                <tr class="productdetail_<?php echo e($p->id); ?>">
                                    <td>
                                       <img src="/uploads/<?php echo e($p->image); ?>" width="60" height="60"><br>
                                      <?php echo e($p->image); ?>

                                    </td>
                                

                                    <td>
                                        <?php echo e($p->name); ?>

                                    </td>
                                    <td>
                                       <?php echo e($p->short_desc); ?>

                                    </td>
                                    <td>
                                       <?php echo $p->description; ?>

                                   </td>

                                    <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateproductdetail')); ?>/<?php echo e($p->id); ?>">update</a></button></td>
                        
                                    <td><button class="btn3 btn0" onclick="deleteproductdetail(<?php echo e($p->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </table>
                    </div>
                </div>  




    

                         
  
          
       </div>
   </div>  

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
   

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">
                  function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
                  function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

        function openForm() {
          document.getElementById("myForm").style.display = "block";
           }
           $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });


           $('.dash>div').click(function(){
         //   alert("test");
           // $('.dryfruit-btn1').find('.active').addClass("test123");
            $(".active").children(".service-update1").slideToggle('slow');
           // $('.service-update1').slideToggle('slow');
           });

           

          /* $(function(){
  
  // Prevent two submenus from being opened at once
  $('.top-nav .dash').on('click',function(event){
//$(this).parent().find('.service-update1').first().toggle(300);  
//$(this).parent().siblings().find('.service-update1').hide(200);
     event.preventDefault()
  });
});*/


function deleteservice($id){

     if(confirm("do you want delete this service ?")){
             $.ajax({

                url:'deleteservice/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.service_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
    
                  },        
          
                });

          }
      }

           



            function deleteportfolio($id){

     if(confirm("do you want delete this application ?")){
             $.ajax({

                url:'deleteportfoilo/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.portfolio_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }         




function deleteproduct($id){
    // alert('i am here');

     if(confirm("do you want delete this Inquiry ?")){
             $.ajax({

                url:'deleteproduct/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.product_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      } 


  function deletewhychooseus($id){

     if(confirm("do you want delete this Inquiry ?")){
             $.ajax({

                url:'deletewhychooseus/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.whychooseus_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      } 

       function teamdelete($id){

     if(confirm("do you want delete this Team member ?")){
             $.ajax({

                url:'teamdelete/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.team_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
    
                  },        
          
                });

          }
      }

 


   function deleteproductdetail($id){

     if(confirm("do you want delete this vacancy ?")){
             $.ajax({

                url:'deleteproductdetail/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.productdetail_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }         




 function deletecontact($id){

     if(confirm("do you want delete this message ?")){
             $.ajax({

                url:'deletecontact/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.contact_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
    
                  },        
          
                });

          }
      }



 

      function deletefaq($id){

     if(confirm("do you want delete this question ?")){
             $.ajax({

                url:'deletefaq/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.faq_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
    
                  },        
          
                });

          }
      }
          

 
     function deleteinquiry($id){

     if(confirm("do you want delete this record ?")){
             $.ajax({

                url:'deleteenquiry/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.enquires_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }


       function deletetestimonial($id){

     if(confirm("do you want delete this testimonial ?")){
             $.ajax({

                url:'deletetestimonial/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.testimonial_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
 

                 
                  },        
          
                });

          }
      }

     
         function deleteimage($id){

    if(confirm("do you want delete this record ?")){
             $.ajax({

                url:'deleteimage/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                       alert('success');
          
                        },

      error: function(response) {
 
        
          var v='image_'+$id;
          /* alert('.image_'+$id);*/

            $('.image_'+$id).hide();  
    /* var x = document.getElementById('image_'+$id);
         
              x.style.display = "none";*/
                 
                  },        
          
                });


          
          }
      }
        


    $(document).ready(function(){
       
        $(".user-details").click(function(){
            $(".main-menu-content").slideToggle("slow");
        })

        // $(".dryfruit-btn").click(function(){
        //     $(".main-menu-content").slideToggle("slow");
        // })

        $(".btn1").click(function(){
            $(".page1").show();
            $(".hosting-page").hide();
        })

       $("button.btn1.btn2").click(function(){
             $(".page2").show();
             $(".page1").hide();
            $(".dryfruit-page").hide();
         })
      });

    var tl = new TimelineMax();

//Logos
TweenMax.set('.wp-logo', { scale: 1 })
TweenMax.set('.weebly-logo', { scale: 1 })  

// Pages 
TweenMax.set('.dashboard-page', { display: 'none' })
TweenMax.set('.hosting-page', { display: 'block' })
TweenMax.set('.marketplace-page', { display: 'none' })
TweenMax.set('.domain-page', { display: 'none' })
TweenMax.set('.message-page', { display: 'none' })
TweenMax.set('.manage-account-page', { display: 'none' })
TweenMax.set('.dryfruit-page', { display: 'none' })
TweenMax.set('.category-page', { display: 'none' })
TweenMax.set('.team-page', { display: 'none' })
TweenMax.set('.faq-page', { display: 'none' })
TweenMax.set('.career-page', { display: 'none' })
TweenMax.set('.quteo1-page', { display: 'none' })
TweenMax.set('.quteo2-page', { display: 'none' })




TweenMax.to('.mobile-nav', 0, { x: -300 })

/* Message Btn Starts */
$('.message-btn').on('click', function(){  
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.manage-account-page').css({ display: 'none' })
   $('.message-page').css({ display: 'block' })
    $('.manage-account-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
     $('.team-page').css({ display: 'none' })
     $('.faq-page').css({ display: 'none' })
      $('.career-page').css({ display: 'none' })
       $('.quteo1-page').css({ display: 'none' })
        $('.quteo2-page').css({ display: 'none' })
  
     });
/* Message Btn Ends */

// Manage Account Btn STARTS
$('.message-btn').on('click', function(){  
    $(this).addClass('active').removeClass('nav-btn');
    $('.marketplace-btn').removeClass('active').addClass('nav-btn');
    $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.hosting-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.dashboard-btn').removeClass('active').addClass('nav-btn');
    $('.manage-account-btn').removeClass('active').addClass('nav-btn');
    $('.team-btn').removeClass('active').addClass('nav-btn');
    $('.faq-btn').removeClass('active').addClass('nav-btn');
     $('.career-btn').removeClass('active').addClass('nav-btn');
     $('.quteo1-btn').removeClass('active').addClass('nav-btn');
     $('.quteo2-btn').removeClass('active').addClass('nav-btn');

   
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.manage-account-page').css({ display: 'none' })
   $('.message-page').css({ display: 'block' })
   $('.dryfruit-page').css({ display: 'none' })
   $('.category-page').css({ display: 'none' })
   $('.team-page').css({ display: 'none' })
   $('.faq-page').css({ display: 'none' })
    $('.career-page').css({ display: 'none' })
     $('.quteo1-page').css({ display: 'none' })
     $('.quteo2-page').css({ display: 'none' })
  

    });

$('.manage-account-btn').on('click', function(){
    $(this).addClass('active').removeClass('nav-btn');
    $('.marketplace-btn').removeClass('active').addClass('nav-btn');
    $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.hosting-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.dashboard-btn').removeClass('active').addClass('nav-btn');
    $('.message-btn').removeClass('active').addClass('nav-btn');
    $('.team-btn').removeClass('active').addClass('nav-btn');
    $('.faq-btn').removeClass('active').addClass('nav-btn');
    $('.career-btn').removeClass('active').addClass('nav-btn');
     $('.quteo1-btn').removeClass('active').addClass('nav-btn');
      $('.quteo2-btn').removeClass('active').addClass('nav-btn');
   
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.message-page').css({ display: 'none' })
  $('.manage-account-page').css({ display: 'block' })
  $('.account-info-drop-down').css({ display: 'none' })
  $('.dryfruit-page').css({ display: 'none' })
  $('.category-page').css({ display: 'none' })
   $('.team-page').css({ display: 'none' })
     $('.faq-page').css({ display: 'none' })
      $('.career-page').css({ display: 'none' })
       $('.quteo1-page').css({ display: 'none' })
       $('.quteo2-page').css({ display: 'none' })
  
    });

    $('.hosting-btn').on('click', function() {
        $(this).addClass('active').removeClass('nav-btn');
        $('.dashboard-btn').removeClass('active').addClass('nav-btn');
        $('.marketplace-btn').removeClass('active').addClass('nav-btn');
        $('.domain-btn').removeClass('active').addClass('nav-btn');
        $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
        $('.message-btn').removeClass('active').addClass('nav-btn'); 
        $('.manage-account-btn').removeClass('active').addClass('nav-btn');
         $('.team-btn').removeClass('active').addClass('nav-btn');  
        $('.faq-btn').removeClass('active').addClass('nav-btn');
        $('.career-btn').removeClass('active').addClass('nav-btn');
         $('.quteo1-btn').removeClass('active').addClass('nav-btn');
          $('.quteo2-btn').removeClass('active').addClass('nav-btn');

        $('.dashboard-page').css({ display: 'none' })
        $('.hosting-page').css({ display: 'block' })
        $('.marketplace-page').css({ display: 'none' })
        $('.domain-page').css({ display: 'none' })
        $('.message-page').css({ display: 'none' })
         $('.manage-account-page').css({ display: 'none' })
         $('.dryfruit-page').css({ display: 'none' })
          $('.category-page').css({ display: 'none' })
          $('.team-page').css({ display: 'none' })
            $('.faq-page').css({ display: 'none' })
             $('.career-page').css({ display: 'none' })
              $('.quteo1-page').css({ display: 'none' })
              $('.quteo2-page').css({ display: 'none' })
  
  
    });

$('.marketplace-btn').on('click', function(){
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
         $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
      $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn');
     $('.team-btn').removeClass('active').addClass('nav-btn'); 
    $('.faq-btn').removeClass('active').addClass('nav-btn');
    $('.career-btn').removeClass('active').addClass('nav-btn');
     $('.quteo1-btn').removeClass('active').addClass('nav-btn');
      $('.quteo2-btn').removeClass('active').addClass('nav-btn');
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'block' })
     $('.domain-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.category-page').css({ display: 'none' })
       $('.team-page').css({ display: 'none' })
        $('.faq-page').css({ display: 'none' })
         $('.career-page').css({ display: 'none' })
          $('.quteo1-page').css({ display: 'none' })
          $('.quteo2-page').css({ display: 'none' })
  
       


   });

$('.domain-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
      $('.team-btn').removeClass('active').addClass('nav-btn');
      $('.faq-btn').removeClass('active').addClass('nav-btn');
      $('.career-btn').removeClass('active').addClass('nav-btn');
       $('.quteo1-btn').removeClass('active').addClass('nav-btn');
        $('.quteo2-btn').removeClass('active').addClass('nav-btn');

     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.domain-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
       $('.category-page').css({ display: 'none' })
        $('.team-page').css({ display: 'none' })
         $('.faq-page').css({ display: 'none' })
          $('.career-page').css({ display: 'none' })
           $('.quteo1-page').css({ display: 'none' })
           $('.quteo2-page').css({ display: 'none' })
  


   });

$('.dryfruit-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
     $('.team-btn').removeClass('active').addClass('nav-btn');
     $('.faq-btn').removeClass('active').addClass('nav-btn');
     $('.career-btn').removeClass('active').addClass('nav-btn');
      $('.quteo1-btn').removeClass('active').addClass('nav-btn');
       $('.quteo2-btn').removeClass('active').addClass('nav-btn');
 $(".page1").hide();
  $(".page2").hide();
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })
       $('.category-page').css({ display: 'none' })
       $('.team-page').css({ display: 'none' })
        $('.faq-page').css({ display: 'none' })
         $('.career-page').css({ display: 'none' })
          $('.quteo1-page').css({ display: 'none' })
          $('.quteo2-page').css({ display: 'none' })
  

   });

$('.category-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
      $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn');
      $('.team-btn').removeClass('active').addClass('nav-btn');
      $('.faq-btn').removeClass('active').addClass('nav-btn');
      $('.career-btn').removeClass('active').addClass('nav-btn');
       $('.quteo1-btn').removeClass('active').addClass('nav-btn');
        $('.quteo2-btn').removeClass('active').addClass('nav-btn'); 
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })
       $('.team-page').css({ display: 'none' })
        $('.faq-page').css({ display: 'none' })
         $('.career-page').css({ display: 'none' })
          $('.quteo1-page').css({ display: 'none' })
          $('.quteo2-page').css({ display: 'none' })
  

  });

$('.team-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
      $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
      $('.faq-btn').removeClass('active').addClass('nav-btn'); 
      $('.career-btn').removeClass('active').addClass('nav-btn');
       $('.quteo1-btn').removeClass('active').addClass('nav-btn');
        $('.quteo2-btn').removeClass('active').addClass('nav-btn');
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })
       $('.team-page').css({ display: 'block' })
        $('.faq-page').css({ display: 'none' })
         $('.career-page').css({ display: 'none' })
          $('.quteo1-page').css({ display: 'none' })
          $('.quteo2-page').css({ display: 'none' })
  

  });

$('.faq-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
      $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
      $('.team-btn').removeClass('active').addClass('nav-btn'); 
      $('.career-btn').removeClass('active').addClass('nav-btn');
       $('.quteo1-btn').removeClass('active').addClass('nav-btn');
        $('.quteo2-btn').removeClass('active').addClass('nav-btn');
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })
       $('.team-page').css({ display: 'none' })
        $('.faq-page').css({ display: 'block' })
         $('.career-page').css({ display: 'none' })
          $('.quteo1-page').css({ display: 'none' })
          $('.quteo2-page').css({ display: 'none' })
  

  });


$('.career-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
      $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
      $('.team-btn').removeClass('active').addClass('nav-btn'); 
      $('.faq-btn').removeClass('active').addClass('nav-btn');
       $('.quteo1-btn').removeClass('active').addClass('nav-btn');
        $('.quteo2-btn').removeClass('active').addClass('nav-btn');
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })
       $('.team-page').css({ display: 'none' })
        $('.faq-page').css({ display: 'none' })
         $('.career-page').css({ display: 'block' })
          $('.quteo1-page').css({ display: 'none' })
          $('.quteo2-page').css({ display: 'none' })
  

  });

$('.quteo1-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
      $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
      $('.team-btn').removeClass('active').addClass('nav-btn'); 
      $('.faq-btn').removeClass('active').addClass('nav-btn');
       $('.career-btn').removeClass('active').addClass('nav-btn');
        $('.quteo2-btn').removeClass('active').addClass('nav-btn');
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })
       $('.team-page').css({ display: 'none' })
        $('.faq-page').css({ display: 'none' })
         $('.career-page').css({ display: 'none' })
          $('.quteo1-page').css({ display: 'block' })
          $('.quteo2-page').css({ display: 'none' })
  

  });
$('.quteo2-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
      $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
      $('.team-btn').removeClass('active').addClass('nav-btn'); 
      $('.faq-btn').removeClass('active').addClass('nav-btn');
       $('.career-btn').removeClass('active').addClass('nav-btn');
        $('.quteo1-btn').removeClass('active').addClass('nav-btn');
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })
       $('.team-page').css({ display: 'none' })
        $('.faq-page').css({ display: 'none' })
         $('.career-page').css({ display: 'none' })
          $('.quteo1-page').css({ display: 'none' })
          $('.quteo2-page').css({ display: 'block' })
  

  });
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\IT_solution\resources\views/admin/home.blade.php ENDPATH**/ ?>