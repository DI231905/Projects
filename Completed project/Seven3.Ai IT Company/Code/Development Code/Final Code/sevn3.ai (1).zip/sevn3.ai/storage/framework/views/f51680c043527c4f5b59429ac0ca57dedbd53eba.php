<?php $__env->startSection('content'); ?>
<div class="co-banner1">
        <div class="container">
            <h1>Service</h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li>/</li>
                <li>Service</li>
            </ul>
        </div>
    </div>
    <section class="service">
      <div class="container">
         <div class="ser_head">
           <h2>Our Services</h2>
           <div class="row">
           <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-4 col-md-6" data-aos="flip-left" data-aos-easing="ease-out-cubic" data-aos-duration="2000">
                  <div class="ser_first_main">
                     <div class="ser_first">
                       <div class="fi_icon"><i class="<?php echo e($service->icon); ?>"></i></div>
                       <h3><?php echo e($service->name); ?></h3>
                       <p><?php echo \Illuminate\Support\Str::limit($service->description, 90, $end='...'); ?> </p>
                     </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
           </div>
         </div>
      </div>
   </section>  
   
<?php $__env->stopSection(); ?>

     
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/sevn3.ai/resources/views/service.blade.php ENDPATH**/ ?>