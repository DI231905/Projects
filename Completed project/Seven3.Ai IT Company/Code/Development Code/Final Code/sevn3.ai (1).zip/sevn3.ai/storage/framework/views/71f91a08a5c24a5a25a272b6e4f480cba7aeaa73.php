<?php $__env->startSection('content'); ?>
<div class="co-banner1">
        <div class="container">
            <h1>Portfolio</h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li>/</li>
                <li>Portfolio</li>
            </ul>
        </div>
    </div>
    <section>
    	<div class="in_port">
    		<div class="container">
    			<div class="tab1" data-aos="fade-up" data-aos-duration="3000">
             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $folio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if($key == 0): ?> 
             <button class="tablinks1" onclick="openCity(event, '<?php echo e($folio->id); ?>')"  id="defaultOpen"><?php echo e($folio->name); ?></button>
             <?php else: ?>
             <button class="tablinks1" onclick="openCity(event, '<?php echo e($folio->id); ?>')"><?php echo e($folio->name); ?></button>
             <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
				</div>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $folio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            <div id="<?php echo e($folio->id); ?>" class="tabcontent1" data-aos="fade-up" data-aos-duration="3000">
				    <section id="gallery">
						<div class="container">
						  <div id="image-gallery">
						    <div class="row">
                         <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if($val->category_id == $folio->id): ?>   
                      <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 image pro_div">
						      	 <a href="uploads/<?php echo e($val->image); ?>" class="">
						        <div class="img-wrapper">
						         <img src="uploads/<?php echo e($val->image); ?>" width="300px" height="270px">
						          <div class="img-overlay">
						            <i class="fa fa-plus-circle" aria-hidden="true"></i>
						          </div>
						        </div>
						      </a>
						      </div>
                        <?php endif; ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						    </div>
						 </div>
						</div>
					</section>
    		    </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
    	    </div>
    	</div>
    </section>
    <div class="copy">
        <a class="up-btn show-1" href="#"><i class="fas fa-angle-double-up"></i></a>
    </div>  

<?php $__env->stopSection(); ?>

     
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/sevn3.ai/resources/views/portfolio.blade.php ENDPATH**/ ?>