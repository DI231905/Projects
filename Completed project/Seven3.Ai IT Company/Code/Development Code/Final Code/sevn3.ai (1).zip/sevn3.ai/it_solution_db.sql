-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 26, 2022 at 06:12 AM
-- Server version: 5.7.36-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `it_solution_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admindetail`
--

CREATE TABLE `admindetail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fblink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitterlink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admindetail`
--

INSERT INTO `admindetail` (`id`, `name`, `email`, `mobileno`, `address`, `fblink`, `instalink`, `twitterlink`, `created_at`, `updated_at`) VALUES
(1, 'apptest', 'raj@sevn3.ai\r\n', '+91-9742896777', 'Sandeep Vihar, Kannamangala, Bengaluru - 560067', '', '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `token`, `created_at`, `updated_at`) VALUES
(1, 'apptest', 'apptest2303@gmail.com', '$2y$10$vM3HX8fYpuYcFq1xhxogh.Z12u.tidJcQOa.PiEYTIOxU/27Olbjy', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_list`
--

CREATE TABLE `category_list` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_list`
--

INSERT INTO `category_list` (`id`, `name`, `created_at`, `updated_at`) VALUES
(3, 'Product', NULL, NULL),
(4, 'Consulting', NULL, NULL),
(8, 'RPAaaS', NULL, NULL),
(9, 'Training & Subtitling', NULL, NULL),
(10, 'OTT Subtitling & Captioning', NULL, NULL),
(11, 'Digital Transformation', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(250) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `phone`, `subject`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Akshay', 'akshay.digitalinovation@gmail.com', '1234567890', 'dsadasdasd', 'ASas', '2021-10-14 06:18:39', '2021-10-14 06:18:39'),
(2, 'Akshay', 'akshay.digitalinovation@gmail.com', '1234567890', 'dsadasdasd', 'test', '2021-10-14 06:20:03', '2021-10-14 06:20:03'),
(3, 'Akshay', 'akshay.digitalinovation@gmail.com', '1234567890', 'dsadasdasd', 'dfg', '2021-10-14 06:48:35', '2021-10-14 06:48:35'),
(4, 'Sandip Bhattacharya', 'info@knucklehead.in', '8777532837', 'Business Proposal', 'We are an org dedicated to AI and ML work where in we have expertise on Data Annotation and Labeling services.please visit our website www.khc.ai for more details.', '2021-10-21 07:22:31', '2021-10-21 07:22:31');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(13, '2014_10_12_000000_create_users_table', 1),
(14, '2014_10_12_100000_create_password_resets_table', 1),
(15, '2019_08_19_000000_create_failed_jobs_table', 1),
(16, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(17, '2021_10_11_053919_create_admins_table', 1),
(18, '2021_10_11_064124_create_admindetail_table', 1),
(19, '2021_10_11_073853_create_service_table', 1),
(20, '2021_10_11_110925_create_category_list_table', 1),
(21, '2021_10_11_115053_create_portfolio_table', 2),
(22, '2021_10_12_051858_create_product_table', 3),
(23, '2021_10_12_071515_create_whychooseus_table', 4),
(24, '2021_10_12_092926_create_team_table', 5),
(25, '2021_10_12_122731_create_productdetail_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `name`, `image`, `category_id`, `created_at`, `updated_at`) VALUES
(5, 'Product', '1634185607_img1.jpg', 3, NULL, NULL),
(6, 'Consulting', '1634185631_img2.jpg', 4, NULL, NULL),
(7, 'RPAaaS', '1634185665_img4.jpg', 8, NULL, NULL),
(8, 'Training & Subtitling', '1634185680_img6.jpg', 9, NULL, NULL),
(9, 'OTT Subtitling & Captioning', '1634185696_img16.jpeg', 10, NULL, NULL),
(10, 'Digital Transformation', '1634185708_img17.jpg', 11, NULL, NULL),
(14, 'RPAaaS', '1634189805_img1.jpg', 8, NULL, NULL),
(15, 'Product', '1634190416_img2.jpg', 3, NULL, NULL),
(16, 'Product', '1634190434_img9.jpg', 3, NULL, NULL),
(17, 'Product', '1634190483_img4.jpg', 3, NULL, NULL),
(18, 'Product', '1634190503_img16.jpeg', 3, NULL, NULL),
(19, 'Product', '1634190518_img17.jpg', 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(2, 'PRODUCT', '<div class=\"pro_f1\">\n                     <div class=\"pro_flex\">\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\n                        <p>Build your App</p>\n                     </div>\n                     <div class=\"pro_flex\">\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\n                        <p>Zeus</p>\n                     </div>\n                     <div class=\"pro_flex\">\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\n                        <p>CMS</p>\n                     </div>\n                     <div class=\"pro_flex\">\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\n                        <p>D.E.A</p>\n                     </div></div>', NULL, NULL),
(3, 'PEOPLE', '<div class=\"pro_f1\">\r\n                     <div class=\"pro_flex\">\r\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\r\n                        <p>Contract, Freelance &amp; Part time hiring</p>\r\n                     </div>\r\n                     <div class=\"pro_flex\">\r\n                       <i class=\"fas fa-long-arrow-alt-right\"></i>\r\n                        <p>RPA</p>\r\n                        </div>\r\n                     <div class=\"pro_flex\">\r\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\r\n                        <p> Team/Packaged/Bundled offering</p>\r\n                     </div></div>', NULL, NULL),
(4, 'CONSULTING & IMPLEMENTATION', '<div class=\"pro_f1\">\r\n                     <div class=\"pro_flex\">\r\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\r\n                        <p>GTM strategy, Project, Product Management, Strategic Advisory.</p>\r\n                     </div>\r\n                     <div class=\"pro_flex\">\r\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\r\n                        <p>RPAaaS</p>\r\n                     </div>\r\n                     <div class=\"pro_flex\">\r\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\r\n                        <p>Digital Transformation</p>\r\n                     </div></div>', NULL, NULL),
(5, 'TRAINING & SUBTITLING', '<div class=\"pro_f1\">\r\n                     <div class=\"pro_flex\">\r\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\r\n                        <p>Corporate Training:</p>\r\n                     </div>\r\n                     <div class=\"pro_flex\">\r\n                        <i class=\"fas fa-long-arrow-alt-right\"></i>\r\n                        <p>OTT Subtitling &amp; Captioning:</p>\r\n                     </div></div>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `productdetail`
--

CREATE TABLE `productdetail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `productdetail`
--

INSERT INTO `productdetail` (`id`, `image`, `name`, `short_desc`, `description`, `created_at`, `updated_at`) VALUES
(6, '1634102110_lamp.png', 'Build your App', 'End to End (Design, prototyping, build, release, maintain) of any application that you may fancy.', '<div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">Design :-</span></h3>\r\n                           </div>\r\n                           <p>Lorem Ipsum is simply a dummy text of the printing and typesetting \r\nindustry. Lorem Ipsum has been the industry\'s standard dummy text ever \r\nsince the 1500s when an unknown printer took a galley of type and \r\nscrambled it to make a type specimen book.<br></p>\r\n                        </div><div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"font-weight: bold; color: rgb(206, 0, 0);\">prototyping :-</span></h3>\r\n                           </div>\r\n                           <p>Lorem Ipsum is simply a dummy text of the \r\nprinting and typesetting industry. Lorem Ipsum has been the industry\'s \r\nstandard dummy text ever since the 1500s when an unknown printer took a\r\n galley of type and scrambled it to make a type specimen book.</p>\r\n                        </div><div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">build :-</span></h3>\r\n                           </div>\r\n                           <p>Lorem Ipsum is simply a dummy text of the \r\nprinting and typesetting industry. Lorem Ipsum has been the industry\'s \r\nstandard dummy text ever since the 1500s when an unknown printer took a\r\n galley of type and scrambled it to make a type specimen book.</p>\r\n                        </div><div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">release :-</span></h3>\r\n                           </div>\r\n                           <p>Lorem Ipsum is simply a dummy text of the \r\nprinting and typesetting industry. Lorem Ipsum has been the industry\'s \r\nstandard dummy text ever since the 1500s when an unknown printer took a\r\n galley of type and scrambled it to make a type specimen book.</p>\r\n                        </div><p>\r\n                        \r\n                        \r\n                        \r\n                        </p><div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">maintain :-</span></h3>\r\n                           </div>\r\n                           <p>Lorem Ipsum is simply a dummy text of the \r\nprinting and typesetting industry. Lorem Ipsum has been the industry\'s \r\nstandard dummy text ever since the 1500s when an unknown printer took a\r\n galley of type and scrambled it to make a type specimen book.</p></div>', NULL, NULL),
(7, '1634106900_Capture1.PNG.png', 'Zeus', 'Best in class, Fully customizable OCR/ICR.', '<h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">ZEUS - OMNI PLATFORM ORCHESTRATOR</span></h3><p>\r\n                        </p><div class=\"point\">\r\n                            <ul>\r\n                              <li>Integration with multiple RPA tools</li>\r\n                              <li>Load balancing and bot reusability <br> with on-demand resource allocation</li>\r\n                              <li>Historical data for analytics &amp; machine learning</li>\r\n                              <li>Unified view of the complete ecosystem</li></ul><h5>&nbsp; &nbsp; &nbsp;<span style=\"font-weight: bold;\"> &nbsp; &nbsp;Benefits of the platform&nbsp; &nbsp; </span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</h5><div class=\"point\">\r\n                              <ul>\r\n                                 <li>Plays the role of an orchestrator \r\nand performs simple tasks like reading the data, data manipulation &amp;\r\n writing in the data base.</li>\r\n                                 <li>Easy integration with multiple \r\ntechnologies in a single environment. Bots from UI Path, AA or Open span\r\n can be used in same automation piece. </li>\r\n                                 <li>Centralized console to get a single view of status of bots, transactions, performance and utilization etc.</li>\r\n                                 <li>Vendor independent and highly scalable for other automation opportunities.</li></ul><h3><span style=\"font-weight: bold; color: rgb(206, 0, 0);\">ZEUS – STUDIO WITH OCR &amp; ICR</span></h3><p>Has in-built provisions for working with \r\nOCRs and BRD builder. This enables a single platform to cater during \r\nrecording and documentation of the target processes.</p><div class=\"point\">\r\n                               <ul>\r\n                                  <li>Detailed activities.</li>\r\n                                  <li>UI elements recognitio</li>\r\n                                  <li>Intelligent codeless bot built</li>\r\n                                  <li>Intelligent web drivers </li>\r\n                                  <li>Flexible designing</li>\r\n                                  <li>Modularized coding</li>\r\n                                  <li>Integrated OCR / ICR </li>\r\n                                  <li>Easy API inclusion</li>\r\n                                  <li>Flexible to integrate with 3rd party tools</li>\r\n                               </ul>\r\n                          </div><div class=\"point\">\r\n                               <ul>\r\n                                  <li>Windows based Try &amp; Catch </li>\r\n                                  <li>Custom base exception handling</li>\r\n                                  <li>Inbuilt modules for data validation</li>\r\n                                  <li>Superior modules to handle latency and other causes</li>\r\n                                  <li>Inbuilt modules for exception handling</li>\r\n                               </ul>\r\n                          </div><p>\r\n                          \r\n                          \r\n                          \r\n                          </p><div class=\"point\">\r\n                               <ul>\r\n                                  <li>Flexibility in every module</li>\r\n                                  <li>User define modules inclusion</li>\r\n                                  <li>Bots Library - WIP</li>\r\n                                  <li>Customized log / activity writer</li>\r\n                                  <li>Integrated OCR / ICR </li>\r\n                                  <li>Modularized coding</li>\r\n                                  <li>Customizable in-built functions to suit the needs</li>\r\n                                  <li>User friendly &amp; Modularized coding support</li>\r\n                               </ul></div><ul>\r\n                              </ul></div><ul>\r\n                            </ul></div>', NULL, NULL),
(8, '1634107428_cms (1).png', 'CMS', 'Contract Management System', '<div class=\"ap\">\r\n                           <div class=\"ap_1\">\r\n                           <h3><b style=\"color: rgb(206, 0, 0);\">24/7 Support:-</b></h3>\r\n                           </div>\r\n                           <p>Lorem Ipsum is simply a dummy text of the \r\nprinting and typesetting industry. Lorem Ipsum has been the industry\'s \r\nstandard dummy text ever since the 1500s when an unknown printer took a\r\n galley of type and scrambled it to make a type specimen book.</p>\r\n                        </div><div class=\"ap\">\r\n                           <div class=\"ap_1\">\r\n                           <h3><span style=\"font-weight: bold; color: rgb(206, 0, 0);\">Trusted Services:-</span></h3>\r\n                           </div>\r\n                           <p>Lorem Ipsum is simply a dummy text of the \r\nprinting and typesetting industry. Lorem Ipsum has been the industry\'s \r\nstandard dummy text ever since the 1500s when an unknown printer took a\r\n galley of type and scrambled it to make a type specimen book.</p>\r\n                        </div><p>\r\n                         \r\n                        </p><div class=\"ap\">\r\n                           <div class=\"ap_1\">\r\n                           <h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">Expert &amp; Professional:-</span></h3>\r\n                           </div>\r\n                           <p>Lorem Ipsum is simply a dummy text of the \r\nprinting and typesetting industry. Lorem Ipsum has been the industry\'s \r\nstandard dummy text ever since the 1500s when an unknown printer took a\r\n galley of type and scrambled it to make a type specimen book.</p></div>', NULL, NULL),
(9, '1634108276_Capture16-1.png', 'D.E.A', 'Digital Enterprise Architecture & Agritech product: upcoming.', '<div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">Scope:-</span></h3>\r\n                           </div>\r\n                            <div class=\"point ap_12\">\r\n                               <ul>\r\n                                  <li>Defines the IT Landscape scope / Bird\'s Eye View of Customer’s Business and IT Architecture.</li>\r\n                                  <li>Defines Complex infra, IT future objectives, Challenges and derives Business Opportunities</li>                                 \r\n                               </ul>\r\n                            </div>\r\n                        </div><div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">Strategy &amp; Business Objectives:-</span></h3>\r\n                           </div> \r\n                            <div class=\"point ap_12\">\r\n                               <ul>\r\n                                  <li> Helps to visualize and relate the Organization goals and supports to build capabilities and capacity</li>\r\n                                  <li> How the business goals are aligned with IT Application and IT support model</li> \r\n                                  <li>Acquisition and divestment decision model</li>                        \r\n                               </ul>\r\n                            </div>\r\n                        </div><div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">AS-IS and TO BE analysis road map:-</span></h3>\r\n                           </div>\r\n                            <div class=\"point ap_12\">\r\n                               <ul>\r\n                                  <li>Strong vision on business value \r\ndriver from AS-IS TO-BE Arch Road map aligning in parallel with Product \r\nfocus considering key factors not limited </li>\r\n                                  <li> Business Value, Inhouse Innovation, Deployment road map, Sunset projects, Capability, Capacity.</li>                        \r\n                               </ul>\r\n                            </div>\r\n                        </div><div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"color: rgb(206, 0, 0); font-weight: bold;\">Business Capabilities Heatmap:-</span></h3>\r\n                           </div>\r\n                             <div class=\"point ap_12\">\r\n                               <ul>\r\n                                  <li> Help to sync with Industries standard reference architecture, Builds on Value drivers</li>\r\n                                  <li>Support in Economic Ecosystem building , Evaluation and Infra fulfillment.</li>                        \r\n                               </ul>\r\n                            </div>\r\n                        </div><p>\r\n                        \r\n                        \r\n                        \r\n                          </p><div class=\"app\">\r\n                           <div class=\"app_1\">\r\n                           <h3><span style=\"font-weight: bold; color: rgb(206, 0, 0);\">Light weight &amp; Easy Maintained eco system[Simplify] and Governance:-</span></h3>\r\n                           </div>\r\n                             <div class=\"point ap_12\">\r\n                               <ul>\r\n                                  <li>Large landscape to reduced complex\r\n landscape with Step by Step approach on application landscape instances\r\n reduction up to 35% Goal</li>\r\n                                  <li>Supports hybrid Cloud-based architectures</li>\r\n                                  <li>Supports better Architecture governance model</li>\r\n                                  <li>Quick to Market solutioning and Reduced deployment time</li>\r\n                               </ul>\r\n                            </div></div>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `name`, `icon`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Temporary only', 'fas fa-laptop', '<p>Lorem Ipsum is simply a dummy text of the printing and typesetting industry.<br></p>', NULL, NULL),
(2, 'Contract-to-Hire', 'fas fa-phone-alt', '<p>Lorem Ipsum is simply a dummy text of the printing and typesetting industry.<br></p>', NULL, NULL),
(3, 'Direct Hire', 'fab fa-hire-a-helper', '<p>Lorem Ipsum is simply a dummy text of the printing and typesetting industry.<br></p>', NULL, NULL),
(4, 'Staff Augmentation Options', 'fas fa-users', '<p>Digital marketing is a long fact that a reader will be distracted by the content of a page.<br></p>', NULL, NULL),
(5, 'Digital Transformation', 'fas fa-laptop', '<p>Lean, kaizen, Lean Six Sigma, AGILE, Transition &amp; Transformation projects (Technology &amp; Business)<br></p>', NULL, NULL),
(6, 'RPAaaS', 'fas fa-file-code', '<p>RPA discovery &amp; Implementation (Pay per Bot model)<br></p>', NULL, NULL),
(7, 'Corporate Training', 'fas fa-laptop', '<p>Digital marketing is a long fact that a reader will be distracted by the content of a page.<br></p>', NULL, NULL),
(8, 'OTT Subtitling & Captioning', 'fas fa-laptop', '<h3><span style=\"font-size: 17px;\">It is a long fact that a reader will be distracted by the content of a page.</span><br></h3>', NULL, NULL),
(9, 'Training & Subtitling', 'fas fa-file-code', '<p>It is a long fact that a reader will be distracted by the content of a page.<br></p>', NULL, NULL),
(10, 'Recruiting', 'fas fa-bullseye', '<h3><span style=\"font-size: 17px;\">Digital marketing is a long fact that a reader will be distracted by the content of a page.</span><br></h3>', NULL, NULL),
(11, 'Consulting & Implentation', 'fas fa-layer-group', '<h3><span style=\"font-size: 17px;\">It is a long fact that a reader will be distracted by the content of a page .</span><br></h3>', NULL, NULL),
(12, 'Product', 'fas fa-laptop', '<h3><span style=\"font-size: 17px;\">It is a long fact that a reader will be distracted by the content of a page&nbsp;</span><br></h3>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE `subscription` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscription`
--

INSERT INTO `subscription` (`id`, `email`, `created_at`, `updated_at`) VALUES
(1, 'akshay.digitalinovation@gmail.com', '2021-10-14 08:27:01', '2021-10-14 08:27:01'),
(2, 'akshay.digitalinovation@gmail.com', '2021-10-14 08:32:39', '2021-10-14 08:32:39'),
(3, 'akshay.digitalinovation@gmail.com', '2021-10-14 08:33:37', '2021-10-14 08:33:37'),
(4, 'akshay.digitalinovation@gmail.com', '2021-10-14 08:34:09', '2021-10-14 08:34:09'),
(5, 'akshay.digitalinovation@gmail.com', '2021-10-14 08:34:29', '2021-10-14 08:34:29');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fblink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitterlink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `name`, `image`, `occupation`, `fblink`, `instalink`, `twitterlink`, `created_at`, `updated_at`) VALUES
(3, 'Prathvini Patel', '1634033237_team1.jpg', 'manager', NULL, NULL, NULL, NULL, NULL),
(4, 'Max Parmar', '1634033289_team2.jpg', 'manager', NULL, NULL, NULL, NULL, NULL),
(5, 'jaimini patel', '1634033312_team3.jpg', 'manager', NULL, NULL, NULL, NULL, NULL),
(6, 'Namrata shinde', '1634033355_team4.jpg', 'manager', NULL, NULL, NULL, NULL, NULL),
(7, 'Rirat rane', '1634033400_team5.jpg', 'manager', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `whychooseus`
--

CREATE TABLE `whychooseus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `whychooseus`
--

INSERT INTO `whychooseus` (`id`, `icon`, `title`, `description`, `created_at`, `updated_at`) VALUES
(2, 'fas fa-laptop', 'OTT & Streaming Tech', '<p>Including ,subtitling, captioning, Operations &amp; Technology \npartnership. Animation, Media &amp; GRAPHICS.LEARNING &amp; Skilling for \nCorporates &amp; government</p><div class=\"point\"><ul>\n                               </ul></div>', NULL, NULL),
(3, 'fa fa-lock', 'Consult & Advisory Service', '<p>Unbiased detailed insights for all your technology need to help you decide better &amp; ensure controls on your CAPEX &amp; OPEX<br></p>', NULL, NULL),
(4, 'fas fa-database', 'Disruptive Technology', '<p>Everything between traditional script-based automation, RPA, ICR/OCR, IOT &amp; Blockchain.<br></p>', NULL, NULL),
(5, 'fas fa-users', 'Staff Augmentation', '<p>Including ,subtitling, captioning, Operations &amp; Technology partnership. Animation, Media &amp; GRAPHICS.LEARNING &amp; Skilling for Corporates &amp; government</p>', NULL, NULL),
(6, 'fas fa-globe', 'Custom Teech', '<p>Customized product & tech stack \r\noffering. patented products include helix, phoenix, custom-built apps \r\naround cybersecurity, CRM, contract management & FI tools with the perpetual licensing model</p>', NULL, NULL),
(7, 'fa fa-lock', 'Flexibility & Quality', '<p>Focus on optimum &amp; unbeatable prices, without compromising Quality. shortest TAT. Highest benchmark of SLAs &amp; the \"CAPABILITY to DO ALL\" IN THE TECHNO - Functional</p>', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admindetail`
--
ALTER TABLE `admindetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_list`
--
ALTER TABLE `category_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productdetail`
--
ALTER TABLE `productdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription`
--
ALTER TABLE `subscription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `whychooseus`
--
ALTER TABLE `whychooseus`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admindetail`
--
ALTER TABLE `admindetail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category_list`
--
ALTER TABLE `category_list`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `productdetail`
--
ALTER TABLE `productdetail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `subscription`
--
ALTER TABLE `subscription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `whychooseus`
--
ALTER TABLE `whychooseus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
