<?php

use App\Http\Controllers\Admin\AboutController;
use App\Http\Controllers\Admin\Admincontroller;
use App\Http\Controllers\Admin\portfolioController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\serviceController;
use App\Http\Controllers\Auth\Adminlogincontroller;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/', [HomeController::class, 'index']);
Route::get('/about', [HomeController::class, 'about']);
Route::get('/service', [HomeController::class, 'service']);
Route::get('/product', [HomeController::class, 'product']);
Route::get('/porfolio', [HomeController::class, 'porfolio']);
Route::get('/contactus', [HomeController::class, 'contactus']);
Route::post('/contacts_details', [HomeController::class, 'storeEnquiry']);
Route::post('/subscription', [HomeController::class, 'subscription']);

Route::prefix('admin')->group(function () {
    Route::get('/login', [Adminlogincontroller::class, 'login']);
    Route::post('/login', [Adminlogincontroller::class, 'authenticate'])->name('login');
    Route::get('/logout', [Adminlogincontroller::class, 'logout'])->name('adminlogout');
    Route::get('/forgetpasswordview', [Adminlogincontroller::class, 'forgetpasswordview'])->name('forgetpasswordview');
    Route::post('/resetpasswordlink', [Adminlogincontroller::class, 'resetpasswordlink'])->name('resetpasswordlink');
    Route::get('/resetpasswordview/{id}', [Adminlogincontroller::class, 'resetpasswordview'])->name('resetpasswordview');
    Route::post('/resetpassword', [Adminlogincontroller::class, 'resetpassword'])->name('resetpassword');
    Route::get('/home', [Admincontroller::class, 'home']);
    Route::get('/changepassword', [Admincontroller::class, 'changepassword']);
    Route::post('/updatepassword/{id}', [Admincontroller::class, 'updatepassword']);

    Route::get('/updateadmindetail/{id}', [Admincontroller::class, 'updateadmindetail']);
    Route::post('/storeadmindetail/{id}', [Admincontroller::class, 'storeadmindetail']);

    Route::get('/addserviceview', [serviceController::class, 'addserviceview']);
    Route::post('/storeservice', [serviceController::class, 'storeservice']);
    Route::get('/deleteservice/{id}', [serviceController::class, 'deleteservice']);
    Route::get('/updateservice/{id}', [serviceController::class, 'updateservice']);
    Route::post('/storeupdateservice/{id}', [serviceController::class, 'storeupdateservice']);

    Route::get('/add_category', [portfolioController::class, 'add_category']);
    Route::post('/storecategory', [portfolioController::class, 'storecategory']);

    Route::get('/addportfolio', [portfolioController::class, 'addportfolio']);
    Route::post('/storeportfolio', [portfolioController::class, 'storeportfolio']);
    Route::get('/deleteportfoilo/{id}', [portfolioController::class, 'deleteportfolio']);
    Route::get('/updateportfolio/{id}', [portfolioController::class, 'updateportfolio']);
    Route::post('/storeupdatedportfolio/{id}', [portfolioController::class, 'storeupdatedportfolio']);

    Route::get('/addproduct', [ProductController::class, 'addproduct']);
    Route::post('/storeproduct', [ProductController::class, 'storeproduct']);
    Route::get('/deleteproduct/{id}', [ProductController::class, 'deleteproduct']);
    Route::get('/updateproduct/{id}', [ProductController::class, 'updateproduct']);
    Route::post('/storeupdateproduct/{id}', [ProductController::class, 'storeupdateproduct']);

    Route::get('/addwhychooseus', [AboutController::class, 'addwhychooseus']);
    Route::post('/storewhychooseus', [AboutController::class, 'storewhychooseus']);
    Route::get('/deletewhychooseus/{id}', [AboutController::class, 'deletewhychooseus']);
    Route::get('/updatewhychooseus/{id}', [AboutController::class, 'updatewhychooseus']);
    Route::post('/storeupdatewhychooseus/{id}', [AboutController::class, 'storeupdatewhychooseus']);

    Route::get('/teamview', [AboutController::class, 'teamview']);
    Route::post('/addteam', [AboutController::class, 'addteam']);
    Route::get('/teamupdate/{id}', [AboutController::class, 'teamupdateview']);
    Route::post('/storeupdateteam/{id}', [AboutController::class, 'storeupdateteam']);

    Route::get('/add_productdetail', [ProductController::class, 'addproductdetail']);
    Route::post('/storeproductdetail', [ProductController::class, 'storeproductdetail']);
    Route::get('/deleteproductdetail/{id}', [ProductController::class, 'deleteproductdetail']);
    Route::get('/updateproductdetail/{id}', [ProductController::class, 'updateproductdetail']);
    Route::post('/storeupdateproductdetail/{id}', [ProductController::class, 'storeupdateproductdetail']);

    /*





    Route::get('/addtestimonial',[Admincontroller::class, 'addtestimonial']);
    Route::post('/storetestimonial',[Admincontroller::class, 'storetestimonial']);
    Route::get('/deletetestimonial/{id}',[Admincontroller::class, 'deletetestimonial']);
    Route::get('/updatetestimonial/{id}',[Admincontroller::class, 'updatetestimonial']);
    Route::post('/storeupdatetestimonial/{id}',[Admincontroller::class, 'storeupdatetestimonial']);



    Route::get('/teamview',[Admincontroller::class, 'teamview']);
    Route::post('/addteam',[Admincontroller::class, 'addteam']);
    Route::get('/deletefaq/{id}',[Admincontroller::class, 'deletefaq']);
    Route::get('/updatefaq/{id}',[Admincontroller::class, 'updatefaq']);

    Route::post('/storefaq',[Admincontroller::class, 'storefaq']);
    Route::get('/teamdelete/{id}',[Admincontroller::class, 'teamdelete']);
    Route::get('/teamupdate/{id}',[Admincontroller::class, 'teamupdateview']);
    Route::post('/storeupdateteam/{id}',[Admincontroller::class, 'storeupdateteam']);


    Route::get('/addgallary',[Admincontroller::class, 'addgallary']);
    Route::post('/storegallary',[Admincontroller::class,'storegallary']);
    Route::get('/deleteimage/{id}',[Admincontroller::class, 'deleteimage']);
    Route::get('/deletecontact/{id}',[Admincontroller::class, 'deletecontact']);
    Route::get('/deleteenquiry/{id}',[Admincontroller::class, 'deleteenquiry']);

    Route::get('/downloadpdf/{id}',[Admincontroller::class, 'downloadpdf']);
    Route::get('/deletecareerinquiry/{id}',[Admincontroller::class,'deletecareerinquiry']);

    Route::get('/deletequeto/{id}',[Admincontroller::class, 'deletequeto']);
    Route::get('/deletequeto1/{id}',[Admincontroller::class, 'deletequeto1']);

    Route::get('/viewInquiry/{id}',[Admincontroller::class, 'viewInquiry']);
    Route::get('/viewInquiry2/{id}',[Admincontroller::class, 'viewInquiry2']);

    */
});
