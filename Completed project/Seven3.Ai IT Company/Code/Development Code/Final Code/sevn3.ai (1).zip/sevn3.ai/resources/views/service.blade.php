@extends('layout.app')
@section('content')
<div class="co-banner1">
        <div class="container">
            <h1>Service</h1>
            <ul class="breadcrumb1">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li>/</li>
                <li>Service</li>
            </ul>
        </div>
    </div>
    <section class="service">
      <div class="container">
         <div class="ser_head">
           <h2>Our Services</h2>
           <div class="row">
           @foreach($services as $service)
              <div class="col-lg-4 col-md-6" data-aos="flip-left" data-aos-easing="ease-out-cubic" data-aos-duration="2000">
                  <div class="ser_first_main">
                     <div class="ser_first">
                       <div class="fi_icon"><i class="{{ $service->icon }}"></i></div>
                       <h3>{{ $service->name }}</h3>
                       <p>{!! \Illuminate\Support\Str::limit($service->description, 90, $end='...')  !!} </p>
                     </div>
                  </div>
              </div>
              @endforeach 
           </div>
         </div>
      </div>
   </section>  
   
@endsection

     