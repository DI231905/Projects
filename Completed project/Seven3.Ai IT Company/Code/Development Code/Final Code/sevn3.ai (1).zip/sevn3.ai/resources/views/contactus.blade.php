@extends('layout.app')
@section('content')
<div class="co-banner1">
        <div class="container">
            <h1>Contact</h1>
            <ul class="breadcrumb1">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li>/</li>
                <li>Contact</li>
            </ul>
        </div>
    </div>
    <div class="in_contct">
    	<div class="container">
    		<h3>Get in touch with us</h3>
          @if ($message = Session::get('error'))
            <div  id="hideDiv1" class="alert alert-success alert-block" >
                <strong style="padding-top : 0px !important; display: inline-block;">{{ $message }}</strong>
             </div>
           @endif
           @if ($errors->has('Validation_Error'))
            @foreach ($errors->all() as $error)
            <div  id="hideDiv1" class="alert alert-danger alert-block" >
                <strong style="padding-top : 0px !important; display: inline-block;">{{ $error }}</strong>
             </div>
            @endforeach
            @endif
            @if ($errors->any())
            <div class="alert alert-danger">
               <ul>
                  @foreach ($errors->all() as $error)
                     <li>{{ $error }}</li>
                  @endforeach
               </ul>
               @if ($errors->has('email'))
               @endif
            </div>
            @endif
    		<div class="row color_bg">
		        <div class="col-lg-5 col-md-5 color_bg1" data-aos="fade-up" data-aos-duration="3000">
		            <div class="contact-list">
		                <div class="heading-layout5 mg-b-30">
		                    <h2>Contact Info</h2>
		                </div>
		                <div class="media">
		                    <div class="item-icon">
		                        <i class="fas fa-phone-alt"></i>
		                    </div>
		                    <div class="media-body">
		                        <h5 class="item-title">Phone</h5>
		                        <ul>
		                            <li>Phone: {{ $contacts[0]->mobileno }}</li>
		                        </ul>
		                    </div>
		                </div>
		                <div class="media">
		                    <div class="item-icon">
		                        <i class="fas fa-map-marker-alt"></i>
		                    </div>
		                    <div class="media-body">
		                        <h5 class="item-title">Address</h5>
		                        <ul>
		                            <li>{{ $contacts[0]->address }}</li>
		                        </ul>
		                    </div>
		                </div>
		                <div class="media">
		                    <div class="item-icon">
		                        <i class="far fa-envelope"></i>
		                    </div>
		                    <div class="media-body">
		                        <h5 class="item-title">E-Mail</h5>
		                        <ul>
		                            <li>{{ $contacts[0]->email }}</li>
		                        </ul>
		                    </div>
		                </div>
		            </div>
		        </div>
		        <div class="col-lg-7 col-md-7" data-aos="fade-up" data-aos-duration="3000">
		            <div class="contact-form-box-layout1">
		                <div class="heading-layout5 mg-b-30">
		                    <h2>Contact Form</h2>
		                </div>
		                <form method="POST" action="{{url('/contacts_details')}}" class="contact-form-box" id="contact-form">
                      @csrf
		                    <div class="row gutters-15">
		                        <div class="col-lg-6 col-12 form-group has-error has-danger">
		                            <label>Name *</label>
		                            <input type="text" placeholder="" class="form-control" name="name" data-error="Name field is required" required>
		                        </div>
		                        <div class="col-lg-6 col-12 form-group has-error has-danger">
		                            <label>E-Mail *</label>
		                            <input type="email" placeholder="" class="form-control" name="email" data-error="email field is required" required="email">
		                        </div>
		                        <div class="col-md-6 col-12 form-group has-error has-danger">
		                            <label>Phone *</label>
		                            <input type="number" placeholder="" class="form-control" name="phone" data-error="Phone field is required" required>
		                        </div>
		                        <div class="col-md-6 col-12 form-group has-error has-danger">
		                            <label>Subject *</label>
		                            <input type="text" placeholder="" class="form-control" name="subject" data-error="Subject field is required" required>
		                        </div>
		                        <div class="col-12 form-group has-error has-danger">
		                            <label>Type Your Comment *</label>
		                            <textarea placeholder="" class="textarea form-control" name="message" id="form-message" rows="5" cols="20" data-error="Message field is required" required></textarea>
		                        </div>
		                        <div class="col-12 form-group">
		                            <button type="submit" class="btn-fill-3 disabled">SUBMIT NOW</button>
		                        </div>
		                    </div>
		                    <div class="form-response"></div>
		                </form>
		            </div>   
		        </div>
		    </div>
    	</div>
    </div> 
    <section class="location">
	 	<div class="container">
	 		<div class="row">
	 			<div class="col-lg-4 col-md-6 mar_location" data-aos="fade-up" data-aos-duration="3000">
	 				<div class="banner-img-box b_overley ttm-textcolor-white text-left">
                        <div class="featured-content featured-content-banner">
                            <i class="fas fa-phone-volume"></i>
                            <div class="featured-title ttm-box-title">
                                <h5>Opening Hours</h5>
                            </div>
                            <div class="featured-desc">
                                <p>If you need any help, please<br> feel free to contact us.</p>
                            </div>
                            <ul>
                                <span>Monday-Saturday</span>
                                <p>9:00AM - 11:00PM</p>
                                <span>Sunday</span>
                                <p>close</p>
                            </ul>
                        </div>
                    </div>
	 			</div>
	 			<div class="col-lg-8 col-md-6" data-aos="fade-up" data-aos-duration="3000">
	 				<div class="map">
		                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29844.679959313195!2d72.96851869478905!3d20.76760839039142!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be0ee423c0a4b2f%3A0xe413d0603fe2891c!2sBilimora%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1630654269623!5m2!1sen!2sin" width="750" height="385" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
		             </div>
	 			</div>
	 		</div>
	 	</div>             
    </section>
    <script>
       $(document).ready(function() {
$("#basic-form").validate({
rules: {
name : {
required: true,
minlength: 3
},
age: {
required: true,
number: true,
min: 18
},
email: {
required: true,
email: true
},
weight: {
required: {
depends: function(elem) {
return $("#age").val() > 50
}
},
number: true,
min: 0
}
}
});
});
                      </script>   
@endsection

     