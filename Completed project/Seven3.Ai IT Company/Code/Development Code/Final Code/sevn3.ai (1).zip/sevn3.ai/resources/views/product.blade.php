@extends('layout.app')
@section('content')
<div class="co-banner1">
        <div class="container">
            <h1>Product</h1>
            <ul class="breadcrumb1">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li>/</li>
                <li>Product</li>
            </ul>
        </div>
    </div>
    <section class="py-5 header">
    <div class="container py-4">
        <div class="row">
            <div class="col-md-3" data-aos="fade-up" data-aos-duration="3000">
                <div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link shadow active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
                        <i class="fa fa-user-circle-o mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Build your App</span></a>

                    <a class="nav-link shadow" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">
                        <i class="fa fa-calendar-minus-o mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Zeus</span></a>

                    <a class="nav-link shadow" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                        <span class="font-weight-bold small text-uppercase">CMS</span></a>

                    <a class="nav-link shadow" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">
                        <span class="font-weight-bold small text-uppercase">D.E.A</span></a>
               </div>
            </div>
            <div class="col-md-9" data-aos="fade-up" data-aos-duration="3000">
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="tab-pane fade shadow rounded bg-white show active p-5" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                        <h4 class="font-italic mb-4">Build your App</h4>
                        <p class="font-italic text-muted mb-2"> End to End (Design, prototyping, build, release, maintain) of any application that you may fancy.</p>
                        <div class="app_img">
                            <img src="image/lamp.png">
                        </div>
                        <div class="app">
                           <div class="app_1">
                           <h3>Design :-</h3>
                           </div>
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                        <div class="app">
                           <div class="app_1">
                           <h3>prototyping :-</h3>
                           </div>
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                        <div class="app">
                           <div class="app_1">
                           <h3>build :-</h3>
                           </div>
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                        <div class="app">
                           <div class="app_1">
                           <h3>release :-</h3>
                           </div>
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                        <div class="app">
                           <div class="app_1">
                           <h3>maintain :-</h3>
                           </div>
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>  
                     </div>                 
                    <div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                        <h4 class="font-italic mb-4">Zeus</h4>
                        <p class="font-italic text-muted mb-2">Best in class, Fully customizable OCR/ICR.</p>
                        <div class="app_img">
                            <img src="image/Capture_1.png">
                        </div>
                        <h3>ZEUS - OMNI PLATFORM ORCHESTRATOR</h3>
                        <div class="point">
                            <ul>
                              <li>Integration with multiple RPA tools</li>
                              <li>Load balancing and bot reusbility <br> with on demand resource allocation</li>
                              <li>Historical data for analytics & machine learning</li>
                              <li>Unified view of the complete ecosystem</li>
                            </ul>
                        </div>
                        <div class="benift">
                           <h4>Benefits of the platform</h4>
                           <div class="point">
                              <ul>
                                 <li>Plays the role of an orchestrator and performs simple tasks like reading the data, data manipulation & writing in the data base.</li>
                                 <li>Easy integration with multiple technologies in a single environment. Bots from UI Path, AA or Open span can be used in same automation piece. </li>
                                 <li>Centralized console to get a single view of status of bots, transactions, performance and utilization etc.</li>
                                 <li>Vendor independent and highly scalable for other automation opportunities.</li>
                              </ul>
                           </div>
                          </div>
                          <h3>ZEUS – STUDIO WITH OCR & ICR</h3>
                          <p>Has in-built provisions for working with OCRs and BRD builder. This enables a single platform to cater during recording and documentation of the target processes.</p>
                          <div class="point">
                               <ul>
                                  <li>Detailed activities.</li>
                                  <li>UI elements recognitio</li>
                                  <li>Intelligent codeless bot built</li>
                                  <li>Intelligent web drivers </li>
                                  <li>Flexible designing</li>
                                  <li>Modularized coding</li>
                                  <li>Integrated OCR / ICR </li>
                                  <li>Easy API inclusion</li>
                                  <li>Flexible to integrate with 3rd party tools</li>
                               </ul>
                          </div>
                          <div class="point">
                               <ul>
                                  <li>Windows based Try & Catch </li>
                                  <li>Custom base exception handling</li>
                                  <li>Inbuilt modules for data validation</li>
                                  <li>Superior modules to handle latency and other causes</li>
                                  <li>Inbuilt modules for exception handling</li>
                               </ul>
                          </div>
                          <div class="point">
                               <ul>
                                  <li>Flexibility in every module</li>
                                  <li>User define modules inclusion</li>
                                  <li>Bots Library - WIP</li>
                                  <li>Customized log / activity writer</li>
                                  <li>Integrated OCR / ICR </li>
                                  <li>Modularized coding</li>
                                  <li>Customizable in-built functions to suit the needs</li>
                                  <li>User friendly & Modularized coding support</li>
                               </ul>
                          </div>                        
                     </div>                   
                    <div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                        <h4 class="font-italic mb-4">CMS</h4>
                        <p class="font-italic text-muted mb-2">Contract Management System</p>
                         <div class="cms">
                            <img src="image/cms (1).png">
                         </div>
                          <div class="ap">
                           <div class="ap_1">
                           <h3>24/7 Support:-</h3>
                           </div>
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                         <div class="ap">
                           <div class="ap_1">
                           <h3>Trusted Services:-</h3>
                           </div>
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                        <div class="ap">
                           <div class="ap_1">
                           <h3>Expert & Professional:-</h3>
                           </div>
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                    </div>                    
                    <div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                        <h4 class="font-italic mb-4">D.E.A</h4>
                        <p class="font-italic text-muted mb-2">Digital Enterprise Architecture & Agritech product: upcoming.</p>
                        <div class="app_img">
                            <img src="image/Capture16-1.png">
                        </div>
                        <div class="app">
                           <div class="app_1">
                           <h3>Scope:-</h3>
                           </div>
                            <div class="point ap_12">
                               <ul>
                                  <li>Defines the IT Land scape scope / Birds Eye view of Customer’s Business and IT Architecture.</li>
                                  <li>Defines Complex infra, IT future objectives , Challenges and derives Business Opportunities</li>                                 
                               </ul>
                            </div>
                        </div>
                        <div class="app">
                           <div class="app_1">
                           <h3>Strategy & Business Objectives:-</h3>
                           </div> 
                            <div class="point ap_12">
                               <ul>
                                  <li> Helps to visualize and relate the Organization goals and supports to build capabilities and capacity</li>
                                  <li> How the business goals are aligned with IT Application and IT support model</li> 
                                  <li>Acquisition and divestment decision model</li>                        
                               </ul>
                            </div>
                        </div>
                        <div class="app">
                           <div class="app_1">
                           <h3>AS-IS and TO BE analysis road map:-</h3>
                           </div>
                            <div class="point ap_12">
                               <ul>
                                  <li>Strong vision on business value driver from AS-IS TO-BE Arch Road map aligning in parallel with Product focus considering key factors not limited </li>
                                  <li> Business Value, Inhouse Innovation, Deployment road map, Sunset projects, Capability, Capacity.</li>                        
                               </ul>
                            </div>
                        </div>
                        <div class="app">
                           <div class="app_1">
                           <h3>Business Capabilities Heatmap:-</h3>
                           </div>
                             <div class="point ap_12">
                               <ul>
                                  <li> Help to sync with Industries standard reference architecture, Builds on Value drivers</li>
                                  <li>Support in Economic Eco system building ,Evaluation and Infra fulfillment.</li>                        
                               </ul>
                            </div>
                        </div>
                          <div class="app">
                           <div class="app_1">
                           <h3>Light weight & Easy Maintained eco system[Simplify] and Governance.:-</h3>
                           </div>
                             <div class="point ap_12">
                               <ul>
                                  <li>Large landscape to reduced complex landscape with Step by Step approach on application landscape instances reduction up to 35% Goal</li>
                                  <li>Supports hybrid Cloud based architectures</li>
                                  <li>Supports better Architecture governance model</li>
                                  <li>Quick to Market solutioning and Reduced deployment time</li>
                               </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
  
   
@endsection

     