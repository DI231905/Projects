@extends('layout.app')
@section('content')
<section class="banner__slider">
     <div class="slider stick-dots">
       <div class="slide">
         <div class="slide__img">
           <img src="image/banner-3.jpg" alt="" data-lazy="" class="full-image animated" data-animation-in="zoomInImage"/>
         </div>
         <div class="slide__content ">
           <div class="slide__content--headings text-center center_content">
              
              <p class="animated top-title" data-animation-in="fadeInUp" data-delay-in="0.3">Welcome to IT solutions</p>
                  <h2 class="animated title" data-animation-in="fadeInUp">Creating a better IT solutions</h2>
                  <button class="btn-light btn button-custom animated" data-animation-in="fadeInUp">Call for inquiry</button>
           </div>
         </div>
       </div>
       <div class="slide">
         <div class="slide__img">
           <img src="image/banner-1.jpg" alt="" data-lazy="" class="full-image animated" data-animation-in="zoomOutImage"/>
         </div>
         <div class="slide__content slide__content__right">
           <div class="slide__content--headings text-right">
                  <p class="animated top-title" data-animation-in="fadeInLeft" data-delay-in="0.2">Optimize IT Systems</p>
              <h2 class="animated title" data-animation-in="fadeInLeft">Creating a better<br> IT solutions</h2>
              <button class="btn-success btn button-custom animated text-white" data-animation-in="fadeInUp">Training</button>
           </div>
         </div>
       </div>
         <div class="slide">
         <div class="slide__img">
           <img src="image/banner-4.jpg" alt="" data-lazy="" class="full-image animated" data-animation-in="zoomInImage"/>
         </div>
         <div class="slide__content slide__content__left">
           <div class="slide__content--headings text-left">
                  <p class="animated top-title" data-animation-in="fadeInRight" data-delay-in="0.2">We Can Take </p>
              <h2 class="animated title" data-animation-in="fadeInRight">Your Business To<br>The Next Level.</h2>
              <button class="btn-light btn button-custom animated" data-animation-in="fadeInUp">Call for inquiry</button>
           </div>
         </div>
       </div>
     </div>
    <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
    <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 44" width="44px" height="44px" id="circle" fill="none" stroke="currentColor">
        <circle r="20" cy="22" cx="22" id="test">
    </symbol>
    </svg>
   </section>
   <div class="about-area inc-shape default-padding">
      <div class="container">
      @if ($message = Session::get('error'))
            <div  id="hideDiv1" class="alert alert-success alert-block" >
                <strong style="padding-top : 0px !important; display: inline-block;">{{ $message }}</strong>
             </div>
           @endif
           @if ($errors->has('Validation_Error'))
            @foreach ($errors->all() as $error)
            <div  id="hideDiv1" class="alert alert-danger alert-block" >
                <strong style="padding-top : 0px !important; display: inline-block;">{{ $error }}</strong>
             </div>
            @endforeach
            @endif
            @if ($errors->any())
            <div class="alert alert-danger">
               <ul>
                  @foreach ($errors->all() as $error)
                     <li>{{ $error }}</li>
                  @endforeach
               </ul>
               @if ($errors->has('email'))
               @endif
            </div>
            @endif
         <div class="row">
            
            <div class="col-lg-6 " data-aos="fade-up" data-aos-duration="3000">
               <div class="thumb">
                  <img src="image/img1.jpg" alt="Thumb">
                  <img src="image/img2.jpg" alt="Thumb">
                  <div class="overlay sz-img1">
                     <div class="content">
                        <h4>20+ years of experience</h4>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-lg-5 offset-lg-1 info" data-aos="fade-up" data-aos-duration="3000">
               
               <h2>About Us</h2>
               <p>
               Sevn3.ai is a full-services Software Development and Consulting company, transforming businesses through the power of 
               People, Innovative Technologies, and Automated Processes. By utilizing our expertise and years of experience in 
               strategic planning and innovative software technologies, our team of certified experts help clients gain efficiency and 
               productivity, reduce operational and labor costs, ensure compliance, and enable digital transformation.
               </p>
               <p>Thanks to our lean, agile methodology and extensive experience in leading-edge technologies, we can design and 
               develop smart, scalable solutions for any industry. We are committed to always learning and researching new ways to 
               solve old (and new) problems. Our team has experience in designing and developing products for a global marketplace. 
               We help organizations go digital and empower them to grow in an increasingly connected world.</p>
               <button class="button-8"><div class="eff-8"></div><a href="{{ url('/about') }}">Read More</a></button>
            </div>        
         </div>
      </div>
   </div>
   <div class="features-area overflow-hidden bg-gray default-padding">
      <div class="container">
         <div class="row align-center">
            <div class="col-lg-5 why-us o_order1" data-aos="fade-up" data-aos-duration="3000">
               <h5>why choose us</h5>
               <h2>Custom IT Solutions for Your Business</h2>
               <p>
               Carried nothing on am warrant towards. Polite in of in oh needed itself silent course. Assistance travelling so especially do prosperous appearance mr no celebrated. Wanted easily in my called formed suffer. Songs hoped sense as taken ye mirth at. Believe fat how six drawing pursuit minutes far. Same do seen head am part it dear open to Whatever.
               </p>
               <button class="button-8"><div class="eff-8"></div><a href="{{ url('/service') }}">What We Offer</a></button>
            </div>
            <div class="col-lg-7 features-box text-center o_order2" data-aos="fade-up" data-aos-duration="3000">
               <div class="row">
               @foreach($why_choose_odd as $key =>$val)
                  <div class="col-lg-6 col-md-6 item-grid">
                  @if ($key == 0 )
                     <div class="item">
                        <i class="{{ $val->icon }}"></i>
                        <h5><a href="#">{{ $val->title }}</a></h5>
                        <p>{!! \Illuminate\Support\Str::limit($val->description, 90, $end='...')  !!}</p>
                     </div>
                     @endif 
                     @if ($key== 1 )
                     <div class="item item1">
                        <i class="{{ $val->icon }}"></i>
                        <h5><a href="#">{{ $val->title }}</a></h5>
                        <p>{!! \Illuminate\Support\Str::limit($val->description, 90, $end='...')  !!}</p>
                     </div>
                     @endif 
                  </div>
                  @endforeach 

                  @foreach($why_choose_even as $k =>$even)
                  <div class="col-lg-6 col-md-6 item-grid">
                     @if ($k == 0 )
                     <div class="item item1">
                        <i class="{{ $even->icon }}"></i>
                        <h5><a href="#">{{ $even->title }}</a></h5>
                        <p>{!! \Illuminate\Support\Str::limit($even->description, 90, $end='...')  !!}</p>
                     </div>
                     @endif 
                     @if ($k==1)
                     <div class="item">
                        <i class="{{ $even->icon }}"></i>
                        <h5><a href="#">{{ $even->title }}</a></h5>
                        <p>{!! \Illuminate\Support\Str::limit($even->description, 90, $end='...')  !!}</p>
                     </div>
                     @endif 
                  </div>
                  @endforeach 
               </div>
            </div>
         </div>
      </div>
   </div>
   <section class="service">
      <div class="container">
         <div class="ser_head">
           <h2>Our Services</h2>
           <div class="row">
             @foreach($services as $service)
              <div class="col-lg-4 col-md-6" data-aos="flip-left" data-aos-easing="ease-out-cubic" data-aos-duration="2000">
                  <div class="ser_first">
                    <div class="fi_icon"><i class="{{ $service->icon }}"></i></div>
                    <h3>{{ $service->name }}</h3>
                    <p>{!! $service->description !!} </p>
                    <a href="{{url('/service')}}">Read More</a>
                  </div>
              </div>
              @endforeach 
           </div>
           <div class="ss_btn">
                <button class="button-8"><div class="eff-8"></div><a href="{{ url('/service') }}">Read More</a></button>
           </div>
         </div>
      </div>
   </section>
   <div class="vision">
       <div class="container">
           <div class="vision_main">
               <div class="row align-center">
                  <div class="col-lg-6 order2" data-aos="fade-up" data-aos-duration="3000">
                     <h2>Solutions Your Company Future</h2>
                     <p>
                     Sevn3.ai is a full-services Software Development and Consulting company
                     </p>
                     <div class="vi_main">
                        <div class="vi-icon-box">
                           <span class="vi-icon">
                              <i class="fas fa-building"></i>        
                           </span>
                        </div>
                        <div class="vi-content">
                           <h4 class="vi-title"><span>Our  Vision</span></h4>
                           <p class="vi-description">We believe that every tech product should have an alluring UX UI, no bugs, great speed, and be unique.Our far-sighted vision of looking beyond the clients’ immediate needs, has set a true testimony for us in developing sustainable and successful tech products.It is our brand DNA that has helped us to be consistent during all these years of service:</p>
                        </div>
                     </div>
                     <div class="vi_main1">
                        <div class="vi-icon-box">
                           <span class="vi-icon">
                              <i class="fas fa-users"></i>        
                           </span>
                        </div>
                        <div class="vi-content">
                           <h4 class="vi-title"><span>Our  Mission</span></h4>
                           <p class="vi-description">Our mission is to give our clients a competitive dvantage and altimate business efficiency through strategic planning, innovative technologies, and streamlined processes,we aspire to deliver competency and excellence to transform every aspect of our clients prganizations.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-6 oder1" data-aos="fade-up" data-aos-duration="3000">
                     <div class="thumb thumb1">
                        <img src="image/img5.jpg" alt="Thumb">
                     </div>
                  </div>
               </div>
            </div>
       </div>
   </div>
   <div class="Technology">
      <div class="container">
        <div class="Technology_main"  data-aos="fade-up" data-aos-duration="3000">
         <div class="Technology_inner">
          <div class="Technology_sub" data-aos="fade-up" data-aos-duration="3000">
            <h4>Benefit</h4>
            <h2>OFFERINGS SNAPSHOT</h2>
          </div>
          <div class="Technology_sub_main">
          @foreach($products as $p_key => $product)
            <div class="Technology_sub1"  data-aos="fade-up" data-aos-duration="3000">
            <div class="numbering">
              <span>{{ $p_key+1 }}</span>
            </div>
            <div class="Advantages">
              <h3>{{ $product->name }}</h3>
              <div class="pro_f">
                  <div class="pro_f1">
                     <div class="pro_flex">
                        <!-- <i class="fas fa-long-arrow-alt-right"></i> -->
                        <p>{!! $product->description !!} </p>
                     </div>
                  </div>
                  <button class="button-9"><div class="eff-9"></div><a href="{{ url('/product') }}">Read More</a></button>
               </div>
            </div>
          </div>
          @endforeach 
         </div>
        </div>
         <div class="Technology_inner1" data-aos="fade-up" data-aos-duration="3000">
          <div class="Technology_sub_inner">
          <div class="single box22" data-aos="fade-up" data-aos-duration="3000">
             <img src="image/lamp.png"  data-aos="flip-left" data-aos-duration="2000">
          </div>
          <button class="button-8 btn_pro"><div class="eff-8"></div><a href="{{ url('/product') }}">Read More</a></button>
          <div class="deign_febric">
            <div>IT solutions</div>
          </div>
        </div>
         </div>
        </div>
      </div>
   </div>  
 
   <div class="newsletterblock" data-aos="fade-up" data-aos-duration="3000">
        <div class="newsletter-form block-content container">
            <div class="newsletter-common row">
                <div class="col-md-6 col-xs-12 col-sm-12 news-content block_div">
                    <div class="icon-mail">
                        <i class="fal fa-envelope"></i>
                    </div>
                    <div class="news-text">
                    <h4 class="title-text page-title">Subscribe Newsletter</h4>
                    <div class="news-desc">Get e-mail updates about our latest shop and special offers.</div>
                    </div>  
                </div>  
                <div class="col-md-6 col-xs-12 block_div">
                    <form method="POST" action="{{url('/subscription')}}" id="subscription-form">
                    @csrf
                        <div class="subscribe-form">
                            <input type="email" name="email" placeholder="Enter your email here..." class="form-control input-lg inputNew txtemail" required="">
                            <button type="submit" class="subscribe-btn">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>              
        </div>
   </div>
  
   
@endsection

     