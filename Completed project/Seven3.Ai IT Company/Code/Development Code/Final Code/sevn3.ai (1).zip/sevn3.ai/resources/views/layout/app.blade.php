<html>
<head>
	<title>Sevn3.ai</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/home.css') }}" >
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://kenwheeler.github.io/slick/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="https://kenwheeler.github.io/slick/slick/slick-theme.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="shortcut icon" href="image/favicon.ico">

</head>
</head>
<body style="margin: 0; padding: 0; overflow-x: hidden;">
    <section class="header_top">
   	    <div class="container">
   			<div class="row">
   				<div class="col-lg-7">
   					<div class="head_main">
   						<ul>
   						   <li><i class="fas fa-map-marker-alt"></i>  {{ $contacts[0]->address }} </li>
   						   <li><i class="fas fa-envelope-open"></i> {{ $contacts[0]->email }} </li>
   						</ul>
   				    </div>
   			    </div>
   				<div class="col-lg-5">
   					<div class="head_inner">
   	                <div class="row info">
                        <div class="col-lg-8 info1">
   	                    <ul>
   	                       <!-- <li><i class="fas fa-clock"></i> Office Hours: 8:00 AM – 7:45 PM </li> -->
   	                    </ul>
                        </div>
                        <div class="col-lg-4">	                
      	                <div class="social">
      	                    <ul>
      	                       <li><a href="{{ $contacts[0]->fblink }}"><i class="fab fa-facebook-f"></i></a></li>
      	                       <li><a href="{{ $contacts[0]->twitterlink }}"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="{{ $contacts[0]->instalink }}"><i class="fab fa-instagram"></i></a></li>

      	                    </ul>
      	                </div>
                      </div>
   	            </div>
               </div>  					
   			</div>  			
      	</div>
       </div>
   	</section>
   	<section class="header_buttom">
   		<div class="container">
   			<div class="row">
   				<div class="col-lg-1">
   					<div class="logo">
                  <a href="{{ url('/') }}"><img src="image/logo.png"></a>
   					</div>
   				</div>
   				<div class="col-lg-7">
   					<div id="menu" class="menu">
                     <nav class="shift">
                         <ul class="nav1">
                            <li class="{{ Request::path() == '/' ? 'active' : '' }}"><a href="{{ url('/') }}"> Home</a></li>
                            <li class="{{ Request::is('about') ? 'active' : '' }}"><a href="{{ url('/about') }}"> About Us</a></li>
                            <li class="{{ Request::is('service') ? 'active' : '' }}"><a href="{{ url('/service') }}">Services</a></li>
                            <li  class="{{ Request::is('product') ? 'active' : '' }}"><a href="{{ url('/product') }}">Product</a></li>
                            <li class="{{ Request::is('porfolio') ? 'active' : '' }}"><a href="{{ url('/porfolio') }}">Portfolio</a></li>
                            <li class="{{ Request::is('contactus') ? 'active' : '' }}"><a href="{{ url('/contactus') }}">Contact Us</a></li>
                         </ul>
                     </nav>
                 </div>
   				</div>
   				<div class="col-lg-4">
   					<div class="attr-nav inc-border">
                        <ul>
                           <li class="contact"><i class="fas fa-phone-alt"></i><p>Call now !<strong> {{ $contacts[0]->mobileno }}</strong></p></li>
                        </ul>
                    </div>
   				</div>
               </div>   				
   			</div>
   		</div>
   	</section>
      <section class="heder_bar12">
         <div class="container">
            <div class="row">
               <div class="col-md-6 col-6">
                  <div class="logo">
                     <img src="image/logo.jpeg">
                  </div>
               </div>
               <div class="col-md-6 col-6">
                  <header class="header dis_div1">
                  <nav class="navbar">
                    <button aria-label="Open Mobile Menu" class="open-mobile-menu">
                      <i class="fas fa-bars"></i>
                    </button>
                    <div id="menu" class="top-menu-wrapper">
                      <ul class="top-menu">
                        <li class="mob-block">
                          <h1 class="logo" alt="sidebar logo">
                            <div class="logo">
                                  <a href="index.html"><img src="image/logo.jpeg"></a>
                             </div>
                         </h1>
                          <button aria-label="Close Mobile Menu" class="close-mobile-menu">
                            <i class="fas fa-window-close"></i>
                          </button>
                        </li>
                        <li class="active"><a href="{{ url('/') }}">Home</a></li>
                            <li><a href="{{ url('/about') }}">About Us</a></li>
                            <li><a href="{{ url('/service') }}">Services</a></li>
                            <li><a href="{{ url('/product') }}">Product</a></li>
                            <li><a href="{{ url('/porfolio') }}">Portfolio</a></li>
                            <li><a href="{{ url('/contactus') }}">Contact Us</a></li>
                      </ul>
                    </div>
                  </nav>
                </header> 
             </div>
          </div>
      </section>
    @yield('content')
   <footer>
      <div class="main-footer">
         <div class="footer1">
         <div class="bg-footer"></div>
         <div class="container">
            <div class="footer-block">
               <div class="row">
                  <div class="col-lg-4 col-md-6 col-12">
                     <div class="f-logo">
                     <div class="logo_img">
                        <img src="image/logo.png">
                     </div>
                     <div>
                        <p>Sevn3.ai is a full-services Software Development and Consulting company, transforming businesses through the power of People, Innovative Technologies, and Automated Processes.</p>
                     </div>
                     <div>
                        <i class="fa fa-facebook-f"><i class="fa fa-twitter"><i class="fa fa-instagram"></i></i></i><i class="fa fa-google-plus"></i><i class="fa fa-linkedin"></i>
                     </div>
                     <div>
                        
                     </div>
                     </div>
                  </div>
                  <div class="col-lg-2 col-md-6 col-6">
                     <div class="f-service">
                     <h2>Services</h2>
                     <div>
                        <ul>
                           <li><a href="{{ url('/about') }}">About Us</a></li>
                           <li><a href="{{ url('/about') }}">How It Works</a></li>
                           <li><a href="{{ url('/service') }}">Our Services</a></li>
                           <li><a href="{{ url('/contactus') }}">Contact Us</a></li>
                        </ul>
                     </div>
                     </div>
                  </div>
                   <div class="col-lg-2 col-md-6 col-6">
                     <div class="f-service">
                     <h2>Help Link</h2>
                     <div>
                        <ul>
                           <li><a href="{{ url('/about') }}">About Us</a></li>
                           <li><a href="{{ url('/service') }}">Service</a></li>
                           <li><a href="{{ url('/product') }}">Product</a></li>
                           <li><a href="{{ url('/porfolio') }}">Portfolio</a></li>
                           <li><a href="{{ url('/contactus') }}">Contact Us</a></li>
                        </ul>
                     </div>
                     </div>
                  </div> 
                  <div class="col-lg-4 col-md-6 col-12">
                     <div class="f-contact">
                     <h2>Contacts</h2>
                     <div class="c-block">
                        <div class="f-icon-c"><i class="fa fa-map-marker"></i></div>
                        <div class="f-text-c"><p> {{ $contacts[0]->address }}</p></div>
                     </div>
                     <div class="c-block">
                        <div class="f-icon-c"><i class="fas fa-phone-alt"></i></div>
                        <div class="f-text-c"><a href="tel: {{ $contacts[0]->mobileno }}"> {{ $contacts[0]->mobileno }}</a></div>
                     </div>
                     <div class="c-block">
                        <div class="f-icon-c"><i class="fa fa-envelope"></i></div>
                        <div class="f-text-c"><a href="mailto: {{ $contacts[0]->email }}"> {{ $contacts[0]->email }}</a> </div>
                     </div>
                     </div>
                  </div> 
               </div>
            </div>
         </div>
         <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Sealosca Theme © Copyright {{ date('Y')}}. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                     <li><a href="{{ $contacts[0]->fblink }}"><i class="fab fa-facebook-f"></i></a></li>
                     <li><a href="{{ $contacts[0]->twitterlink }}"><i class="fab fa-twitter"></i></a></li>
                     <li><a href="{{ $contacts[0]->instalink }}"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </div>
   </div>
   </footer>
   <div class="copy">
        <a class="up-btn show-1" href="#"><i class="fas fa-angle-double-up"></i></a>
    </div>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://kenwheeler.github.io/slick/slick/slick.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script>
    <script type="text/javascript" src="https://alexandrebuffet.fr/codepen/slider/slick-animation.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script type="text/javascript">
         $('.slider').slick({
           autoplay: true,
           speed: 800,
           lazyLoad: 'progressive',
           arrows: true,
           dots: false,
            prevArrow: '<div class="slick-nav prev-arrow"><i></i><svg><use xlink:href="#circle"></svg></div>',
            nextArrow: '<div class="slick-nav next-arrow"><i></i><svg><use xlink:href="#circle"></svg></div>',
         }).slickAnimation();

         $('.slick-nav').on('click touch', function(e) {

             e.preventDefault();

             var arrow = $(this);

             if(!arrow.hasClass('animate')) {
                 arrow.addClass('animate');
                 setTimeout(() => {
                     arrow.removeClass('animate');
                 }, 1600);
             }

         });
       
          </script>
          <script type="text/javascript">
             jQuery(document).ready(function($) {
            $('.slider_them').slick({
              dots: false,
              infinite: true,
              speed: 500,
              slidesToShow: 3,
              slidesToScroll: 1,
              autoplay: true,
              autoplaySpeed: 2000,
              arrows: true,
               prevArrow: '<div class="slide-arrow3 prev-arrow3"><i class="fa fa-angle-left"></i></div>',
               nextArrow: '<div class="slide-arrow3 next-arrow3"><i class="fa fa-angle-right"></i></div>',
              responsive: [{
                breakpoint: 600,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1
                }
              },
              {
                 breakpoint: 400,
                 settings: {
                    arrows: false,
                    slidesToShow: 1,
                    slidesToScroll: 1
                 }
              }]
          });
      });
         $(document).ready(function() {
                  var scrollTop = $(".up-btn");
                  $(window).scroll(function() {
                      var topPos = $(this).scrollTop();
                      if (topPos > 100) {
                        $(scrollTop).css("opacity", "1");
                      } else {
                        $(scrollTop).css("opacity", "0");
                      }
                  }); 
                  $(scrollTop).click(function() {
                      $('html, body').animate({
                          scrollTop: 0
                      }, 800);
                      return false;
                  }); 
              });
              
      </script>
       <script>
		$(document).ready(function(){
            $('.buttons').click(function(){
                $(this).addClass('active').siblings().removeClass('active');
                var filter = $(this).attr('data-filter')
                if(filter == 'all'){
                    $('.image').show(400);
                }else{
                    $('.image').not('.'+filter).hide(200);
                    $('.image').filter('.'+filter).show(400);
                }
            });
            $('.in_port').magnificPopup({
                delegate:'a',
                type:'image',
                gallery:{
                    enabled:true
                }
            });
        });

		function openCity(evt, cityName) {
		  var i, tabcontent1, tablinks1;
		  tabcontent1 = document.getElementsByClassName("tabcontent1");
		  for (i = 0; i < tabcontent1.length; i++) {
		    tabcontent1[i].style.display = "none";
		  }
		  tablinks1 = document.getElementsByClassName("tablinks1");
		  for (i = 0; i < tablinks1.length; i++) {
		    tablinks1[i].className = tablinks1[i].className.replace(" active", "");
		  }
		  document.getElementById(cityName).style.display = "block";
		  evt.currentTarget.className += " active";
	    }

		document.getElementById("defaultOpen").click();
	    </script>
	  <script>
		  $( ".img-wrapper" ).hover(
		  function() {
		    $(this).find(".img-overlay").animate({opacity: 1}, 600);
		  }, function() {
		    $(this).find(".img-overlay").animate({opacity: 0}, 600);
		  }
		);

		  $(".img-overlay").click(function(event) {
		  event.preventDefault();
		  var imageLocation = $(this).prev().attr("href");
		  $image.attr("src", imageLocation);
		  $overlay.fadeIn("slow");
		});
      </script>
      <script>
        AOS.init();
      </script>
      <script type="text/javascript">
        const pageHeader = document.querySelector(".header");
        const openMobMenu = document.querySelector(".open-mobile-menu");
        const closeMobMenu = document.querySelector(".close-mobile-menu");
        const topMenuWrapper = document.querySelector(".top-menu-wrapper");
        const isVisible = "is-visible";
        const showOffCanvas = "show-offcanvas";
        const noTransition = "no-transition";
        let resize;
        openMobMenu.addEventListener("click", () => {
          topMenuWrapper.classList.add(showOffCanvas);
        });
        closeMobMenu.addEventListener("click", () => {
          topMenuWrapper.classList.remove(showOffCanvas);
        });
        window.addEventListener("resize", () => {
          pageHeader.querySelectorAll("*").forEach(function(el) {
            el.classList.add(noTransition);
          });
          clearTimeout(resize);
          resize = setTimeout(resizingComplete, 500);
        });

        function resizingComplete() {
          pageHeader.querySelectorAll("*").forEach(function(el) {
            el.classList.remove(noTransition);
          });
        }
        
      //   $('#menu > nav ul.nav1 li a').click(function(e) {
      //    var $this = $(this);
      //    $this.parent().siblings().removeClass('active').end().addClass('active');
      //     e.preventDefault();
      // });
      $(document).ready(function () {

            $('#contact-form').validate({ // initialize the plugin
               rules: {
                  name: {
                        required: true,
                        minlength : 3
                  },
                  email: {
                        required: true,
                        email: true
                     },
                     phone: {
                        required:true,
                        minlength:10,
                        maxlength:10,
                     },
                     subject : {
                        required:true,
                        maxlength:50,
                     },
                     message : {
                        required:true,
                        maxlength:200
                     }
               }
            });

            $('#subscription-form').validate({ // initialize the plugin
               rules: {
                     email: {
                        required: true,
                        email: true
                     }
               }
            });

      });

    </script>
</body>
</html>


