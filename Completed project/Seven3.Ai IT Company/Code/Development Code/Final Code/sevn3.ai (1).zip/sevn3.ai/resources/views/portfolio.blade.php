@extends('layout.app')
@section('content')
<div class="co-banner1">
        <div class="container">
            <h1>Portfolio</h1>
            <ul class="breadcrumb1">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li>/</li>
                <li>Portfolio</li>
            </ul>
        </div>
    </div>
    <section>
    	<div class="in_port">
    		<div class="container">
    			<div class="tab1" data-aos="fade-up" data-aos-duration="3000">
             @foreach($categories as $key => $folio)
             @if ($key == 0) 
             <button class="tablinks1" onclick="openCity(event, '{{ $folio->id}}')"  id="defaultOpen">{{ $folio->name }}</button>
             @else
             <button class="tablinks1" onclick="openCity(event, '{{ $folio->id}}')">{{ $folio->name }}</button>
             @endif 
            @endforeach  
				</div>
            @foreach($categories as $key => $folio)
	            <div id="{{$folio->id}}" class="tabcontent1" data-aos="fade-up" data-aos-duration="3000">
				    <section id="gallery">
						<div class="container">
						  <div id="image-gallery">
						    <div class="row">
                         @foreach($portfolio as $val )
                         @if ($val->category_id == $folio->id)   
                      <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 image pro_div">
						      	 <a href="uploads/{{ $val->image }}" class="">
						        <div class="img-wrapper">
						         <img src="uploads/{{ $val->image }}" width="300px" height="270px">
						          <div class="img-overlay">
						            <i class="fa fa-plus-circle" aria-hidden="true"></i>
						          </div>
						        </div>
						      </a>
						      </div>
                        @endif 
                        @endforeach 
						    </div>
						 </div>
						</div>
					</section>
    		    </div>
              @endforeach       
    	    </div>
    	</div>
    </section>
    <div class="copy">
        <a class="up-btn show-1" href="#"><i class="fas fa-angle-double-up"></i></a>
    </div>  

@endsection

     