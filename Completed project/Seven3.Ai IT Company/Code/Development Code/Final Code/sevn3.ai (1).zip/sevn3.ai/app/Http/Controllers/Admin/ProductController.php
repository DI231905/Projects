<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\support\facades\validator;
use DB;

class ProductController extends Controller
{
     public function __construct(){

                $this->middleware('auth:admin');
        }

       public function addproduct(){
  
        return view('admin.addproduct');

       }

         public function storeproduct(Request $request){


       	  $request->validate([

            'name' => 'required',
            'description' => 'required',
           
           
        ]);

       	  $name=$request->input('name');
      
           $description=$request->input('description');

       

        DB::table('product')->insert(['name'=>$name,'description'=>$description]);
       
          return redirect('admin/home')->with('error',' Product data inserted succcesfully!!!!');

 

         }


        public function deleteproduct($id){

      
        DB::table('product')->where('id', $id)->delete();

        return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);


        }


      public function updateproduct($id){ 

        $product= DB::table('product')->where('id', $id)->get();
       
        $data['id']=$product[0]->id;
        $data['name']=$product[0]->name;
        $data['description']=$product[0]->description;
       
       
        return view('admin.updateproduct',$data);

       
       }

        public function storeupdateproduct(Request $request,$id){


         $request->validate([

            'name' => 'required',
            'description'=>'required',
           
        ]);
       
        $name=$request->input('name');
        $description=$request->input('description');
     
       

          DB::table('product')->where('id', $id)->update(['name'=>$name,'description'=>$description]);

           return redirect('admin/home')->with('error','product data updated sucessfully!!');

    }

      public function addproductdetail(){
  
        return view('admin.addproductdetail');

       }

        public function storeproductdetail(Request $request){


          $request->validate([
            'image'=>'required',
            'name' => 'required',
            'short_desc' => 'required',
            'description' => 'required',
           
           
        ]);

           $name=$request->input('name');
           $short_desc=$request->input('short_desc');
           $description=$request->input('description');
           $file=$request->file('image');

           $imagename='';

             if ($file) {
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();

         $file->move($destinationPath,$imagename);
      
          }

       
         DB::table('productdetail')->insert(['name'=>$name,'description'=>$description,'short_desc'=>$short_desc,'image'=>$imagename]);
       
          return redirect('admin/home')->with('error',' Product data inserted succcesfully!!!!');


         }

      public function updateproductdetail($id){

        
       $productdetail=DB::table('productdetail')->where('id', $id)->get();
      
        $data['id']=$productdetail[0]->id;
        $data['name']=$productdetail[0]->name;
        $data['image']=$productdetail[0]->image;
        $data['short_desc']=$productdetail[0]->short_desc;
        $data['description']=$productdetail[0]->description;
      
        return view('admin.updateproductdetail',$data);   

      }

        public function storeupdateproductdetail(Request $request,$id){


           $request->validate([

            'name' => 'required',
            'short_desc' => 'required', 
            'description' => 'required', 
           
           
        ]);
       
           $name=$request->input('name');
           $short_desc=$request->input('short_desc');
           $description=$request->input('description');
           $file=$request->file('image');

          $imagename=' ';

        if($file){
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('productdetail')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink(public_path("/uploads/".$request->input('oldimage')));

             }

           }

          DB::table('productdetail')->where('id', $id)->update(['name'=>$name,'description'=>$description,'short_desc'=>$short_desc]);

           return redirect('admin/home')->with('error',' update product data succcesfully!!!!');;

          }


       public function deleteproductdetail($id){


        $productdetail= DB::table('productdetail')->where('id', $id)->get();



         if ($productdetail[0]->image!='') {

         

            unlink(public_path("/uploads/".$productdetail[0]->image));

          }

        DB::table('productdetail')->where('id', $id)->delete();

   return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);

      } 
       







}
