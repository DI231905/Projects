<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class serviceController extends Controller
{
      public function __construct(){

                $this->middleware('auth:admin');
        }


          public function addserviceview(){
  
        return view('admin.addservices');

       }

        public function storeservice(Request $request){


        $request->validate([

             'name' =>'required',
             'icon'=>'required',
             'description'=>'required', 

        ]);
       
         $name=$request->input('name');
         $icon=$request->input('icon');
         $description=$request->input('description');
        
    

         DB::table('service')->insert(['name'=>$name,'icon'=>$icon, 'description'=>$description]);
       
          return redirect('admin/home')->with('error','your service has been inserted sucessfully' );
          
    }


     public function deleteservice($id){

      
        DB::table('service')->where('id', $id)->delete();

      return response()->json([
            'success' => 'Record has been deleted successfully!'
          ]);

    }

      public function updateservice($id){

    

      $service= DB::table('service')->where('id', $id)->get();
       
        //$work=DB::table('work')->where('id',$id)->get();
        $data['id']=$service[0]->id;
        $data['name']=$service[0]->name;
        $data['icon']=$service[0]->icon;
     
     
        $data['description']=$service[0]->description;
       
        return view('admin.updateservice',$data);

       
       }

  public function storeupdateservice(Request $request,$id){


      $request->validate([

            'name' => 'required',
            'icon'=> 'required',
            'description' => 'required',
           
           
        ]);
       
           $name=$request->input('name');
           $icon=$request->input('icon');
           $description=$request->input('description');
        

    
          DB::table('service')->where('id', $id)->update(['name'=>$name,'icon'=>$icon,'description'=>$description]);

           return redirect('admin/home')->with('error','your service has been updated sucessfully' );

    }





}
