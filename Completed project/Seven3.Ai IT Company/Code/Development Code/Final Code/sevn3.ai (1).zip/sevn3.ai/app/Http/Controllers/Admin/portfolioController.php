<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;
use Illuminate\support\facades\Redirect;

class portfolioController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function add_category()
    {
        return view('admin.addportfolio_type');
    }

    public function storecategory(Request $request)
    {
        $request->validate([
             'name' => 'required',
        ]);

        $name = $request->input('name');

        $catgory = DB::table('category_list')->where('name', $name)->count();

        if ($catgory) {
            return redirect()->back()->with('error', 'This category is already insterted!!!');
        } else {
            DB::table('category_list')->insert(['name' => $name]);

            return redirect('admin/home')->with('error', 'your category has been inserted sucessfully');
        }
    }

    public function addportfolio()
    {
        $category_list = DB::table('category_list')->get();
        $data['category_list'] = $category_list;

        return view('admin.addportfolio', $data);
    }

    public function storeportfolio(Request $request)
    {
        $request->validate([
            'type' => 'required',
            'image' => 'required',
        ]);

        $type1 = $request->input('type');
        $type = DB::table('category_list')->where('id', $type1)->get();
        $portfolio_type = $type[0]->name;
        $file = $request->file('image');

        $imagename = '';

        if ($file) {
            $destinationPath = 'uploads';
            $imagename = time().'_'.$file->getClientOriginalName();

            $file->move($destinationPath, $imagename);
        }

        DB::table('portfolio')->insert(['name' => $portfolio_type, 'category_id' => $type1, 'image' => $imagename]);

        return redirect('admin/home')->with('error', ' Portfolio data inserted succcesfully!!!!');
    }

    public function deleteportfolio($id)
    {
        $portfolio = DB::table('portfolio')->where('id', $id)->get();

        if ($portfolio[0]->image != '') {
            unlink(public_path('/uploads/'.$portfolio[0]->image));
        }

        DB::table('portfolio')->where('id', $id)->delete();

        return response()->json([
            'success' => 'Record has been deleted successfully!',
          ]);
    }

    public function updateportfolio($id)
    {
        $category_list = DB::table('category_list')->get();
        $data['category_list'] = $category_list;

        $portfolio = DB::table('portfolio')->where('id', $id)->get();

        $data['id'] = $portfolio[0]->id;

        $data['image'] = $portfolio[0]->image;
        $data['type'] = $portfolio[0]->name;

        $type1 = $portfolio[0]->name;

        $type = DB::table('category_list')->where('name', $type1)->get();
        $data['type_id'] = $type[0]->id;

        return view('admin.updateportfolio', $data);
    }

    public function storeupdatedportfolio(Request $request, $id)
    {
        $request->validate([
            'type' => 'required',
        ]);

        $type1 = $request->input('type');

        $type = DB::table('category_list')->where('id', $type1)->get();
        $category = $type[0]->name;

        $file = $request->file('image');
        $imagename = ' ';

        if ($file) {
            $destinationPath = 'uploads';
            $imagename = time().'_'.$file->getClientOriginalName();

            $file->move($destinationPath, $imagename);

            DB::table('portfolio')->where('id', $id)->update(['image' => $imagename]);

            if ($request->input('oldimage') != '') {
                unlink(public_path('/uploads/'.$request->input('oldimage')));
            }
        }

        DB::table('portfolio')->where('id', $id)->update(['name' => $category, 'category_id' => $type1]);

        return redirect('admin/home')->with('error', ' update Team member data succcesfully!!!!');
    }
}
