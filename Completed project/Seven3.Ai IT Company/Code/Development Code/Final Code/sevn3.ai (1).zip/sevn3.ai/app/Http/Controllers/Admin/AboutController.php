<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;
use Illuminate\support\facades\Redirect;

class AboutController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function addwhychooseus()
    {
        return view('admin.addwhychoose');
    }

    public function storewhychooseus(Request $request)
    {
        $request->validate([
            'icon' => 'required',
             'title' => 'required',
            'description' => 'required',
        ]);

        $icon = $request->input('icon');
        $title = $request->input('title');
        $description = $request->input('description');

        DB::table('whychooseus')->insert(['icon' => $icon, 'title' => $title, 'description' => $description]);

        return redirect('admin/home')->with('error', ' why choose us data inserted succcesfully!!!!');
    }

    public function deletewhychooseus($id)
    {
        DB::table('whychooseus')->where('id', $id)->delete();

        return response()->json([
            'success' => 'Record has been deleted successfully!',
          ]);
    }

    public function updatewhychooseus($id)
    {
        $whychooseus = DB::table('whychooseus')->where('id', $id)->get();

        $data['id'] = $whychooseus[0]->id;
        $data['icon'] = $whychooseus[0]->icon;
        $data['title'] = $whychooseus[0]->title;
        $data['description'] = $whychooseus[0]->description;

        return view('admin.updatewhychoose', $data);
    }

    public function storeupdatewhychooseus(Request $request, $id)
    {
        $request->validate([
            'icon' => 'required',
            'title' => 'required',
            'description' => 'required',
        ]);

        $icon = $request->input('icon');
        $title = $request->input('title');
        $description = $request->input('description');

        DB::table('whychooseus')->where('id', $id)->update(['icon' => $icon, 'title' => $title, 'description' => $description]);

        return redirect('admin/home')->with('error', 'why choose us data updated sucessfully!!');
    }

    public function teamview()
    {
        return view('admin.teamview');
    }

    public function addteam(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
        ]);

        $name = $request->input('name');
        $file = $request->file('image');
        $occupation = $request->input('occupation');
        $fblink = $request->input('fblink');
        $instalink = $request->input('instalink');
        $twitterlink = $request->input('twitterlink');
        $imagename = ' ';

        if ($file) {
            $destinationPath = 'uploads';
            $imagename = time().'_'.$file->getClientOriginalName();

            $file->move($destinationPath, $imagename);
        }

        DB::table('team')->insert(['name' => $name, 'image' => $imagename, 'occupation' => $occupation, 'twitterlink' => $twitterlink, 'fblink' => $fblink, 'instalink' => $instalink]);

        return redirect('admin/home')->with('error', ' insert Team member data succcesfully!!!!');
    }

    public function teamdelete($id)
    {
        $team = DB::table('team')->where('id', $id)->get();

        if ($team[0]->image != '') {
            unlink(public_path('/uploads/'.$team[0]->image));
        }

        DB::table('team')->where('id', $id)->delete();

        return response()->json([
            'success' => 'Record has been deleted successfully!',
          ]);
    }

    public function teamupdateview($id)
    {
        $team = DB::table('team')->where('id', $id)->get();

        $data['id'] = $team[0]->id;
        $data['name'] = $team[0]->name;
        $data['image'] = $team[0]->image;
        $data['occupation'] = $team[0]->occupation;
        $data['twitterlink'] = $team[0]->twitterlink;
        $data['fblink'] = $team[0]->fblink;
        $data['instalink'] = $team[0]->instalink;

        return view('admin.updateteamview', $data);
    }

    public function storeupdateteam(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $name = $request->input('name');
        $occupation = $request->input('occupation');
        $fblink = $request->input('fblink');
        $twitterlink = $request->input('twitterlink');
        $instalink = $request->input('instalink');

        $file = $request->file('image');
        $imagename = ' ';

        if ($file) {
            $destinationPath = 'uploads';
            $imagename = time().'_'.$file->getClientOriginalName();

            $file->move($destinationPath, $imagename);

            DB::table('team')->where('id', $id)->update(['image' => $imagename]);

            if ($request->input('oldimage') != '') {
                unlink(public_path('/uploads/'.$request->input('oldimage')));
            }
        }

        DB::table('team')->where('id', $id)->update(['name' => $name, 'occupation' => $occupation, 'twitterlink' => $twitterlink, 'fblink' => $fblink, 'instalink' => $instalink]);

        return redirect('admin/home')->with('error', ' update Team member data succcesfully!!!!');
    }
}
