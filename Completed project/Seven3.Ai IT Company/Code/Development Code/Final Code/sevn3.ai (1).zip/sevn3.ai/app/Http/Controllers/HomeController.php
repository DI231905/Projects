<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use Validator;

class HomeController extends Controller
{
    public function index()
    {
        $why_choose_us_odd = DB::table('whychooseus')->take(2)->get()->toArray();
        $why_choose_us_even = DB::table('whychooseus')->skip(2)->take(2)->get()->toArray();
        $services = DB::table('service')->get()->take(6)->toArray();
        $products = DB::table('product')->get()->take(4)->toArray();
        $contacts = DB::table('admindetail')->get()->toArray();

        $data['why_choose_odd'] = $why_choose_us_odd;
        $data['why_choose_even'] = $why_choose_us_even;
        $data['services'] = $services;
        $data['products'] = $products;
        $data['contacts'] = $contacts;

        return view('welcome', $data);
    }

    public function about()
    {
        $why_choose_us_odd = DB::table('whychooseus')->take(3)->get()->toArray();
        $why_choose_us_even = DB::table('whychooseus')->skip(3)->take(3)->get()->toArray();
        $teams = DB::table('team')->get()->toArray();
        $contacts = DB::table('admindetail')->get()->toArray();

        $data['why_choose_odd'] = $why_choose_us_odd;
        $data['why_choose_even'] = $why_choose_us_even;
        $data['teams'] = $teams;
        $data['contacts'] = $contacts;

        return view('about', $data);
    }

    public function service()
    {
        $services = DB::table('service')->get()->toArray();
        $contacts = DB::table('admindetail')->get()->toArray();

        $data['services'] = $services;
        $data['contacts'] = $contacts;

        return view('service', $data);
    }

    public function product()
    {
        $products = DB::table('productdetail')->get()->toArray();
        $contacts = DB::table('admindetail')->get()->toArray();

        $data['products'] = $products;
        $data['contacts'] = $contacts;

        return view('product', $data);
    }

    public function porfolio()
    {
        $categories = DB::table('category_list')->get()->toArray();
        $portfolio = DB::table('portfolio')->get()->toArray();
        $contacts = DB::table('admindetail')->get()->toArray();

        $data['categories'] = $categories;
        $data['portfolio'] = $portfolio;
        $data['contacts'] = $contacts;

        return view('portfolio', $data);
    }

    public function contactus()
    {
        $contacts = DB::table('admindetail')->get()->toArray();

        $data['contacts'] = $contacts;

        return view('contactus', $data);
    }

    public function storeEnquiry(Request $request)
    {
        $validator = Validator::make($request->all(), [
                'name' => 'required',
                'email' => 'required|email',
                'phone' => 'required|digits:10',
                'subject' => 'required',
                'message' => 'required',
            ]);

        if ($validator->fails()) {
            return redirect('/contactus')
                         ->withErrors($validator)
                         ->withInput();
        }
        // if ($validator->fails()) {
        //     return redirect('/contactus')->with('Validation_Error.', $validator->errors());
        // }

        $name = $request->input('name');
        $email = $request->input('email');
        $phone = $request->input('phone');
        $subject = $request->input('subject');
        $message = $request->input('message');

        DB::table('contact_us')->insert(['name' => $name, 'email' => $email, 'phone' => $phone, 'subject' => $subject, 'message' => $message, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);

        return redirect('/contactus')->with('error', 'Thanks for your comments, we will get back soon with reply !!!');
    }

    public function subscription(Request $request)
    {
        $validator = Validator::make($request->all(), [
                'email' => 'required|email',
            ]);

        if ($validator->fails()) {
            return redirect('/')
                         ->withErrors($validator)
                         ->withInput();
        }
        $email = $request->input('email');
        DB::table('subscription')->insert(['email' => $email, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);

        return redirect('/')->with('error', 'Thanks for your subscription !!!');
    }
}
