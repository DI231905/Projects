@extends('layouts.app')

@section('content')
    <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/about-bg.jpg">
    	    </div>
    	    <div class="about">
    	    	<div class="container">
    	    		<h2>Services</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">Services</li>
    		        </ul>
    	    	</div>
    	    </div>
    	</div>
    </div>
    <div class="co_service">
		<div class="container">
			<div class="row">
				 @foreach($services as  $key =>$s)
                <div class="col-lg-4 col-md-6 col-12 part">
                    <div class="set-service">
                        <div class="service bg1" style="background-image: url(/uploads/{{$s->image}});">
                            <div class="service-info">
                                <h2>{{$s->name}}</h2>
                                <p>{{$s->description}}</p>
                                <a href="#">Read More</a>
                                <div class="figcaption-number animate-in-to-top-content">

                                     <span>0{{$key+1}}</span>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
				
			</div>
		</div>
	</div>
	
	

	
	  @endsection