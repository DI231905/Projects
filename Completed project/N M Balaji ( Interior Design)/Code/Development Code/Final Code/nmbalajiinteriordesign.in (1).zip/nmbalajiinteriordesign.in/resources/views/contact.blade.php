@extends('layouts.app')

@section('content')
<div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/about-bg.jpg">
    	    </div>
    	    <div class="about">
    	    	<div class="container">
    	    		<h2>Contact</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">Contact Us</li>
    		        </ul>
    	    	</div>
    	    </div>
    	</div>
    </div>

    @if ($errors->any())
                        <div id="hideDiv" class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li  style="color:red;">{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif 

     @if(session()->has('error'))
                           <div id="hideDiv" class="alert alert-success">
                           {{ session()->get('error') }}
                         </div>
                    @endif


    <div class="co_part-3">
	    <div class="container">
	    	<div class="part-3">
	    		<div class="set-part-3">
	    			<div class="contact-icon">
	    				<i class="fa fa-map"></i>
	    			</div>
	    			<div class="add">
	    				<h2>our office:</h2>
	    				<p>{{$address}}</p>
	    			</div>
	    		</div>
	    		<div class="set-part-3">
	    			<div class="contact-icon">
	    				<i class="fa fa-phone"></i>
	    			</div>
	    			<div class="add">
	    				<h2>contact number:</h2>
	    				<p>{{$mobileno}}</p>
	    			</div>
	    		</div>
	    		<div class="set-part-3">
	    			<div class="contact-icon">
	    				<i class="fa fa-envelope"></i>
	    			</div>
	    			<div class="add">
	    				<h2>Email us:</h2>
	    				<p>{{$email}}</p>
	    			</div>
	    		</div>
	    	</div>
    	</div>
    </div>

   
      

    <div class="co_form1">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-6 col-md-6 col-12">
    				<h2>Contact Us</h2>
    				<form method="POST" action="{{url('/Contactusfrom')}}">
	    		@csrf
	    		<div class="port">
	    			<div class="text2">
	    				<input type="text" placeholder="Name" name="name"  value="" required>
	    			</div>
	    		</div>
	    		<div class="port">
	    			<div class="text2">
	    				<input type="text" placeholder="Email" name="email"  value="" required>
	    			</div>
	    		</div>
	    		<div class="port">
	    			<div class="text2">
	    				<input type="text" placeholder="Subject" name="subject" value="" required>
	    			</div>
	    		</div>
	    		<div class="text1">
	    			<textarea placeholder="Your Message" name="description"  value="" required></textarea>
	    		</div>
    			<div class="sub">
    			    <input type="submit" value="Send Message">
    			</div>
    		</form>
    			</div>
    			<div class="col-lg-6 col-md-6 col-12">
    				<div class="map1">
    	                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59764.094077289905!2d72.96736868876388!3d20.577605478419326!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be0c33d2794f769%3A0x6c130b07faf22184!2sN%20M%20Balaji%20Interior%20Design!5e0!3m2!1sen!2sin!4v1628667157218!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
    			</div>
    		</div>
    	</div>
    </div>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script type="text/javascript">
       
 $(function() {
setTimeout(function() {$("#hideDiv").fadeOut(1500); }, 5000)

});

</script>

     @endsection