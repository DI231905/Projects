@extends('layouts.app')

@section('content')
    <div class="co_banner">
        <div id="demo" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators">
                <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                <li data-target="#demo" data-slide-to="2"></li>
            </ul>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="banner-img">
                        <img src="image/banner1.jpg" alt="banner1.jpg">
                    </div>
                    <div class="banner-info">
                        <div class="inner-banner"></div>
                        <div class="banner-content">
                            <h1>Our Functional <br>Designs Energize <br>Your Living Space</h1>
                            <button class="my-btn btn14"><a style="color: black;" href="{{url('/About')}}">Read More</a></button>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="banner-img">
                        <img src="image/banner2.jpg" alt="banner2.jpg">
                    </div>
                    <div class="banner-info">
                        <div class="inner-banner"></div>
                        <div class="banner-content">
                            <h1>Complete Residential <br> & Commercial <br> Interior Solutions </h1>
                            <button class="my-btn btn14"><a style="color: black;" href="{{url('/About')}}">Read More</a></button>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="banner-img">
                        <img src="image/banner3.jpg" alt="banner3.jpg">
                    </div>
                    <div class="banner-info">
                        <div class="inner-banner"></div>
                        <div class="banner-content">
                            <h1>Make Bold <br>Statement With <br>Inviting Interiors </h1>
                           <button class="my-btn btn14"><a style="color: black;" href="{{url('/About')}}">Read More</a></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_about">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="about1">
                        <h1>An Efficient Interior Design Team </h1>
                        <p>Designing residential and commercial properties has become our forte and almost every functional space is customised to the client’s personal choice such as bedrooms, guest rooms, entertainment areas, reception areas, etc. We believe in a client-first approach and listening to their unique demands and customising them accordingly.</p>
                        <ul class="about-list">
                            <li><i class="far fa-chevron-right"></i>PAN India Presence </li>
                            <li><i class="far fa-chevron-right"></i>Personalised Interior Design Services </li>
                            <li><i class="far fa-chevron-right"></i>Plan and Design Luxury Residences</li>
                            <li><i class="far fa-chevron-right"></i>Clientelle Include High Net Worth Individuals</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-bg">
                        <img src="image/video-bg.jpg">
                        <div class="wrapper">
                            <div class="video-main">
                                <div class="promo-video">
                                    <div class="waves-block">
                                        <div class="waves wave-1"></div>
                                        <div class="waves wave-2"></div>
                                        <div class="waves wave-3"></div>
                                    </div>
                                </div>
                                <a href="#" class="video video-popup mfp-iframe" data-toggle="modal" data-target="#VideoPop"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal -->
            <div class="modal fade VideoPopup" id="VideoPop" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-body p-0">
                            <iframe width="100%" height="380" src="/uploads/{{$name1}}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <div class="modal-icon"><i class="fal fa-times-circle"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_discount">
        <div class="container">
            <div class="row">
               
               @foreach($offers as $o)
                <div class="col-lg-6 col-md-6 col-12">
                <div class="banner1">
                    <div class="set-banner1">
                        <div class="inner1">
                            <a href="#"><img src="/uploads/{{$o->image}}"></a>
                        </div>
                        <div class="inner2">   
                            <div class="promo-text-box">                
                                <h3 class="promo-title">{{$o->discount}} </h3>
                                <p class="promo-desc">{{$o->name}}</p>        
                                
                            </div>           
                        </div> 
                    </div>         
                </div>
                 </div>
                @endforeach
              
            </div>  
        </div>  
    </div>
    <div class="co_service">
        <div class="container">
            <h6 class="section-head">Complete Solutions</h6>
            <h1 class="title">Our Services</h1>
            <div class="row row1">

               @foreach($services as $key =>$s)
                <div class="col-lg-4 col-md-6 col-12 part">
                    <div class="set-service">
                        <div class="service bg1" style="background-image: url(/uploads/{{$s->image}});">
                            <div class="service-info">
                                <h2>{{$s->name}}</h2>
                                <p>{{$s->description}}</p>
                                <a href="{{url('/Service')}}">Read More</a>
                                <div class="figcaption-number animate-in-to-top-content">

                                    <span>0{{$key+1}}</span> 
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    <div class="co_testimonial">
        <div class="container">
            <h6 class="section-head">Testimonials</h6>
            <h1 class="title">What Our Clients Have To Say </h1>
        
            <div class="main1">
                <div class="slider slider-nav">
                  @foreach($testimonial as $t) 
                    <div>
                        <div class="testimonial">
                            <span class="testi-icon1">
                                <img src="image/left-quote.png" alt="">
                            </span>
                            <div class="client-area">
                                <h6>{{$t->name}}</h6> 
                                
                            </div>
                            <p>{{$t->description}}</p>
                        </div>
                    </div>
                    @endforeach
        
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="co_portfolio">
        <div class="container">
            <h6 class="section-head">Best Works</h6>
            <h1 class="title">Portfolio</h1>
            <div class="gallery">
            <div class="row row1">
              
                
             
                <div class="image-container">
                     @foreach($portfolio as $p)
                    <a href="/uploads/{{$p->image}}" class="image">
                        <div class="product-list set-product">
                            <img src="/uploads/{{$p->image}}" alt="">
                            <div class="product-name">
                                <i class="search far fa-search-plus"></i>
                                <h5>{{$p->name}}</h5>
                                <span>{{$p->brand}}</span>
                            </div>
                        </div>
                    </a>
                    @endforeach
                </div>

                
            </div>
        </div>
    </div>
</div> -->
  <!--  <div class="co_portfolio">
        <div class="container">
            <h6 class="section-head">Best Works</h6>
            <h1 class="title">Portfolio</h1>
            <div class="gallery">
               
                 <div class="row1">
                      
                <div class="image-container">
                    @foreach($portfolio as $p)
                    <a href="/uploads/{{$p->image}}" class="image">
                        <div class="product-list set-product">
                            <img src="/uploads/{{$p->image}}" alt="">
                            <div class="product-name">
                                <i class="search far fa-search-plus"></i>
                                <h5>{{$p->name}}</h5>
                                <span>{{$p->brand}}</span>
                            </div>
                        </div>
                    </a>
                  @endforeach
                  
                </div>
                
            </div>

        </div>
        </div>
    </div>-->

<div class="co_portfolio">
		<div class="container">
			<h6 class="section-head">Best Works</h6>
			<h1 class="title">Portfolio</h1>
			<div class="row row1">
			       @foreach($portfolio as $p)
				<span href="/uploads/{{$p->image}}" data-toggle="lightbox" data-gallery="gallery" class="col-lg-4 col-md-6 col-12">
                    <div class="product-list">
                        <img src="/uploads/{{$p->image}}" class="img-fluid">
                        <div class="product-name">
                        	<i class="search far fa-search-plus"></i>
                        	<h5>{{$p->name}}</h5>
                            <span>{{$p->brand}}</span>
                        </div>
                    </div>
                </span>
                 @endforeach
               
			</div>
		</div>
	</div>


<style type="text/css">
 
/*-------Modal css-------------*/
.modal-header .close {
    padding: 0!important;
    margin: 0;
    color: #fff;
    opacity: 1;
    position: absolute;
    top: 0px;
    right: -20px;
}
.modal-header {
    background: transparent !important;
    margin: 0!important;
    padding: 0!important;
}
.modal-content {
    background: transparent!important;
    border: unset!important;
}
.modal-body {
    background: #fff !important;
}
.close {
  position: absolute;
  right: 32px;
  top: 32px;
  width: 32px;
  height: 32px;
  opacity: 0.3;
}
.close:hover {
  opacity: 1;
}
.close:before, .close:after {
    top: 0;
    position: absolute;
    left: 0;
    content: ' ';
    height: 25px;
    width: 2px;
    background-color: #fff;
}
.close:before {
  transform: rotate(45deg);
}
.close:after {
  transform: rotate(-45deg);
}
.modal-header .close span {
    display: none;
}
button.close:focus {
    outline: unset;
}
.ekko-lightbox a {
    opacity: 1;
    text-decoration: none;
}
.ekko-lightbox-nav-overlay a span {
    padding: 0 15px;
}
@media only screen and (max-width:767px){
.modal-dialog {
    padding: 0 15px;
}
}
</style>

    @endsection