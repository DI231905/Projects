

<?php $__env->startSection('content'); ?>
    <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/about-bg.jpg">
    	    </div>
    	    <div class="about">
    	    	<div class="container">
    	    		<h2>About</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">About</li>
    		        </ul>
    	    	</div>
    	    </div>
    	</div>
    </div>
    <div class="co_about">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-6 col-md-12 col-12">
    				<div class="about-info">
    				    <h3>Raising the Design & Décor Standards</h3>
    				    <p>The hero of this story is always our clients, who are worthy of our best endeavours. NM Balaji Interiors bring residential and commercial design and décor solutions right to your doorstep. Our unmatched experience and expertise bring you complete interior solutions for all your spaces. We ensure that your space is aesthetically pleasing and also captures the reflection of your personality.</p>
    				    <p>With over years of experience catering to the diverse and unique demands of our global clients, we bring your blueprint into reality by acknowledging your requirements for a winning solution that transforms your living space with the best design quality. We craft practical solutions that stand the test of time with the finest craftsmanship.</p>
    				</div>
    			</div>
    			<div class="col-lg-6 col-md-12 col-12">
    				<div class="row">
    					<div class="main-mission">
    						<div class="mission">
    							<img src="image/mission-2.jpg">
    						</div>
    					</div>
    					<div class="main-mission">
    						<div class="mission-detail">
    							<div class="set-mission-detail">
    							    <img src="image/writing.png">
    							    <h2>Mission</h2>
    						    </div>
    							<div class="icon-box-content effect-box">
        	                        <div class="effect-btn">
				                       <i class="cross-arrow fal fa-arrows-v"></i>
			                        </div>
                                    <p class="icon-box-desc">We desire to add value to your space with functional beautiful and stylish design. </p>
                                </div>
    						</div>
    					</div>
    					<div class="main-mission">
    						<div class="mission-detail m-detail1">
    							<div class="set-mission-detail">
    							    <img src="image/writing.png">
    							    <h2>Vision</h2>
    						    </div>
    							<div class="icon-box-content1 effect-box e-box1">
        	                        <div class="effect-btn">
				                       <i class="c-arrow1 fal fa-arrows-v"></i>
			                        </div>
                                    <p class="icon-box-desc">we envision being the best team and delivering the best spatial design and excellent services to a wide range.</p>
                                </div>
    						</div>
    					</div>
    					<div class="main-mission">
    						<div class="mission">
    							<img src="image/mission-1.jpg">
    						</div>
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
    <div class="co_choose">
        <div class="container">
            <h1 class="title">WHY CHOOSE NM BALAJI</h1>
            <div class="row row1">
                <div class="col-lg-4 col-md-6 col-12 holder">
                    <div class="icon-holder">
                        <img src="image/why-1.png">
                    </div>
                    <div class="text-holder">
                        <h3>5 Years of Experince</h3>
                        <p>We rely on our advanced experience and professional knowledge in the design field through the process of interior remodelling, interior finishing, and new construction, with exceptional customer service.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 holder">
                    <div class="icon-holder">
                        <img src="image/why-2.png">
                    </div>
                    <div class="text-holder">
                        <h3>Creative Designers</h3>
                        <p>Our team of designers understand each project according to requirement, budget, and the level of quality that is expected. Each residential and commercial project starts with a personalised concept relating to your individual style and vision. </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 holder">
                    <div class="icon-holder">
                        <img src="image/why-3.png">
                    </div>
                    <div class="text-holder">
                        <h3>Quality Products</h3>
                        <p>With us, you get access to the antique, modern, and contemporary home decor products and accessories ready to add a personal touch to your space for an energized and vibrant look. </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 holder">
                    <div class="icon-holder">
                        <img src="image/why-4.png">
                    </div>
                    <div class="text-holder">
                        <h3>24/7 Customer Support</h3>
                        <p>Our in-house team of expert designers and support team will guide you every step of the way with any design and decor specification and deliver the best possible outcome. </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 holder">
                    <div class="icon-holder">
                        <img src="image/why-5.png">
                    </div>
                    <div class="text-holder">
                        <h3>Value for Investment </h3>
                        <p>By working with experts, you not only have the benefit of our industry knowledge, but also of our trusted and preferred suppliers and traders giving you a finished project that best meets your needs and demands.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 holder">
                    <div class="icon-holder">
                        <img src="image/why-6.png">
                    </div>
                    <div class="text-holder">
                        <h3>Free Consultation</h3>
                        <p>With us, you get free consultation without any obligation. All you need is to send us your enquiries via mail <?php echo e($email); ?> or call us on <?php echo e($mobileno); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
   <!--  <div class="co_team">
    	<div class="container">
    		<h1 class="title">our team</h1>
    		<div class="main1 row1">
                <div class="slider slider-nav1">
                    <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                	    <div class="box15">
                            <img src="/uploads/<?php echo e($t->image); ?>" alt="">
                            <div class="box-content">
                                <h3 class="title"><?php echo e($t->name); ?></h3>
                                <ul class="icon">
                                  <li><a href="<?php echo e($t->fblink); ?>"><i class="fab fa-facebook-f"></i></a></li>
                                  <li><a href="<?php echo e($t->instalink); ?>"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
            </div>
    	</div>
    </div> -->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
        <script>
            $('.slider-nav1').slick({
                autoplay: true,
            	autoplayspeed: 1500,
                slidesToShow: 3,
                slidesToScroll: 1,
                dots: true,
                arrows:false,
                adaptiveHeight: true,
                focusOnSelect: true,
                 responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            adaptiveHeight: true,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
            });
        </script>
     <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/resources/views/Aboutview.blade.php ENDPATH**/ ?>