<!DOCTYPE html>
<html>
<head>
	<title>NM Balaji Interior</title>
	<link rel="stylesheet" type="text/css" href="/css/admin.css">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
<div class="main-form">
	<div class="form">
	    <h2>RESET PASSWORD</h2>

	  <!--   <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>  -->
       
           <?php if(session()->has('error')): ?>
                   <div class="alert alert-danger">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?> 
	    <form class="form1" method="POST" action="<?php echo e(route('resetpassword')); ?>">
	       <?php echo csrf_field(); ?>
		    <div class="email">
		    	<div class="icon">
		    		<span class="fa fa-envelope"></span>
		    	</div>
		    	<div class="text">
		    		 <input type="text" placeholder="Email" name="email" value="<?php echo e($email); ?>" required>
		    	</div>  
		    </div>
		    <div class="email">
		    	<div class="icon">
		    		<span class="fa fa-lock"></span>
		    	</div>
		    	<div class="text">
		    		<input type="text" placeholder="OTP" name="token" value=""required>
		    	</div> 
		    </div>
		    <div class="email">
		    	<div class="icon">
		    		<span class="fa fa-lock"></span>
		    	</div>
		    	<div class="text">
		    		 <input type="password" placeholder= "New Password" name="password" value=""required>
		    	</div> 
		    </div>
		    <div class="get">
		        <button class="btn">Submit</button>
		    </div>
	    </form>
    </div>
</div>

</body>
</html><?php /**PATH D:\xampp\htdocs\NMbalaji_interior\resources\views/admin/resetpassword.blade.php ENDPATH**/ ?>