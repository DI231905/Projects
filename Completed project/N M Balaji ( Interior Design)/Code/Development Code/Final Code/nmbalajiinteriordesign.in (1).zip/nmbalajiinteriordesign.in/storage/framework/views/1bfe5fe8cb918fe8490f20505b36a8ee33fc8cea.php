<?php $__env->startSection('content'); ?>
    <div class="co_banner">
        <div id="demo" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators">
                <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                <li data-target="#demo" data-slide-to="2"></li>
            </ul>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="banner-img">
                        <img src="image/banner1.jpg" alt="banner1.jpg">
                    </div>
                    <div class="banner-info">
                        <div class="inner-banner"></div>
                        <div class="banner-content">
                            <h1>Our Functional <br>Designs Energize <br>Your Living Space</h1>
                            <button class="my-btn btn14"><a style="color: black;" href="<?php echo e(url('/About')); ?>">Read More</a></button>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="banner-img">
                        <img src="image/banner2.jpg" alt="banner2.jpg">
                    </div>
                    <div class="banner-info">
                        <div class="inner-banner"></div>
                        <div class="banner-content">
                            <h1>Complete Residential <br> & Commercial <br> Interior Solutions </h1>
                            <button class="my-btn btn14"><a style="color: black;" href="<?php echo e(url('/About')); ?>">Read More</a></button>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="banner-img">
                        <img src="image/banner3.jpg" alt="banner3.jpg">
                    </div>
                    <div class="banner-info">
                        <div class="inner-banner"></div>
                        <div class="banner-content">
                            <h1>Make Bold <br>Statement With <br>Inviting Interiors </h1>
                           <button class="my-btn btn14"><a style="color: black;" href="<?php echo e(url('/About')); ?>">Read More</a></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_about">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="about1">
                        <h1>An Efficient Interior Design Team </h1>
                        <p>Designing residential and commercial properties has become our forte and almost every functional space is customised to the client’s personal choice such as bedrooms, guest rooms, entertainment areas, reception areas, etc. We believe in a client-first approach and listening to their unique demands and customising them accordingly.</p>
                        <ul class="about-list">
                            <li><i class="far fa-chevron-right"></i>PAN India Presence </li>
                            <li><i class="far fa-chevron-right"></i>Personalised Interior Design Services </li>
                            <li><i class="far fa-chevron-right"></i>Plan and Design Luxury Residences</li>
                            <li><i class="far fa-chevron-right"></i>Clientelle Include High Net Worth Individuals</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-bg">
                        <img src="image/video-bg.jpg">
                        <div class="wrapper">
                            <div class="video-main">
                                <div class="promo-video">
                                    <div class="waves-block">
                                        <div class="waves wave-1"></div>
                                        <div class="waves wave-2"></div>
                                        <div class="waves wave-3"></div>
                                    </div>
                                </div>
                                <a href="#" class="video video-popup mfp-iframe" data-toggle="modal" data-target="#VideoPop"><i class="fa fa-play"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal -->
            <div class="modal fade VideoPopup" id="VideoPop" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-body p-0">
                            <iframe width="100%" height="380" src="/uploads/<?php echo e($name1); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <div class="modal-icon"><i class="fal fa-times-circle"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_discount">
        <div class="container">
            <div class="row">
               
               <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 col-md-6 col-12">
                <div class="banner1">
                    <div class="set-banner1">
                        <div class="inner1">
                            <a href="#"><img src="/uploads/<?php echo e($o->image); ?>"></a>
                        </div>
                        <div class="inner2">   
                            <div class="promo-text-box">                
                                <h3 class="promo-title"><?php echo e($o->discount); ?> </h3>
                                <p class="promo-desc"><?php echo e($o->name); ?></p>        
                                
                            </div>           
                        </div> 
                    </div>         
                </div>
                 </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>  
        </div>  
    </div>
    <div class="co_service">
        <div class="container">
            <h6 class="section-head">Complete Solutions</h6>
            <h1 class="title">Our Services</h1>
            <div class="row row1">

               <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-12 part">
                    <div class="set-service">
                        <div class="service bg1" style="background-image: url(/uploads/<?php echo e($s->image); ?>);">
                            <div class="service-info">
                                <h2><?php echo e($s->name); ?></h2>
                                <p><?php echo e($s->description); ?></p>
                                <a href="<?php echo e(url('/Service')); ?>">Read More</a>
                                <div class="figcaption-number animate-in-to-top-content">

                                    <span><?php echo e($key+1); ?></span> 
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="co_testimonial">
        <div class="container">
            <h6 class="section-head">Testimonials</h6>
            <h1 class="title">What Our Clients Have To Say </h1>
        
            <div class="main1">
                <div class="slider slider-nav">
                  <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div>
                        <div class="testimonial">
                            <span class="testi-icon1">
                                <img src="image/left-quote.png" alt="">
                            </span>
                            <div class="client-area">
                                <h6><?php echo e($t->name); ?></h6> 
                                
                            </div>
                            <p><?php echo e($t->description); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="co_portfolio">
        <div class="container">
            <h6 class="section-head">Best Works</h6>
            <h1 class="title">Portfolio</h1>
            <div class="gallery">
            <div class="row row1">
              
                
             
                <div class="image-container">
                     <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/uploads/<?php echo e($p->image); ?>" class="image">
                        <div class="product-list set-product">
                            <img src="/uploads/<?php echo e($p->image); ?>" alt="">
                            <div class="product-name">
                                <i class="search far fa-search-plus"></i>
                                <h5><?php echo e($p->name); ?></h5>
                                <span><?php echo e($p->brand); ?></span>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
            </div>
        </div>
    </div>
</div> -->
    <div class="co_portfolio">
        <div class="container">
            <h6 class="section-head">Best Works</h6>
            <h1 class="title">Portfolio</h1>
            <div class="gallery">
               
                 <div class="row1">
                      
                <div class="image-container">
                    <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/uploads/<?php echo e($p->image); ?>" class="image">
                        <div class="product-list set-product">
                            <img src="/uploads/<?php echo e($p->image); ?>" alt="">
                            <div class="product-name">
                                <i class="search far fa-search-plus"></i>
                                <h5><?php echo e($p->name); ?></h5>
                                <span><?php echo e($p->brand); ?></span>
                            </div>
                        </div>
                    </a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </div>
                
            </div>

        </div>
        </div>
    </div>

<style type="text/css">
 


</style>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\NMbalaji_interior\resources\views/welcome.blade.php ENDPATH**/ ?>