<html>
<head>
	<title>NM Balaji interiors</title>
	<link rel="stylesheet" type="text/css" href="css/home.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Martel:wght@200;300;400;600;700;800;900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css">

	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css">
    <link rel="icon" type="image/png" href="image/NM logo.png">
	<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
	<div class="co_header">
		<div class="container">
			<div class="row">
			    <div class="col-lg-3 col-md-6 col-6">
				    <div class="logo-img">
				    	<a href="<?php echo e(url('/')); ?>"><img src="image/NM logo.png"></a>
				    </div>
			    </div>
			    <div class="col-lg-9 col-md-6 col-6">
			    	<div class="menu">
			    		<a href="<?php echo e(url('/')); ?>">Home</a>
			    		<a href="<?php echo e(url('/About')); ?>">About us</a>
			    		<a href="<?php echo e(url('/Service')); ?>">Services</a>
			    		<a href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>
			    		<a href="<?php echo e(url('/Contact')); ?>">Contact us</a>
			    	</div>
                    <div class="mobile-menu">
                        <div id="mySidepanel" class="sidepanel">
                            <div class="m_menu">
                                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a>    
                                <a class="link" href="<?php echo e(url('/')); ?>">Home</a>
                                <a class="link" href="<?php echo e(url('/About')); ?>">About us</a>
                                <a class="link" href="<?php echo e(url('/Service')); ?>">Services</a>
                                <a class="link" href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>
                                <a class="link" href="<?php echo e(url('/Contact')); ?>">Contact us</a>
                            </div>
                        </div>
                        <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                    </div>
			    </div>
		    </div>
		</div>
	</div>
	<div >
  <?php echo $__env->yieldContent('content'); ?>
</div>

    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-12 footer-logo footer1">
                    <div class="main-footer">
                        <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="image/NM logo.png"></a></h2>
                        <p>We offer the most suitable interior solutions for residential and commercial projects with an authentic functional design and style that is completely yours. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-12 footer1">
                    <h2 class="title1">Company</h2>
                    <div class="footer-widget">
                        <ul>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/About')); ?>">About</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Service')); ?>">Service</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Contact')); ?>">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-12 footer1">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                        <li><i class="fa fa-home" aria-hidden="true"></i>
                            <p><?php echo e($address); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                            <p><a href="tel:<?php echo e($mobileno); ?>"><?php echo e($mobileno); ?></a></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span> NM Balaji Interior Designs© Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                   <li><a href="https://www.facebook.com/sutharnarpatm"><i class="fab fa-facebook-f"></i></a></li>
                  
                   <li><a href="https://www.instagram.com/nmbalajiinterior/"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </div>
    <div class="copy">
       <a class="up-btn show1" href="#">
    	    <i class="fas fa-angle-up"></i>
        </a>
    </div>
    
    

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>

   <!--  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script> -->
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

        // $(document).on("click", '[data-toggle="lightbox"]', function(event) {
        //     event.preventDefault();
        //     $(this).ekkoLightbox();
        // });

       $(document).ready(function(){
                $(".cross-arrow").click(function(){
                    $(".icon-box-content").toggleClass("main");
                });
            
                $(".c-arrow1").click(function(){
                    $(".icon-box-content1").toggleClass("main");
                });
            });
     

        $('.slider-nav').slick({
        	autoplay: true,
        	autolayspeed: 1500,
        	arrows: false,
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: false,
            focusOnSelect: true
        });

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');  
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });

        $(".modal-icon").click(function(){
            $(".show").hide();
        });

         $(document).ready(function(){
            $('.buttons').click(function(){
                $(this).addClass('active').siblings().removeClass('active');
                var filter = $(this).attr('data-filter')
                if(filter == 'all'){
                    $('.image').show(400);
                }else{
                    $('.image').not('.'+filter).hide(200);
                    $('.image').filter('.'+filter).show(400);
                }
            });
            $('.gallery').magnificPopup({
                delegate:'a',
                type:'image',
                gallery:{
                    enabled:true
                }
            });
        });


//         $(".VideoPopup").on('hidden.bs.modal', function (e) {
//      $(".VideoPopup iframe").attr("src",   $(".VideoPopup iframe").attr("src"));
// });



    
    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\NMbalaji_interior\resources\views/layouts/app.blade.php ENDPATH**/ ?>