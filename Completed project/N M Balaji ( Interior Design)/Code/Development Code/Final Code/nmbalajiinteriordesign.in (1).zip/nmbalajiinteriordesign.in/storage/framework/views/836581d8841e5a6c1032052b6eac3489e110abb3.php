

<?php $__env->startSection('content'); ?>
    <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/about-bg.jpg">
    	    </div>
    	    <div class="about">
    	    	<div class="container">
    	    		<h2>Services</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">Services</li>
    		        </ul>
    	    	</div>
    	    </div>
    	</div>
    </div>
    <div class="co_service">
		<div class="container">
			<div class="row">
				 <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-12 part">
                    <div class="set-service">
                        <div class="service bg1" style="background-image: url(/uploads/<?php echo e($s->image); ?>);">
                            <div class="service-info">
                                <h2><?php echo e($s->name); ?></h2>
                                <p><?php echo e($s->description); ?></p>
                                <a href="#">Read More</a>
                                <div class="figcaption-number animate-in-to-top-content">

                                     <span>0<?php echo e($key+1); ?></span>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>
		</div>
	</div>
	
	

	
	  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/resources/views/service.blade.php ENDPATH**/ ?>