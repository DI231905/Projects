<!DOCTYPE html>
<html>
<head>
    <title>NM Balaji interiors</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Martel:wght@200;300;400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
      <link rel="icon" type="image/png" href="image/NM-logo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
  <div class="co_header">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="logo-img">
                        <a href="<?php echo e(url('/')); ?>"><img src="image/NM logo.png"></a>
                    </div>
                </div>
                <div class="col-lg-9 col-md-6 col-6">
                    <div class="menu">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <a href="<?php echo e(url('/About')); ?>">About us</a>
                        <a href="<?php echo e(url('/Service')); ?>">Services</a>
                        <a href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>
                        <a href="<?php echo e(url('/Contact')); ?>">Contact us</a>
                    </div>
                    <div class="mobile-menu">
                        <div id="mySidepanel" class="sidepanel">
                            <div class="m_menu">
                                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a>    
                                <a class="link" href="<?php echo e(url('/')); ?>">Home</a>
                                <a class="link" href="<?php echo e(url('/About')); ?>">About us</a>
                                <a class="link" href="<?php echo e(url('/Service')); ?>">Services</a>
                                <a class="link" href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a>
                                <a class="link" href="<?php echo e(url('/Contact')); ?>">Contact us</a>
                            </div>
                        </div>
                        <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_part-2">
        <div class="fix-part-2">
            <div class="img1">
                <img src="image/about-bg.jpg">
            </div>
            <div class="about">
                <div class="container">
                    <h2>Portfolio</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Portfolio</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_portfolio">
        <div class="container">
            <div class="gallery">
                <ul class="controls">
                    <li class="buttons active" data-filter="all">All</li>
                    <li class="buttons" data-filter="bathroom">CNC</li>
                    <li class="buttons" data-filter="spa">Living room</li>
                    <li class="buttons" data-filter="Furniture">Kitchen</li>
                    <li class="buttons" data-filter="Decor">Office space</li>
                    <li class="buttons" data-filter="Living">Bed room</li>
                </ul>
                <div class="image-container">

                    <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/uploads/<?php echo e($p->image); ?>" class="image <?php echo e($p->sub_type); ?>">
                        <div class="product-list set-product">
                            <img src="/uploads/<?php echo e($p->image); ?>" alt="">
                            <div class="product-name">
                                <i class="search far fa-search-plus"></i>
                                <h5><?php echo e($p->name); ?></h5>
                                <span><?php echo e($p->brand); ?></span>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
                </div>
            </div>
        </div>
    </div>
     <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-12 footer-logo footer1">
                    <div class="main-footer">
                        <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="image/NM logo.png"></a></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur repudiandae quisquam adipisci asperiores, ipsum ipsa repellat assumenda dolor perspiciatis.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-12 footer1">
                    <h2 class="title1">Company</h2>
                    <div class="footer-widget">
                        <ul>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/About')); ?>">About</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Service')); ?>">Service</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Portfolio')); ?>">Portfolio</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Contact')); ?>">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5 col-12 footer1">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                        <li><i class="fa fa-home" aria-hidden="true"></i>
                            <p><?php echo e($address); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                            <p><a href="tel:<?php echo e($mobileno); ?>"><?php echo e($mobileno); ?></a></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span> NM Balaji Interior Designs© Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                   <li><a href="https://www.facebook.com/sutharnarpatm"><i class="fab fa-facebook-f"></i></a></li>
                  
                   <li><a href="https://www.instagram.com/nmbalajiinterior/"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        </div>
    </div>
    <div class="copy">
       <a class="up-btn show1" href="#">
            <i class="fas fa-angle-up"></i>
        </a>
    </div>
    
    
       
        

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>

    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.height = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.height = "0";
        }

        $(document).ready(function(){
            $('.buttons').click(function(){
                $(this).addClass('active').siblings().removeClass('active');
                var filter = $(this).attr('data-filter')
                if(filter == 'all'){
                    $('.image').show(400);
                }else{
                    $('.image').not('.'+filter).hide(200);
                    $('.image').filter('.'+filter).show(400);
                }
            });
            $('.gallery').magnificPopup({
                delegate:'a',
                type:'image',
                gallery:{
                    enabled:true
                }
            });
        });

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });

    </script>
</body>
</html>
    
    
<?php /**PATH /home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/resources/views/portfolio.blade.php ENDPATH**/ ?>