<!DOCTYPE html>
<html>
<head>
    <title>NM Balaji Interior</title>
    <link rel="stylesheet" type="text/css" href="/css/main-dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   
      <link rel="icon" type="image/png" href="/image/logo1.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div class="mobile-view">
        <div class="row">
            <div class="col-md-6 col-6 logo1">
                <img src="/image/NM logo.png">
            </div>
            <div class="col-md-6 col-6">
                <div class="mobile-menu">
                    <div id="mySidepanel" class="sidepanel">
                        <div class="m_menu">
                            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="far fa-times-circle"></i></a>  
                            <div class="top-nav-wrapper">
                                <div class="top-nav">                       
                                    <div class="co_profile">
                                        <div class="profile-img">
                                           
                                        </div>
                                        <div class="user-details">
                                            <span id="more-details">NM Balaji Interior<i class="fa fa-caret-down"></i></span>
                                        </div>
                                    </div>
                                    <div class="main-menu-content">
                                        <ul>   
                                            <li class="more-details">
                                             <i class="" aria-hidden="true"></i><a href="<?php echo e(url('admin/changepassword')); ?>">change password</a>
                                           </li><br>

                                             <li class="more-details">
                                         <i class="" aria-hidden="true"></i><a href="<?php echo e(url('admin/updatevideoview')); ?>/<?php echo e($id); ?>">updatevideo</a>
                                       </li><br>  


                                            <li class="more-details">
                                                <i class="fa fa-lock" aria-hidden="true"></i><a href="<?php echo e(route('adminlogout')); ?>">Logout</a>
                                            </li>
                                        </ul>

                                    </div>
                                    <div class="nav-slider"></div>
                                    <div class="hosting dash">
                                      <div class="hosting-btn nav-btn">Portfolio </div>
                                    </div>

                                     <div class="dryfruit dash">
                                   <div class="dryfruit-btn nav-btn">Service </div>
                                    </div>
                                    <div class="domains dash">
                                        <div class="domain-btn nav-btn">Contact </div>
                                    </div>
                         <div class="marketplace dash">
                            <div class="marketplace-btn nav-btn">Admin Detail </div>
                        </div>
                         
                         <div class="manage-account dash">
                           <div class="manage-account-btn nav-btn">Team </div>
                        </div>
                         <div class="message dash">
                           <div class="message-btn nav-btn">Offer </div>
                        </div>
                         <div class="category dash">
                            <div class="category-btn nav-btn">Testimonial</div>
                        </div> 
                                   
                                    <div class="nav-slider"></div>
                                </div>
                            </div> 
                        </div>
                    </div>
                    <button class="openbtn" onclick="openNav()"><i class="far fa-bars"></i></button> 
                </div>
            </div>
        </div> 
    </div>
    <div class="row">
        <div class="col-xl-2 col-lg-3 col-md-6">
            <div class="two">
                <div class="top-nav-wrapper">
                    <div class="top-nav">
                        <div class="logo">
                            <img src="/image/NM logo.png">
                        </div>
                        <div class="co_profile">
                            <div class="profile-img">
                               
                            </div>
                            <div class="user-details">
                                <span id="more-details">NM Balaji Interior<i class="fa fa-caret-down"></i></span>
                            </div>
                        </div>
                        <div class="main-menu-content">
                                  <ul>                                  
                                      <li class="more-details">
                                         <i class="" aria-hidden="true"></i><a href="<?php echo e(url('admin/changepassword')); ?>">change password</a>
                                      </li><br>

                                       <li class="more-details">
                                         <i class="" aria-hidden="true"></i><a href="<?php echo e(url('admin/updatevideoview')); ?>/<?php echo e($id); ?>">updatevideo</a>
                                       </li><br>  

                                             <li class="more-details">
                                          <i class="fa fa-lock" aria-hidden="true"></i><a href="<?php echo e(route('adminlogout')); ?>">Logout</a>
                                      </li>
                                  </ul>
                              </div>
                        <div class="nav-slider"></div>
                        <!-- <div class="dashboard dash">
                            <button class="active dashboard-btn nav-btn">Details List</button>
                        </div> -->
                        <div class="hosting dash">
                            <div class="hosting-btn nav-btn">Portfolio </div>
                        </div>
                        
                          <div class="dryfruit dash">
                            <div class="dryfruit-btn nav-btn">Service </div>
                        </div>

                        <div class="domains dash">
                            <div class="domain-btn nav-btn">Contact </div>
                        </div>
                        <div class="marketplace dash">
                            <div class="marketplace-btn nav-btn"> Admin Detail </div>
                        </div>
                         <div class="manage-account dash">
                            <div class="manage-account-btn nav-btn">Team </div>
                        </div>
                         <div class="message dash">
                            <div class="message-btn nav-btn">Offer</div>
                        </div> 
                        <div class="category dash">
                            <div class="category-btn nav-btn">Testimonial </div>
                        </div> 
                        
                        <div class="nav-slider"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-10 col-lg-9 col-md-12">
                <?php if($message = Session::get('error')): ?>
           <div  id="hideDiv" class="alert alert-success alert-block" >
            <!--     <input type="text" class="close" data-dismiss="alert"></input> -->
           <strong style=" padding-top : 5px !important; display: inline-block;"><?php echo e($message); ?></strong>
           </div>
           <?php endif; ?>
            <div class="page mt-4 marketplace-page title1">
                <div class="mt-5">
                    <h4 class="mb-4"> Admin Details List</h4>
                     <div class="detail">
                       <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile no</th>
                                    <th>Address</th>
                                    <th>Update</th>
                                   
                                </tr>
                            </thead>
                             <tbody>
                                 <?php $__currentLoopData = $admindetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($ac->name); ?>

                                    </td>
                                
                    
                                    <td>
                                          <?php echo e($ac->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($ac->mobileno); ?>

                                    </td>
                                    <td>
                                        <?php echo e($ac->address); ?>

                                   </td>
                                  
                             <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateadmindetail')); ?>/<?php echo e($ac->id); ?>" >Update</a></button></td>
                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="page mt-4 hosting-page title1">
                <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4">Portfolio List</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addprotfolio')); ?>" style="color:white">ADD</a></button>
                    </div>
                       
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Project Type</th>
                                    <th>Brand & Design</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>

                                <tr>
                                    <td>
                                      <img src="/uploads/<?php echo e($p->image); ?>" width="60" height="60"><br>
                                         <?php echo e($p->image); ?> 
                                    </td>
                                    <td>
                                         <?php echo e($p->name); ?>

                                    </td>
                                   
                                    <td>
                                      <?php echo e($p->type); ?>

                                   </td>
                                    <td>
                                      <?php echo e($p->brand); ?>

                                   </td>

                                     <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateprotfolio')); ?>/<?php echo e($p->id); ?>">Update</a></button></td>

                         
                                    <td><button class="btn3 btn0"><a href="<?php echo e(url('admin/deleteprotfolio')); ?>/<?php echo e($p->id); ?>">Delete</a></button></td>
                                </tr>
                          
                            </tbody>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </table>
                    </div>
                </div>
            </div> 
            <div class="page mt-4 domain-page title1">
                <div class="mt-5">
                    <h4 class="mb-4">Contact List</h4>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                   
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $contact_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                             
                                <tr>
                                    <td>
                                        <?php echo e($cu->name); ?>

                                    </td>
                                

                                    <td>
                                    <?php echo e($cu->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($cu->subject); ?>

                                    </td>
                                    <td>
                                        <?php echo e($cu->description); ?>

                                   </td>
                        
                                    <td><button class="btn3 btn0"><a href="<?php echo e(url('admin/deletecontactus')); ?>/<?php echo e($cu->id); ?>">Delete</a></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div> 
            </div>

            <div class="page mt-4 manage-account-page title1">
                <div class="mt-5">
                     <div class="list1">
                       <h4 class="mb-4">TEAM LIST</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/teamview')); ?>" style="color:white">ADD</a></button>
                    </div>
                    <div class="detail">

                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>name</th>
                                    <th>image</th>
                                    <th>facbook</th>
                                    <th>instagram</th>
                                    <th>update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                              <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>

                                <tr>
                                    <td>
                                       <?php echo e($t->name); ?>

                                    </td>
                                       

                                    <td>
                                         <img src="/uploads/<?php echo e($t->image); ?>" width="60" height="60"><br>
                                         <?php echo e($t->image); ?>

                                    </td>
                                   
                                    <td>
                                      <?php echo e($t->fblink); ?>

                                   </td>
                                    <td>
                                      <?php echo e($t->instalink); ?>

                                   </td>

                                     <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/teamupdate')); ?>/<?php echo e($t->id); ?>" >Update</a></button></td>

                         
                                    <td><button class="btn3 btn0"><a href="<?php echo e(url('admin/teamdelete')); ?>/<?php echo e($t->id); ?>">Delete</a></button></td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            </tbody>
                        </table>
                    </div>

                </div>
            </div> 

            <div class="page mt-4 message-page title1">
                <div class="mt-5">
                       <div class="list1">
                       <h4 class="mb-4">OFFER LIST</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addoffersview')); ?>"style="color:white">ADD</a></button>
                    </div>

                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Discount</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr>
                                    <td>
                                         <img src="/uploads/<?php echo e($o->image); ?>" width="60" height="60"><br>
                                         <?php echo e($o->image); ?>

                                    </td>

                                    <td>
                                        <?php echo e($o->name); ?>  
                                    </td>
                                    <td>
                                       <?php echo e($o->discount); ?>

                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateoffer')); ?>/<?php echo e($o->id); ?>">Update</a></button></td>
                                    <td><button class="btn3 btn0"><a href="<?php echo e(url('admin/deleteoffer')); ?>/<?php echo e($o->id); ?>">Delete</a></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>

                </div>
            </div> 

            <div class="page mt-4 dryfruit-page title1">
                  <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Services</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addserviceview')); ?>"style="color:white">ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                             <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr>
                                    <td>
                                         <img src="/uploads/<?php echo e($s->image); ?>" width="60" height="60"><br>
                                         <?php echo e($s->image); ?>

                                    </td>

                                    <td>
                                        <?php echo e($s->name); ?>  
                                    </td>
                                    <td>
                                       <?php echo e($s->description); ?>

                                    </td>
                                    
                          <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/updateservice')); ?>/<?php echo e($s->id); ?>" >Update</a></button></td>
                                    <td><button class="btn3 btn0"><a href="<?php echo e(url('admin/deleteservice')); ?>/<?php echo e($s->id); ?>">Delete</a></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div> 
              <div class="page mt-4 category-page title1">
                  <div class="mt-5">
                    <div class="list1">
                        <h4 class="mb-4">Testimonial List</h4>
                        <button class="btn1"><a href="<?php echo e(url('admin/addtestimonial')); ?>" >ADD</a></button>
                    </div>
                    <div class="detail">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    
                                    <th>Name</th>
                                  
                                    <th>Description</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                               <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                             
                               <tr>
                                    <td>
                                         
                                         <?php echo e($t->name); ?>

                                    </td>

                                  
                                    <td>
                                       <?php echo e($t->description); ?>

                                    </td>
                                    <td><button class="btn3 btn0"><a href="<?php echo e(url('admin/deletetestimonial')); ?>/<?php echo e($t->id); ?>">Delete</a></button></td>
                                </tr>
                                
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
    
                            
                </div>
            </div> 

  <!-- <div class=" page page1 my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">ADD NEW TEXTTILE PRODUCT</h4>
            <div class="detail">
                <div class="form">

                      <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 
                 <form  action="<?php echo e(url('admin/storetexttiledata')); ?>" enctype="multipart/form-data" method="POST" >
                         <?php echo csrf_field(); ?>
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Image</label>
                            </div>
                            <div class="col-md-12">
                                 <input type='file' name='image' onchange="readURL(this);" /required>
                                 <img id="blah" src="#" alt="" />
                               
                             </div>   
                        </div>
                        

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Name</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Product Name" name="name" value=""required>
                            </div>   
                        </div> 

                         <div class="part">
                            <div class="col-md-12 label">
                                <label>Price</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Product Price" name="price" value="">
                            </div>   
                        </div>  
                        <div class="main-button">
                            <button class="btn">Add</button> 
                       
                      <a href="<?php echo e(url('admin/home')); ?>"> Back to Home ?</a>
                            
                        </div>

                         
              
            
                    </form> 
                    
                        
                </div>
                
            </div>
        </div>
    </div>
 -->

   <!--  <div class="page page2 my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">ADD NEW SAFFROIND PRODUCT</h4>
            <div class="detail">
                <div class="form">

                      <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 
                 <form  action="<?php echo e(url('admin/storesaffroindproduct')); ?>" enctype="multipart/form-data" method="POST" >
                         <?php echo csrf_field(); ?>
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Image</label>
                            </div>
                            <div class="col-md-12">
                                 <input type='file' name='image' onchange="readURL(this);" /required>
                                 <img id="blah" src="#" alt="" />
                               
                             </div>   
                        </div>
                        

                          <div class="part">
                            <div class="col-md-12 label">
                                <label>Name</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Product Name" name="name" value=""required>
                            </div>   
                        </div> 

                         <div class="part">
                            <div class="col-md-12 label">
                                <label>Price</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Product Price ex. 100/kg" name="price" value="">
                            </div>   
                        </div>  
                        <div class="main-button">
                            <button class="btn">Add</button> 
                       
                      <a href="<?php echo e(url('admin/home')); ?>"> Back to Home ?</a>
                            
                        </div>

                         
              
            
                    </form> 
                    
                        
                </div>
                
            </div>
        </div>
    </div> -->
   
            
        
    </div>
    </div> 

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

        function openForm() {
  document.getElementById("myForm").style.display = "block";
}


         $(function() {
setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

});

    $(document).ready(function(){
       
        $(".user-details").click(function(){
            $(".main-menu-content").slideToggle("slow");
        })

        $(".btn1").click(function(){
            $(".page1").show();
            $(".hosting-page").hide();
        })

       $("button.btn1.btn2").click(function(){
             $(".page2").show();
             $(".page1").hide();
            $(".dryfruit-page").hide();
         })
    });


  
   
    var tl = new TimelineMax();

//Logos
TweenMax.set('.wp-logo', { scale: 1 })
TweenMax.set('.weebly-logo', { scale: 1 })  

// Pages 
TweenMax.set('.dashboard-page', { display: 'none' })
TweenMax.set('.hosting-page', { display: 'block' })
TweenMax.set('.marketplace-page', { display: 'none' })
TweenMax.set('.domain-page', { display: 'none' })
TweenMax.set('.message-page', { display: 'none' })
TweenMax.set('.manage-account-page', { display: 'none' })
TweenMax.set('.dryfruit-page', { display: 'none' })
TweenMax.set('.category-page', { display: 'none' })

TweenMax.to('.mobile-nav', 0, { x: -300 })

/* Message Btn Starts */
$('.message-btn').on('click', function(){  
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.manage-account-page').css({ display: 'none' })
   $('.message-page').css({ display: 'block' })
    $('.manage-account-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })



  
});
/* Message Btn Ends */

// Manage Account Btn STARTS
$('.message-btn').on('click', function(){  
    $(this).addClass('active').removeClass('nav-btn');
    $('.marketplace-btn').removeClass('active').addClass('nav-btn');
    $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.hosting-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.dashboard-btn').removeClass('active').addClass('nav-btn');
    $('.manage-account-btn').removeClass('active').addClass('nav-btn');


   
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.manage-account-page').css({ display: 'none' })
   $('.message-page').css({ display: 'block' })
     $('.dryfruit-page').css({ display: 'none' })
     $('.category-page').css({ display: 'none' })
  
});
$('.manage-account-btn').on('click', function(){
    $(this).addClass('active').removeClass('nav-btn');
    $('.marketplace-btn').removeClass('active').addClass('nav-btn');
    $('.domain-btn').removeClass('active').addClass('nav-btn');
    $('.hosting-btn').removeClass('active').addClass('nav-btn');
    $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
    $('.category-btn').removeClass('active').addClass('nav-btn');
    $('.dashboard-btn').removeClass('active').addClass('nav-btn');
    $('.message-btn').removeClass('active').addClass('nav-btn');

   
   $('.dashboard-page').css({ display: 'none' })
   $('.hosting-page').css({ display: 'none' })
   $('.marketplace-page').css({ display: 'none' })
   $('.domain-page').css({ display: 'none' })
   $('.message-page').css({ display: 'none' })
  $('.manage-account-page').css({ display: 'block' })
  $('.account-info-drop-down').css({ display: 'none' })
  $('.dryfruit-page').css({ display: 'none' })
  $('.category-page').css({ display: 'none' })
});

    $('.hosting-btn').on('click', function() {
        $(this).addClass('active').removeClass('nav-btn');
        $('.dashboard-btn').removeClass('active').addClass('nav-btn');
        $('.marketplace-btn').removeClass('active').addClass('nav-btn');
        $('.domain-btn').removeClass('active').addClass('nav-btn');
        $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
        $('.message-btn').removeClass('active').addClass('nav-btn'); 
        $('.manage-account-btn').removeClass('active').addClass('nav-btn');  

        $('.dashboard-page').css({ display: 'none' })
        $('.hosting-page').css({ display: 'block' })
        $('.marketplace-page').css({ display: 'none' })
        $('.domain-page').css({ display: 'none' })
        $('.message-page').css({ display: 'none' })
         $('.manage-account-page').css({ display: 'none' })
         $('.dryfruit-page').css({ display: 'none' })
          $('.category-page').css({ display: 'none' })
  
    });

$('.marketplace-btn').on('click', function(){
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
         $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
      $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 

  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'block' })
     $('.domain-page').css({ display: 'none' })
     $('.message-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.category-page').css({ display: 'none' })

});

$('.domain-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
      $('.category-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.domain-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
       $('.category-page').css({ display: 'none' })

});

$('.dryfruit-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
 $(".page1").hide();
  $(".page2").hide();
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.dryfruit-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })

});

$('.category-btn').on('click', function() {
     $(this).addClass('active').removeClass('nav-btn');
     $('.hosting-btn').removeClass('active').addClass('nav-btn');
     $('.dashboard-btn').removeClass('active').addClass('nav-btn');
     $('.marketplace-btn').removeClass('active').addClass('nav-btn');
     $('.domain-btn').removeClass('active').addClass('nav-btn');
      $('.dryfruit-btn').removeClass('active').addClass('nav-btn');
     $('.message-btn').removeClass('active').addClass('nav-btn'); 
     $('.manage-account-btn').removeClass('active').addClass('nav-btn'); 
  
     $('.dashboard-page').css({ display: 'none' })
     $('.hosting-page').css({ display: 'none' })
     $('.marketplace-page').css({ display: 'none' })
     $('.category-page').css({ display: 'block' })
     $('.message-page').css({ display: 'none' })
      $('.dryfruit-page').css({ display: 'none' })
      $('.manage-account-page').css({ display: 'none' })
      $('.domain-page').css({ display: 'none' })

});
</script>
</body>
</html><?php /**PATH D:\xampp\htdocs\NMbalaji_interior\resources\views/admin/home.blade.php ENDPATH**/ ?>