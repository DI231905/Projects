<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
//use App\Models\User;
use Carbon\carbon;
use DB;
use Hash;
use \Crypt;
use Illuminate\support\facades\Auth;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class portfolioController extends Controller{


   public function __construct(){

                $this->middleware('auth:admin');
        }


         public function addprotfolio(){

         $portfolio_type=DB::table('portfolio_type')->get();
         $data['portfolio_type']=$portfolio_type;    

          return view('admin.addprotfolio',$data);

        }

   public function storeprotfolio(Request $request){

           $request->validate([

            
            'image' => 'required',
            'portfoliotype' =>'required',
            'name' => 'required|string',
            'brand' => 'required',
            

        ]);

            $image=$request->file('image');
            $portfoliotype=$request->input('portfoliotype');
            $name=$request->input('name');
            $brand=$request->input('brand');
            $description=$request->input('description');

            $portfolio=DB::table('portfolio_type')->where('id',$portfoliotype)->get();

                $portfoliotype1=$portfolio[0]->name;
                $subtype=$portfolio[0]->subtype;

             $imagename=' ';

           if ($image) {
          
                $destinationPath='uploads';
                $imagename=time().'_'.$image->getClientOriginalName();

               $image->move($destinationPath,$imagename);
      
            }

         DB::table('portfolio')->insert(['name'=>$name,'image'=>$imagename,'type'=>$portfoliotype1,'brand'=>$brand,'sub_type'=>$subtype,'description'=> $description]);

     
         return redirect('admin/home')->with('error',' insert Portfolio succcesfully!!!!'); 

        }

        public function deleteprotfolio($id){


            $portfolio= DB::table('portfolio')->where('id', $id)->get();

            if ($portfolio[0]->image!='') {

          
             unlink("/home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/uploads/".$portfolio[0]->image);

            }

           DB::table('portfolio')->where('id', $id)->delete();


           return redirect('admin/home')->with('error',' delete Portfolio  data succcesfully!!!!');

        }
        public function updateprotfolio($id){

        $portfolio_type=DB::table('portfolio_type')->get();
        $data['portfolio_type']=$portfolio_type;   

        $portfolio= DB::table('portfolio')->where('id', $id)->get();
      
        $data['id']=$portfolio[0]->id;
        $data['name']=$portfolio[0]->name;
        $data['image']=$portfolio[0]->image;
        $data['portfoliotype']=$portfolio[0]->type;
        $data['brand']=$portfolio[0]->brand;

        $portfolioname=$portfolio[0]->type;
       
         $ptype=DB::table('portfolio_type')->where('name', $portfolioname)->get();
         $data['ptype_id']=$ptype[0]->id;
         
         return view('admin.updateportflio',$data);
        }


      
      public function storeupdateprotfolio(Request $request, $id){

          $request->validate([

           'portfoliotype' =>'required',
            'name' => 'required|string',
            'brand' => 'required',
            
        ]);
       

        $name=$request->input('name');
        $file = $request->file('image');
        $portfoliotype=$request->input('portfoliotype');
        $brand=$request->input('brand');

        $portfolio=DB::table('portfolio_type')->where('id',$portfoliotype)->get();

        $portfoliotype1=$portfolio[0]->name;
         $subtype=$portfolio[0]->subtype;

       
                $imagename=' ';

        if($file){
         
            $destinationPath='uploads';
            $imagename=time().'_'.$file->getClientOriginalName();
    
            $file->move($destinationPath,$imagename);

            DB::table('portfolio')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink("/home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/uploads/".$request->input('oldimage'));

          }

        }

       DB::table('portfolio')->where('id', $id)->update(['name'=>$name,'type'=>$portfoliotype1,'brand'=>$brand,'sub_type'=>$subtype]);
   
       return redirect('admin/home')->with('error',' update portfolio detail sucessfully!!!!');
         
    
       }


        }



     
 


   

  




