<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Carbon\carbon;
use DB;
use Hash;
use \Crypt;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\validator;
use Auth;

class Admincontroller extends Controller{


   public function __construct(){

                $this->middleware('auth:admin');
        }

   public function home(){
 
     
         $admin=Auth::guard('admin')->user();
         $data['admin']=$admin;
         $data['site_url']= env('APP_URl');
         $data['metatitle']='home page';


         $admindetail=DB::table('admindetail')->get();
         $data['admindetail']=$admindetail;

         $services=DB::table('services')->get();
         $data['services']=$services;

         $team=DB::table('team')->get();
         $data['team']=$team;

          $offers=DB::table('offers')->get();
         $data['offers']=$offers;

         $contact_us=DB::table('contact_us')->get();
         $data['contact_us']=$contact_us;

         $portfolio=DB::table('portfolio')->get();
         $data['portfolio']=$portfolio;

          $testimonial=DB::table('testimonial')->get();
         $data['testimonial']=$testimonial;

          $video=DB::table('video')->where('id',1)->get();

          $data['name1']=$video[0]->name;
          $data['id']=$video[0]->id;

       
         return view('admin.home',$data);
      
    } 

   public function changepassword(){
       
         return view('admin.changepassword');
    }

   public function updatepassword(Request $request,$id){

         $request->validate([
              'oldpassword' => 'required|string',
              'newpassword' => 'required|string|min:8',
           
           ]);

             $oldpassword=$request->input('oldpassword');
             $newpassword=$request->input('newpassword');

             $password=DB::table('admins')->where('id', $id)->get();

             $password1=$password[0]->password;

           if(Hash::check($oldpassword,$password1)){

               DB::table('admins')->where('id', $id)->update(['password'=>Hash::make($newpassword)]);

              return redirect('admin/home')->with('error','your password has been update sucessfully' );

             }else{

                return Redirect::back()->with('error','Your Old password is not correct!!!!');

            }
         }

     public function updateadmindetail($id){


       $admindetail=DB::table('admindetail')->where('id', $id)->get();

        $data['id']=$admindetail[0]->id;
         $data['email']=$admindetail[0]->email;
        $data['name']=$admindetail[0]->name;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      

         return view('admin.updateadmindetailview',$data);


       }

       public function storeadmindetail(Request $request,$id){


         $request->validate([

            'name' => 'required|string',
            'email' => 'required|email',
            'mobileno' => 'required',
            'address' => 'required',  

        ]);
       

        $name=$request->input('name');
        $email = $request->input('email');
        $mobileNo=$request->input('mobileno');
        $address=$request->input('address');

       DB::table('admindetail')->where('id',$id)->update(['name'=>$name ,'email'=>$email,'mobileno'=>$mobileNo,'address'=>$address]);

        return redirect('admin/home')->with('error',' update admin detail sucessfully!!!!');
         
    
          }


     public function deletecontactus($id){
  
       DB::table('contact_us')->where('id', $id)->delete();

       return redirect('admin/home');

    }
      public function teamview(){
  
     
       return view('admin.teamview');

    }

    public function addteam(Request $request){


         $request->validate([

            'name' => 'required|string',
            'image' => 'required',
             

        ]);
       

        $name=$request->input('name');
        $file=$request->file('image');
        $fblink=$request->input('fblink');
        $instalink=$request->input('instalink');
        $imagename=' ';

        if ($file) {
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();

         $file->move($destinationPath,$imagename);
      
        }
  

         DB::table('team')->insert(['name'=>$name,'image'=>$imagename,'fblink'=>$fblink,'instalink'=>$instalink]);
       
          return redirect('admin/home')->with('error',' insert Team member data succcesfully!!!!');

          }

       public function teamdelete($id){


        $team= DB::table('team')->where('id', $id)->get();

         if ($team[0]->image!='') {

            unlink("/home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/uploads/".$team[0]->image);

          }

        DB::table('team')->where('id', $id)->delete();

        return redirect('admin/home')->with('error',' delete Team member data succcesfully!!!!');

     
    } 


    public function teamupdateview($id){

          $team= DB::table('team')->where('id', $id)->get();
      
        $data['id']=$team[0]->id;
        $data['name']=$team[0]->name;
        $data['image']=$team[0]->image;
        $data['fblink']=$team[0]->fblink;
        $data['instalink']=$team[0]->instalink;
       
        return view('admin.updateteamview',$data);   

    }

       public function storeupdateteam(Request $request,$id){


   $request->validate([

            'name' => 'required',
        
           
        ]);
       
        $name=$request->input('name');
        $occupation=$request->input('occupation');
        $fblink=$request->input('fblink');
        $instalink=$request->input('instalink');
     
        $file=$request->file('image');
        $imagename=' ';

        if($file){
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('team')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink("/home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/uploads/".$request->input('oldimage'));

             }

           }

          DB::table('team')->where('id', $id)->update(['name'=>$name ,'fblink'=>$fblink,'instalink'=>$instalink]);

           return redirect('admin/home')->with('error',' update Team member data succcesfully!!!!');

     }

       public function addtestimonial(){

           return view('admin.addtestimonial');

    }
      public function storetestimonial(Request $request){

           $name=$request->input('name');
          
           $description=$request->input('description');

         DB::table('testimonial')->insert(['name'=>$name ,'description'=>$description]);
    
           return redirect('admin/home')->with('error',' testimonial insterted succcesfully!!!!');

    }

    public function deletetestimonial($id){

        DB::table('testimonial')->where('id', $id)->delete();

       return redirect('admin/home')->with('error',' testimonial delete succcesfully!!!!');


      }


        }



     
 


   

  




