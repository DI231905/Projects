<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;

class userController extends Controller
{
     public function index(){

        $offers=DB::table('offers')->get();
        $data['offers']=$offers;

         $services=DB::table('services')->get();
         $data['services']=$services;

         $testimonial=DB::table('testimonial')->get();
         $data['testimonial']=$testimonial;

         $portfolio=DB::table('portfolio')->orderBy('id', 'desc')->take(3)->get();
         $data['portfolio']=$portfolio;

          $video=DB::table('video')->where('id',1)->get();

          $data['name1']=$video[0]->name;


       $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;


        return view('welcome',$data);
    }



     public function About(){

         $team=DB::table('team')->get();
         $data['team']=$team;



        $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;


        return view('Aboutview',$data);
    }

    public function Service(){

         $services=DB::table('services')->get();
         $data['services']=$services;
        
         $portfolio=DB::table('portfolio')->orderBy('id', 'desc')->take(3)->get();
         $data['portfolio']=$portfolio;
        
        $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

        return view('service',$data);
    }
    
   
    
     public function Contact(){

         $admindetail=DB::table('admindetail')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

        return view('contact',$data);
    }

     public function Portfolio(){

        $admindetail=DB::table('admindetail')->where('id',1)->get();
        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

         $portfolio=DB::table('portfolio')->get();
         $data['portfolio']=$portfolio;

        return view('portfolio',$data);
    }

   
 
     public function contactusfrom(Request $request){

        $request->validate([

            'name' => 'required',
            'email' => 'required|email', 
            'subject' => 'required',  
            'description' => 'required',  


        ]);

            $name=$request->input('name'); 
            $email=$request->input('email');
            $subject=$request->input('subject');
            $description=$request->input('description');

            echo $name;
            echo $email;
            echo $subject;
            echo $description;

         DB::table('contact_us')->insert(['name'=>$name,'email'=>$email,'subject'=>$subject,'description'=>$description]);
          

       return redirect()->back()->with('error','your massage was submitted sucessfully !!!!' );


    }


}
