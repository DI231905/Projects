<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class serviceController extends Controller
{
      public function __construct(){

                $this->middleware('auth:admin');
        }


          public function addserviceview(){
  
        return view('admin.addservices');

       }

        public function storeservice(Request $request){


        $request->validate([

            'name' => 'required',
             'image'=>'required',
            'description' => 'required', 

        ]);
       
        $name=$request->input('name');
        $description=$request->input('description');
    
        $file=$request->file('image');
        $imagename=' ';

        if ($file){
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();

         $file->move($destinationPath,$imagename);
      
        }


         DB::table('services')->insert(['name'=>$name,'image'=>$imagename,'description'=>$description]);
       
          return redirect('admin/home')->with('error','your service has been inserted sucessfully' );
          
    }


     public function deleteservice($id){


          $services= DB::table('services')->where('id', $id)->get();

         if ($services[0]->image!='') {

            unlink("/home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/uploads/".$services[0]->image);

            }

      
        DB::table('services')->where('id', $id)->delete();

        return redirect('admin/home')->with('error','your service has been deleted sucessfully' );


    }

      public function updateservice($id){

    

      $services= DB::table('services')->where('id', $id)->get();
       
        //$work=DB::table('work')->where('id',$id)->get();
        $data['id']=$services[0]->id;
        $data['name']=$services[0]->name;
        $data['image']=$services[0]->image;
        $data['description']=$services[0]->description;
       
        return view('admin.updateservice',$data);

       
       }

  public function storeupdateservice(Request $request,$id){


        $request->validate([

            'name' => 'required',
            'description' =>'required',
           
        ]);
       
       echo $name=$request->input('name');
       echo $description = $request->input('description');
            $file=$request->file('image');

    
        $imagename=' ';

        if($file){
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('services')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink("/home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/uploads/".$request->input('oldimage'));

             }

           }

          DB::table('services')->where('id', $id)->update(['name'=>$name ,'description'=>$description]);

           return redirect('admin/home')->with('error','your service has been updated sucessfully' );

    }





}
