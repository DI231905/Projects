<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\support\facades\Redirect;
use Illuminate\support\facades\validator;

class offersController extends Controller
{
      public function __construct(){

                $this->middleware('auth:admin');
        }


          public function addoffersview(){
  
        return view('admin.addoffers');

       }

        public function storeoffers(Request $request){


        $request->validate([

             'image'=>'required',
          

        ]);
       
        $name=$request->input('name');
        $discount=$request->input('discount');
    
        $file=$request->file('image');
        $imagename=' ';

        if ($file){
          
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();

         $file->move($destinationPath,$imagename);
      
        }


         DB::table('offers')->insert(['name'=>$name,'image'=>$imagename,'discount'=> $discount]);
       
          return redirect('admin/home')->with('error','your offer has been inserted sucessfully' );
          
    }


    public function updatevideoview($id){

         $video=DB::table('video')->where('id',$id)->get();

          $data['name1']=$video[0]->name;
          $data['id']=$video[0]->id;

          return view('admin.video',$data);    

     
     }

    public function updatevideo1(Request $request, $id){
      
         $request->validate([

            'video'=>'mimes:mp4,mov,ogg|max:40000',     

        ]);

       $file=$request->file('video');

          $videoname=' ';

        if($file){
         
          $destinationPath='uploads';
          $videoname=time().'_'.$file->getClientOriginalName();

          echo $videoname;
         
           $file->move($destinationPath,$videoname);

           DB::table('video')->where('id', $id)->update(['name'=>$videoname]);

            if ($request->input('oldvideo')!='') {

             unlink("/home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/uploads/".$request->input('oldvideo'));

             }

             return redirect('admin/home')->with('error','your video has been updated sucessfully');

           }
        
       }


     public function deleteoffer($id){


          $offers= DB::table('offers')->where('id', $id)->get();

         if ($offers[0]->image!='') {

            unlink("/home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/uploads/".$offers[0]->image);

            }

      
        DB::table('offers')->where('id', $id)->delete();

        return redirect('admin/home')->with('error','your offer has been deleted sucessfully' );


    }

      public function updateoffer($id){

    

      $offer= DB::table('offers')->where('id', $id)->get();
       
        //$work=DB::table('work')->where('id',$id)->get();
        $data['id']=$offer[0]->id;
        $data['name']=$offer[0]->name;
        $data['image']=$offer[0]->image;
        $data['discount']=$offer[0]->discount;
       
        return view('admin.updateoffer',$data);

       
       }

  public function storeupdateoffer(Request $request,$id){


        
       
       echo $name=$request->input('name');
       echo $discount = $request->input('discount');
            $file=$request->file('image');

    
        $imagename=' ';

        if($file){
         
          $destinationPath='uploads';
          $imagename=time().'_'.$file->getClientOriginalName();
    
           $file->move($destinationPath,$imagename);

           DB::table('offers')->where('id', $id)->update(['image'=>$imagename]);

            if ($request->input('oldimage')!='') {

             unlink("/home/mzldwoswysm5/public_html/nmbalajiinteriordesign.in/uploads/".$request->input('oldimage'));

             }

           }

          DB::table('offers')->where('id', $id)->update(['name'=>$name ,'discount'=>$discount]);

           return redirect('admin/home')->with('error','your offer has been updated sucessfully' );

    }





}
