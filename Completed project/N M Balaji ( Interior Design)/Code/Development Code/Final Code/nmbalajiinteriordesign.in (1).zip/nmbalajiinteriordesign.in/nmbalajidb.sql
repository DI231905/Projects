-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 26, 2022 at 05:56 AM
-- Server version: 5.7.36-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nmbalajidb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admindetail`
--

CREATE TABLE `admindetail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admindetail`
--

INSERT INTO `admindetail` (`id`, `name`, `email`, `mobileno`, `address`, `created_at`, `updated_at`) VALUES
(1, 'NM Balaji Interior Designs', 'nmbalaji1507@gmail.com', '+91 99796 45717', 'Valsad - Dharampur Rd, near Power House, Atak Pardi, Valsad, Gujarat 396007', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `token`, `created_at`, `updated_at`) VALUES
(1, 'apptest', 'nmbalaji1507@gmail.com', '$2y$10$2x/tko4g9w5CUp3f.XGDzOhkl3k0G57jPpCwO8BvbY1gJ2jITHEo6', '2664', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `emp_type`
--

CREATE TABLE `emp_type` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_type`
--

INSERT INTO `emp_type` (`id`, `type`) VALUES
(1, 'Owner'),
(2, 'Employee');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `discount` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `name`, `image`, `discount`) VALUES
(3, NULL, '1628572796_offer1.jpg', NULL),
(4, NULL, '1628573531_offer2.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `sub_type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `Description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `image`, `type`, `sub_type`, `name`, `brand`, `Description`) VALUES
(13, '1628492181_WhatsApp Image 2021-08-06 at 12.18.43.jpeg', 'Office space', 'Decor', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(14, '1628492215_WhatsApp Image 2021-08-06 at 12.18.45.jpeg', 'Living room', 'spa', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(15, '1628492262_WhatsApp Image 2021-08-06 at 12.18.48.jpeg', 'Office space', 'Decor', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(16, '1628492292_WhatsApp Image 2021-08-06 at 12.18.48 (1).jpeg', 'Kitchen', 'Furniture', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(17, '1628492357_WhatsApp Image 2021-08-06 at 12.18.56.jpeg', 'Office space', 'Decor', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(18, '1628492417_WhatsApp Image 2021-08-06 at 12.18.57.jpeg', 'Office space', 'Decor', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(19, '1628492461_WhatsApp Image 2021-08-06 at 15.18.54.jpeg', 'Bed room', 'Living', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(23, '1628509910_WhatsApp Image 2021-08-06 at 15.18.58 (1).jpeg', 'Living room', 'spa', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(24, '1628509949_WhatsApp Image 2021-08-06 at 15.19.06.jpeg', 'Bed room', 'Living', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(26, '1628666804_WhatsApp Image 2021-08-11 at 11.02.15.jpeg', 'CNC', 'bathroom', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(27, '1628666837_WhatsApp Image 2021-08-11 at 11.02.15 (1).jpeg', 'CNC', 'bathroom', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(28, '1628666901_WhatsApp Image 2021-08-11 at 11.02.19 (1).jpeg', 'CNC', 'bathroom', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL),
(29, '1628666942_WhatsApp Image 2021-08-11 at 11.02.20.jpeg', 'CNC', 'bathroom', 'NM Balaji Interior Designs', 'NM Balaji Interior Designs', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_image`
--

CREATE TABLE `portfolio_image` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `portfolio_image`
--

INSERT INTO `portfolio_image` (`id`, `name`, `p_id`, `created_at`, `updated_at`) VALUES
(4, '1625550134_projects-1.jpg', '5', NULL, NULL),
(5, '1625550135_projects-2.jpg', '5', NULL, NULL),
(6, '1625550135_projects-6.jpg', '5', NULL, NULL),
(8, '1625559402_02.png', '6', NULL, NULL),
(9, '1625559402_05.jpg', '6', NULL, NULL),
(12, '1625644067_choose.png', '6', NULL, NULL),
(13, '1625644067_contact.jpg', '6', NULL, NULL),
(14, '1626499595_04.jpg', '12', NULL, NULL),
(15, '1626499595_05.jpg', '12', NULL, NULL),
(16, '1626499595_22-1.jpg', '12', NULL, NULL),
(17, '1626499595_about-11.jpg', '12', NULL, NULL),
(18, '1626499825_02.png', '13', NULL, NULL),
(19, '1626499825_04.jpg', '13', NULL, NULL),
(20, '1626499826_05.jpg', '13', NULL, NULL),
(21, '1626499826_22-1.jpg', '13', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_type`
--

CREATE TABLE `portfolio_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `subtype` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `portfolio_type`
--

INSERT INTO `portfolio_type` (`id`, `name`, `subtype`) VALUES
(1, 'CNC', 'bathroom'),
(2, 'Living room', 'spa'),
(3, 'Kitchen', 'Furniture'),
(4, 'Office space', 'Decor'),
(5, 'Bed room', 'Living');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `image`, `description`) VALUES
(3, 'Glass & Lighting', '1626181897_portfolio-2.jpg', 'When you not only want to light up a room but want to make an impressive statement with glass window solutions we can help you do that.'),
(5, 'Residential Interior', '1626164859_service-bg1.jpg', 'We strive to design graceful, elegant, and refined interiors with a balanced aesthetic for your home sweet home.'),
(6, 'Master Bathroom', '1626181916_portfolio-4.jpg', 'Incorporating all the right features for added comfort and tailoring it to your personalised needs.'),
(7, 'Office Interior', '1626164969_service-bg1.jpg', 'We render office designs that are welcoming to your employees, clients, and customers improving overall productivity and efficiency.'),
(8, 'Retail Shop & Showroom', '1626165033_service-bg1.jpg', 'Appealing interior retail and showroom designs that improve the buying experience of your target audience.'),
(9, 'Wallpaper & Painting', '1626165076_service-bg1.jpg', 'Make a statement with visually arresting wallpapers that add longevity to your walls with many other décor accessories.'),
(10, 'CNC design', '1633439360_103.jpg', 'vdshvhgd');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fblink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `name`, `image`, `occupation`, `fblink`, `instalink`, `created_at`, `updated_at`) VALUES
(5, 'Williamson', '1626072819_team-1.jpg', NULL, 'https://www.facebook.com/', 'https://www.instagram.com/', NULL, NULL),
(6, 'Williamson1', '1626072864_team-2.jpg', NULL, 'https://www.facebook.com/', 'https://www.instagram.com/', NULL, NULL),
(7, 'Williamson3', '1626072898_team-3.png', NULL, 'https://www.facebook.com/', 'https://www.instagram.com/', NULL, NULL),
(8, 'Williamson4', '1626073359_team-5.jpg', NULL, 'https://www.facebook.com/', 'https://www.instagram.com/', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`id`, `name`, `description`) VALUES
(5, 'Yash Parekh', '\"The entire NM Balaji team is truly exceptional at what it does best. They fully captured our vision for a well-lit and highly functional home. We trusted them completely from the start. They truly are the best and can’t recommend them enough. \"'),
(6, 'Mr and Mrs Arora', '\"NM Balaji interiors exceeded our expectations and did a complete home makeover with improved features. They were recommended to us by our friends and we recommend them to you. \"'),
(7, 'pukhraj suthar', 'Your design is very excellent.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`id`, `name`) VALUES
(1, '1628835825_1628510478646_7Ub3Y3Df_wWov (1).mp4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admindetail`
--
ALTER TABLE `admindetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_type`
--
ALTER TABLE `emp_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio_image`
--
ALTER TABLE `portfolio_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio_type`
--
ALTER TABLE `portfolio_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admindetail`
--
ALTER TABLE `admindetail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emp_type`
--
ALTER TABLE `emp_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `portfolio_image`
--
ALTER TABLE `portfolio_image`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `portfolio_type`
--
ALTER TABLE `portfolio_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
