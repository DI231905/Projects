<!DOCTYPE html>
<html>
 <title>ARQX</title>
    <link rel="stylesheet" type="text/css" href="/css/upload.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css">
   <link rel="icon" type="image/png" href="/image/logo.jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

     



</head>
<body class="body">       

    <div class="page my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">UPDATE FOOTER ABOUT US</h4>
            <div class="detail">
      
              <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li  style="color:red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?> 

                <div class="form">

                    
                 <form  action="<?php echo e(url('admin/store_update_footer_data')); ?>/<?php echo e($id); ?>" enctype="multipart/form-data" method="POST" >
                         <?php echo csrf_field(); ?>


                         <div class="part">
                            <div class="col-md-12 label">
                                <label>Image</label>
                            </div>
                            <div class="col-md-12">
                                  <input type="file" value="<?php echo e($image); ?>" name="image" accept="image/*"  onchange="readURL(this);" />
                                  <img id="blah" src="/uploads/<?php echo e($image); ?>" width="120" height="120" />

                                <input type="hidden" name="oldimage" value="<?php echo e($image); ?> "/>
                             </div>   
                        </div>

                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Title</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Title" name="title" value="<?php echo e($title); ?>"required>
                            </div>   
                        </div> 

                      
                         <div class="part part1">
                            <div class="col-md-12 label">
                                <label>Description</label>
                            </div>
                            <div class="col-md-12 data">
                                   <textarea placeholder="Enter text.."  name="description" value="<?php echo e($description); ?>" id="summernote"><?php echo $description; ?></textarea>
                            </div>   
                        </div>
  
                        <div class="main-button">
                            <button class="btn1">UPDATE</button> 
                       
                      <a href="<?php echo e(url('admin/footer_data_list')); ?>"> Back to Home?</a>
                            
                        </div>
                    </form>       
                </div>
                
            </div>
        </div>
    </div>
    


    
    
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>


    <script type="text/javascript">


       


       
        $('textarea#summernote').summernote({
        placeholder: 'Hello bootstrap 4',
        tabsize: 2,
        height: 100,
  toolbar: [
        ['style', ['style']],
        ['font', ['bold', 'italic', 'underline', 'clear']],
        // ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
        //['fontname', ['fontname']],
       // ['fontsize', ['fontsize']],
        ['color', ['color']],
        ['para', ['ul', 'ol', 'paragraph']],
        ['height', ['height']],
        ['table', ['table']],
        ['insert', ['link', 'picture', 'hr']],
        //['view', ['fullscreen', 'codeview']],
        ['help', ['help']]
      ],
      });

     function delete_tag($id){

     if(confirm("do you want delete this Tag ?")){
             $.ajax({

                url:'delete_footer_tag/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.tag_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });
            }
        }  


</script>
</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/admin/update_footer_about.blade.php ENDPATH**/ ?>