<!DOCTYPE html>
<html>
<head>
    <title>ARQX</title>
     <link rel="stylesheet" type="text/css" href="/css/upload.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css">
    <link rel="icon" type="image/png" href="/image/logo.jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body"> 
    <div class="page my-4 title1">
        <div class="mt-5">
            <h4 class="mb-4">Update Performance</h4>
                <div class="form">

                     
                 <form  action="<?php echo e(url('admin/store_update_performance')); ?>/<?php echo e($id); ?>" enctype="multipart/form-data" method="POST" >
                         <?php echo csrf_field(); ?>
                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Image</label>
                            </div>
                            <div class="col-md-12">
                                  <input type="file" value="" name="image" accept="image/*"  onchange="readURL(this);" />
                                  <input type="hidden" name="oldimage" value="<?php echo e($image); ?>">
                                  <img id="blah" src="/uploads/<?php echo e($image); ?>" alt="" height="100px" />

                               
                             </div>   
                        </div>                           

                           <div class="part">
                            <div class="col-md-12 label">
                                <label>Title</label>
                            </div>
                            <div class="col-md-12 data">
                                <input type="text" placeholder="Enter Title" name="title" value="<?php echo e($title); ?>" >
                                <?php if($errors->has('title')): ?> <p class="error_mes"><?php echo e($errors->first('title')); ?></p> <?php endif; ?>
                            </div>   
                        </div>
 

                        <div class="part">
                            <div class="col-md-12 label">
                                <label>Description</label>
                            </div>
                          <div class="col-md-12 data data1">
                             <div class=" data1">
                                <textarea  id="summernote" placeholder="Enter text.."  name="description" value="<?php echo e($description); ?>" ><?php echo $description; ?></textarea>
                               <?php if($errors->has('description')): ?> <p class="error_mes"><?php echo e($errors->first('description')); ?></p> <?php endif; ?>
                          </div>
                       </div>

                     <div class="upload">
                        <button class="btn1">Update</button> 
                        <a href="<?php echo e(url('admin/view_performance')); ?>">Back to Home?</a>       
                      </div>  
                        </div>

                    </form>     
                </div>
            </div>
        </div>
    </div>
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>

    
 <script type="text/javascript">
         function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result)
                        .width(130)
                        .height(130);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }


         $("#addRow").click(function () {
            var html = '';
           
            html += '<div class="days">';
            html += ' <textarea type="text" placeholder="Enter here" name="short_descriptions[]" value="" > <textarea>';
            html += '<button id="removeRow" type="button" class="btn-remove">Remove</button>';
            html += '</div>';
           

            $('#newRow').append(html);
        });

        // remove row
        $(document).on('click', '#removeRow', function () {
            $(this).closest('.days').remove();
        });

        


         $('textarea#summernote').summernote({
        placeholder: 'Hello bootstrap 4',
        tabsize: 2,
        height: 100,
  toolbar: [
        ['style', ['style']],
        ['font', ['bold', 'italic', 'underline', 'clear']],
        // ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
        //['fontname', ['fontname']],
       // ['fontsize', ['fontsize']],
        ['color', ['color']],
        ['para', ['ul', 'ol', 'paragraph']],
        ['height', ['height']],
        ['table', ['table']],
        ['insert', ['link', 'picture', 'hr']],
        //['view', ['fullscreen', 'codeview']],
        ['help', ['help']]
      ],
      });
</script>
<style type="text/css">
.upload {
  
      margin-top: 36px;
  }
}
</style>

</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/admin/updateperformance.blade.php ENDPATH**/ ?>