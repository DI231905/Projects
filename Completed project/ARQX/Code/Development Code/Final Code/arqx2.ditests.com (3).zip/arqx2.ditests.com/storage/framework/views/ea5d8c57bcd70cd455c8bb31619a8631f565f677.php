<html>
<head>
  <meta charset="utf-8">
  <title>ARQX</title>
  <link rel="stylesheet" type="text/css" href="/css/home1.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css">
  <link rel="icon" href="image/logo.jpg">
  <meta name="viewport" content="width=device-width, initial-scale=1">

      <style type="text/css">

      .login-inner{
        position: relative;
      }

.login-inner:after{
       content: '';
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
    width: 100%;
    height: 100%;
    background: rgb(0 0 0 / 40%);
    display: none;

}
      

  #loading-bar-spinner.spinner {
   left: 50%;
   margin-left: -20px;
   top: 44%;
   margin-top: -20px;
   position: absolute;
   z-index: 19 !important;
   animation: loading-bar-spinner 700ms linear infinite;
   display: none;
}
 #loading-bar-spinner.spinner .spinner-icon {
   width: 40px;
   height: 40px;
   border: solid 6px transparent;
   border-top-color: black !important;
   border-left-color: black !important;
   border-radius: 50%;
}
 @keyframes  loading-bar-spinner {
   0% {
     transform: rotate(0deg);
     transform: rotate(0deg);
  }
   100% {
     transform: rotate(360deg);
     transform: rotate(360deg);
  }

}

#pageMessages {
    position: fixed;
    top: 10%;
    right: 15px;
    width: 30%;
    z-index: 999999999;
  }

  .alert {
  position: relative;
}

.alert .close {
  position: absolute;
  top: 5px;
  right: 5px;
  font-size: 1em;
}

.alert .fa {
  margin-right:.3em;
}
    </style>


</head>
<body class="body">
  <div class="co_header" id="dynamic">
    <div class="container">
      <div class="row row1">
        <div class="col-lg-2 col-md-6 col-6">
          <div class="logo">
            <a href="<?php echo e(url('/')); ?>"><img src="uploads/<?php echo e($footer_image); ?>"></a>
          </div>
        </div>
        <div class="col-lg-7 col-md-1 col-6 order_01">
          <div class="menu">
            <a href="<?php echo e(url('/')); ?>">home</a>
            <a href="<?php echo e(url('/about_us')); ?>">about us</a>
            <a href="<?php echo e(url('/service')); ?>">services</a>
            <a href="<?php echo e(url('/market')); ?>">market</a>
            <a href="<?php echo e(url('/blogs')); ?>">blogs</a>
            <a href="<?php echo e(url('/contact_us')); ?>">contact us</a>
          </div>
          <div class="mobile-menu">
            <div id="mySidepanel" class="sidepanel">
                          <div class="m_menu">
                              <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fal fa-times"></i></a>
                                <a class="link1" href="<?php echo e(url('/')); ?>">Home</a>
                    <a class="link1" href="<?php echo e(url('/about_us')); ?>">About Us</a>
                    <a class="link1" href="<?php echo e(url('/service')); ?>">Services</a>
                    <a class="link1" href="<?php echo e(url('/market')); ?>">markets</a>
                    <a class="link1" href="<?php echo e(url('/blogs')); ?>">Blogs</a>
                    <a class="link1" href="<?php echo e(url('/contact_us')); ?>">Contact us</a>
                          </div>
                        </div>
                        <button class="openbtn" onclick="openNav()"><i class="fal fa-bars"></i></button> 
          </div>
        </div>
        <div class="col-lg-3 col-md-5 col-4 order_02">
          <div class="button">
           <a href="myModal" data-toggle="modal" data-target="#myModal">get started</a>



           
              <?php if(auth()->guard()->guest()): ?>

                  <a class="login-btn" href="<?php echo e(url('/login')); ?>">login</a>

                    <?php else: ?>


                  <a class="login-btn" href="<?php echo e(url('/logout')); ?>">logout</a>               


             <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

    <?php if($message = Session::get('error')): ?>
            <div  id="pageMessages" class="alert alert-success alert-block" >
                <!--     <input type="text" class="close" data-dismiss="alert"></input> -->
                <strong style="padding-top : 5px !important; display: inline-block;"><?php echo e($message); ?></strong>
             </div>
           <?php endif; ?>

   
  <div>
    <div id="pageMessages"></div>
  <div>
  <?php echo $__env->yieldContent('content'); ?>
</div>
<div class="co_footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 col-md-12">
          <div class="footer footer_1">
            <h2 class="footer-title"><?php echo e($footer_title); ?></h2>
              <p><?php echo $footer_description; ?></p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="footer use">
            <h2 class="footer-title">Useful Links</h2>
            <a href="<?php echo e(url('/about_us')); ?>">About Us</a>
            <a href="<?php echo e(url('/service')); ?>">Our Service</a>
            <a href="<?php echo e(url('/contact_us')); ?>">Contact Us</a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="footer">
              <h2 class="footer-title">Contact Us</h2>
              <ul class="con-home">
                            <li><img src="image/house.png">
                                <p><?php echo e($admin_address); ?></p>
                            </li>
                            <li><img src="image/email.png">
                                <p><a href="mailto:<?php echo e($admin_email); ?>"><?php echo e($admin_email); ?></a></p>    
                            </li>
                            <li><img src="image/telephone.png">
                                <p><a href="tel:<?php echo e($admin_phone); ?>"><?php echo e($admin_phone); ?></a></p>
                            </li>
                        </ul>
            </div>
          </div>
        </div>
        <div class="bottom-footer">
          <div class="row row1">
            <div class="col-lg-6 col-md-6 col-12">
              <p>Copyright © 2021 ARQX. All rights reserved.</p>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
              <ul class="social-link">
                <li><a href="<?php echo e($admin_facebook); ?>"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="<?php echo e($admin_twitter); ?>"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="<?php echo e($admin_linkedin); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="<?php echo e($admin_instagram); ?>"><i class="fab fa-instagram"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
  </div>
  <div class="copy">
        <a class="up-btn show" href="#"><i class="fas fa-angle-double-up"></i></a>
    </div>

    <!------------- Inquiry-modal ------------>
    <div class="modal modal-address" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">GET INQUIRY</h4>

                     <div class="alert alert-danger print-error-msg" style="display:none">
                          <ul></ul>
                          </div>


                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <form  class="b-detail form12" id="sendmessage" name="sendmessage" method="post">

                       <div id="loading-bar-spinner" class="spinner"><div class="spinner-icon"></div></div>

                       <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-6 check">
                                <input type="text" placeholder="First name" name="fname" id="fname" required autocomplete="off">
                            </div>
                            <div class="col-md-6 check">
                                <input type="text" placeholder="Last name" name="lname" id="lname" required autocomplete="off">
                            </div>
                            <div class="col-md-6 check">
                                <input type="email" placeholder="Email address" name="email" id="email" required autocomplete="off">
                            </div>
                            <div class="col-md-6 check">
                                <input type="number" placeholder="Phone Number" name="mobileno" id="mobileno" required autocomplete="off">
                            </div>
                            <div class="col-md-12 check">
                                <textarea type="number" placeholder="Message" name="description" id="description" rows="5" required autocomplete="off"></textarea>
                            </div>
                        </div>
                        <button class="btn_acele btn_black" id="submit" type="submit">submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>




  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script type="text/javascript" src="js/home.js"></script>
    <script type="text/javascript">
      $('.quote-slider').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            prevArrow: '<div class="quote-arrow slide-arrow prev-arrow"><i class="fal fa-arrow-left"></i></div>',
            nextArrow: '<div class="quote-arrow slide-arrow next-arrow"><i class="fal fa-arrow-right"></i></div>'
        });

        $('.counter-count').each(function () {
            $(this).prop('Counter',0).animate({
                Counter: $(this).text()
                }, {          
                //chnage count up speed here
                duration: 4000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });

  
function createAlert(title, summary, details, severity, dismissible, autoDismiss, appendToId) {
  var iconMap = {
    info: "fa fa-info-circle",
    success: "fa fa-thumbs-up",
    warning: "fa fa-exclamation-triangle",
    danger: "fa ffa fa-exclamation-circle"
  };

  var iconAdded = false;

  var alertClasses = ["alert", "animated", "flipInX"];
  alertClasses.push("alert-" + severity.toLowerCase());

  if (dismissible) {
    alertClasses.push("alert-dismissible");
  }

  var msgIcon = $("<i />", {
    "class": iconMap[severity] // you need to quote "class" since it's a reserved keyword
  });

  var msg = $("<div />", {
    "class": alertClasses.join(" ") // you need to quote "class" since it's a reserved keyword
  });

  if (title) {
    var msgTitle = $("<h4 />", {
      html: title
    }).appendTo(msg);
    
    if(!iconAdded){
      msgTitle.prepend(msgIcon);
      iconAdded = true;
    }
  }

  if (summary) {
    var msgSummary = $("<strong />", {
      html: summary
    }).appendTo(msg);
    
    if(!iconAdded){
      msgSummary.prepend(msgIcon);
      iconAdded = true;
    }
  }

  if (details) {
    var msgDetails = $("<p />", {
      html: details
    }).appendTo(msg);
    
    if(!iconAdded){
      msgDetails.prepend(msgIcon);
      iconAdded = true;
    }
  }
  

  if (dismissible) {
    var msgClose = $("<span />", {
      "class": "close", // you need to quote "class" since it's a reserved keyword
      "data-dismiss": "alert",
      html: "<i class='fa fa-times-circle'></i>"
    }).appendTo(msg);
  }
  
  $('#' + appendToId).prepend(msg);
  
  if(autoDismiss){
    setTimeout(function(){
      msg.addClass("flipOutX");
      setTimeout(function(){
        msg.remove();
      },1000);
    }, 5000);
  }
}


$('.banner-slider').slick({
            slidesToShow: 1,
            slidesToScroll: 1
        });


    $(document).ready(function() {
          $("#submit").click(function(e){
            e.preventDefault();
         
            var _token = $("input[name='_token']").val();  
            var email = $('#email').val();
            var lname = $('#lname').val();
            var fname = $('#fname').val();
            var mobileno = $('#mobileno').val();
            var description = $('#description').val();
          
                    
            $.ajax({
                url: '/getinquiry',
                type:'post',
                data: {_token:_token,email:email,fname:fname,lname:lname,mobileno:mobileno,description:description},


                  beforeSend: function(){
                      $('#loading-bar-spinner').show();


                      $('#overlay').fadeIn()

                    

                          },
                      complete: function(){
                        $('#loading-bar-spinner').hide();

                        
                        },

                success: function(data) {
                    if($.isEmptyObject(data.error)){

                           $( '#sendmessage' ).each(function(){
                          this.reset();

                           $('#myModal').modal('hide');    
                        });  

                   
                          createAlert('','Success!','Your Inquiry submitted successfully!!.','success',true,true,'pageMessages');


                     
                           
                    }else{



                      if(data.status==202){

                     

                      }else{

                           printErrorMsg(data.error);

                         $('.alert').delay(3000).fadeOut(3000);  



                      }



                     
                        

                    }
                }
            });
       
        }); 
       
        function printErrorMsg (msg) {
            $(".print-error-msg").find("ul").html('');
            $(".print-error-msg").css('display','block');
            $.each( msg, function( key, value ) {
                $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
            });
        }
    });




    </script>
    </script>
</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>