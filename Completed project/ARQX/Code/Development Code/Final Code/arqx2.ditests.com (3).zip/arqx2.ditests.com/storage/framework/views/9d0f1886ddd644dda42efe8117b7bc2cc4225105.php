 


<?php $__env->startSection('content'); ?>

<div class="co-banner1">
       <?php $__currentLoopData = $allbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($a->name == 'Blogs'): ?>
        <img src="uploads/<?php echo e($a->image); ?>">
        <div class="container_11">
            <h1><?php echo e($a->name); ?></h1>
            <ul class="breadcrumb1">
                <li><a href="<?php echo e(url('/')); ?>"><img src="image/house.png"> Home</a></li>
                <li>/</li>
                <li><?php echo e($a->name); ?></li>
            </ul>
        </div>
        <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


 <div class="co_blog">
    	<div class="container">
    		<div class="blog-search">
                <form method="get">
    			<input type="text" placeholder="search here.." name="search" id="txtSearch">
                </form>
    		</div>
    		<div class="inner_blog">
    			<div class="row" id="blogdata">

               <?php $__currentLoopData = $blogdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				<div class="col-lg-4 col-md-6 col-12">
    					<div class="blog">
    						<div class="blog-img">
    							<img src="uploads/<?php echo e($b->image); ?>">
    						</div>
    						<div class="blog-content">

                      
                         <?php
                           $date1=date('F j, Y', strtotime($b->date)); //June, 2017
                         ?>

    							<h6><?php echo e($date1); ?></h6>
    							<h3><?php echo e($b->title); ?></h3>
    							<p><?php echo $b->description; ?></p>
    						</div>
    					</div>
    				</div>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				
    				
    			</div>
    		</div>
    	</div>
    </div>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(document).ready(function(){

    $('#txtSearch').on('keyup', function(){

        var text = $('#txtSearch').val();


        $.ajax({

            type:"GET",
            url: '/search',
            data: {text: $('#txtSearch').val()},
            success: function(response) {
                /* response = JSON.parse(response);
                 for (var search_result of response) {
                     console.log(search_result);

                        var output = '';

          output+='<div class="col-lg-4 col-md-6 col-12">'
                  '<div class="blog">'
                '<div class="blog-img">'
                ' <img src=" ">'
                '</div>'
                '<div class="blog-content">'

                      
                    
                  '<h6>fgdfgf</h6>'
                  '<h3>dgfdgfg</h3>'
                 '<p>dfdgdgfgfff</p>'
                '</div>'
              '</div>'
            '</div>'

           

        

                 }*/

             $('#blogdata').html("");
              $('#blogdata').html(response);

                 console.log(response);
             }



        });


    });

});
          


      </script>

    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/blogs.blade.php ENDPATH**/ ?>