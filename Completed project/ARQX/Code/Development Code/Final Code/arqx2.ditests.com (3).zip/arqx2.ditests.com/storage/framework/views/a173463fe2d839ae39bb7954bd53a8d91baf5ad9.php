

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
             <div class="mt-5">
                    <h4 class="mb-4"> Footer About Us  </h4>
                     <div class="detail table-responsive">
                       <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Title</th>
                                  
                                    <th>Description</th>
                                   
                                </tr>
                            </thead>
                               <?php $__currentLoopData = $footer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tbody>
                                
                                <tr>


                                    <td>
                                         <img src="/uploads/<?php echo e($fa->image); ?>" width="300" height="180"><br>
                                    </td>

                                     <td>
                                           <?php echo e($fa->title); ?>

                                    </td>



                                    <td>
                                        <?php echo $fa->description; ?>

                                    </td>
                                
                    
                                  
                               <td><button class="btn0 btn2"><a href="<?php echo e(url('admin/update_footer_data')); ?>/<?php echo e($fa->id); ?>" ><i class="fal fa-pencil"></i></a></button></td>
                                   
                               
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                 </div>
           
              </div> 
           </div>
           <?php $__env->stopSection(); ?>

           
         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">
        
        

       $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });

      </script>
    

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mzldwoswysm5/public_html/arqx2.ditests.com/resources/views/admin/footeraboutlist.blade.php ENDPATH**/ ?>