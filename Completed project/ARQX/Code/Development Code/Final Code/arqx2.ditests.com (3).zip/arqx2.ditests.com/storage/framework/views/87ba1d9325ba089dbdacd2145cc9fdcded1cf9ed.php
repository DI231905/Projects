

<?php $__env->startSection('content'); ?>

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4">Brochure</h4>
                  <button class="btn1"><a href="<?php echo e(url('admin/addbrochure')); ?>" style="color:black;">ADD</a></button>
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                   <th>Image</th>  
                                    <th>Update</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                        
                             <tbody>
                               <?php $__currentLoopData = $brochuredata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="broch_<?php echo e($s->id); ?>">
                                  
                                <td><?php echo e($s->image); ?></td>
                                  
                                 <td>
                                <button class="btn0 btn2"><a href="<?php echo e(url('admin/updatebrochure')); ?>/<?php echo e($s->id); ?>"><i class="fal fa-pencil"></i></a></button>
                              </td>
                             <td>
                                <button class="btn3 btn0" onclick="deletebroch(<?php echo e($s->id); ?>)"><i class="fal fa-trash-alt"></i></a></button>
                              </td> 
                            
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>
      <script type="text/javascript">
        
         function deletebroch($id){

     if(confirm("do you want delete this data ?")){
             $.ajax({

                url:'deletebrochure/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.broch_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
      </script>

       <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ARQX\resources\views/admin/brochure.blade.php ENDPATH**/ ?>