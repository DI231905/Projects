@extends('admin.layouts.app')

@section('content')

  <div class="page mt-4 hosting-page title1" style="display: block;">
          <div class="mt-5">
              <div class="list1">
                  <h4 class="mb-4">User List</h4>
                 
              </div>
               <div class="detail table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th> 
                                    <th>Email</th>        
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                        
                             <tbody>
                               @foreach($user as $s)
                               <tr class="user_{{$s->id}}">
                                 
                                     <td>{{$s->name}}</td>

                                    <td>{!!$s->email !!}</td>               
                
                              <td>
                                <button class="btn3 btn0" onclick="deleteuser({{$s->id}})"><i class="fal fa-trash-alt"></i></a></button>
                              </td> 
                              
                            
                                </tr>
                                @endforeach 
                                
                            </tbody>
                           
                        </table>
                    </div>
          </div>
      </div>
      
       <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">

      	
      	   $(function() {
                 setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

             });
        
         function deleteuser($id){

     if(confirm("do you want delete this data ?")){
             $.ajax({

                url:'delete_user/'+$id,
                type:'GET',
                dataType: "json",

        success: function(response){
        
                      $('.user_'+$id).hide();
          
                        },

      error: function(response) {


           alert('error');
          
                 
                  },        
          
                });

          }
      }  
      </script>

       @endsection