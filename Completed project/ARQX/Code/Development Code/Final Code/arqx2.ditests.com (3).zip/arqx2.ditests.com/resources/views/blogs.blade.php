 
@extends('layouts.app')

@section('content')

<div class="co-banner1">
       @foreach($allbanner as $a)
            @if($a->name == 'Blogs')
        <img src="uploads/{{$a->image}}">
        <div class="container_11">
            <h1>{{$a->name}}</h1>
            <ul class="breadcrumb1">
                <li><a href="{{url('/')}}"><img src="image/house.png"> Home</a></li>
                <li>/</li>
                <li>{{$a->name}}</li>
            </ul>
        </div>
        @endif
       @endforeach
    </div>


 <div class="co_blog">
    	<div class="container">
    		<div class="blog-search">
                <form method="get">
    			<input type="text" placeholder="search here.." name="search" id="txtSearch">
                </form>
    		</div>
    		<div class="inner_blog">
    			<div class="row" id="blogdata">

               @foreach($blogdata as $b)
    				<div class="col-lg-4 col-md-6 col-12">
    					<div class="blog">
    						<div class="blog-img">
    							<img src="uploads/{{$b->image}}">
    						</div>
    						<div class="blog-content">

                      
                         <?php
                           $date1=date('F j, Y', strtotime($b->date)); //June, 2017
                         ?>

    							<h6>{{$date1}}</h6>
    							<h3>{{$b->title}}</h3>
    							<p>{!! $b->description !!}</p>
    						</div>
    					</div>
    				</div>

               @endforeach
    				
    				
    			</div>
    		</div>
    	</div>
    </div>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script type="text/javascript">

          $(document).ready(function(){

    $('#txtSearch').on('keyup', function(){

        var text = $('#txtSearch').val();


        $.ajax({

            type:"GET",
            url: '/search',
            data: {text: $('#txtSearch').val()},
            success: function(response) {
                /* response = JSON.parse(response);
                 for (var search_result of response) {
                     console.log(search_result);

                        var output = '';

          output+='<div class="col-lg-4 col-md-6 col-12">'
                  '<div class="blog">'
                '<div class="blog-img">'
                ' <img src=" ">'
                '</div>'
                '<div class="blog-content">'

                      
                    
                  '<h6>fgdfgf</h6>'
                  '<h3>dgfdgfg</h3>'
                 '<p>dfdgdgfgfff</p>'
                '</div>'
              '</div>'
            '</div>'

           

        

                 }*/

             $('#blogdata').html("");
              $('#blogdata').html(response);

                 console.log(response);
             }



        });


    });

});
          


      </script>

    
    @endsection