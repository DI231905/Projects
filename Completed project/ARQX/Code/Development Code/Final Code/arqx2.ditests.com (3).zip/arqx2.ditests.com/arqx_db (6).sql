-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 26, 2022 at 05:58 AM
-- Server version: 5.7.36-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arqx_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutdescription`
--

CREATE TABLE `aboutdescription` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aboutdescription`
--

INSERT INTO `aboutdescription` (`id`, `title`, `description`) VALUES
(1, 'A RELIABILITY HYPOTHESIS', '<span style=\"color: rgb(20, 9, 88); font-family: Inter, sans-serif; font-size: 18px; letter-spacing: 0.81px; text-align: center;\">In the grand scheme of things, we’re a young firm. However, we have a few very seasoned principles. We’re composed of a group of people with direct operational experience in the sectors we invest in, enabling deeper insight and ultimately, higher returns for our clients. ARQX Capital executes the reliability hypothesis, aiming to be your dependable partner in navigating global markets.</span>');

-- --------------------------------------------------------

--
-- Table structure for table `achive_target`
--

CREATE TABLE `achive_target` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `achive_target`
--

INSERT INTO `achive_target` (`id`, `title`, `value`, `created_at`, `updated_at`) VALUES
(3, 'CHF AUM', '100 M', NULL, NULL),
(4, 'MAJOR MARKETS', '11', NULL, NULL),
(5, 'ASSET CLASSES', '8', NULL, NULL),
(6, 'LANGUAGES', '4', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`id`, `name`, `email`, `address`, `phone`, `facebook`, `instagram`, `twitter`, `linkedin`, `created_at`, `updated_at`) VALUES
(1, 'ARQX', 'n.treand@arqx-capital.com', 'Allée Pic-Pic 2, 1203 Genève', '+41 79 662 70 98', 'https://www.facebook.com/', 'https://www.instagram.com/', 'https://twitter.com/', 'https://www.linkedin.com/', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `token`, `created_at`, `updated_at`) VALUES
(1, 'ARQX', 'n.treand@arqx-capital.com', '$2y$10$lv9YKyRLCAbtc0k4DtSmrOsqzG12oJrPH1bMrj5lQe/ueR43ucm7.', '9117', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `image`, `title`, `created_at`, `updated_at`) VALUES
(3, '1642675941_banner1.png', 'ACTIVATED ASSET MANAGEMENT', NULL, NULL),
(4, '1642676034_banner1.png', 'DIVERSIFIED MARKETS & ASSET CLASSES', NULL, NULL),
(5, '1642676165_banner-2.png', 'CAPITAL PROTECTION STRATEGIES', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `banner_image`
--

CREATE TABLE `banner_image` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `page_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner_image`
--

INSERT INTO `banner_image` (`id`, `name`, `image`, `page_name`) VALUES
(2, 'Services', '1643095452_banner1.png', 'Services'),
(3, 'Markets', '1643105218_banner1.png', 'Markets'),
(4, 'About Us', '1642836363_about-bg.png', 'About Us'),
(5, 'Contact Us', '1643175990_about-bg.png', 'Contact Us'),
(6, 'Blogs', '1643173711_about-bg.png', 'Blogs');

-- --------------------------------------------------------

--
-- Table structure for table `benefits`
--

CREATE TABLE `benefits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `benefits`
--

INSERT INTO `benefits` (`id`, `image`, `title`, `description`, `created_at`, `updated_at`) VALUES
(2, '1643208749_about-service1.jpg', 'Operational Excellence', 'We execute your vision in accordance with Swiss standards, with fiduciary responsibility.', NULL, NULL),
(3, '1643208758_about-service2.png', 'Governance & Compliance', 'Supervised by ARIF (OSIF), we’re proud to be a member of one of Switzerland’s most reputed Self-Regulatory Organizations. We pass annual anti-money laundering audits, alongside technology and risk audits.', NULL, NULL),
(4, '1643208765_about-service3.png', 'Reliability & Growth', 'We’ve delivered reliable growth to our clients through efficient allocations. We’ve achieved through clear and concise advice, which our clients find actionable and built upon clear financial logic.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `image`, `description`, `date`) VALUES
(2, 'MAKING MORE FROM YOUR SALARY', '1643199442_blog-1.png', '<p><span style=\"color: rgb(33, 37, 41); font-family: Inter, sans-serif; font-size: 16px; letter-spacing: 0.72px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.</span><br></p>', '2022-01-20'),
(3, 'WP Dummy Content', '1643199472_blog-2.png', '<p><span style=\"color: rgb(33, 37, 41); font-family: Inter, sans-serif; font-size: 16px; letter-spacing: 0.72px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.</span><br></p>', '2022-01-22'),
(4, 'MAKING MORE FROM YOUR SALARY', '1643199513_blog-3.png', '<p><span style=\"color: rgb(33, 37, 41); font-family: Inter, sans-serif; font-size: 16px; letter-spacing: 0.72px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.</span><br></p>', '2022-01-22'),
(5, 'MAKING MORE FROM YOUR SALARY', '1643199597_blog-4.png', '<p><span style=\"color: rgb(33, 37, 41); font-family: Inter, sans-serif; font-size: 16px; letter-spacing: 0.72px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.</span><br></p>', '2022-01-22'),
(6, 'MAKING MORE FROM YOUR SALARY', '1643199628_blog-5.png', '<p><span style=\"color: rgb(33, 37, 41); font-family: Inter, sans-serif; font-size: 16px; letter-spacing: 0.72px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.</span><br></p>', '2022-01-22'),
(7, 'MAKING MORE FROM YOUR SALARY', '1643199669_blog-6.png', '<p><span style=\"color: rgb(33, 37, 41); font-family: Inter, sans-serif; font-size: 16px; letter-spacing: 0.72px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.</span><br></p>', '2022-01-22'),
(8, 'MAKING MORE FROM YOUR SALARY', '1643199700_blog-7.png', '<p><span style=\"color: rgb(33, 37, 41); font-family: Inter, sans-serif; font-size: 16px; letter-spacing: 0.72px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.</span><br></p>', '2022-01-22'),
(9, 'MAKING MORE FROM YOUR SALARY', '1643199735_blog-8.png', '<p><span style=\"color: rgb(33, 37, 41); font-family: Inter, sans-serif; font-size: 16px; letter-spacing: 0.72px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.</span><br></p>', '2022-01-22'),
(10, 'MAKING MORE FROM YOUR SALARY', '1643199779_blog-9.png', '<p><span style=\"color: rgb(33, 37, 41); font-family: Inter, sans-serif; font-size: 16px; letter-spacing: 0.72px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore veniam dolore.</span><br></p>', '2022-01-22');

-- --------------------------------------------------------

--
-- Table structure for table `brochure`
--

CREATE TABLE `brochure` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brochure`
--

INSERT INTO `brochure` (`id`, `image`, `created_at`, `updated_at`) VALUES
(6, '1644301550_pdfview.pdf', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us_desc`
--

CREATE TABLE `contact_us_desc` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_us_desc`
--

INSERT INTO `contact_us_desc` (`id`, `title`, `description`) VALUES
(1, 'OR GET IN TOUCH', '<span style=\"color: rgb(255, 255, 255); font-family: Inter, sans-serif; font-size: 18px; letter-spacing: 0.81px; background-color: rgb(2, 99, 246);\">In the grand scheme of things, we’re a young firm. However, we have a few very seasoned principles. We’re composed of a group of people with direct operational experience in the sectors we invest in, enabling deeper insight and ultimately,&nbsp;</span>');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `icon_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`id`, `icon_image`, `title`, `description`, `created_at`, `updated_at`) VALUES
(3, '1642741810_inner-service1.png', 'Independent Asset Managers', 'Experience the finest services coupled with flexibility and dynamic culture.', NULL, NULL),
(4, '1642741878_inner-service2.png', 'Sustainable Development Approach', 'We integrate asset management and a sustainable approach by recognizing opportunities for investment in ESG.', NULL, NULL),
(5, '1642741902_inner-service3.png', 'Digital Investing', 'Investment practice is completely digitalized thus consolidating competence with technology.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `features_description`
--

CREATE TABLE `features_description` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key_features_id` int(11) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `features_description`
--

INSERT INTO `features_description` (`id`, `key_features_id`, `description`, `created_at`, `updated_at`) VALUES
(12, 1, 'We focus on beating your expectations, not benchmarks.', NULL, NULL),
(13, 1, 'We offer advice on alternative assets, not exposure.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `footer_data`
--

CREATE TABLE `footer_data` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `footer_data`
--

INSERT INTO `footer_data` (`id`, `title`, `image`, `description`) VALUES
(1, 'About Us', '1643194521_logo.jpg', '<p style=\"font-size: 14px; line-height: 21px; letter-spacing: 0.045em; margin-bottom: 12px; color: rgb(255, 255, 255); font-family: Inter, sans-serif; background-color: rgb(35, 31, 32);\">ARQX Capital is an asset management firm operating in the heart of Geneva, Switzerland.</p><p style=\"font-size: 14px; line-height: 21px; letter-spacing: 0.045em; margin-bottom: 12px; color: rgb(255, 255, 255); font-family: Inter, sans-serif; background-color: rgb(35, 31, 32);\">Discreet and reliable, ARQX is injecting sophisticated technology into timeless investing principles.</p><p style=\"font-size: 14px; line-height: 21px; letter-spacing: 0.045em; margin-bottom: 12px; color: rgb(255, 255, 255); font-family: Inter, sans-serif; background-color: rgb(35, 31, 32);\">Operating under the supervision of ARIF (OSIF), ARQX exceeds the highest standards in Swiss financial governance.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `get_in_touch`
--

CREATE TABLE `get_in_touch` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `get_in_touch`
--

INSERT INTO `get_in_touch` (`id`, `name`, `number`, `email`, `message`) VALUES
(5, 'kjuy', '123456789', 'apptest2303@gmail.com', 'test'),
(6, 'kjuy', '123456789', 'apptest2303@gmail.com', 'test'),
(7, 'JP', '12345678', 'apptest2303@gmail.com', 'test'),
(9, 'kjuy', '123456789', 'jinal.digitalinovation2021@gmail.com', 'test'),
(10, 'kjuy', '13232', 'jinal.digitalinovation2021@gmail.com', 'tretr'),
(11, 'kjuy', '13232', 'jinal.digitalinovation2021@gmail.com', 'tretr'),
(12, 'kjuy', '123848977', 'jinal.digitalinovation2021@gmail.com', 'test'),
(13, 'test', '1234569023', 'jinal.digitalinovation2021@gmail.com', 'test'),
(14, 'test', '222323445', 'apptest2303@gmail.com', 'test'),
(15, 'test', '213243554', 'apptest2303@gmail.com', 'sxadcfd'),
(16, 'test', '123456789', 'apptest2303@gmail.com', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `home_aboutus`
--

CREATE TABLE `home_aboutus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `home_aboutus`
--

INSERT INTO `home_aboutus` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'DISCIPLINED INVESTING, FUNDAMENTAL ANALYSIS TECHNICAL INTELLIGENCE', '<p style=\"font-size: 18px; line-height: 26px; letter-spacing: 0.045em; margin-bottom: 1rem; color: rgb(20, 9, 88); font-family: Inter, sans-serif;\">We have best-in-class funds tuned not just for tracking the benchmark, but for beating them.</p><p style=\"font-size: 18px; line-height: 26px; letter-spacing: 0.045em; margin-bottom: 1rem; color: rgb(20, 9, 88); font-family: Inter, sans-serif;\">We shield your portfolio with reliable and credible instruments and complete confidence in our strategies. Accomplishing your targets to support all facets of your growth objective. Careful sector and holdings apportionment, applying our investment due diligence to over a hundred thousand different investing instruments.</p>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `home_aboutus_image`
--

CREATE TABLE `home_aboutus_image` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_aboutus_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `home_aboutus_image`
--

INSERT INTO `home_aboutus_image` (`id`, `image`, `home_aboutus_id`, `created_at`, `updated_at`) VALUES
(1, '1643208666_about-1.png', 1, NULL, NULL),
(2, '1643208672_about-2.png', 1, NULL, NULL),
(3, '1643208681_about-3.png', 1, NULL, NULL),
(4, '1643208689_about-4.png', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE `inquiry` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inquiry`
--

INSERT INTO `inquiry` (`id`, `fname`, `lname`, `email`, `mobileno`, `description`) VALUES
(15, 'jinal', 'patel', 'apptest2303@gamil.com', '1234567890', 'test'),
(18, 'jinal', 'patel', 'apptest2303@gmail.com', '12345678', 'test'),
(19, 'jinal', 'patel', 'apptest2303@gmail.com', '1234567', 'test'),
(20, 'jinal', 'patel', 'apptest2303@gmail.com', '1234567', 'test'),
(21, 'jinal', 'patel', 'apptest2303@gmail.com', '1234567', 'test'),
(23, 'jinal', 'patel', 'jinal23@gmail.com', '123456789', 'test'),
(24, 'jinal', 'patel', 'jinal.digitalinovation2021@gmail.com', '1234567', 'test'),
(25, 'test', '123456', 'jinal.digitalinovation2021@gmail.com', '12132132', '23234324');

-- --------------------------------------------------------

--
-- Table structure for table `invesment_process`
--

CREATE TABLE `invesment_process` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invesment_process`
--

INSERT INTO `invesment_process` (`id`, `title`, `image`, `created_at`, `updated_at`) VALUES
(1, 'OUR INVESTMENT PROCESS', '1642830157_invest.png', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invesment_process_step`
--

CREATE TABLE `invesment_process_step` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invesment_process_step`
--

INSERT INTO `invesment_process_step` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Selection Criteria', 'A broad net is fine-tuned by Industry experts specific to the theater of operations of target companies.', NULL, NULL),
(2, 'Position Evaluation', 'Long-term evaluation is executed to ensure minimum uncertainty and reduce the impact of risks.', NULL, NULL),
(3, 'Active Monitoring', 'Performance is mindfully studied and actively managed to maintain predictability and offset wild fluctuations in returns', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `key_feature`
--

CREATE TABLE `key_feature` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `key_feature`
--

INSERT INTO `key_feature` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Discreet. Private. Reliable.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `loginpage`
--

CREATE TABLE `loginpage` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `loginpage`
--

INSERT INTO `loginpage` (`id`, `image`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, '1643368756_login-bg.png', 'WELCOME TO', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type unknown printer took a galley of type and scrambled', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_01_20_080712_create_banner_table', 1),
(6, '2022_01_20_080912_create_more_maintitle_table', 1),
(7, '2022_01_20_122556_create_features_table', 2),
(8, '2022_01_21_052730_create_home_aboutus_table', 3),
(9, '2022_01_21_053020_create_home_aboutus_image_table', 3),
(10, '2022_01_21_100528_create_key_feature_table', 4),
(11, '2022_01_21_100654_create_features_description_table', 4),
(12, '2022_01_21_122253_create_achive_target_table', 5),
(13, '2022_01_21_132152_create_invesment_process_table', 6),
(14, '2022_01_21_132421_create_invesment_process_step_table', 6),
(15, '2022_01_22_084540_create__skillset_table', 7),
(16, '2022_01_22_091735_create_benifits_table', 8),
(17, '2014_10_12_200000_add_two_factor_columns_to_users_table', 9),
(18, '2022_01_31_061706_create_sessions_table', 9),
(19, '2022_01_31_062155_add_fb_id_column_in_users_table', 10),
(20, '2022_01_31_100609_add_fb_id_column_in_users_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `more_maintitle`
--

CREATE TABLE `more_maintitle` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `more_maintitle` text COLLATE utf8mb4_unicode_ci,
  `banner_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `more_maintitle`
--

INSERT INTO `more_maintitle` (`id`, `more_maintitle`, `banner_id`, `created_at`, `updated_at`) VALUES
(12, 'Investments are globally diversified to bring out maximum yield with low-risk strategies', 4, NULL, NULL),
(13, 'We preserve the value you’ve created through a qualitative approach', 5, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `news_letter`
--

CREATE TABLE `news_letter` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news_letter`
--

INSERT INTO `news_letter` (`id`, `email`, `number`) VALUES
(1, 'apptest2303@gmail.com', '1212324343');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `performance`
--

CREATE TABLE `performance` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `performance`
--

INSERT INTO `performance` (`id`, `image`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, '1643093193_performance.png', 'OUR PERFORMANCE', '<p><span style=\"color: rgb(20, 9, 88); font-family: Inter, sans-serif; font-size: 18px; letter-spacing: 0.045em;\">We have best-in-class funds tuned not just for tracking the benchmark, but for beating them.</span><br></p><p style=\"font-size: 18px; line-height: 26px; letter-spacing: 0.045em; margin-bottom: 1rem; color: rgb(20, 9, 88); font-family: Inter, sans-serif;\">We shield your portfolio with reliable and credible instruments and complete confidence in our strategies. Accomplishing your targets to support all facets of your growth objective. Careful sector and holdings apportionment, applying our investment due diligence to over a hundred thousand different investing instruments.</p>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `image`, `title`, `description`, `created_at`, `updated_at`) VALUES
(4, '1643208907_service_01.png', 'REGION', '<p>We tend to focus on developed markets, qualifying options through stringent due-diligence processes, alongside in-depth AML checks. Our choices reflect the values held by our clients. Through a focus on high-growth companies, we aim to deliver higher-value returns from investments into the US or European firms than competing firms.</p>', NULL, NULL),
(5, '1643208917_service_02.png', 'SECTOR', '<p>After the onset of the pandemic, we’ve created special vehicles that target firms that could potentially benefit from the rise of the gig economy. In broader terms, we focus on investment opportunities in consumer discretionary, energy, data and analytics, infrastructure, and security.<br></p>', NULL, NULL),
(6, '1643208930_service_03.png', 'INSTRUMENTS', '<p>We offer access to flagship funds as well as unique one-off vehicles developed for specific purposes. Our strategies tend to utilize instruments that offer deep liquidity and exposure to multiple assets.<br></p>', NULL, NULL),
(7, '1643208940_service_04.png', 'UNIVERSES', '<p>To diversify sources of Alpha, the firms invest in various cross-universe instruments that are appropriate risk-adjusted and carry Sharpe Ratios of > 2. Additionally, exposure to various stock universes allows ARQX to seek high growth opportunities in low-risk environments.<br></p>', NULL, NULL),
(8, '1643208954_service_05.png', 'STRATEGIES', '<p>Our strategies aim to benefit from the technologies and philosophies associated with Enterprise 4.0. The team as ARQX has deep industry knowledge in sectors such as Data, Infrastructure, and Security - enabling both long and short-term strategies that compound our client\'s wealth.<br></p>', NULL, NULL),
(9, '1643208962_service_06.png', 'WHITE SPACES', '<p>Focusing on investment areas that are traditionally ignored by mainstream investment houses, these areas are often misunderstood, capitalized, and more importantly, mispriced. Various opportunities in white spaces have delivered consistent and eye-watering returns.<br></p>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `service_aboutus`
--

CREATE TABLE `service_aboutus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_aboutus`
--

INSERT INTO `service_aboutus` (`id`, `name`, `title`, `description`) VALUES
(1, 'Asset Management', 'Establishing Standards In Research And Returns, ARQX Capital Is An Independent And Private Asset Management Firm.', '<p style=\"font-size: 18px; line-height: 26px; letter-spacing: 0.045em; margin-bottom: 1rem; color: rgb(20, 9, 88); font-family: Inter, sans-serif;\">Every investment portfolio managed by us has a unique profile. The only thing common across our services to our clients is our transparency and professionalism. We fine-tune strategies based on individuals\' preferences and experiences, giving the firm depth in its approach.</p><p style=\"font-size: 18px; line-height: 26px; letter-spacing: 0.045em; margin-bottom: 1rem; color: rgb(20, 9, 88); font-family: Inter, sans-serif;\">While our range of skills is broad, we don’t attempt everything. Instead, we maintain our core competencies across a few chosen sectors and regions. We’ve focused on companies and instruments that directly create value for our investors, but also their customers and communities.&nbsp;</p>');

-- --------------------------------------------------------

--
-- Table structure for table `service_aboutus_image`
--

CREATE TABLE `service_aboutus_image` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `service_about_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_aboutus_image`
--

INSERT INTO `service_aboutus_image` (`id`, `image`, `service_about_id`) VALUES
(1, '1643208850_s1.png', 1),
(2, '1643208844_s2.png', 1),
(3, '1643208860_s3.png', 1),
(4, '1643208866_s4.png', 1),
(5, '1643208875_s5.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('9FpRffJGz11d9AiS9dc9pvftLqBMR1WpjjQAwWo1', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoia0owWmJ2cUowSU5wWWJubDdCUmQ4ZUFaYlZFT2p3UGhlcm5GaUxpZCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozMjoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2FkbWluL2hvbWUiO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozNToiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2F1dGgvZmFjZWJvb2siO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjU6InN0YXRlIjtzOjQwOiJrNHBIV0lKREZXMEhGc3pSYnd0QmdkeDM4bHpXaU10cUREZ2ZxZkZXIjt9', 1643621506);

-- --------------------------------------------------------

--
-- Table structure for table `skillset`
--

CREATE TABLE `skillset` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `skillset`
--

INSERT INTO `skillset` (`id`, `image`, `title`, `description`, `created_at`, `updated_at`) VALUES
(2, '1642842452_service-1.png', 'Financial Structuring', 'Funds are carefully allocated to each sector keeping in mind various technical and risk factors.', NULL, NULL),
(3, '1642842515_service-2.png', 'Asset Management Advice', 'Keeping your principle in the pristine form alongside establishing consistent returns.', NULL, NULL),
(4, '1642842535_service-3.png', 'Diversified Alpha Generation', 'Actively managed funds to benefit from exposure to multiple high-growth sectors.', NULL, NULL),
(5, '1642842559_service-4.png', 'Satellite Funds', 'Micro funds with built-in strategies to avoid stagnancy and maintain momentum.', NULL, NULL),
(6, '1642842584_service-5.png', 'Low Volatility & Fixed Income', 'Safe and stable instruments that form the bedrock of your portfolio.', NULL, NULL),
(9, '1642842605_service-6.png', 'Equity & Debt', 'Gain a sophisticated understanding of how portfolio-architecture can be optimized through strategic allocation.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `terms_condition` int(11) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fb_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `terms_condition`, `remember_token`, `created_at`, `updated_at`, `fb_id`, `google_id`) VALUES
(8, 'jinal patel', 'jinalpatel23697@gmail.com', NULL, 'eyJpdiI6Imh0MzBlc0xTRUt4RVJnTlI0V1RtQWc9PSIsInZhbHVlIjoiUG1wcFdybUI2TzU5c2hGcEsveTFPbGE3T0lreEJUN2t6T1FsMGRHK3NGYz0iLCJtYWMiOiJlMDY0ZWEzMjhhZTQ5ZWM1MTRhNTc2NzhmNzYwYTMyODRlNDY3YmQzY2Q2Mjg0MmQ2MmNlZDFlNGZiNTQwYjkzIiwidGFnIjoiIn0=', NULL, NULL, NULL, NULL, '2022-02-03 00:09:20', '2022-02-03 00:09:20', NULL, '102570437693459135492'),
(10, 'jinal', 'apptest2303@gmail.com', NULL, '$2y$10$aX4hsRHu8zHiEmRI4jlIaOVEWoIqL5v61GEK1yHXextxHCSHa/k8S', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL),
(11, 'kjuy', 'jinal.digitalinovation2021@gmail.com', NULL, '$2y$10$cDmfkx31CJWzMqUtGvOqPuaPWu8YBpaqVepKtlZSUc2zobItBjWH.', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `whychooseus`
--

CREATE TABLE `whychooseus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `whychooseus`
--

INSERT INTO `whychooseus` (`id`, `image`, `title`, `description`, `created_at`, `updated_at`) VALUES
(3, '1643090813_why-1.png', 'Process Development', 'Acepteur sintas haecat sed non dui proident sunt culpa sed ipsum tempor.', NULL, NULL),
(4, '1643090840_why-2.png', 'Financial Advice', 'Acepteur sintas haecat sed non dui proident sunt culpa sed ipsum tempor.', NULL, NULL),
(5, '1643090863_why-3.png', 'Planning Strategies', 'Acepteur sintas haecat sed non dui proident sunt culpa sed ipsum tempor.', NULL, NULL),
(6, '1643090878_why-4.png', 'Wealth Marketing', 'Acepteur sintas haecat sed non dui proident sunt culpa sed ipsum tempor.', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutdescription`
--
ALTER TABLE `aboutdescription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `achive_target`
--
ALTER TABLE `achive_target`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner_image`
--
ALTER TABLE `banner_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `benefits`
--
ALTER TABLE `benefits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brochure`
--
ALTER TABLE `brochure`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us_desc`
--
ALTER TABLE `contact_us_desc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `features_description`
--
ALTER TABLE `features_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer_data`
--
ALTER TABLE `footer_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `get_in_touch`
--
ALTER TABLE `get_in_touch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_aboutus`
--
ALTER TABLE `home_aboutus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_aboutus_image`
--
ALTER TABLE `home_aboutus_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquiry`
--
ALTER TABLE `inquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invesment_process`
--
ALTER TABLE `invesment_process`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invesment_process_step`
--
ALTER TABLE `invesment_process_step`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `key_feature`
--
ALTER TABLE `key_feature`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loginpage`
--
ALTER TABLE `loginpage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `more_maintitle`
--
ALTER TABLE `more_maintitle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_letter`
--
ALTER TABLE `news_letter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `performance`
--
ALTER TABLE `performance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_aboutus`
--
ALTER TABLE `service_aboutus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_aboutus_image`
--
ALTER TABLE `service_aboutus_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `skillset`
--
ALTER TABLE `skillset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `whychooseus`
--
ALTER TABLE `whychooseus`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutdescription`
--
ALTER TABLE `aboutdescription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `achive_target`
--
ALTER TABLE `achive_target`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `admininfo`
--
ALTER TABLE `admininfo`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `banner_image`
--
ALTER TABLE `banner_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `benefits`
--
ALTER TABLE `benefits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `brochure`
--
ALTER TABLE `brochure`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contact_us_desc`
--
ALTER TABLE `contact_us_desc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `features_description`
--
ALTER TABLE `features_description`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `footer_data`
--
ALTER TABLE `footer_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `get_in_touch`
--
ALTER TABLE `get_in_touch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `home_aboutus`
--
ALTER TABLE `home_aboutus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `home_aboutus_image`
--
ALTER TABLE `home_aboutus_image`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `inquiry`
--
ALTER TABLE `inquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `invesment_process`
--
ALTER TABLE `invesment_process`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `invesment_process_step`
--
ALTER TABLE `invesment_process_step`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `key_feature`
--
ALTER TABLE `key_feature`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `loginpage`
--
ALTER TABLE `loginpage`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `more_maintitle`
--
ALTER TABLE `more_maintitle`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `news_letter`
--
ALTER TABLE `news_letter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `performance`
--
ALTER TABLE `performance`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `service_aboutus`
--
ALTER TABLE `service_aboutus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `service_aboutus_image`
--
ALTER TABLE `service_aboutus_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `skillset`
--
ALTER TABLE `skillset`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `whychooseus`
--
ALTER TABLE `whychooseus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
