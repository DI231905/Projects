<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;


class AboutUsController extends Controller
{
    public function __construct(){

                $this->middleware('auth:admin');
        }



         public function aboutusBannerlist(){



            $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $allbanner=DB::table('banner_image')->get();
           $data['allbanner']=$allbanner;
         

             return view('admin.aboutusbannerlist',$data);
 
         }

       
       
            public function updatebannerimg($id)
          {
            $allbanner= DB::table('banner_image')->where('id', $id)->get(); 

            $name=$allbanner[0]->name;

              $data['id']=$allbanner[0]->id;
              $data['image']=$allbanner[0]->image;
              $data['name']=$allbanner[0]->name;
              $data['page_name']=$allbanner[0]->page_name;

               return view('admin.updatebannerimage',$data);
            
          }

          public function storeupdatebannerimg(Request $request,$id)
          {

            
             $image=$request->file('image');
             $page_name=$request->input('page');
              $name=$request->input('name');
   
             $imagename='';

            if($image)
            {
              $destinationPath='uploads';
              $imagename=time().'_'.$image->getClientOriginalName();
    
              $image->move($destinationPath,$imagename);

              DB::table('banner_image')->where('id', $id)->update(['image'=>$imagename]);

              if ($request->input('oldimage')!='') 
              {
                  unlink(public_path("/uploads/".$request->input('oldimage')));  
              }

             
              }

             DB::table('banner_image')->where('id', $id)->update(['page_name'=>$page_name]);

              if($name=="About Us"){

                return redirect('admin/aboutusBannerlist')->with('error',' update About Us page banner image succcesfully!!!!');
             }

              elseif($name=="Services"){

                return redirect('admin/servicesBannerlist')->with('error',' update Services page  banner image succcesfully!!!!');
             }
              elseif($name=="Markets"){

                return redirect('admin/marketBannerlist')->with('error',' update  Market page banner image succcesfully!!!!');
             }
            elseif($name=="Blogs"){

                return redirect('admin/blogsBannerlist')->with('error',' update Blogs page banner image succcesfully!!!!');
             }
             
              elseif($name=="Contact Us"){

                return redirect('admin/ContactUsBannerlist')->with('error',' update Contact Us Page banner image succcesfully!!!!');
             }
          }

          public function view_about_descr()
         {
            $id=Auth::id();

            $admin=Admin::where('id',$id)->get();
            $data['name']=$admin[0]->name;

            $about_descr_data=DB::table('aboutdescription')->get();
            $data['about_descr_data']=$about_descr_data;

            return view('admin.aboutdescr',$data);
         }
         public function update_about_descr($id)
         {
           $list=DB::table('aboutdescription')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['title']=$list[0]->title;
           $data['description']=$list[0]->description;
          
           return view('admin.updateaboutdescr',$data);
         }
         public function storeupdate_about_descr(Request $request,$id)
         {

           $error=$request->validate([
             
              'title' => 'required',
              'description' => 'required',
             
              
              ]);
            

            $title=$request->input('title');
            $description=$request->input('description');
            

            DB::table('aboutdescription')->where('id',$id)->update(['title'=>$title,'description'=>$description]);

            return redirect('admin/view_about_descr')->with('error','About description Info Updated Successfully!!!');

         }


           public function view_benefits(){

                $id=Auth::id();
   
                $admin=Admin::where('id',$id)->get();
                $data['name']=$admin[0]->name;
   
                $benefitdata=DB::table('benefits')->get();
                $data['benefitdata']=$benefitdata;
   
               return view('admin.benefits',$data);
             }

         public function add_benefits()
         {
           return view('admin.addbenefits');
         }

         public function store_benefits(Request $request)
         {
           $error=$request->validate([

               'image'=>'required',
               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);
       
           }
           DB::table('benefits')->insert(['title'=>$title,'description'=>$description,'image'=>$imagename]);

           return redirect('admin/view_benefits')->with('error','Benefits data inserted successfully!!!');

         }

         public function delete_benefits($id)
         {
          $list=DB::table('benefits')->where('id',$id)->get();
          $image=$list[0]->image;

          if($image!='')
          {
               unlink(public_path('/uploads/'.$image));
          }

          DB::table('benefits')->where('id',$id)->delete();

          return response()->json(['success'=>'Benefits data deleted successfully!!!']);
         }

         public function update_benefits($id)
         {
           $list=DB::table('benefits')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['title']=$list[0]->title;
           $data['image']=$list[0]->image;
           $data['description']=$list[0]->description;
           
           return view('admin.updatebenefits',$data);
         }

         public function store_update_benefits(Request $request,$id)
         {
           $error=$request->validate([

               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $oldimage=$request->input('oldimage');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);

               DB::table('benefits')->where('id',$id)->update(['image'=>$imagename]);

               if($oldimage!='')
                {
                  unlink(public_path('/uploads/'.$oldimage));
                }
       
           }
           DB::table('benefits')->where('id',$id)->update(['title'=>$title,'description'=>$description]);

           return redirect('admin/view_benefits')->with('error','Benefits data updated successfully!!!');

         }


         public function view_whychooseus()
         {
          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

          $whychdata=DB::table('whychooseus')->get();
          $data['whychdata']=$whychdata;

          return view('admin.whychooseus',$data);
         }

          public function add_whychooseus()
         {
           return view('admin.addwhychooseus');
         }

         public function store_whychooseus(Request $request)
         {
           $error=$request->validate([

               'image'=>'required',
               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);
       
           }
           DB::table('whychooseus')->insert(['title'=>$title,'description'=>$description,'image'=>$imagename]);

           return redirect('admin/view_whychooseus')->with('error','Why choose us data inserted successfully!!!');

         }

         public function delete_whychooseus($id)
         {
          $list=DB::table('whychooseus')->where('id',$id)->get();
          $image=$list[0]->image;

          if($image!='')
          {
               unlink(public_path('/uploads/'.$image));
          }

          DB::table('whychooseus')->where('id',$id)->delete();

          return response()->json(['success'=>'Why choose us data deleted successfully!!!']);
         }

         public function update_whychooseus($id)
         {
           $list=DB::table('whychooseus')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['title']=$list[0]->title;
           $data['image']=$list[0]->image;
           $data['description']=$list[0]->description;
           
           return view('admin.updatewhychooseus',$data);
         }

         public function store_update_whychooseus(Request $request,$id)
         {
           $error=$request->validate([

               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $oldimage=$request->input('oldimage');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);

               DB::table('whychooseus')->where('id',$id)->update(['image'=>$imagename]);

               if($oldimage!='')
                {
                  unlink(public_path('/uploads/'.$oldimage));
                }
       
           }
           DB::table('whychooseus')->where('id',$id)->update(['title'=>$title,'description'=>$description]);

           return redirect('admin/view_whychooseus')->with('error','Why choose us data updated successfully!!!');

         }


          public function view_performance()
         {
          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

          $perfdata=DB::table('performance')->get();
          $data['perfdata']=$perfdata;

          return view('admin.performance',$data);
         }

         public function update_performance($id)
         {
           $list=DB::table('performance')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['title']=$list[0]->title;
           $data['image']=$list[0]->image;
           $data['description']=$list[0]->description;
           
           return view('admin.updateperformance',$data);
         }

         public function store_update_performance(Request $request,$id)
         {
           $error=$request->validate([

               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $oldimage=$request->input('oldimage');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);

               DB::table('performance')->where('id',$id)->update(['image'=>$imagename]);

               if($oldimage!='')
                {
                  unlink(public_path('/uploads/'.$oldimage));
                }
       
           }
           DB::table('performance')->where('id',$id)->update(['title'=>$title,'description'=>$description]);

           return redirect('admin/view_performance')->with('error','Performance data updated successfully!!!');

         }

         public function view_get_in_touch(){

           $news_letter=DB::table('news_letter')->get();
           $data['news_letter']=$news_letter;

            $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

            return view('admin.news_letterdata', $data);


         }

          public function delete_get_in_touch($id){

           DB::table('news_letter')->where('id',$id)->delete();
         
          
          return response()->json(['success'=>'Why choose us data deleted successfully!!!']);

         }

         






}
