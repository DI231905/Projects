<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;
use Carbon\Carbon;

class BlogsController extends Controller
{
   public function __construct(){

                $this->middleware('auth:admin');
        }



         public function blogsBannerlist(){



            $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $allbanner=DB::table('banner_image')->get();
           $data['allbanner']=$allbanner;
         

             return view('admin.blogsbannerlist',$data);
 
         }

         public function viewblog()
         {
          
          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

         $blogdata=DB::table('blog')->get();

          $data['blogdata']=$blogdata;

          return view('admin.blog',$data);
         
         }
         public function addblog()
         {
          return view('admin.addblog');
         }

         public function storeblog(Request $request)
         {
          $error=$request->validate([

               'image'=>'required',
               'title'=>'required',
               'description'=>'required',
               'date'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $date=$request->input('date');
        

           $image=$request->file('image');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);
       
           }
           DB::table('blog')->insert(['title'=>$title,'description'=>$description,'image'=>$imagename,'date'=>$date]);

           return redirect('admin/viewblog')->with('error','Blog data inserted successfully!!!');

         }

         public function deleteblog($id)
         {
          $list=DB::table('blog')->where('id',$id)->get();
          $image=$list[0]->image;

          if($image!='')
          {
               unlink(public_path('/uploads/'.$image));
          }

          DB::table('blog')->where('id',$id)->delete();

          return response()->json(['success'=>'Blog data deleted successfully!!!']);
         }

         public function updateblog($id)
         {
           $list=DB::table('blog')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['title']=$list[0]->title;
           $data['image']=$list[0]->image;
           $data['date']=$list[0]->date;
           $data['description']=$list[0]->description;
           
           return view('admin.updateblog',$data);
         }

         public function storeupdateblog(Request $request,$id)
         {
           $error=$request->validate([

               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $date=$request->input('date');
           $description=$request->input('description');
           $image=$request->file('image');
           $oldimage=$request->input('oldimage');
           $imagename='';

         $date1=date('F j, Y', strtotime($date)); //June, 2017

           if($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);

               DB::table('blog')->where('id',$id)->update(['image'=>$imagename]);

               if($oldimage!='')
                {
                  unlink(public_path('/uploads/'.$oldimage));
                }
       
           }
           DB::table('blog')->where('id',$id)->update(['title'=>$title,'description'=>$description,'date'=>$date]);

           return redirect('admin/viewblog')->with('error','blog data updated successfully!!!');

         }

         


}
