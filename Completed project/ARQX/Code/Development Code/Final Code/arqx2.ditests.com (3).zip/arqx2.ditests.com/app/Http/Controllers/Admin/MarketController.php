<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;

class MarketController extends Controller
{
     public function __construct(){

                $this->middleware('auth:admin');
        }



         public function marketBannerlist(){



            $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $allbanner=DB::table('banner_image')->get();
           $data['allbanner']=$allbanner;
         

             return view('admin.marketbanner',$data);
 
         }

}
