<?php


namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use DB;
use Auth;



class ServiceController extends Controller
{

	   public function __construct(){

                $this->middleware('auth:admin');
        }

   
         public function servicesBannerlist(){



            $id=Auth::id();
           $admin=Admin::where('id',$id)->get();


           $data['name']=$admin[0]->name;

           $allbanner=DB::table('banner_image')->get();
           $data['allbanner']=$allbanner;
         

             return view('admin.servicebanner',$data);
 
         }



         public function view_service()
         {
          $id=Auth::id();

          $admin=Admin::where('id',$id)->get();
          $data['name']=$admin[0]->name;

          $servicedata=DB::table('service')->get();
          $data['servicedata']=$servicedata;

          return view('admin.service',$data);
         }

         public function add_service()
         {
           return view('admin.addservice');
         }

         public function store_service(Request $request)
         {
           $error=$request->validate([

               'image'=>'required',
               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);
       
           }
           DB::table('service')->insert(['title'=>$title,'description'=>$description,'image'=>$imagename]);

           return redirect('admin/view_service')->with('error','Service data inserted successfully!!!');

         }

         public function delete_service($id)
         {
          $list=DB::table('service')->where('id',$id)->get();
          $image=$list[0]->image;

          if($image!='')
          {
               unlink(public_path('/uploads/'.$image));
          }

          DB::table('service')->where('id',$id)->delete();

          return response()->json(['success'=>'Service data deleted successfully!!!']);
         }

         public function update_service($id)
         {
           $list=DB::table('service')->where('id',$id)->get();
           $data['id']=$list[0]->id;
           $data['title']=$list[0]->title;
           $data['image']=$list[0]->image;
           $data['description']=$list[0]->description;
           
           return view('admin.updateservice',$data);
         }

         public function store_update_service(Request $request,$id)
         {
           $error=$request->validate([

               'title'=>'required',
               'description'=>'required'

           ]);

           $title=$request->input('title');
           $description=$request->input('description');
           $image=$request->file('image');
           $oldimage=$request->input('oldimage');
           $imagename='';

           if ($image)
           {
          
               $destinationPath='uploads';
               $imagename=time().'_'.$image->getClientOriginalName();
               $image->move($destinationPath,$imagename);

               DB::table('service')->where('id',$id)->update(['image'=>$imagename]);

               if($oldimage!='')
                {
                  unlink(public_path('/uploads/'.$oldimage));
                }
       
           }
           DB::table('service')->where('id',$id)->update(['title'=>$title,'description'=>$description]);

           return redirect('admin/view_service')->with('error','Service data updated successfully!!!');

         }



            public function service_about_us(){


        	 $id=Auth::id();
             $admin=Admin::where('id',$id)->get();


            $data['name']=$admin[0]->name;

             $service_aboutus=DB::table('service_aboutus')->get();
             $data['service_aboutus']=$service_aboutus;

             $service_aboutus_image=DB::table('service_aboutus_image')->get();
             $data['service_aboutus_image']=$service_aboutus_image;
         
    	   return view('admin.service_about_us',$data);
       }

        public function update_service_about_us($id){

             $service_aboutus=DB::table('service_aboutus')->get();
             $data['id']=$service_aboutus[0]->id;
             $data['name']=$service_aboutus[0]->name;
             $data['title']=$service_aboutus[0]->title;
             $data['description']=$service_aboutus[0]->description;

             $service_aboutus_image=DB::table('service_aboutus_image')->get();
             $data['service_aboutus_image']=$service_aboutus_image;
         
    	   return view('admin.update_service_aboutus',$data);
       }

       public function update_service_about_us_image($id){

          $service_aboutus_image=DB::table('service_aboutus_image')->where('id',$id)->get();
          $data['image']=$service_aboutus_image[0]->image;

          $data['id']=$id;

          return view('admin.update_service_aboutus_img',$data);

       }

         public function store_service_about_image(Request $request,$id){

          $service_aboutus_image=DB::table('service_aboutus_image')->where('id',$id)->get();
          $service_about_id=$service_aboutus_image[0]->service_about_id;

          


           $file=$request->file('image');


         
            $imagename='';

            if($file){
         
               $destinationPath='uploads';
               $imagename=time().'_'.$file->getClientOriginalName();
                
                echo $imagename;

          

               $file->move($destinationPath,$imagename);

               DB::table('service_aboutus_image')->where('id', $id)->update(['image'=>$imagename]);

              if($request->input('oldimage')!='') {

                    unlink(public_path("/uploads/".$request->input('oldimage')));  
                 }
              }


              return redirect('admin/update_service_about_us/'.$service_about_id);
         


       }

       public function store_service_aboutus(Request $request, $id){


       	  $error=$request->validate([

              'title' => 'required',
               'name' => 'required',
              'description' => 'required',
               
            ]);

       	   $title=$request->input('title');
       	   $name=$request->input('name');
       
         $description=$request->input('description');
        

         DB::table('service_aboutus')->where('id',$id)->update(['title'=>$title,'name'=>$name,'description'=>$description]);
       
          return redirect('admin/service_about_us')->with('error',' Service about us data has been updated sucessfully !!' );
          

       }
}
