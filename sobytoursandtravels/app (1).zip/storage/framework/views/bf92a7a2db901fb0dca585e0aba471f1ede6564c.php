<!DOCTYPE html>
<html>
<head>
    <title>TRAVEL AGENCY</title>
    <link rel="stylesheet" type="text/css" href="css/Travel_visa.css">
    <link rel="stylesheet" type="text/css" href="css/Travel_header-footer.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css">
    <meta name="description" content="Fixed Sidebar on Scroll By Balveer">
    <meta name="author" content="Fixed On Scroll By Balveer">
    <link rel="icon" type="image/png" href="image/logo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div id="header">
        <div id="fixedHeader">
           <div class="co_part-1">
        <div class="container fix-part-1">
            <div class="part-1">
                <a href="<?php echo e(url('/')); ?>"><img src="image/logo-2.png"></a>
            </div>
            <div class="menu1">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                <div class="dropdown hover">
                    <div class="menu">
                        <div class="package1">Packages</div>
                    </div>      
                    <ul class="submenu">
                        <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                        <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                    </ul>
                </div>
                <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
               <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
            </div>
            <div class="mobile-menu">
                <div id="mySidepanel" class="sidepanel">
                    <div class="m_menu">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-times" aria-hidden="true"></i></a>     
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                        <div class="dropdown hover">
                            <div class="menu">
                                <a href="">Packages</a>
                            </div>      
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                                <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                            </ul>
                        </div>
                        <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                        <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                        <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                        <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                        <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
                    </div>
                </div>
               <button class="openbtn" onclick="openNav()"><i class="fa fa-bars" aria-hidden="true"></i></button>
            </div>
        </div>
    </div>  
        </div>
      <div class="co_part-2">
        <div class="fix-part-2">
            <div class="img1">
                <img src="image/visa banner.png">
            </div>
            <div class="about">
                <div class="container">
                    <h2>Visa</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Visa</li>
                    </ul>
                    
                </div>
            </div>
        </div>
    </div>
    </div>
    <div class="main_visa">
        <div class="container">
            <div id="sidebarWrap">
                <div class="co_form" id="sidebar">
                    <div class="visa-form">
                    

                       <?php if($message = Session::get('error')): ?>
           <div  id="hideDiv" class="alert alert-success alert-block" >
            <!--     <input type="text" class="close" data-dismiss="alert"></input> -->
           <strong style=" padding-top : 5px !important; display: inline-block;"><?php echo e($message); ?></strong>
           </div>
           <?php endif; ?>


                        <h2>GET QUICK QUOTE</h2>
                         <form method="POST" action="<?php echo e(url('/Visainquirefrom')); ?>">
                              <?php echo csrf_field(); ?>
                            <div class="visa-text">
                                <input type="text" placeholder="Name" name="name" value="" required>
                            </div>
                            <div class="visa-text">
                                <input type="text" placeholder="Number" name="number" value="" required> 
                            </div>
                            <div class="visa-text">
                                <input type="email" placeholder="Email" name="email" value="" required> 
                            </div>
                            <div class="visa-text">
                               <select name="visatype" value="" required>
                                    <option  name="visatype" value="">Select Visa</option>
                                    <option name="Student visa" value="Student visa">Student visa</option>
                                    <option name="Tourist Visa" value="Tourist Visa">Tourist Visa</option>
                                    <option name="Employment visa" value="Employment visa">Employment visa</option>
                                </select>
                            </div>
                            <div class="visa-text">
                                <textarea placeholder="Messages" name="description" value="" required></textarea>
                            </div>
                            <div class="sub">
                                <input type="submit" value="submit">
                            </div> 
                        </form>
                    </div>
                </div>
            </div>
            <div id="main">
                <div class="co_visa">
                    <div class="gallery">
                        <ul class="controls">
                            <li class="buttons active" data-filter="all">All</li>
                            <li class="buttons" data-filter="Tourist">Tourist Visa</li>
                            <li class="buttons" data-filter="Student">Student visa</li>
                            <li class="buttons" data-filter="E-visa">E-visa</li>
                        </ul>
                        <div class="image-container">
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/visa-1.png"></div>
                                <div class="visa-name">
                                    <img src="image/visa-11.png">
                                    <h2>ANTIGUA AND BARBUDA</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/visa-2.png"></div>
                                <div class="visa-name">
                                    <img src="image/visa-12.jpg">
                                    <h2>Argentina</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/visa-3.png"></div>
                                <div class="visa-name">
                                    <img src="image/visa-13.jpg">
                                    <h2>Armenia</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Student Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/australia.png"></div>
                                <div class="visa-name">
                                    <img src="image/Australiaflag.jpg">
                                    <h2>Australia</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/azerbaijan.png"></div>
                                <div class="visa-name">
                                    <img src="image/azerbaijanflag.jpg">
                                    <h2>azerbaijan</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Bahrain.png"></div>
                                <div class="visa-name">
                                    <img src="image/Bahrainflag.jpg">
                                    <h2>Bahrain</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Cambodia.png"></div>
                                <div class="visa-name">
                                    <img src="image/Cambodiaflag.jpg">
                                    <h2>Cambodia</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Djibouti.png"></div>
                                <div class="visa-name">
                                    <img src="image/Djiboutiflag.png">
                                    <h2>Djibouti</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Ethiopia.png"></div>
                                <div class="visa-name">
                                    <img src="image/Ethiopiaflag.jpg">
                                    <h2>Ethiopia</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Gabon.png"></div>
                                <div class="visa-name">
                                    <img src="image/Gabonflag.png">
                                    <h2>Gabon</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Georgia.png"></div>
                                <div class="visa-name">
                                    <img src="image/Georgiaflag.jpg">
                                    <h2>Georgia</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/HONGKONG.png"></div>
                                <div class="visa-name">
                                    <img src="image/HONGKONGflag.jpg">
                                    <h2>HONGKONG</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/IvoryCoast.png"></div>
                                <div class="visa-name">
                                    <img src="image/IvoryCoastflag.png">
                                    <h2>IvoryCoast</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Kenya.png"></div>
                                <div class="visa-name">
                                    <img src="image/Kenyaflag.jpg">
                                    <h2>Kenya</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Kuwait.png"></div>
                                <div class="visa-name">
                                    <img src="image/Kuwaitflag.jpg">
                                    <h2>Kuwait</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Kyrgyzstan.png"></div>
                                <div class="visa-name">
                                    <img src="image/Kyrgyzstanflag.png">
                                    <h2>Kyrgyzstan</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Malaysia.png"></div>
                                <div class="visa-name">
                                    <img src="image/Malaysiaflag.jpg">
                                    <h2>Malaysia</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                 <div class="visa-img"><img src="image/Myanmar.png"></div>
                                <div class="visa-name">
                                    <img src="image/Myanmarflag.jpg">
                                    <h2>Myanmar</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Student Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/NewZealand.png"></div>
                                <div class="visa-name">
                                    <img src="image/NewZealandflag.jpg">
                                    <h2>NewZealand</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Oman.png"></div>
                                <div class="visa-name">
                                    <img src="image/Omanflag.jpg">
                                    <h2>Oman</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Qatar.png"></div>
                                <div class="visa-name">
                                    <img src="image/Qatarflag.jpg">
                                    <h2>Qatar</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Rwanda.png"></div>
                                <div class="visa-name">
                                    <img src="image/Rwandaflag.png">
                                    <h2>Rwanda</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/SaoTomeAndPrincipe.png"></div>
                                <div class="visa-name">
                                    <img src="image/SaoTomeAndPrincipeflag.png">
                                    <h2>SaoTomeAndPrincipe</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/SriLanka.png"></div>
                                <div class="visa-name">
                                    <img src="image/SriLankaflag.jpg">
                                    <h2>SriLanka</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/STKITTSANDNEVIS.png"></div>
                                <div class="visa-name">
                                    <img src="image/STKITTSANDNEVISflag.png">
                                    <h2>STKITTSANDNEVIS</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Taiwan.png"></div>
                                <div class="visa-name">
                                    <img src="image/Taiwanflag.jpg">
                                    <h2>Taiwan</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Tajikistan.png"></div>
                                <div class="visa-name">
                                    <img src="image/Tajikistanflag.jpeg">
                                    <h2>Tajikistan</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Tanzania.png"></div>
                                <div class="visa-name">
                                    <img src="image/Tanzaniaflag.jpg">
                                    <h2>Tanzania</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Thailand.png"></div>
                                <div class="visa-name">
                                    <img src="image/Thailandflag.jpg">
                                    <h2>Thailand</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Turkey.png"></div>
                                <div class="visa-name">
                                    <img src="image/Turkeyflag.jpg">
                                    <h2>Turkey</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/UAE.png"></div>
                                <div class="visa-name">
                                    <img src="image/UAEflag.jpg">
                                    <h2>UAE</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Uganda.png"></div>
                                <div class="visa-name">
                                    <img src="image/Ugandaflag.jpg">
                                    <h2>Uganda</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Uzbekistan.png"></div>
                                <div class="visa-name">
                                    <img src="image/Uzbekistanflag.jpg">
                                    <h2>Uzbekistan</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Vietnam.png"></div>
                                <div class="visa-name">
                                    <img src="image/Vietnamflag.jpg">
                                    <h2>Vietnam</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Zambia.png"></div>
                                <div class="visa-name">
                                    <img src="image/Zambiaflag.jpg">
                                    <h2>Zambia</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image E-visa">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Zimbabwe.png"></div>
                                <div class="visa-name">
                                    <img src="image/Zimbabweflag.jpg">
                                    <h2>Zimbabwe</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/UnitedKingdom.png"></div>
                                <div class="visa-name">
                                    <img src="image/UnitedKingdomflag.jpg">
                                    <h2>United Kingdom</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Canada.png"></div>
                                <div class="visa-name">
                                    <img src="image/Canadaflag.jpg">
                                    <h2>Canada</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/UnitedStates.png"></div>
                                <div class="visa-name">
                                    <img src="image/UnitedStatesflag.jpg">
                                    <h2>UnitedStates</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Belgium.png"></div>
                                <div class="visa-name">
                                    <img src="image/Belgiumflag.jpg">
                                    <h2>Belgium</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Denmark.png"></div>
                                <div class="visa-name">
                                    <img src="image/Denmarkflag.jpg">
                                    <h2>Denmark</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Finland.png"></div>
                                <div class="visa-name">
                                    <img src="image/Finlandflag.jpg">
                                    <h2>Finland</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/France.png"></div>
                                <div class="visa-name">
                                    <img src="image/Franceflag.jpg">
                                    <h2>France</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Germany.png"></div>
                                <div class="visa-name">
                                    <img src="image/Germanyflag.jpg">
                                    <h2>Germany</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Greece.png"></div>
                                <div class="visa-name">
                                    <img src="image/Greeceflag.jpg">
                                    <h2>Greece</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Iceland.png"></div>
                                <div class="visa-name">
                                    <img src="image/Icelandflag.png">
                                    <h2>Iceland</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Italy.png"></div>
                                <div class="visa-name">
                                    <img src="image/Italyflag.jpg">
                                    <h2>Italy</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Latvia.png"></div>
                                <div class="visa-name">
                                    <img src="image/Latviaflag.jpg">
                                    <h2>Latvia</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Netherlands.png"></div>
                                <div class="visa-name">
                                    <img src="image/Netherlandsflag.jpg">
                                    <h2>Netherlands</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Norway.png"></div>
                                <div class="visa-name">
                                    <img src="image/Norwayflag.jpg">
                                    <h2>Norway</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Switzerland.png"></div>
                                <div class="visa-name">
                                    <img src="image/Switzerlandflag.jpg">
                                    <h2>Switzerland</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Bangladesh.png"></div>
                                <div class="visa-name">
                                    <img src="image/Bangladeshflag.jpg">
                                    <h2>Bangladesh</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Chile.png"></div>
                                <div class="visa-name">
                                    <img src="image/Chileflag.jpg">
                                    <h2>Chile</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Colombia.png"></div>
                                <div class="visa-name">
                                    <img src="image/Colombiaflag.jpg">
                                    <h2>Colombia</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Ireland.png"></div>
                                <div class="visa-name">
                                    <img src="image/Irelandflag.jpg">
                                    <h2>Ireland</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Morocco.png"></div>
                                <div class="visa-name">
                                    <img src="image/Moroccoflag.jpg">
                                    <h2>Morocco</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Singapore.png"></div>
                                <div class="visa-name">
                                    <img src="image/Singaporeflag.jpg">
                                    <h2>Singapore</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/SouthAfrica.png"></div>
                                <div class="visa-name">
                                    <img src="image/SouthAfricaflag.jpg">
                                    <h2>SouthAfrica</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Tourist">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Thailand.png"></div>
                                <div class="visa-name">
                                    <img src="image/Thailandflag.jpg">
                                    <h2>Thailand</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/China.png"></div>
                                <div class="visa-name">
                                    <img src="image/Chinaflag.jpg">
                                    <h2>China</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Japan.png"></div>
                                <div class="visa-name">
                                    <img src="image/Japanflag.jpg">
                                    <h2>Japan</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Spain.png"></div>
                                <div class="visa-name">
                                    <img src="image/Spainflag.jpg">
                                    <h2>Spain</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Poland.png"></div>
                                <div class="visa-name">
                                    <img src="image/Polandflag.jpg">
                                    <h2>Poland</h2>
                                </div>
                            </div>
                        </span>
                        <span class="image Student">
                            <div class="product-list set-product e-visa">
                                <div class="visa-img"><img src="image/Sweden.png"></div>
                                <div class="visa-name">
                                    <img src="image/Swedenflag.png">
                                    <h2>Sweden</h2>
                                </div>
                            </div>
                        </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<div id="footer">
  <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">
                    <div class="main-footer">
                        <h2 class="title1"><a href="<?php echo e(url('/')); ?>"><img src="image/logo-2.png"></a></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur repudiandae quisquam adipisci asperiores, ipsum ipsa repellat assumenda dolor perspiciatis.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-12">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Company</h2>
                            <div class="footer-widget">
                                <ul>
                                     <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/aboutview')); ?>">About</a></li>
                                
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">All Package</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Contact')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Service</h2>
                            <div class="footer-widget">
                                <ul>
                                  <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">Various Tour</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Visa')); ?>">Visa</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Passportinquire')); ?>">Passport Inquires</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                        <li><i class="fa fa-home" aria-hidden="true"></i>
                             <p> <?php echo e($address); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                             <p><a href="tel:<?php echo nl2br(e($mobileno)); ?>"><?php echo nl2br(e($mobileno)); ?></a></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Sobytour&travels Theme © Copyright 2021. All rights reserved</span>
            </div>
             <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="https://www.facebook.com/Soby-tour-and-travels-546125568809837/"><i class="fa fa-facebook-square"></i></a></li>
                    <li><a href="https://www.instagram.com/sobytourandtravels/"><i class="fa fa-instagram"></i></a></li>
            
                </ul>
            </div>
        </div>
        </div>
    </div>
     <a class="up-btn" href="#"></a>
</div>

    <script src="https://code.jquery.com/jquery-2.2.0.min.js"></script>
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }
          $(function() {
        setTimeout(function(){$("#hideDiv").fadeOut(1500); }, 3000);

});
 

        $(function() {
            var top = $('#sidebar').offset().top - parseFloat($('#sidebar').css('marginTop').replace(/auto/, 0));
            var footTop = $('#footer').offset().top - parseFloat($('#footer').css('marginTop').replace(/auto/, 0));

            var maxY = footTop - $('#sidebar').outerHeight();

            $(window).scroll(function(evt) {
                var y = $(this).scrollTop();
                if (y >= top - $('#fixedHeader').height()) {
                    if (y < maxY) {
                        $('#sidebar').addClass('fixed').removeAttr('style');
                    } else {
                        $('#sidebar').removeClass('fixed').css({
                            position: 'absolute',
                            top: (maxY - top) + 'px'
                        });
                    }
                } else {
                    $('#sidebar').removeClass('fixed');
                }
            });
        });

        $(document).ready(function(){
            $('.buttons').click(function(){
                $(this).addClass('active').siblings().removeClass('active');
                var filter = $(this).attr('data-filter')
                if(filter == 'all'){
                    $('.image').show(400);
                }else{
                    $('.image').not('.'+filter).hide(200);
                    $('.image').filter('.'+filter).show(400);
                }
            });
        });
    </script>
</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/resources/views/visa.blade.php ENDPATH**/ ?>