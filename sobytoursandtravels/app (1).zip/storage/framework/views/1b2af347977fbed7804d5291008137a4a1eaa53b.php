<!DOCTYPE html>
<html>
<head>
    <title>TRAVEL AGENCY</title>
    <link rel="stylesheet" type="text/css" href="css/Travel_brochure.css">
    <link rel="stylesheet" type="text/css" href="css/Travel_header-footer.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
    <link rel="icon" type="image/png" href="image/logo.png">
     <meta name="viewport" content="width=device-width, initial-scale=1">
    
</head>
<body class="body">
    <div class="co_part-1">
        <div class="container fix-part-1">
            <div class="part-1">
                <a href="<?php echo e(url('/')); ?>"><img src="image/logo-2.png"></a>
            </div>
            <div class="menu1">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                <div class="dropdown hover">
                    <div class="menu">
                        <div class="package1">Packages</div>
                    </div>      
                    <ul class="submenu">
                        <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                        <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                    </ul>
                </div>
                <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
            </div>
            <div class="mobile-menu">
                <div id="mySidepanel" class="sidepanel">
                    <div class="m_menu">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-times" aria-hidden="true"></i></a>      
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                        <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                        <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                        <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                        <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                        <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                        <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
                    </div>
                </div>
               <button class="openbtn" onclick="openNav()"><i class="fa fa-bars" aria-hidden="true"></i></button>
            </div>
        </div>
    </div>
     <!-- <div class="co_part-2">
         <div class="fix-part-2">
            <div class="img1">
                <img src="image/breadcrum8.jpeg">
            </div>
            <div class="about">
                <h2>brochure</h2>
                <ul type="none">
                    <li>Home</li>
                    <li><span class="fa fa-angle-right"></span></li>
                    <li class="bt">Brochure</li>
                </ul>
            </div>
        </div>
    </div> -->
    <div class="co_part-2">
        <div class="fix-part-2">
            <div class="img1">
                <img src="image/breadcrum8.jpeg">
            </div>
            <div class="about">
                <div class="container">
                    <h2>brochure</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Brochure</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
   
    <div class="co_brochure">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $brochures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span href="/uploads/<?php echo e($b->image); ?>" data-toggle="lightbox" data-gallery="gallery" class="col-lg-4 col-md-6 col-12">
                    <div class="single">
                        <img src="/uploads/<?php echo e($b->image); ?>">
                    </div>
                </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>     
        </div>
    </div>
     <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">
                    <div class="main-footer">
                        <h2 class="title1"><a href="index.html"><img src="image/logo-2.png"></a></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur repudiandae quisquam adipisci asperiores, ipsum ipsa repellat assumenda dolor perspiciatis.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-12">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Company</h2>
                            <div class="footer-widget">
                                 <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/aboutview')); ?>">About</a></li>
                                
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">All Package</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Contact')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Service</h2>
                            <div class="footer-widget">
                                <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">Various Tour</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Visa')); ?>">Visa</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Passportinquire')); ?>">Passport Inquires</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                       <li><i class="fa fa-home" aria-hidden="true"></i>
                             <p> <?php echo e($address); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                             <p><a href="tel:<?php echo nl2br(e($mobileno)); ?>"><?php echo nl2br(e($mobileno)); ?></a></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                 <span>Sobytour&travels Theme © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="https://www.facebook.com/Soby-tour-and-travels-546125568809837/"><i class="fa fa-facebook-square"></i></a></li>
                    <li><a href="https://www.instagram.com/sobytourandtravels/"><i class="fa fa-instagram"></i></a></li>
            
                </ul>
            </div>
        </div>
        </div>
    </div>
    <a class="up-btn" href="#"></a>


    
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script>
    <script type="text/javascript">
         function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  }
            else {
                btn.removeClass('show1');
            } 
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        }); 

        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });


   
    </script>
</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/resources/views/brochures.blade.php ENDPATH**/ ?>