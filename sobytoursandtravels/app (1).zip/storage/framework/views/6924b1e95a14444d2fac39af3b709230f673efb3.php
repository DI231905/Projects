<!DOCTYPE html>
<html>
<head>
    <title>TRAVEL AGENCY</title>
    <link rel="stylesheet" type="text/css" href="/css/Travel_home.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="image/flaticon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body class="body">
    <div class="co_part-1">
        <div class="container fix-part-1">
            <div class="part-1">
                <a href="<?php echo e(url('/')); ?>"><img src="image/logo-2.png"></a>
            </div>
            <div class="menu1">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                <div class="dropdown hover">
                    <div class="menu">
                        <div class="package1">Packages</div>
                    </div>      
                    <ul class="submenu">
                        <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                        <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                    </ul>
                </div>
                <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                  <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
            </div>
            <div class="mobile-menu">
                <div id="mySidepanel" class="sidepanel">
                    <div class="m_menu">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-times" aria-hidden="true"></i></a>    
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                        <div class="dropdown hover">
                            <div class="menu">
                                <a href="">Packages</a>
                            </div>      
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                                <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                            </ul>
                        </div>
                        <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                        <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                        <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                        <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                        <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
                    </div>
                </div>
                <button class="openbtn" onclick="openNav()"><i class="fa fa-bars" aria-hidden="true"></i></button> 
            </div>
        </div>
    </div>
    <div class="co_part-2">
        <div class="fix-part-2">
            <!-- <div class="bg-video-wrap">
                <video src="https://designsupply-web.com/samplecontent/vender/codepen/20181014.mp4" loop muted autoplay></video>
                <div class="overlay"></div>
                <div class="part-2">
                    <h1>Travel</h1>
                </div>
            </div> -->
            <div id="demo" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                      <img src="image/banner2.jpg" alt="banner2.jpg">
                        <div class="part-2">
                            <h1>Travel</h1>
                        </div>
                    </div>
                    <div class="carousel-item">
                      <img src="image/banner1.jpg" alt="banner1.jpg">
                      <div class="part-2">
                            <h1>Travel</h1>
                        </div>
                    </div>
                    <div class="carousel-item">
                      <img src="image/banner3.jpg" alt="banner3.jpg">
                      <div class="part-2">
                            <h1>Travel</h1>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#demo" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>
    </div>
    <div class="co_part-3">
        <div class="fix-part-3">
            <div class="form">
                <div class="select">
                    
                    <h5>Keywords</h5>
                    <label class="fa fa-map-marker"></label>
                    <form method="GET" action="<?php echo e(url('/travel-search')); ?>" id="databaseActionForm" name="databaseActionForm" >
                    <input type="text" placeholder="Enter a destination place" id="search_keywords" name="search_keywords" value="" required>
                     <div class="select-1">
                     <button class="btn1" type="submit" onclick="serarch_value()">Find Now</button>
                    </div>
                    
                    </form> 
                </div>
            </div>
        </div>

         <?php if($message = Session::get('error')): ?>
           <div id="hideDiv" style="background-color:#003a6c !important; border-color:#003a6c !important;"class="alert alert-danger alert-block " > 
<!--     <input type="text" class="close" data-dismiss="alert"></input> -->
           <strong class="error" style=" padding-top : 5px !important; display: inline-block; color: black;background-color:#003a6c !important; border-color:#003a6c !important; "><?php echo e($message); ?></strong>
           </div>
           <?php endif; ?>



   
   
    </div>
    <div class="co_part-7">
        <div class="fix-part-7">
            <h2>Why Travel with Soby Tour & Travels?</h2>
            <div class="part-7">
                <div class="inner_part-7">
                    <div class="set-part-7">
                        <img src="image/why-us-save-money.png">
                        <h3>Save Money</h3>
                        <p>Dummy text ever since the 1500s, when an unknown printer took. A galley of type and scrambled it to make a type</p>
                    </div>
                </div>
                <div class="inner_part-7">
                    <div class="set-part-7">
                        <img src="image/get-help.png">
                        <h3>Get Help</h3>
                        <p>Dummy text ever since the 1500s, when an unknown printer took. A galley of type and scrambled it to make a type</p>
                    </div>
                </div>
                <div class="inner_part-7">
                    <div class="set-part-7">
                        <img src="image/stay-safe.png">
                        <h3>Stay Safe</h3>
                        <p>Dummy text ever since the 1500s, when an unknown printer took. A galley of type and scrambled it to make a type</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_part-6">
        <div class="container">
            <h2 class="main-title">Our Best Services</h2>
            <p class="title-inner">Why we are the best for our client</p>
            <div class="row">
                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-img">
                        <img src="image/service-1.jpg">
                        <div class="service-title">
                            <h4>Various Tour</h4>
                        </div>
                    </div>              
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-img">
                        <img src="image/service-2.jpg">
                        <div class="service-title">
                            <h4>Visa Service</h4>
                        </div>
                    </div>              
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-img">
                        <img src="image/service-3.jpg">
                        <div class="service-title">
                            <h4>Passport Service</h4>
                        </div>
                    </div>              
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-img">
                        <img src="image/hotel-img.jpg">
                        <div class="service-title">
                            <h4>Hotel Ticket Booking</h4>
                        </div>
                    </div>              
                </div>
            </div>  
        </div>
    </div>  
    <div class="co_part-5">
        <div class="fix-part-5">
            <h2 class="main-title">Featured Tours</h2>
            <p class="title-inner">check out our best promotion tours!</p>
            <div class="part-5">
   
              <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="inner_part-5">
                    <div class="set_part-5">
                     
                          
                        <div class="image">
                            <img src="/uploads/<?php echo e($p->image); ?>">
                              <span class="price">
                                    <span>RS <?php echo e($p->price); ?></span>
                              </span>
                        </div>
                       
                        <div class="prg">
                            <h3><?php echo e($p->tittle); ?></h3>
                            <span><a href="#"><?php echo e($p->city); ?>, <?php echo e($p->tour_type); ?> </a></span>
                            <div class="main_rev">
                                <div class="rev">
                                    <span><a href="<?php echo e(url('/tourlist')); ?>">Read More</a></span>
                                </div>
                                <div class="day">
                                    <span class="fa fa-clock-o"></span>
                                    <strong><?php echo e($p->days); ?> </strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
      
          </div>
           <div class="custom_pagination text-center">
            <?php echo e($package->links('pagination::bootstrap-4')); ?>

        </div>
<style type="text/css">
    .custom_pagination ul.pagination {
        justify-content: center;
    }
    
</style>


        </div>
    </div>
    <div class="co_part-8">
        <div class="fix-part-8">
            <div class="part-8">
                <div class="inner_part-8">
                    <div class="why">
                        <h2>WHY US?</h2>
                        <p>We make all the process easy</p>
                    </div>
                    <div class="block">
                        <div class="block-1">
                            <img src="image/globe.png">
                        </div>
                        <div class="block-2">
                            <h3>All Around the World Tours</h3>
                            <p>Dummy text ever since the 1500s, when an unknown printer took. A galley of type and scrambled it to make a type</p>
                        </div>
                    </div>
                    <div class="block">
                        <div class="block-1">
                            <img src="image/trolly.png">
                        </div>
                        <div class="block-2">
                            <h3>Private & Customized Tours</h3>
                            <p>Dummy text ever since the 1500s, when an unknown printer took. A galley of type and scrambled it to make a type</p>
                        </div>
                    </div>
                    <div class="block">
                        <div class="block-1">
                            <img src="image/book.png">
                        </div>
                        <div class="block-2">
                            <h3>Immigration & Passport Help</h3>
                            <p>Dummy text ever since the 1500s, when an unknown printer took. A galley of type and scrambled it to make a type</p>
                        </div>
                    </div>
                </div>
                <div class="inner_part-8">
                    <div class="why-us">
                        <img src="image/why-us-img-new.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="co_package">
        <div class="fix-package">
            <div class="package">
                <h1>HOLIDAY BIG SALE</h1>
                <h4>Book now and get offers on packages</h4>
            </div>
            <div class="btn_">
                <div class="set-btn">
                    <span><a href="<?php echo e(url('/Brochure')); ?>">Discover More</a></span>
                    <span class="fa fa-caret-right"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">
                    <div class="main-footer">
                        <h2 class="title1"><a href="index.html"><img src="image/logo-2.png"></a></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur repudiandae quisquam adipisci asperiores, ipsum ipsa repellat assumenda dolor perspiciatis.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-12">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Company</h2>
                            <div class="footer-widget">
                                <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/aboutview')); ?>">About</a></li>
                                
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">All Package</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Contact')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Service</h2>
                            <div class="footer-widget">
                                <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">Various Tour</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Visa')); ?>">Visa</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Passportinquire')); ?>">Passport Inquires</a></li>
                                   
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                        <li><i class="fa fa-home" aria-hidden="true"></i>
                             <p> <?php echo e($address); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                             <p><a href="tel:<?php echo nl2br(e($mobileno)); ?>"><?php echo nl2br(e($mobileno)); ?></a></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                 <span>Sobytour&travels Theme © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="https://www.facebook.com/Soby-tour-and-travels-546125568809837/"><i class="fa fa-facebook-square"></i></a></li>
                    <li><a href="https://www.instagram.com/sobytourandtravels/"><i class="fa fa-instagram"></i></a></li>
            
                </ul>
            </div>
        </div>
        </div>
    </div>
    <a class="up-btn" href="#"></a>

   <style type="text/css">
       .package1{
        font-size: 18px!important;
        color: white;
       }
   </style>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

            $(function() {
setTimeout(function() { $("#hideDiv").fadeOut(1500); }, 3000)

});


        function serarch_value(){
         var search_keywords = $('#search_keywords').val();

      if(search_keywords == "")
         {
            // alert('Search is empty');
         }else{
         
         }
              var search_keywords = $('#search_keywords').val();
         
         if(search_keywords == "")
         {
           //  alert('Search is empty');
         }else{
                 $('#databaseActionForm').submit();
         }
           
    


}


        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show1');  
            }
            else {
                btn.removeClass('show1');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
        $('html, body').animate({scrollTop:0}, '300');
    }); 


    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\oratravel\resources\views/welcome.blade.php ENDPATH**/ ?>