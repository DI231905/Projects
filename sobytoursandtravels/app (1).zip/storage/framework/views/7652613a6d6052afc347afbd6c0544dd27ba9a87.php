<!DOCTYPE html>
<html>
<head>
	<title>TRAVEL AGENCY</title>
	<link rel="stylesheet" type="text/css" href="/css/Travel_tour.css">
	<link rel="stylesheet" type="text/css" href="css/Travel_header-footer.css">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="icon" type="image/png" href="image/flaticon.png">
	 <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="body">
	<div class="co_part-1">
        <div class="container fix-part-1">
            <div class="part-1">
                <a href="<?php echo e(url('/')); ?>"><img src="image/logo-2.png"></a>
            </div>
            <div class="menu1">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                <div class="dropdown hover">
                    <div class="menu">
                        <div class="package1">Packages</div>
                    </div>      
                    <ul class="submenu">
                        <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                        <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                    </ul>
                </div>
                <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
            </div>
            <div class="mobile-menu">
                <div id="mySidepanel" class="sidepanel">
                    <div class="m_menu">
                         <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-times" aria-hidden="true"></i></a>    
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                        <div class="dropdown hover">
                            <div class="menu">
                                <a href="">Packages</a>
                            </div>      
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                                <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                            </ul>
                        </div>
                        <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                        <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                        <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                        <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                        <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
                    </div>
                </div>
               <button class="openbtn" onclick="openNav()"><i class="fa fa-bars" aria-hidden="true"></i></button>
            </div>
        </div>
    </div>
    <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/5.jpg">
    	    </div>
    	    <div class="about">
    		    <div class="container">
                    <h2>Tours</h2>
                    <ul type="none">
                        <li>Home</li>
                        <li><span class="fa fa-angle-right"></span></li>
                        <li class="bt">Tour List</li>
                    </ul>
                </div>
    	    </div>
    	</div>
    </div>
    <div class="co_part-3">
    	<div class="fix-part-3">
    		<div class="coc">
			    <div class="coc-2">
			    	 <div class="part-5">
   
              <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="inner_part-5">
                    <div class="set_part-5">
                     
                          
                        <div class="image">
                            <img src="/uploads/<?php echo e($p->image); ?>">
                              <span class="price">
                                    <span>RS <?php echo e($p->price); ?></span>
                              </span>
                        </div>
                       
                        <div class="prg">
                            <h3><?php echo e($p->tittle); ?></h3>
                            <span><?php echo e($p->city); ?>, <?php echo e($p->tour_type); ?> </span>
                            <div class="main_rev">
                                <div class="rev">
                                    <span><a href="<?php echo e(url('/tourlist')); ?>"></a></span>
                                </div>
                                <div class="day">
                                    <span class="fa fa-clock-o"></span>
                                    <strong><?php echo e($p->days); ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
      
          </div>
			  
	   <div class="custom_pagination text-center">
            <?php echo e($package->links('pagination::bootstrap-4')); ?>

        </div>
      <style type="text/css">
       .custom_pagination ul.pagination {
        justify-content: center;
       }  
</style>        
			           
			           
			          
		           
    			</div>
    		</div>
    	</div>
    </div>
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">
                    <div class="main-footer">
                        <h2 class="title1"><a href="index.html"><img src="image/logo-2.png"></a></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur repudiandae quisquam adipisci asperiores, ipsum ipsa repellat assumenda dolor perspiciatis.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-12">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Company</h2>
                            <div class="footer-widget">
                                  <ul>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/aboutview')); ?>">About</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="#">Blog</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">All Product</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Contact')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Service</h2>
                            <div class="footer-widget">
                                <ul>
                                  <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">Various Tour</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Visa')); ?>">Visa</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Passportinquire')); ?>">Passport Inquires</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                        <li><i class="fa fa-home" aria-hidden="true"></i>
                             <p> <?php echo e($address); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:websitename@mail.com"><?php echo e($email); ?></a></p>    
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                           <p><a href="tel:<?php echo nl2br(e($mobileno)); ?>"><?php echo nl2br(e($mobileno)); ?></a></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                 <span>Sobytour&travels Theme © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                    <li><a href="https://www.facebook.com/Soby-tour-and-travels-546125568809837/"><i class="fa fa-facebook-square"></i></a></li>
                    <li><a href="https://www.instagram.com/sobytourandtravels/"><i class="fa fa-instagram"></i></a></li>
            
                </ul>
            </div>
        </div>
        </div>
    </div>
    <a class="up-btn" href="#"></a>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script type="text/javascript">
    	 function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }

        $(function () {
            $(".radio1").slice(0, 4).show();
            $("body").on('click touchstart', '.filter-expand', function (e) {
                e.preventDefault();
                $(".radio1:hidden").slice(0, 3).slideDown();
                if ($(".radio1:hidden").length == 0) {
                    $(".filter-expand").css('visibility', 'hidden');
                }
            });
        });

        $("#slider").slider({
            range: true,
            max: 70,
            values: [0, 70],
            slide: function(event, ui) {
              var min = ui.values[0];
              var max = ui.values[1];
              $("[name=min]").val(min);
              $("[name=max]").val(max);
            }
        });
        
        var min = $("#slider").slider("values", 0);
        var max = $("#slider").slider("values", 1);
        $("[name=min]").val(min);
        $("[name=max]").val(max);

        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show'); 
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });

    </script>
</body>
</html><?php /**PATH /home/mzldwoswysm5/public_html/resources/views/tourlist.blade.php ENDPATH**/ ?>