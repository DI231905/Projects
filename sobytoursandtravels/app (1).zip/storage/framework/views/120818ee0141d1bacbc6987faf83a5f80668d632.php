<!DOCTYPE html>
<html>
<head>
	<title>TRAVEL AGENCY</title>
	<link rel="stylesheet" type="text/css" href="/css/Travel_about.css">
	<link rel="stylesheet" type="text/css" href="/css/Travel_header-footer.css">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="image/flaticon.png">
</head>
<body class="body">
	<div class="co_part-1">
        <div class="container fix-part-1">
            <div class="part-1">
                <a href="<?php echo e(url('/')); ?>"><img src="image/logo-2.png"></a>
            </div>
            <div class="menu1">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                <div class="dropdown hover">
                    <div class="menu">
                        <div class="package1">Packages</div>
                    </div>      
                    <ul class="submenu">
                        <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                        <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                    </ul>
                </div>
                <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
               <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
            </div>
            <div class="mobile-menu">
                <div id="mySidepanel" class="sidepanel">
                    <div class="m_menu">
                         <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-times" aria-hidden="true"></i></a>     
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <a href="<?php echo e(url('/aboutview')); ?>">About</a>
                        <div class="dropdown hover">
                            <div class="menu">
                                <a href="">Packages</a>
                            </div>      
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('/Domesticpackages')); ?>">Domestic Packages</a></li>
                                <li><a href="<?php echo e(url('/Internationalpackages')); ?>">International packages</a></li>
                            </ul>
                        </div>
                        <a href="<?php echo e(url('/Visa')); ?>">Visa</a>
                        <a href="<?php echo e(url('/Passportinquire')); ?>">Passport inquires</a>
                        <a href="<?php echo e(url('/Gallery')); ?>">Gallery</a>
                          <a href="<?php echo e(url('/Brochure')); ?>">Tour Brochure</a>
                        <a href="<?php echo e(url('/Contact')); ?>">Contact</a>
                    </div>
                </div>
              <button class="openbtn" onclick="openNav()"><i class="fa fa-bars" aria-hidden="true"></i></button>
            </div>
        </div>
    </div>	
    <div class="co_part-2">
    	<div class="fix-part-2">
    		<div class="img1">
    		    <img src="image/3.jpg">
    	    </div>
    	    <div class="about">
                <div class="container">
    		        <h2>About</h2>
    		        <ul type="none">
    			        <li>Home</li>
    			        <li><span class="fa fa-angle-right"></span></li>
    			        <li class="bt">About</li>
    		        </ul>
                </div>
    	    </div>
    	</div>
    </div>
    <div class="co_part-3">
    	<div class="container">
    		<div class="row row1">
    			<div class="box">
    				<div class="prg">
    				    <h2>Who We Are</h2>
    				    <p>Soby tour and travel mainly deal with the Domestic/International packages, E-visa, Tourist visa, 
student visa,and expert in making passport. 
Founder of Soby tour and Travels is Mr. Soyab saiyed who established the business in the 2013
Your complete satisfaction is only the first of our goals - we want your travel experience to be memorable in positive ways, 
and to expand and enrich your life as nothing else can.
</p>
			        </div>
			    </div>
			    <div class="box">
			    	<div class="inner-box">
			    		<img src="image/yacht.jpg">
			    		<div class="inner-box1">
			    			<img src="image/happy-friend.jpg">
			    		</div>
			    	</div>
			    </div>
		    </div>
		    <div class="row row1">
		    	<div class="box">
		    		<div class="set-box">
		    		    <img src="image/lonely-yacht.jpg">
		    		</div>
		    	</div>
		    	<div class="box">
		    		<div class="prg">
		    			<h2>Our Vision</h2>
		    			<p>Soby tour and travels seeks to enhance the corporate management tools to improve the service while reducing your travel costs.
                        We manage almost every type of travel needs, from simplest to the complex, and create an unparalleled experience that our customers could rely on. 
                        We also manage visa and passport services.
                        We aim to maintain our vision of high class travel services at reasonable prices through consistent leadership, controlled growth and excellent commitment.
				    </div>
			    </div>
		    </div>
	    </div>
    </div>
      <div class="co_Testimonial">
        <div class="container">
            <h5 class="title-about">Testimonial</h5>
            <h1 class="main-title">Our Client Say!</h1>
            <p class="prg1">Lorem ipsum dolor sit amet, consectetur blandit magna adipiscing elit ncididunt labore et dolore magna aliqua enim.</p>
            <div class="main">
                <div class="slider slider-nav">

                   <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="client-img">
                             <img src="/uploads/<?php echo e($t->image); ?>">
                        </div>
                        <div class="box-1">
                            <h1><?php echo e($t->name); ?></h1>
                            <h5 class="title-design"><?php echo e($t->occupation); ?></h5>
                            <p> <?php echo e($t->description); ?></p>
                        </div>
                    </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                   
                </div>
            </div>
        </div>
    </div>
    <div class="co_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12 footer-logo">
                    <div class="main-footer">
                        <h2 class="title1"><a href="index.html"><img src="image/logo-2.png"></a></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur repudiandae quisquam adipisci asperiores, ipsum ipsa repellat assumenda dolor perspiciatis.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-12">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Company</h2>
                            <div class="footer-widget">
                                <ul>
                                     <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/aboutview')); ?>">About</a></li>
                                
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">All Package</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Contact')); ?>">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <h2 class="title1">Service</h2>
                            <div class="footer-widget">
                                <ul>
                                   <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/tourlist')); ?>">Various Tour</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Visa')); ?>">Visa</a></li>
                                    <li><i class="fa fa-angle-right" aria-hidden="true"></i><a href="<?php echo e(url('/Passportinquire')); ?>">Passport Inquires</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12">
                    <h2 class="title1">Contact Us</h2>
                    <ul class="con-home">
                         <li><i class="fa fa-home" aria-hidden="true"></i>
                             <p> <?php echo e($address); ?></p>
                        </li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i>
                            <p><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>    
                        </li>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>
                            <p><a href="tel:<?php echo nl2br(e($mobileno)); ?>"><?php echo nl2br(e($mobileno)); ?></a></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="co_bottom">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-12 bm-1">
                <span>Sobytour&travels Theme © Copyright 2021. All rights reserved</span>
            </div>
            <div class="col-md-4 col-12 bm-1">
                <ul type="none">
                     <li><a href="https://www.facebook.com/Soby-tour-and-travels-546125568809837/"><i class="fa fa-facebook-square"></i></a></li>
                    <li><a href="https://www.instagram.com/sobytourandtravels/"><i class="fa fa-instagram"></i></a></li>
            
                </ul>
            </div>
        </div>
        </div>
    </div>
    <a class="up-btn" href="#"></a>




    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script type="text/javascript">
    	function openNav() {
            document.getElementById("mySidepanel").style.width = "100%";
        }
        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        } 


        var btn = $('.up-btn');
        $(window).scroll(function() {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show'); 
            }
            else {
                btn.removeClass('show');
            }
        });
        btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '300');
        });

        $('.slider-nav').slick({
            autoplay: true,
            autoplaySpeed: 1500,
            slidesToShow: 3,
            slidesToScroll: 1,
            dots: false,
            focusOnSelect: true,
            adaptiveHeight:true,
            responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            adaptiveHeight: true,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],

        });

        
    
    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\oratravel\resources\views/aboutview.blade.php ENDPATH**/ ?>