<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\uploadedFile;
use Illuminate\Support\Facades\Storage;
use DB;



class userController extends Controller

{
  
   public function index(){

      $package=DB::table('package_detail')->paginate(6);

        $data['package']= $package;

        $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      

    
       return view('welcome',$data); 

   }

   public function travel_search(Request $request){

    
       $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
    
    
$type=$request->type;
$service=$request->service;
$price=$request->price;

        
        if ($request->filled('search_keywords')) {
            $search_keywords = $request->search_keywords;
        }else{
            $search_keywords = "";
        }

//         $q=DB::table('package_detail')->orWhere(function ($query) use ($search_keywords) {
//             if($search_keywords!=''){
//                  $query->orWhere('tittle', 'like', '%'.$search_keywords.'%');
//             }
//        });
//          $q->where(function ($query) use ($c, $d) {
//      if($search_keywords!=''){
//                  $query->orWhere('tittle', 'like', '%'.$search_keywords.'%');
//             }
// });
//       $count= $q->count();

          $package=DB::table('package_detail')->Where('tittle', 'like', '%'.$search_keywords.'%')->Where('country', 'like', '%'.$search_keywords.'%')->Where('city', 'like', '%'.$search_keywords.'%')->count();

         
          if($package!=0){ 

             $package=DB::table('package_detail')->orWhere('tittle', 'like', '%'.$search_keywords.'%')->orWhere('country', 'like', '%'.$search_keywords.'%')->orWhere('city', 'like', '%'.$search_keywords.'%')->get();

             $data['package']=$package;
             return view('searchtour',$data);
 
     }else{
         
        

        return redirect()->back()->with('error','No Tour availble for this destination!!!' );
 
     }

}

    public function aboutview(){

      $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

      $testimonial=DB::table('testimonial')->get();

      $data['testimonial']=$testimonial;

      

     return view('aboutview',$data);
    }



   public function tourlist(){


     $package=DB::table('package_detail')->paginate(6);

      $data['package']= $package;

       $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      

      return view('tourlist',$data); 
    }

      public function indiantour(){

      $package=DB::table('package_detail')->where('package_type','Domestic Packages')->paginate(6);

      $data['package']= $package;

       $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      
      return view('indiantour',$data); 
    }

      public function internationaltour(){

      $package=DB::table('package_detail')->where('package_type','International Packages')->paginate(6);

        $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      

      $data['package']= $package;

      return view('internationaltour',$data); 
    }


   public function showcontact(){

        return redirect('/');
   
   }


    public function brochure(){

      $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

      $brochures=DB::table('brochures')->get();

      $data['brochures']=$brochures;
      return view('brochures',$data);
    }



   public function visapage(){

     $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      

     return view('visa',$data);
    }

     public function passportinquire(){

         $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;

     return view('passportinquire',$data);
    }

  public function Gallery(){

     $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
      

     return view('gallery',$data);
    }

     public function Contact(){

       $admindetail=DB::table('admincontactdetail')->where('id',3)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
    

     return view('contact',$data);
    }


    public function Visainquirefrom(Request $request){

        echo $request->input('name') ;
         echo $request->input('number');
          echo $request->input('email');
           echo $request->input('visatype');
            echo $request->input('description');
          
      $request->validate([

            'name' => 'required', 
            'number' => 'required',
            'email' => 'required|email',
            'visatype' => 'required',
            'description' => 'required',
        ]);

       DB::table('visainquires')->insert(['name'=>$request->input('name') ,'mobileno'=> $request->input('number'),'email'=> $request->input('email'),'visatype'=>$request->input('visatype'), 'mes'=>$request->input('description')]);
          

       return redirect()->back()->with('error','your inquire is submitted sucessfully !!!!' );   
      
    }

     public function usercontact(Request $request){

        $request->validate([

            'name' => 'required',
            'email' => 'required|email',
            'sub' => 'required',
            'description' => 'required',  

        ]);

           echo $request->input('name');
           echo $request->input('email');
           echo $request->input('sub');
           echo $request->input('description');

      
     


 DB::table('contact_us')->insert(['name'=>$request->input('name') ,'email'=> $request->input('email'),'subject'=>$request->input('sub'), 'description'=>$request->input('description')]);
          

       return redirect()->back()->with('error','your inquire is submitted sucessfully !!!!' );   
    
      
    }

    public function search(Request $request){

     $keyword=$request->input('keyword');
     echo $keyword;

    $country=DB::table('package_detail')->where('country',$keyword)->count();

       if($country){
   
                $package=DB::table('package_detail')->where('country',$keyword)->paginate(6);
                  $data['package']= $package; 
                   return view('tourlist',$data); 

                    }else{
                            $city=DB::table('package_detail')->where('city',$keyword)->count();

                              if($city){
                                 $package=DB::table('package_detail')->where('city',$keyword)->paginate(6);
                                 
                                    $data['package']= $package; 
                                    return view('tourlist',$data); 

                               }else{



                               }

                  
                    }


       }

   
   
  }  
