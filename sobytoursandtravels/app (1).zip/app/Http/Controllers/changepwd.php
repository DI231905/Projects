<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Redirect;
use App\Http\Controllers\Controller;
use Illuminate\support\facades\Auth;
use App\Models\Admin;
use Illuminate\support\MessageBag;
use Illuminate\Support\Facades\Mail;
use Illuminate\support\facades\Input;
use DB;
use Hash;

class changepwd extends Controller
{
 // 	public function __construct(){
 // 		$this->middleware('guest:admin')->except('logout');
	// }

	public function changepassword(){
      return view('admin.changepassword');
    } 
}
