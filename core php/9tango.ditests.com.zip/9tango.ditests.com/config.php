<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (DoughouzForest)
// | @author_url 1: http://www.quickdate.com
// | @author_url 2: http://codecanyon.net/user/doughouzforest
// | @author_email: wowondersocial@gmail.com
// +------------------------------------------------------------------------+
// | Quickdate - The Ultimate PHP Dating Platform
// | Copyright (c) 2018 Quickdate. All rights reserved.
// +------------------------------------------------------------------------+
// MySQL Hostname
$servername = "localhost";
// MySQL Database User
$dbusername = "9tango_user";
// MySQL Database Password
$dbpassword = "UC,StW]NTp7]";
// MySQL Database Name
$dbname = "9tango_db";

// Site URL
$site_url = "http://9tango.ditests.com"; // e.g (http://example.com)

$app = "QuickDating";
$endpoint_v = "v1";
$serverkey = "fe3f4a1a774d2360aed02188298b3950";

// Purchase code
$purchase_code = "b2c400ac-3688-4b88-a026-52c781670006"; // Your purchase code, don't give it to anyone.
?>