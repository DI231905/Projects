<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'taxmentor' );

/** Database username */
define( 'DB_USER', 'taxmentor_user' );

/** Database password */
define( 'DB_PASSWORD', 'H#n.UsYe}5;c' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ' wt(#g71q^x7+.C&PNh+4mOt5I~gb eZ,Hv9qtp#4H5Q{plv7XzI#H!I_Xo2NFy9' );
define( 'SECURE_AUTH_KEY',  'n6+]GP1D,]L$Nl+|oodTxi;^lz0uNo?L|Q0E)BzAhn}~Ywv=~/+@Q!jI$Xg8{ihH' );
define( 'LOGGED_IN_KEY',    'j<He*f)X[977. ,ce%&{l18O$j`b=4viS:JW+8meWSzr8T|+I}^9VpS2qo uc2+Q' );
define( 'NONCE_KEY',        '!!|9yWQRV^T;VVmrD^rWnV=6h0AI-(e!%AOL+,^;m]`Ih{0ry}IH<)Sj4Hl-;,OC' );
define( 'AUTH_SALT',        '`:p?133r^T|R$R,]jvj*f)|RA^^|SVoA%[Q-e@OfJ)w)i+Jg}V^o%0-%x/vWXjtV' );
define( 'SECURE_AUTH_SALT', '+w|gkgYDjEO4]yF|tokLfV $lWN}4ekRBtT`&__r0-0W8iIRBI~j;#cHhpIX@`i,' );
define( 'LOGGED_IN_SALT',   'B spZ#fB59-sj9ua)jdBW`%HH:eRggJUqR2amq|}&%m9ev4HvmGC9.E7`emfi.Cd' );
define( 'NONCE_SALT',       'lAdC`BQn#L@!u_yJ!7i1#iIqKv+1uO-&i<vJYwX[Cu {$hP]$AoRX[8C(8[8s?rs' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
