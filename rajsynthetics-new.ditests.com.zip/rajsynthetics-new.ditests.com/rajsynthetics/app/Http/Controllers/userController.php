<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class userController extends Controller
{
    
    public function index(){


      $country=DB::table('countries')->get();

        $data['country']= $country;


        $admindetail=DB::table('admincontact')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['address']=$admindetail[0]->address;
        $data['fb_url']=$admindetail[0]->fb_url;
         $data['india_mart_url']=$admindetail[0]->india_mart_url;

        $phone_no=DB::table('phone_no')->where('admin_id',1)->get();
        $data['phone_no']=$phone_no;


        return view('welcome',$data);
    }

     public function Aboutview(){

        $admindetail=DB::table('admincontact')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['address']=$admindetail[0]->address;
        $data['fb_url']=$admindetail[0]->fb_url;
        $data['india_mart_url']=$admindetail[0]->india_mart_url;

        $phone_no=DB::table('phone_no')->get();
        $data['phone_no']=$phone_no;


        return view('Aboutview',$data);
    }

  /*  public function appview(){
   
       $admindetail=DB::table('admincontact')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['mobileno']=$admindetail[0]->mobileno;
        $data['address']=$admindetail[0]->address;
     
         return view('app',$data);
    }*/

     public function Chemical(){


       $chemicaldproduct=DB::table('chemicaldproduct')->get();
       $data['chemicaldproduct']= $chemicaldproduct;

        $admindetail=DB::table('admincontact')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['address']=$admindetail[0]->address;
        $data['fb_url']=$admindetail[0]->fb_url;
        $data['india_mart_url']=$admindetail[0]->india_mart_url;

        $phone_no=DB::table('phone_no')->get();
        $data['phone_no']=$phone_no;

       return view('chemicalproduct',$data);

    }

       public function chemical_product_detail($id){

             $admindetail=DB::table('admincontact')->where('id',1)->get();
             $data['id']=$admindetail[0]->id;
             $data['name']=$admindetail[0]->name;
             $data['email']=$admindetail[0]->email;
             $data['address']=$admindetail[0]->address;
             $data['fb_url']=$admindetail[0]->fb_url;
             $data['india_mart_url']=$admindetail[0]->india_mart_url;

             $phone_no=DB::table('phone_no')->get();
             $data['phone_no']=$phone_no;

             $product= DB::table('chemicaldproduct')->where('id', $id)->get();
       
             $data['id']=$product[0]->id;
             $data['name']=$product[0]->name;
             $data['banner_image']=$product[0]->banner_image;
             $data['product_image']=$product[0]->product_image;
             $data['description']=$product[0]->description;

             return view('chemical_product_detail',$data);

        }
 


    public function Texttile(){

      $texttileproduct=DB::table('texttileproduct')->get();

       $data['texttileproduct']= $texttileproduct;

        $admindetail=DB::table('admincontact')->where('id',1)->get();

        $data['id']=$admindetail[0]->id;
        $data['name']=$admindetail[0]->name;
        $data['email']=$admindetail[0]->email;
        $data['address']=$admindetail[0]->address;
        $data['fb_url']=$admindetail[0]->fb_url;
        $data['india_mart_url']=$admindetail[0]->india_mart_url;

        $phone_no=DB::table('phone_no')->get();
        $data['phone_no']=$phone_no;


        return view('texttileproduct',$data);
    }

        public function textile_product_detail($id){

             $admindetail=DB::table('admincontact')->where('id',1)->get();
             $data['id']=$admindetail[0]->id;
             $data['name']=$admindetail[0]->name;
             $data['email']=$admindetail[0]->email;
             $data['address']=$admindetail[0]->address;
             $data['fb_url']=$admindetail[0]->fb_url;
             $data['india_mart_url']=$admindetail[0]->india_mart_url;

             $phone_no=DB::table('phone_no')->get();
             $data['phone_no']=$phone_no;

             $product= DB::table('texttileproduct')->where('id', $id)->get();
       
             $data['id']=$product[0]->id;
             $data['name']=$product[0]->name;
             $data['banner_image']=$product[0]->banner_image;
             $data['product_image']=$product[0]->product_image;
             $data['description']=$product[0]->description;

             return view('textile_product_detail',$data);

        }
 



     public function Careerview(){

           $admindetail=DB::table('admincontact')->where('id',1)->get();

         $data['id']=$admindetail[0]->id;
         $data['name']=$admindetail[0]->name;
         $data['email']=$admindetail[0]->email;
         $data['address']=$admindetail[0]->address;

        $data['fb_url']=$admindetail[0]->fb_url;
        $data['india_mart_url']=$admindetail[0]->india_mart_url;

        $phone_no=DB::table('phone_no')->get();
        $data['phone_no']=$phone_no;

        return view('career',$data);
    }
     public function Contactus(){

  $admindetail=DB::table('admincontact')->where('id',1)->get();
             $data['id']=$admindetail[0]->id;
             $data['name']=$admindetail[0]->name;
             $data['email']=$admindetail[0]->email;
             $data['address']=$admindetail[0]->address;
             $data['fb_url']=$admindetail[0]->fb_url;
             $data['india_mart_url']=$admindetail[0]->india_mart_url;

             $phone_no=DB::table('phone_no')->get();
             $data['phone_no']=$phone_no;

        return view('contactus',$data);
    }

     public function enquiryform(Request $request){

        $request->validate([

            'cname' => 'required',
            'email' => 'required|email',
            'pname' => 'required',
            'mobileno' => 'required',  
            'country' => 'required',  
            'subject' => 'required',  
            'details' => 'required',  


        ]);

            $cname=$request->input('cname');
            $pname= $request->input('pname');
            $email=$request->input('email');
            $mobileno=$request->input('mobileno');
            $subject=$request->input('subject');
            $details=$request->input('details');
         

          $country=DB::table('countries')->where('id', $request->input('country'))->get();
           
            $countryname=$country[0]->name;


       DB::table('enquiry')->insert(['cname'=>$cname,'pname'=> $pname,'email'=>$email,'mobileno'=> $mobileno, 'subject'=>$subject,'details'=>$details,'country'=>$countryname]);
          

       return redirect()->back()->with('error','your inquire was submitted sucessfully !!!!' );   
       
    }

      public function applicationform(Request $request){

        $request->validate([

            'name' => 'required',
            'email' => 'required',
            'position' => 'required',
            'mobileno' => 'required',     
            'mobileno' => 'required',  
            'experience' => 'required',  
            'description' => 'required',  


        ]);

            $name=$request->input('name');
            $position= $request->input('position');
            $email=$request->input('email');
            $mobileno=$request->input('mobileno');
            $experience=$request->input('experience');
            $description=$request->input('description');
      
         $file=$request->file('file');
         $resume=' ';

        if ($file) {
          
          $destinationPath='uploads';
          $resume=time().'_'.$file->getClientOriginalName();
          $file->move($destinationPath,$resume);
      
         }           
                
          
       DB::table('applicationform')->insert(['name'=>$name,'email'=>$email,'mobileno'=>$mobileno,'experience'=>$experience,'position'=>$position,'description'=>$description,'resume'=>$resume]);
          

       return redirect()->back()->with('error','your inquire was submitted sucessfully !!!!' );   
       
    }

    public function contactusfrom(Request $request){

        $request->validate([

            'name' => 'required',
            'email' => 'required|email',  
            'subject' => 'required',  
            'description' => 'required',  


        ]);

            $name=$request->input('name'); 
            $email=$request->input('email');
            $subject=$request->input('subject');
            $description=$request->input('description');


         DB::table('contact_us')->insert(['name'=>$name,'email'=>$email,'subject'=>$subject,'description'=>$description]);
          

       return redirect()->back()->with('error','your massage was submitted sucessfully !!!!' );


    }



}
